# db_migration.py
# Database Migration System with Version Control
# Created: 2026-01-08

import sqlite3
import os
import json
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class DatabaseMigration:
    """Database migration system with version control"""
    
    # Migration definitions: version -> (description, up_sql, down_sql)
    MIGRATIONS = {
        1: (
            "Initial schema - users and companies",
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TEXT,
                updated_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                name TEXT,
                type TEXT,
                company_type TEXT,
                address TEXT,
                city TEXT,
                country TEXT,
                phone TEXT,
                email TEXT,
                rfc TEXT,
                tax_id TEXT,
                bank_name TEXT,
                bank_account TEXT,
                clabe TEXT,
                created_at TEXT,
                updated_at TEXT
            );
            """,
            """
            DROP TABLE IF EXISTS users;
            DROP TABLE IF EXISTS companies;
            """
        ),
        
        2: (
            "Add ports and jobs tables",
            """
            CREATE TABLE IF NOT EXISTS ports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                name TEXT,
                city TEXT,
                country TEXT,
                type TEXT DEFAULT 'SEA',
                created_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_no TEXT UNIQUE,
                mode TEXT,
                customer TEXT,
                partner TEXT,
                carrier TEXT,
                shipper TEXT,
                consignee TEXT,
                notify TEXT,
                mbl TEXT,
                hbl TEXT,
                vessel TEXT,
                voyage TEXT,
                flight_no TEXT,
                pol TEXT,
                pod TEXT,
                etd TEXT,
                eta TEXT,
                atd TEXT,
                ata TEXT,
                status TEXT DEFAULT 'OPEN',
                remarks TEXT,
                truck_line TEXT,
                location TEXT,
                created_at TEXT,
                updated_at TEXT
            );
            """,
            """
            DROP TABLE IF EXISTS ports;
            DROP TABLE IF EXISTS jobs;
            """
        ),
        
        3: (
            "Add containers and cargo tables",
            """
            CREATE TABLE IF NOT EXISTS containers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                cntr_no TEXT,
                cntr_type TEXT,
                seal_no TEXT,
                pcs INTEGER,
                weight REAL,
                cbm REAL,
                location TEXT,
                status TEXT,
                FOREIGN KEY (job_id) REFERENCES jobs(id)
            );
            
            CREATE TABLE IF NOT EXISTS cargo_details (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                description TEXT,
                hs_code TEXT,
                pcs INTEGER,
                unit TEXT,
                weight REAL,
                cbm REAL,
                value REAL,
                currency TEXT DEFAULT 'USD',
                FOREIGN KEY (job_id) REFERENCES jobs(id)
            );
            """,
            """
            DROP TABLE IF EXISTS containers;
            DROP TABLE IF EXISTS cargo_details;
            """
        ),
        
        4: (
            "Add exchange rates table",
            """
            CREATE TABLE IF NOT EXISTS exchange_rates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                rate_date TEXT,
                from_currency TEXT DEFAULT 'USD',
                to_currency TEXT DEFAULT 'MXN',
                rate REAL,
                source TEXT,
                created_at TEXT,
                UNIQUE(rate_date, from_currency, to_currency)
            );
            """,
            """
            DROP TABLE IF EXISTS exchange_rates;
            """
        ),
        
        5: (
            "Add quotation tables",
            """
            CREATE TABLE IF NOT EXISTS quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quote_no TEXT UNIQUE NOT NULL,
                date TEXT,
                valid_until TEXT,
                customer_name TEXT,
                customer_code TEXT,
                revenue_total REAL DEFAULT 0,
                cost_total REAL DEFAULT 0,
                profit REAL DEFAULT 0,
                margin REAL DEFAULT 0,
                status TEXT DEFAULT 'DRAFT',
                notes TEXT,
                created_at TEXT,
                updated_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS quote_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quote_id INTEGER NOT NULL,
                item_type TEXT DEFAULT 'revenue',
                vendor TEXT,
                description TEXT,
                qty REAL DEFAULT 1,
                unit TEXT DEFAULT 'EA',
                rate REAL DEFAULT 0,
                amount REAL DEFAULT 0,
                FOREIGN KEY (quote_id) REFERENCES quotes(id)
            );
            
            CREATE TABLE IF NOT EXISTS quote_vendor_quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quote_id INTEGER NOT NULL,
                vendor_name TEXT,
                service_type TEXT,
                rate REAL DEFAULT 0,
                currency TEXT DEFAULT 'USD',
                validity TEXT,
                remarks TEXT,
                is_selected INTEGER DEFAULT 0,
                created_at TEXT,
                FOREIGN KEY (quote_id) REFERENCES quotes(id)
            );
            """,
            """
            DROP TABLE IF EXISTS quote_vendor_quotes;
            DROP TABLE IF EXISTS quote_items;
            DROP TABLE IF EXISTS quotes;
            """
        ),
        
        6: (
            "Add settlements and invoices tables",
            """
            CREATE TABLE IF NOT EXISTS invoices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_no TEXT UNIQUE,
                job_id INTEGER,
                job_no TEXT,
                invoice_type TEXT DEFAULT 'REVENUE',
                customer_code TEXT,
                customer_name TEXT,
                currency TEXT DEFAULT 'USD',
                subtotal REAL DEFAULT 0,
                tax REAL DEFAULT 0,
                total REAL DEFAULT 0,
                status TEXT DEFAULT 'DRAFT',
                invoice_date TEXT,
                due_date TEXT,
                paid_date TEXT,
                notes TEXT,
                created_at TEXT,
                updated_at TEXT,
                FOREIGN KEY (job_id) REFERENCES jobs(id)
            );
            
            CREATE TABLE IF NOT EXISTS invoice_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id INTEGER,
                charge_code TEXT,
                description TEXT,
                qty REAL DEFAULT 1,
                unit TEXT DEFAULT 'EA',
                unit_price REAL DEFAULT 0,
                amount REAL DEFAULT 0,
                tax_rate REAL DEFAULT 0,
                tax_amount REAL DEFAULT 0,
                FOREIGN KEY (invoice_id) REFERENCES invoices(id)
            );
            """,
            """
            DROP TABLE IF EXISTS invoice_items;
            DROP TABLE IF EXISTS invoices;
            """
        ),
        
        7: (
            "Add freight rates and charge codes",
            """
            CREATE TABLE IF NOT EXISTS freight_rates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                carrier TEXT,
                pol TEXT,
                pod TEXT,
                mode TEXT,
                container_type TEXT,
                rate REAL,
                currency TEXT DEFAULT 'USD',
                valid_from TEXT,
                valid_to TEXT,
                remarks TEXT,
                created_at TEXT,
                updated_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS charge_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                name_en TEXT,
                name_es TEXT,
                name_ko TEXT,
                category TEXT,
                default_rate REAL,
                currency TEXT DEFAULT 'USD',
                is_taxable INTEGER DEFAULT 1,
                created_at TEXT
            );
            """,
            """
            DROP TABLE IF EXISTS freight_rates;
            DROP TABLE IF EXISTS charge_codes;
            """
        ),
        
        8: (
            "Add company_info and branches",
            """
            CREATE TABLE IF NOT EXISTS company_info (
                id INTEGER PRIMARY KEY,
                company_name TEXT,
                rfc TEXT,
                regimen_fiscal TEXT,
                address TEXT,
                city TEXT,
                state TEXT,
                zip_code TEXT,
                country TEXT,
                phone TEXT,
                email TEXT,
                website TEXT,
                bank_name TEXT,
                bank_account TEXT,
                clabe TEXT,
                usd_clabe TEXT,
                logo_path TEXT,
                updated_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS branches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                name TEXT,
                address TEXT,
                city TEXT,
                state TEXT,
                phone TEXT,
                email TEXT,
                manager TEXT,
                is_active INTEGER DEFAULT 1,
                created_at TEXT
            );
            """,
            """
            DROP TABLE IF EXISTS company_info;
            DROP TABLE IF EXISTS branches;
            """
        ),
        
        9: (
            "Add user preferences and settings",
            """
            CREATE TABLE IF NOT EXISTS user_preferences (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                preference_key TEXT,
                preference_value TEXT,
                UNIQUE(user_id, preference_key),
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
            
            CREATE TABLE IF NOT EXISTS app_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                setting_key TEXT UNIQUE,
                setting_value TEXT,
                setting_type TEXT DEFAULT 'string',
                updated_at TEXT
            );
            """,
            """
            DROP TABLE IF EXISTS user_preferences;
            DROP TABLE IF EXISTS app_settings;
            """
        ),
        
        10: (
            "Add indexes for performance",
            """
            CREATE INDEX IF NOT EXISTS idx_jobs_job_no ON jobs(job_no);
            CREATE INDEX IF NOT EXISTS idx_jobs_customer ON jobs(customer);
            CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
            CREATE INDEX IF NOT EXISTS idx_jobs_etd ON jobs(etd);
            CREATE INDEX IF NOT EXISTS idx_jobs_mode ON jobs(mode);
            CREATE INDEX IF NOT EXISTS idx_containers_job_id ON containers(job_id);
            CREATE INDEX IF NOT EXISTS idx_invoices_job_id ON invoices(job_id);
            CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
            CREATE INDEX IF NOT EXISTS idx_exchange_rates_date ON exchange_rates(rate_date);
            """,
            """
            DROP INDEX IF EXISTS idx_jobs_job_no;
            DROP INDEX IF EXISTS idx_jobs_customer;
            DROP INDEX IF EXISTS idx_jobs_status;
            DROP INDEX IF EXISTS idx_jobs_etd;
            DROP INDEX IF EXISTS idx_jobs_mode;
            DROP INDEX IF EXISTS idx_containers_job_id;
            DROP INDEX IF EXISTS idx_invoices_job_id;
            DROP INDEX IF EXISTS idx_invoices_status;
            DROP INDEX IF EXISTS idx_exchange_rates_date;
            """
        ),
    }
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ensure_migration_table()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get database connection"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _ensure_migration_table(self):
        """Ensure migrations tracking table exists"""
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    version INTEGER UNIQUE NOT NULL,
                    description TEXT,
                    applied_at TEXT,
                    checksum TEXT
                )
            """)
            conn.commit()
        finally:
            conn.close()
    
    def get_current_version(self) -> int:
        """Get current schema version"""
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT MAX(version) FROM schema_migrations")
            row = cur.fetchone()
            return row[0] if row and row[0] else 0
        except:
            return 0
        finally:
            conn.close()
    
    def get_applied_migrations(self) -> List[Dict]:
        """Get list of applied migrations"""
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT version, description, applied_at FROM schema_migrations ORDER BY version")
            return [dict(row) for row in cur.fetchall()]
        except:
            return []
        finally:
            conn.close()
    
    def get_pending_migrations(self) -> List[Tuple[int, str]]:
        """Get list of pending migrations"""
        current = self.get_current_version()
        pending = []
        for version in sorted(self.MIGRATIONS.keys()):
            if version > current:
                desc, _, _ = self.MIGRATIONS[version]
                pending.append((version, desc))
        return pending
    
    def migrate_up(self, target_version: Optional[int] = None) -> List[int]:
        """Run migrations up to target version (or latest)"""
        current = self.get_current_version()
        target = target_version or max(self.MIGRATIONS.keys())
        
        applied = []
        for version in sorted(self.MIGRATIONS.keys()):
            if version > current and version <= target:
                self._apply_migration(version)
                applied.append(version)
        
        return applied
    
    def migrate_down(self, target_version: int) -> List[int]:
        """Rollback migrations down to target version"""
        current = self.get_current_version()
        
        rolled_back = []
        for version in sorted(self.MIGRATIONS.keys(), reverse=True):
            if version <= current and version > target:
                self._rollback_migration(version)
                rolled_back.append(version)
        
        return rolled_back
    
    def _apply_migration(self, version: int):
        """Apply a single migration"""
        if version not in self.MIGRATIONS:
            raise ValueError(f"Migration version {version} not found")
        
        desc, up_sql, _ = self.MIGRATIONS[version]
        
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            # Execute migration SQL
            cur.executescript(up_sql)
            
            # Record migration
            cur.execute("""
                INSERT INTO schema_migrations (version, description, applied_at, checksum)
                VALUES (?, ?, ?, ?)
            """, (version, desc, datetime.now().isoformat(), self._checksum(up_sql)))
            
            conn.commit()
            logger.info(f"Applied migration v{version}: {desc}")
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to apply migration v{version}: {e}")
            raise
        finally:
            conn.close()
    
    def _rollback_migration(self, version: int):
        """Rollback a single migration"""
        if version not in self.MIGRATIONS:
            raise ValueError(f"Migration version {version} not found")
        
        desc, _, down_sql = self.MIGRATIONS[version]
        
        conn = self._get_connection()
        cur = conn.cursor()
        try:
            # Execute rollback SQL
            cur.executescript(down_sql)
            
            # Remove migration record
            cur.execute("DELETE FROM schema_migrations WHERE version = ?", (version,))
            
            conn.commit()
            logger.info(f"Rolled back migration v{version}: {desc}")
        except Exception as e:
            conn.rollback()
            logger.error(f"Failed to rollback migration v{version}: {e}")
            raise
        finally:
            conn.close()
    
    def _checksum(self, sql: str) -> str:
        """Generate checksum for SQL"""
        import hashlib
        return hashlib.md5(sql.encode()).hexdigest()[:8]
    
    def verify_schema(self) -> Dict:
        """Verify schema integrity"""
        conn = self._get_connection()
        cur = conn.cursor()
        result = {
            "current_version": self.get_current_version(),
            "latest_version": max(self.MIGRATIONS.keys()),
            "pending_count": len(self.get_pending_migrations()),
            "tables": [],
            "issues": []
        }
        
        try:
            # List all tables
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            result["tables"] = [row[0] for row in cur.fetchall()]
            
            # Check for missing core tables
            core_tables = ["users", "companies", "jobs", "ports"]
            for table in core_tables:
                if table not in result["tables"]:
                    result["issues"].append(f"Missing core table: {table}")
            
        except Exception as e:
            result["issues"].append(f"Schema check error: {e}")
        finally:
            conn.close()
        
        return result


def run_migrations(db_path: str = None):
    """CLI function to run migrations"""
    if db_path is None:
        config_dir = os.path.join(os.path.expanduser("~"), ".duruduru")
        db_path = os.path.join(config_dir, "duruduru.db")
    
    migration = DatabaseMigration(db_path)
    
    print(f"Database: {db_path}")
    print(f"Current version: {migration.get_current_version()}")
    print(f"Latest version: {max(migration.MIGRATIONS.keys())}")
    print()
    
    pending = migration.get_pending_migrations()
    if pending:
        print(f"Pending migrations ({len(pending)}):")
        for version, desc in pending:
            print(f"  v{version}: {desc}")
        print()
        
        response = input("Apply pending migrations? [y/N]: ")
        if response.lower() == 'y':
            applied = migration.migrate_up()
            print(f"Applied {len(applied)} migration(s)")
    else:
        print("Database is up to date.")
    
    # Verify schema
    result = migration.verify_schema()
    if result["issues"]:
        print("\nSchema issues found:")
        for issue in result["issues"]:
            print(f"  - {issue}")


if __name__ == "__main__":
    run_migrations()
