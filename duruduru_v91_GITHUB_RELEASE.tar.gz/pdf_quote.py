# pdf_quote.py
# PDF Quote Export Module
# Created: 2026-01-08

import os
from datetime import datetime
from typing import Dict, List, Optional
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT


class QuotePDFExporter:
    """Export quotations to PDF format"""
    
    def __init__(self, company_info: Dict = None):
        self.company_info = company_info or {}
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='QuoteTitle',
            parent=self.styles['Heading1'],
            fontSize=20,
            textColor=colors.HexColor('#1565C0'),
            spaceAfter=20,
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=12,
            textColor=colors.HexColor('#333333'),
            spaceBefore=15,
            spaceAfter=8,
            borderPadding=5,
            backColor=colors.HexColor('#E3F2FD')
        ))
        
        self.styles.add(ParagraphStyle(
            name='CompanyName',
            parent=self.styles['Normal'],
            fontSize=16,
            textColor=colors.HexColor('#1565C0'),
            spaceAfter=5,
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='CompanyInfo',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#666666'),
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='TableHeader',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.white,
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='TotalLabel',
            parent=self.styles['Normal'],
            fontSize=11,
            textColor=colors.HexColor('#333333'),
            alignment=TA_RIGHT
        ))
        
        self.styles.add(ParagraphStyle(
            name='TotalAmount',
            parent=self.styles['Normal'],
            fontSize=12,
            textColor=colors.HexColor('#1565C0'),
            fontName='Helvetica-Bold',
            alignment=TA_RIGHT
        ))
        
        self.styles.add(ParagraphStyle(
            name='Footer',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.HexColor('#999999'),
            alignment=TA_CENTER
        ))
    
    def export(self, quote_data: Dict, output_path: str, include_costs: bool = False) -> str:
        """
        Export quote to PDF
        
        Args:
            quote_data: Quote information dictionary
            output_path: Output file path
            include_costs: Whether to include cost breakdown (internal use)
        
        Returns:
            Path to generated PDF
        """
        doc = SimpleDocTemplate(
            output_path,
            pagesize=letter,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=0.75*inch,
            bottomMargin=0.75*inch
        )
        
        elements = []
        
        # Header with company info
        elements.extend(self._build_header(quote_data))
        
        # Quote info section
        elements.extend(self._build_quote_info(quote_data))
        
        # Customer info
        elements.extend(self._build_customer_section(quote_data))
        
        # Items table (revenue only for customer quote)
        elements.extend(self._build_items_table(quote_data, include_costs))
        
        # Totals
        elements.extend(self._build_totals(quote_data, include_costs))
        
        # Terms and conditions
        elements.extend(self._build_terms(quote_data))
        
        # Footer
        elements.extend(self._build_footer(quote_data))
        
        # Build PDF
        doc.build(elements)
        
        return output_path
    
    def _build_header(self, quote_data: Dict) -> List:
        """Build header section with company info and logo"""
        elements = []
        
        # Logo (if exists)
        logo_path = self.company_info.get('logo_path')
        if logo_path and os.path.exists(logo_path):
            try:
                logo = Image(logo_path, width=1.5*inch, height=0.75*inch)
                elements.append(logo)
            except:
                pass
        
        # Company name
        company_name = self.company_info.get('company_name', 'DURUDURU Freight Forwarding')
        elements.append(Paragraph(company_name, self.styles['CompanyName']))
        
        # Company details
        address_parts = []
        if self.company_info.get('address'):
            address_parts.append(self.company_info['address'])
        if self.company_info.get('city'):
            address_parts.append(self.company_info['city'])
        if self.company_info.get('country'):
            address_parts.append(self.company_info['country'])
        
        if address_parts:
            elements.append(Paragraph(', '.join(address_parts), self.styles['CompanyInfo']))
        
        contact_parts = []
        if self.company_info.get('phone'):
            contact_parts.append(f"Tel: {self.company_info['phone']}")
        if self.company_info.get('email'):
            contact_parts.append(f"Email: {self.company_info['email']}")
        
        if contact_parts:
            elements.append(Paragraph(' | '.join(contact_parts), self.styles['CompanyInfo']))
        
        if self.company_info.get('rfc'):
            elements.append(Paragraph(f"RFC: {self.company_info['rfc']}", self.styles['CompanyInfo']))
        
        elements.append(Spacer(1, 20))
        
        # Title
        elements.append(Paragraph("QUOTATION / COTIZACIÓN", self.styles['QuoteTitle']))
        
        return elements
    
    def _build_quote_info(self, quote_data: Dict) -> List:
        """Build quote information section"""
        elements = []
        
        # Quote details table
        data = [
            ['Quote No:', quote_data.get('quote_no', ''), 'Date:', quote_data.get('date', '')],
            ['Valid Until:', quote_data.get('valid_until', ''), 'Status:', quote_data.get('status', 'DRAFT')],
        ]
        
        table = Table(data, colWidths=[1.2*inch, 2*inch, 1.2*inch, 2*inch])
        table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#666666')),
            ('TEXTCOLOR', (2, 0), (2, -1), colors.HexColor('#666666')),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _build_customer_section(self, quote_data: Dict) -> List:
        """Build customer information section"""
        elements = []
        
        elements.append(Paragraph("Customer Information / Información del Cliente", 
                                  self.styles['SectionHeader']))
        
        customer_name = quote_data.get('customer_name', '')
        customer_code = quote_data.get('customer_code', '')
        
        data = [
            ['Customer:', f"{customer_name} ({customer_code})" if customer_code else customer_name],
        ]
        
        # Add route info if available
        if quote_data.get('pol') and quote_data.get('pod'):
            data.append(['Route:', f"{quote_data['pol']} → {quote_data['pod']}"])
        
        if quote_data.get('mode'):
            data.append(['Mode:', quote_data['mode']])
        
        table = Table(data, colWidths=[1.5*inch, 5*inch])
        table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#666666')),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _build_items_table(self, quote_data: Dict, include_costs: bool = False) -> List:
        """Build items table"""
        elements = []
        
        # Revenue items
        elements.append(Paragraph("Charges / Cargos", self.styles['SectionHeader']))
        
        revenue_items = quote_data.get('revenue_items', [])
        
        # Table header
        header = ['#', 'Description / Descripción', 'Qty', 'Unit', 'Rate', 'Amount']
        data = [header]
        
        for i, item in enumerate(revenue_items, 1):
            row = [
                str(i),
                item.get('description', ''),
                str(item.get('qty', 1)),
                item.get('unit', 'EA'),
                f"${item.get('rate', 0):,.2f}",
                f"${item.get('amount', 0):,.2f}"
            ]
            data.append(row)
        
        if not revenue_items:
            data.append(['', 'No items', '', '', '', ''])
        
        col_widths = [0.4*inch, 3*inch, 0.6*inch, 0.6*inch, 1*inch, 1*inch]
        table = Table(data, colWidths=col_widths)
        table.setStyle(TableStyle([
            # Header style
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1565C0')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # Data rows
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('ALIGN', (0, 1), (0, -1), 'CENTER'),  # #
            ('ALIGN', (2, 1), (2, -1), 'CENTER'),  # Qty
            ('ALIGN', (3, 1), (3, -1), 'CENTER'),  # Unit
            ('ALIGN', (4, 1), (-1, -1), 'RIGHT'),  # Rate, Amount
            
            # Borders
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CCCCCC')),
            
            # Alternating row colors
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F5F5F5')]),
            
            # Padding
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        # Cost breakdown (if internal)
        if include_costs and quote_data.get('cost_items'):
            elements.append(Paragraph("Cost Breakdown (Internal) / Desglose de Costos", 
                                      self.styles['SectionHeader']))
            
            cost_items = quote_data.get('cost_items', [])
            header = ['#', 'Vendor', 'Description', 'Qty', 'Rate', 'Amount']
            data = [header]
            
            for i, item in enumerate(cost_items, 1):
                row = [
                    str(i),
                    item.get('vendor', ''),
                    item.get('description', ''),
                    str(item.get('qty', 1)),
                    f"${item.get('rate', 0):,.2f}",
                    f"${item.get('amount', 0):,.2f}"
                ]
                data.append(row)
            
            col_widths = [0.4*inch, 1.2*inch, 2.2*inch, 0.5*inch, 1*inch, 1*inch]
            table = Table(data, colWidths=col_widths)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#FF9800')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CCCCCC')),
                ('ALIGN', (4, 1), (-1, -1), 'RIGHT'),
                ('TOPPADDING', (0, 0), (-1, -1), 5),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ]))
            
            elements.append(table)
            elements.append(Spacer(1, 10))
        
        return elements
    
    def _build_totals(self, quote_data: Dict, include_costs: bool = False) -> List:
        """Build totals section"""
        elements = []
        
        revenue_total = quote_data.get('revenue_total', 0)
        
        # Totals table
        data = []
        
        if include_costs:
            cost_total = quote_data.get('cost_total', 0)
            profit = quote_data.get('profit', revenue_total - cost_total)
            margin = quote_data.get('margin', (profit / revenue_total * 100) if revenue_total else 0)
            
            data = [
                ['Revenue Total:', f"${revenue_total:,.2f}"],
                ['Cost Total:', f"${cost_total:,.2f}"],
                ['Profit:', f"${profit:,.2f}"],
                ['Margin:', f"{margin:.1f}%"],
            ]
        else:
            data = [
                ['Total:', f"${revenue_total:,.2f} USD"],
            ]
        
        table = Table(data, colWidths=[4.5*inch, 2*inch])
        
        style_commands = [
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 11),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#666666')),
            ('TEXTCOLOR', (1, -1), (1, -1), colors.HexColor('#1565C0')),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]
        
        if include_costs:
            # Highlight profit row
            style_commands.append(('TEXTCOLOR', (1, 2), (1, 2), colors.HexColor('#4CAF50')))
        
        # Last row highlight
        style_commands.extend([
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#E3F2FD')),
            ('FONTSIZE', (0, -1), (-1, -1), 12),
        ])
        
        table.setStyle(TableStyle(style_commands))
        
        elements.append(table)
        elements.append(Spacer(1, 20))
        
        return elements
    
    def _build_terms(self, quote_data: Dict) -> List:
        """Build terms and conditions section"""
        elements = []
        
        elements.append(Paragraph("Terms & Conditions / Términos y Condiciones", 
                                  self.styles['SectionHeader']))
        
        terms = quote_data.get('terms', [
            "• This quotation is valid until the date specified above.",
            "• Rates are subject to space availability and carrier confirmation.",
            "• Final charges may vary based on actual weight/volume.",
            "• Payment terms: Net 30 days from invoice date.",
            "• All charges are in USD unless otherwise specified.",
        ])
        
        for term in terms:
            elements.append(Paragraph(term, self.styles['Normal']))
        
        elements.append(Spacer(1, 15))
        
        # Notes
        if quote_data.get('notes'):
            elements.append(Paragraph("Notes / Notas:", self.styles['SectionHeader']))
            elements.append(Paragraph(quote_data['notes'], self.styles['Normal']))
            elements.append(Spacer(1, 15))
        
        return elements
    
    def _build_footer(self, quote_data: Dict) -> List:
        """Build footer section"""
        elements = []
        
        elements.append(Spacer(1, 30))
        
        # Signature area
        sig_data = [
            ['_' * 30, '', '_' * 30],
            ['Prepared by / Preparado por', '', 'Accepted by / Aceptado por'],
            ['Date / Fecha: _____________', '', 'Date / Fecha: _____________'],
        ]
        
        table = Table(sig_data, colWidths=[2.5*inch, 1.5*inch, 2.5*inch])
        table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 20))
        
        # Footer text
        footer_text = f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M')} | DURUDURU Freight System"
        elements.append(Paragraph(footer_text, self.styles['Footer']))
        
        return elements


def export_quote_to_pdf(quote_id: int, output_dir: str = None, include_costs: bool = False) -> Optional[str]:
    """
    Export a quote to PDF by ID
    
    Args:
        quote_id: Quote ID in database
        output_dir: Output directory (defaults to user's Downloads)
        include_costs: Include cost breakdown (for internal use)
    
    Returns:
        Path to generated PDF or None if failed
    """
    from db import get_connection
    
    if output_dir is None:
        output_dir = os.path.join(os.path.expanduser("~"), "Downloads")
    
    os.makedirs(output_dir, exist_ok=True)
    
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        # Get quote data
        cur.execute("""
            SELECT quote_no, date, valid_until, customer_name, customer_code,
                   revenue_total, cost_total, profit, margin, status, notes
            FROM quotes WHERE id = ?
        """, (quote_id,))
        quote_row = cur.fetchone()
        
        if not quote_row:
            return None
        
        quote_data = {
            'quote_no': quote_row[0],
            'date': quote_row[1],
            'valid_until': quote_row[2],
            'customer_name': quote_row[3],
            'customer_code': quote_row[4],
            'revenue_total': quote_row[5] or 0,
            'cost_total': quote_row[6] or 0,
            'profit': quote_row[7] or 0,
            'margin': quote_row[8] or 0,
            'status': quote_row[9],
            'notes': quote_row[10],
            'revenue_items': [],
            'cost_items': [],
        }
        
        # Get revenue items
        cur.execute("""
            SELECT description, qty, unit, rate, amount
            FROM quote_items WHERE quote_id = ? AND item_type = 'revenue'
        """, (quote_id,))
        for row in cur.fetchall():
            quote_data['revenue_items'].append({
                'description': row[0],
                'qty': row[1],
                'unit': row[2],
                'rate': row[3],
                'amount': row[4],
            })
        
        # Get cost items
        cur.execute("""
            SELECT vendor, description, qty, unit, rate, amount
            FROM quote_items WHERE quote_id = ? AND item_type = 'cost'
        """, (quote_id,))
        for row in cur.fetchall():
            quote_data['cost_items'].append({
                'vendor': row[0],
                'description': row[1],
                'qty': row[2],
                'unit': row[3],
                'rate': row[4],
                'amount': row[5],
            })
        
        # Get company info
        cur.execute("SELECT * FROM company_info WHERE id = 1")
        company_row = cur.fetchone()
        company_info = {}
        if company_row:
            company_info = dict(company_row)
        
        # Generate PDF
        output_path = os.path.join(output_dir, f"Quote_{quote_data['quote_no']}.pdf")
        
        exporter = QuotePDFExporter(company_info)
        return exporter.export(quote_data, output_path, include_costs)
        
    except Exception as e:
        print(f"Export failed: {e}")
        return None
    finally:
        conn.close()
