# ui_order_reg.py
# Registration Frames with T/S, Cargo detail with L×W×H→CBM auto-calc, Quote Ref search

import customtkinter as ctk
import datetime
from tkinter import messagebox
from tkinter import ttk
import tkinter as tk
import platform

# =============================================================================
# I18N IMPORT
# =============================================================================
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"

# Import centralized utilities
from utils import (
    get_connection, now_str,
    fetch_customers_for_combo, fetch_shippers_for_combo, execute_query
)
from theme import get_theme, Icons

# Import unified config
try:
    from config import COLORS, FONTS, SIZES, SPACING
except ImportError:
    class COLORS:
        PRIMARY = "#1565C0"
        SUCCESS = "#059669"
        ERROR = "#DC2626"
        TEXT_PRIMARY = "#212121"
        BACKGROUND = "#F5F5F5"
        SURFACE = "#FFFFFF"
        BORDER = "#E0E0E0"

try:
    from tkcalendar import Calendar
    HAS_CALENDAR = True
except ImportError:
    HAS_CALENDAR = False


def get_mod_key():
    return "Command" if platform.system() == "Darwin" else "Control"


def fetch_carriers_for_combo(carrier_type=None):
    """Fetch carriers from companies table by type"""
    if carrier_type:
        return execute_query(
            "SELECT code, name FROM companies WHERE type=? ORDER BY code",
            (carrier_type,)
        ) or []
    else:
        return execute_query(
            "SELECT code, name FROM companies WHERE type IN ('Shipping Line', 'Airline', 'Trucker', 'Forwarder') ORDER BY code"
        ) or []


def fetch_shipping_lines():
    """Fetch shipping line carriers"""
    return fetch_carriers_for_combo("Shipping Line")


def fetch_airlines():
    """Fetch airline carriers"""
    return fetch_carriers_for_combo("Airline")


def fetch_truckers():
    """Fetch trucker carriers"""
    return fetch_carriers_for_combo("Trucker")


def fetch_forwarders():
    """Fetch forwarder partners"""
    return fetch_carriers_for_combo("Forwarder")


def fetch_sea_ports_for_combo():
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("SELECT code, name, city, country FROM ports WHERE type='SEA' ORDER BY code")
        results = cur.fetchall()
    except:
        pass
    finally:
        conn.close()
    return results


def fetch_air_ports_for_combo():
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("SELECT code, name, city, country FROM ports WHERE type='AIR' ORDER BY code")
        results = cur.fetchall()
    except:
        pass
    finally:
        conn.close()
    return results


def fetch_land_ports_for_combo():
    """Fetch land ports/cities for truck routing"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        # First try LAND type ports
        cur.execute("SELECT code, name, city, country FROM ports WHERE type='LAND' ORDER BY code")
        results = cur.fetchall()
        
        # If no LAND ports, get all ports (cities can be used for trucking)
        if not results:
            cur.execute("SELECT code, name, city, country FROM ports ORDER BY country, city")
            results = cur.fetchall()
        
        # Also include common Mexican cities if not in ports table
        if not results:
            # Return common Mexican cities as default
            results = [
                ("MXMEX", "Mexico City", "Mexico City", "Mexico"),
                ("MXGDL", "Guadalajara", "Guadalajara", "Mexico"),
                ("MXMTY", "Monterrey", "Monterrey", "Mexico"),
                ("MXVER", "Veracruz", "Veracruz", "Mexico"),
                ("MXMAN", "Manzanillo", "Manzanillo", "Mexico"),
                ("MXLZC", "Lazaro Cardenas", "Lazaro Cardenas", "Mexico"),
                ("MXPVR", "Puerto Vallarta", "Puerto Vallarta", "Mexico"),
                ("MXTIJ", "Tijuana", "Tijuana", "Mexico"),
                ("MXCUN", "Cancun", "Cancun", "Mexico"),
                ("MXPBC", "Puebla", "Puebla", "Mexico"),
                ("MXQUE", "Queretaro", "Queretaro", "Mexico"),
                ("MXSLP", "San Luis Potosi", "San Luis Potosi", "Mexico"),
                ("MXAGU", "Aguascalientes", "Aguascalientes", "Mexico"),
                ("MXLEO", "Leon", "Leon", "Mexico"),
                ("MXCJS", "Ciudad Juarez", "Ciudad Juarez", "Mexico"),
            ]
    except:
        pass
    finally:
        conn.close()
    return results


def check_hbl_duplicate(hbl, exclude_job_id=None):
    if not hbl or not hbl.strip():
        return False
    conn = get_connection()
    cur = conn.cursor()
    try:
        if exclude_job_id:
            cur.execute("SELECT COUNT(*) FROM jobs WHERE hbl = ? AND id != ?", (hbl.strip(), exclude_job_id))
        else:
            cur.execute("SELECT COUNT(*) FROM jobs WHERE hbl = ?", (hbl.strip(),))
        count = cur.fetchone()[0]
        return count > 0
    except:
        return False
    finally:
        conn.close()


def search_quote_ref(parent, entry_widget):
    """Open Quote Ref search dialog"""
    dialog = ctk.CTkToplevel(parent)
    dialog.title("🔍 Search Quote Ref")
    dialog.geometry("600x400")
    dialog.transient(parent)
    dialog.grab_set()
    
    # Search frame
    search_frame = ctk.CTkFrame(dialog, fg_color="transparent")
    search_frame.pack(fill="x", padx=10, pady=10)
    
    ctk.CTkLabel(search_frame, text="Search:").pack(side="left", padx=5)
    search_var = tk.StringVar()
    search_entry = ctk.CTkEntry(search_frame, textvariable=search_var, width=200)
    search_entry.pack(side="left", padx=5)
    
    # Results tree
    tree_frame = ctk.CTkFrame(dialog)
    tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
    
    columns = ("quote_no", "customer", "pol", "pod", "date")
    tree = ttk.Treeview(tree_frame, columns=columns, show="headings", height=12)
    tree.heading("quote_no", text="Quote No")
    tree.heading("customer", text="Customer")
    tree.heading("pol", text="POL/AOL")
    tree.heading("pod", text="POD/AOD")
    tree.heading("date", text="Date")
    tree.column("quote_no", width=120)
    tree.column("customer", width=150)
    tree.column("pol", width=80)
    tree.column("pod", width=80)
    tree.column("date", width=100)
    
    scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    tree.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    def load_quotes(filter_text=""):
        tree.delete(*tree.get_children())
        conn = get_connection()
        cur = conn.cursor()
        try:
            if filter_text:
                cur.execute("""SELECT quote_no, customer, pol, pod, created_at FROM quotes 
                              WHERE quote_no LIKE ? OR customer LIKE ? 
                              ORDER BY created_at DESC LIMIT 50""", 
                           (f"%{filter_text}%", f"%{filter_text}%"))
            else:
                cur.execute("SELECT quote_no, customer, pol, pod, created_at FROM quotes ORDER BY created_at DESC LIMIT 50")
            for row in cur.fetchall():
                tree.insert("", "end", values=row)
        except:
            pass
        finally:
            conn.close()
    
    def on_search(*args):
        load_quotes(search_var.get())
    
    search_var.trace("w", on_search)
    
    def on_select():
        selected = tree.selection()
        if selected:
            item = tree.item(selected[0])
            quote_no = item["values"][0]
            entry_widget.delete(0, "end")
            entry_widget.insert(0, quote_no)
            dialog.destroy()
    
    # Buttons
    btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
    btn_frame.pack(fill="x", padx=10, pady=10)
    ctk.CTkButton(btn_frame, text="Select", fg_color="#007AFF", command=on_select).pack(side="right", padx=5)
    ctk.CTkButton(btn_frame, text="Cancel", fg_color="#E5E5EA", text_color="#333", command=dialog.destroy).pack(side="right", padx=5)
    
    tree.bind("<Double-1>", lambda e: on_select())
    load_quotes()
    search_entry.focus()


class CustomerComboBox(ctk.CTkFrame):
    """Customer selection with Code, Name, Address auto-fill - bidirectional sync"""
    
    def __init__(self, master, label_text, show_address=True, provider_type=None, exclude_carriers=False):
        super().__init__(master, fg_color="transparent")
        self.show_address = show_address
        self.provider_type = provider_type
        self.exclude_carriers = exclude_carriers  # True for SHIPPER/CONSIGNEE/NOTIFY
        self.on_select_callback = None  # Callback when a customer is selected
        
        # Load data based on type
        if provider_type:
            self.customers = fetch_carriers_for_combo(provider_type)
            # Add empty address for compatibility
            self.customers = [(c[0], c[1], "") for c in self.customers]
        elif exclude_carriers:
            # Use fetch_shippers_for_combo which excludes Trucker, Airline, Shipping line
            self.customers = fetch_shippers_for_combo()
        else:
            self.customers = fetch_customers_for_combo()
            # Add empty address for compatibility if needed
            if self.customers and len(self.customers[0]) == 2:
                self.customers = [(c[0], c[1], "") for c in self.customers]
        
        self._syncing = False  # Prevent infinite loop
        
        if label_text:
            ctk.CTkLabel(self, text=label_text, width=80).grid(row=0, column=0, sticky="w", padx=5, pady=3)
        
        self.code_var = tk.StringVar()
        self.code_combo = ttk.Combobox(self, textvariable=self.code_var, width=12)
        self.code_combo.grid(row=0, column=1, sticky="w", padx=5, pady=3)
        self.code_combo.bind("<<ComboboxSelected>>", self._on_code_selected)
        self.code_combo.bind("<KeyRelease>", self._on_code_keyrelease)
        
        self.name_var = tk.StringVar()
        self.name_combo = ttk.Combobox(self, textvariable=self.name_var, width=25)
        self.name_combo.grid(row=0, column=2, sticky="w", padx=5, pady=3)
        self.name_combo.bind("<<ComboboxSelected>>", self._on_name_selected)
        self.name_combo.bind("<KeyRelease>", self._on_name_keyrelease)
        
        if show_address:
            self.addr_var = tk.StringVar()
            self.addr_entry = ctk.CTkEntry(self, textvariable=self.addr_var, width=300, placeholder_text="Address")
            self.addr_entry.grid(row=1, column=1, columnspan=2, sticky="w", padx=5, pady=3)
        
        self._update_combos()
    
    def _fire_callback(self):
        """Call the on_select_callback if set"""
        if self.on_select_callback:
            try:
                self.on_select_callback(self.get_code())
            except Exception as e:
                print(f"Callback error: {e}")
        
        self._update_combos()
    
    def refresh_data(self):
        """Refresh data from database"""
        if self.provider_type:
            self.customers = fetch_carriers_for_combo(self.provider_type)
            self.customers = [(c[0], c[1], "") for c in self.customers]
        elif self.exclude_carriers:
            self.customers = fetch_shippers_for_combo()
        else:
            self.customers = fetch_customers_for_combo()
            if self.customers and len(self.customers[0]) == 2:
                self.customers = [(c[0], c[1], "") for c in self.customers]
        self._update_combos()
    
    def _update_combos(self):
        codes = [c[0] for c in self.customers if c[0]]
        names = [c[1] for c in self.customers if c[1]]
        self.code_combo["values"] = codes
        self.name_combo["values"] = names
    
    def _on_code_selected(self, event=None):
        if self._syncing:
            return
        self._syncing = True
        code = self.code_var.get()
        for c in self.customers:
            if c[0] == code:
                self.name_var.set(c[1] or "")
                if self.show_address:
                    self.addr_var.set(c[2] or "")
                break
        self._syncing = False
        self._fire_callback()
    
    def _on_code_keyrelease(self, event):
        typed = self.code_var.get().upper()
        if typed:
            filtered = [c[0] for c in self.customers if c[0] and typed in c[0].upper()]
            self.code_combo["values"] = filtered
            # Auto-fill if exact match
            for c in self.customers:
                if c[0] and c[0].upper() == typed:
                    if not self._syncing:
                        self._syncing = True
                        self.name_var.set(c[1] or "")
                        if self.show_address:
                            self.addr_var.set(c[2] or "")
                        self._syncing = False
                    break
        else:
            self._update_combos()
    
    def _on_name_selected(self, event=None):
        if self._syncing:
            return
        self._syncing = True
        name = self.name_var.get()
        for c in self.customers:
            if c[1] == name:
                self.code_var.set(c[0] or "")
                if self.show_address:
                    self.addr_var.set(c[2] or "")
                break
        self._syncing = False
    
    def _on_name_keyrelease(self, event):
        typed = self.name_var.get().upper()
        if typed:
            filtered = [c[1] for c in self.customers if c[1] and typed in c[1].upper()]
            self.name_combo["values"] = filtered
            # Auto-fill if exact match
            for c in self.customers:
                if c[1] and c[1].upper() == typed:
                    if not self._syncing:
                        self._syncing = True
                        self.code_var.set(c[0] or "")
                        if self.show_address:
                            self.addr_var.set(c[2] or "")
                        self._syncing = False
                    break
        else:
            self._update_combos()
    
    def get_code(self): return self.code_var.get()
    def get_name(self): return self.name_var.get()
    def get_address(self): return self.addr_var.get() if self.show_address else ""
    def clear(self):
        self.code_var.set("")
        self.name_var.set("")
        if self.show_address: self.addr_var.set("")
        self._update_combos()


class PortComboBox(ctk.CTkFrame):
    def __init__(self, master, label_text, port_type="SEA"):
        super().__init__(master, fg_color="transparent")
        self.port_type = port_type
        
        # Load ports based on type
        if port_type == "SEA":
            self.ports = fetch_sea_ports_for_combo()
        elif port_type == "AIR":
            self.ports = fetch_air_ports_for_combo()
        elif port_type == "LAND":
            self.ports = fetch_land_ports_for_combo()
        else:
            self.ports = fetch_sea_ports_for_combo()
        
        if label_text:
            ctk.CTkLabel(self, text=label_text, width=50).grid(row=0, column=0, sticky="w", padx=5, pady=3)
            self.port_var = tk.StringVar()
            self.port_combo = ttk.Combobox(self, textvariable=self.port_var, width=35)
            self.port_combo.grid(row=0, column=1, sticky="w", padx=5, pady=3)
        else:
            self.port_var = tk.StringVar()
            self.port_combo = ttk.Combobox(self, textvariable=self.port_var, width=35)
            self.port_combo.pack(side="left")
        
        self.port_combo.bind("<KeyRelease>", self._on_keyrelease)
        self._update_combo()
    
    def _format_port(self, p):
        code, name, city, country = p[0], p[1] or "", p[2] or "", p[3] or ""
        display = name or city
        return f"{code} - {display}, {country}" if country else f"{code} - {display}"
    
    def _update_combo(self):
        self.port_combo["values"] = [self._format_port(p) for p in self.ports]
    
    def _on_keyrelease(self, event):
        typed = self.port_var.get().upper()
        if typed:
            filtered = [self._format_port(p) for p in self.ports 
                       if typed in (p[0] or "").upper() or typed in (p[1] or "").upper() 
                       or typed in (p[2] or "").upper() or typed in (p[3] or "").upper()]
            self.port_combo["values"] = filtered
        else:
            self._update_combo()
    
    def get_code(self):
        val = self.port_var.get()
        return val.split(" - ")[0].strip() if " - " in val else val.strip()
    def get_value(self): return self.port_var.get()
    def set_value(self, val): self.port_var.set(val)
    def clear(self): self.port_var.set(""); self._update_combo()


def _open_date_picker(entry_widget, parent):
    if HAS_CALENDAR:
        popup = ctk.CTkToplevel(parent)
        popup.overrideredirect(True)
        popup.attributes("-topmost", True)
        popup.geometry(f"+{entry_widget.winfo_rootx()}+{entry_widget.winfo_rooty()+entry_widget.winfo_height()}")
        today = datetime.date.today()
        cal = Calendar(popup, selectmode="day", year=today.year, month=today.month, day=today.day, date_pattern="yyyy-mm-dd")
        cal.pack(padx=2, pady=2)
        cal.bind("<<CalendarSelected>>", lambda e: [entry_widget.delete(0, "end"), entry_widget.insert(0, cal.get_date()), popup.destroy()])
    else:
        entry_widget.delete(0, "end")
        entry_widget.insert(0, datetime.date.today().strftime("%Y-%m-%d"))


class CargoDetailCalculator:
    """Auto-calculate CBM from L×W×H and R/T from weight"""
    
    @staticmethod
    def calc_cbm(l_val, w_val, h_val, unit="cm"):
        """Calculate CBM from L × W × H"""
        try:
            l = float(l_val) if l_val else 0
            w = float(w_val) if w_val else 0
            h = float(h_val) if h_val else 0
            if unit == "cm":
                return round((l * w * h) / 1000000, 4)  # cm³ to m³
            else:  # m
                return round(l * w * h, 4)
        except:
            return 0
    
    @staticmethod
    def calc_revenue_ton(weight_kg, cbm):
        """Calculate Revenue Ton (R/T) = max(weight/1000, cbm)"""
        try:
            w = float(weight_kg) if weight_kg else 0
            c = float(cbm) if cbm else 0
            return round(max(w / 1000, c), 4)
        except:
            return 0
    
    @staticmethod
    def calc_chargeable_weight(weight_kg, cbm):
        """Calculate Chargeable Weight for Air = max(actual_weight, vol_weight)
           Volume weight = CBM × 167 (or CBM × 1000000 / 6000 for cm dimensions)"""
        try:
            w = float(weight_kg) if weight_kg else 0
            c = float(cbm) if cbm else 0
            vol_weight = c * 167  # 1 CBM = 167 kg for air
            return round(max(w, vol_weight), 2)
        except:
            return 0


# ============================================================
# OCEAN REGISTRATION FRAME
# ============================================================
class OceanRegFrame(ctk.CTkFrame):
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FAFAFA", width=width, height=height)
        self._is_dirty = False
        self.ts_rows = []
        self.fcl_rows = []
        self.lcl_rows = []
        self.current_job_id = None  # Track loaded job

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        self.scroll.pack(fill="both", expand=True, padx=8, pady=(38, 8))
        scroll = self.scroll  # For backward compatibility

        # === Top toolbar with Save/Load ===
        toolbar = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=8)
        toolbar.grid(row=0, column=0, sticky="ew", padx=20, pady=(10, 5))
        
        ctk.CTkButton(toolbar, text="💾 Save", width=80, height=32, fg_color="#059669", hover_color="#388E3C",
                     font=("SF Pro Display", 12, "bold"), command=self._save_job).pack(side="left", padx=10, pady=8)
        ctk.CTkButton(toolbar, text="📂 Load", width=80, height=32, fg_color="#374151", hover_color="#1565C0",
                     font=("SF Pro Display", 12, "bold"), command=self._load_job_dialog).pack(side="left", padx=5, pady=8)
        ctk.CTkButton(toolbar, text="🆕 New", width=80, height=32, fg_color="#FF9800", hover_color="#F57C00",
                     font=("SF Pro Display", 12), command=self._new_job).pack(side="left", padx=5, pady=8)
        
        self._status_label = ctk.CTkLabel(toolbar, text="", font=("SF Pro Display", 11), text_color="#666")
        self._status_label.pack(side="right", padx=15)

        # === Job Order / Quote Ref ===
        job_row = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        job_row.grid(row=1, column=0, sticky="w", padx=20, pady=(10, 10))

        ctk.CTkLabel(job_row, text="Job Order").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.job_order = ctk.CTkEntry(job_row, width=180)
        self.job_order.grid(row=0, column=1, sticky="w", padx=20, pady=3)
        self.job_order.insert(0, "AUTO")
        self.job_order.configure(state="disabled")

        ctk.CTkLabel(job_row, text="Quote Ref").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        self.quote_ref = ctk.CTkEntry(job_row, width=150)
        self.quote_ref.grid(row=0, column=3, sticky="w", padx=5, pady=3)
        ctk.CTkButton(job_row, text="🔍", width=32, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: search_quote_ref(self, self.quote_ref)).grid(row=0, column=4, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=2, column=0, sticky="ew", padx=20, pady=3)

        # === Basic Info ===
        basic = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        basic.grid(row=3, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(basic, text="OP").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.op_var = ctk.StringVar()
        self.op_entry = ctk.CTkEntry(basic, width=100, textvariable=self.op_var, state="disabled")
        self.op_entry.grid(row=0, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="MBL").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.mbl = ctk.CTkEntry(basic, width=180)
        self.mbl.grid(row=1, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="HBL").grid(row=1, column=2, sticky="w", padx=5, pady=3)
        self.hbl = ctk.CTkEntry(basic, width=180)
        self.hbl.grid(row=1, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="SHIPPING LINE").grid(row=2, column=0, sticky="w", padx=5, pady=3)
        self.shipping_line_code = tk.StringVar()
        self.shipping_line_combo = ttk.Combobox(basic, textvariable=self.shipping_line_code, width=20)
        self.shipping_line_combo.grid(row=2, column=1, sticky="w", padx=5, pady=3)
        self._setup_customer_combo(self.shipping_line_combo)

        ctk.CTkLabel(basic, text="BOOKING").grid(row=2, column=2, sticky="w", padx=5, pady=3)
        self.booking = ctk.CTkEntry(basic, width=180)
        self.booking.grid(row=2, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="VESSEL").grid(row=3, column=0, sticky="w", padx=5, pady=3)
        self.vessel = ctk.CTkEntry(basic, width=180)
        self.vessel.grid(row=3, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="VOYAGE").grid(row=3, column=2, sticky="w", padx=5, pady=3)
        self.voyage = ctk.CTkEntry(basic, width=180)
        self.voyage.grid(row=3, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=4, column=0, sticky="ew", padx=20, pady=3)

        # === POL / POD === (row 5)
        routing = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        routing.grid(row=5, column=0, sticky="w", padx=20, pady=(0, 10))

        self.pol_combo = PortComboBox(routing, "POL", "SEA")
        self.pol_combo.grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.pol_combo.port_combo.bind("<KeyRelease>", lambda e: self._update_op())

        self.pod_combo = PortComboBox(routing, "POD", "SEA")
        self.pod_combo.grid(row=0, column=1, sticky="w", padx=20, pady=3)

        # === ETD / ETA === (row 6)
        etd_eta = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        etd_eta.grid(row=6, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(etd_eta, text="ETD").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.etd = ctk.CTkEntry(etd_eta, width=130, placeholder_text="YYYY-MM-DD")
        self.etd.grid(row=0, column=1, sticky="w", padx=5, pady=3)
        ctk.CTkButton(etd_eta, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.etd, self)).grid(row=0, column=2, padx=4, pady=3)

        ctk.CTkLabel(etd_eta, text="ETA").grid(row=0, column=3, sticky="w", padx=5, pady=3)
        self.eta = ctk.CTkEntry(etd_eta, width=130, placeholder_text="YYYY-MM-DD")
        self.eta.grid(row=0, column=4, sticky="w", padx=5, pady=3)
        ctk.CTkButton(etd_eta, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.eta, self)).grid(row=0, column=5, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=7, column=0, sticky="ew", padx=20, pady=3)

        # === T/S Toggle Checkbox === (row 8)
        ts_toggle_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        ts_toggle_frame.grid(row=8, column=0, sticky="w", padx=20, pady=(5, 0))
        
        self.ts_enabled_var = tk.BooleanVar(value=False)
        self.ts_checkbox = ctk.CTkCheckBox(ts_toggle_frame, text="🔄 T/S (Transshipment)", 
                                           variable=self.ts_enabled_var, command=self._toggle_ts_section,
                                           font=("SF Pro Display", 12, "bold"))
        self.ts_checkbox.pack(side="left", padx=5)

        # === T/S (Transshipment) Section - Initially Hidden ===
        self.ts_frame = ctk.CTkFrame(scroll, fg_color="#FFF8E1", corner_radius=10)
        # Don't grid initially - hidden
        
        ts_header = ctk.CTkFrame(self.ts_frame, fg_color="transparent")
        ts_header.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(ts_header, text="T/S Details", font=("SF Pro Display", 11)).pack(side="left")
        ctk.CTkButton(ts_header, text="+ Add T/S", width=80, fg_color="#FFA000", hover_color="#FF8F00", command=self._add_ts_row).pack(side="right")

        self.ts_body = ctk.CTkFrame(self.ts_frame, fg_color="#FFFFFF")
        self.ts_body.pack(fill="x", padx=10, pady=(0, 10))

        ts_lbl_frame = ctk.CTkFrame(self.ts_body, fg_color="transparent")
        ts_lbl_frame.pack(fill="x", pady=(5, 0))
        for txt, w in [("T/S PORT", 150), ("VESSEL", 120), ("VOYAGE", 80), ("ETD", 100), ("ETA", 100)]:
            ctk.CTkLabel(ts_lbl_frame, text=txt, width=w, font=("SF Pro Display", 10)).pack(side="left", padx=5)

        self.ts_rows_frame = ctk.CTkFrame(self.ts_body, fg_color="transparent")
        self.ts_rows_frame.pack(fill="x")

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=9, column=0, sticky="ew", padx=20, pady=3)

        # === CUSTOMER / PARTNER ===
        cust_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        cust_frame.grid(row=10, column=0, sticky="w", padx=20, pady=(6, 10))

        self.customer_combo = CustomerComboBox(cust_frame, "CUSTOMER", show_address=False)
        self.customer_combo.grid(row=0, column=0, sticky="w", padx=5, pady=3)

        self.partner_combo = CustomerComboBox(cust_frame, "PARTNER", show_address=False)
        self.partner_combo.grid(row=0, column=1, sticky="w", padx=20, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=11, column=0, sticky="ew", padx=20, pady=3)

        # === SHPR / CNEE / NOTI ===
        self.parties_frame = ctk.CTkFrame(scroll, fg_color="#F9FAFB", corner_radius=10)
        self.parties_frame.grid(row=12, column=0, sticky="ew", padx=20, pady=(10, 10))

        ctk.CTkLabel(self.parties_frame, text="Parties Information", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 4))

        self.shipper_combo = CustomerComboBox(self.parties_frame, "SHIPPER", show_address=True, exclude_carriers=True)
        self.shipper_combo.grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=5)

        self.consignee_combo = CustomerComboBox(self.parties_frame, "CONSIGNEE", show_address=True, exclude_carriers=True)
        self.consignee_combo.grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=5)

        noti_frame = ctk.CTkFrame(self.parties_frame, fg_color="transparent")
        noti_frame.grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=5)
        self.notify_combo = CustomerComboBox(noti_frame, "NOTIFY", show_address=True, exclude_carriers=True)
        self.notify_combo.grid(row=0, column=0, sticky="w")
        ctk.CTkButton(noti_frame, text="SAME AS CNEE", width=110, fg_color="#E5E5EA", text_color="#333", command=self._copy_cnee_to_noti).grid(row=0, column=1, padx=10)
        
        # Bind customer selection to check company type
        self.customer_combo.on_select_callback = self._on_customer_selected

        # === Cargo Type ===
        cargo_type_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        cargo_type_frame.grid(row=13, column=0, sticky="w", padx=20, pady=(10, 5))

        ctk.CTkLabel(cargo_type_frame, text="Cargo Type:").grid(row=0, column=0, padx=5)
        self.cargo_type = ctk.StringVar(value="")
        ctk.CTkRadioButton(cargo_type_frame, text="FCL", variable=self.cargo_type, value="FCL", command=self._switch_cargo_type).grid(row=0, column=1, padx=10)
        ctk.CTkRadioButton(cargo_type_frame, text="LCL", variable=self.cargo_type, value="LCL", command=self._switch_cargo_type).grid(row=0, column=2, padx=10)

        # === FCL Section ===
        self.fcl_frame = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=10)
        self.fcl_frame.grid(row=14, column=0, sticky="ew", padx=20, pady=(5, 10))

        fcl_header = ctk.CTkFrame(self.fcl_frame, fg_color="transparent")
        fcl_header.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(fcl_header, text="📦 FCL Container Details", font=("SF Pro Display", 12, "bold")).pack(side="left")
        ctk.CTkButton(fcl_header, text="+ Add Container", width=110, fg_color="#374151", command=self._add_fcl_row).pack(side="right")

        fcl_lbl = ctk.CTkFrame(self.fcl_frame, fg_color="transparent")
        fcl_lbl.pack(fill="x", padx=10)
        for txt, w in [("CNTR NO", 140), ("TYPE", 100), ("SEAL NO", 100), ("WEIGHT(KG)", 80), ("CBM", 60)]:
            ctk.CTkLabel(fcl_lbl, text=txt, width=w, font=("SF Pro Display", 10)).pack(side="left", padx=5)

        self.fcl_body = ctk.CTkFrame(self.fcl_frame, fg_color="#FFFFFF")
        self.fcl_body.pack(fill="x", padx=10, pady=(0, 10))
        self._add_fcl_row()

        # === LCL Section with L×W×H auto-calculation ===
        self.lcl_frame = ctk.CTkFrame(scroll, fg_color="#E8F5E9", corner_radius=10)
        self.lcl_frame.grid(row=15, column=0, sticky="ew", padx=20, pady=(5, 10))
        
        lcl_header = ctk.CTkFrame(self.lcl_frame, fg_color="transparent")
        lcl_header.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(lcl_header, text="📦 LCL Cargo Details", font=("SF Pro Display", 12, "bold")).pack(side="left")
        ctk.CTkButton(lcl_header, text="+ Add Cargo", width=100, fg_color="#388E3C", command=self._add_lcl_row).pack(side="right")

        lcl_lbl = ctk.CTkFrame(self.lcl_frame, fg_color="transparent")
        lcl_lbl.pack(fill="x", padx=10)
        for txt, w in [("PCS", 50), ("PKG", 80), ("L(cm)", 60), ("W(cm)", 60), ("H(cm)", 60), ("CBM", 70), ("G.W(KG)", 70), ("R/T", 60)]:
            ctk.CTkLabel(lcl_lbl, text=txt, width=w, font=("SF Pro Display", 10)).pack(side="left", padx=3)

        self.lcl_body = ctk.CTkFrame(self.lcl_frame, fg_color="#FFFFFF")
        self.lcl_body.pack(fill="x", padx=10, pady=(0, 10))
        self._add_lcl_row()

        # LCL Total
        self.lcl_total_frame = ctk.CTkFrame(self.lcl_frame, fg_color="transparent")
        self.lcl_total_frame.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkLabel(self.lcl_total_frame, text="TOTAL:", font=("SF Pro Display", 11, "bold")).pack(side="left", padx=5)
        self.lcl_total_pcs = ctk.CTkLabel(self.lcl_total_frame, text="PCS: 0")
        self.lcl_total_pcs.pack(side="left", padx=10)
        self.lcl_total_cbm = ctk.CTkLabel(self.lcl_total_frame, text="CBM: 0.00")
        self.lcl_total_cbm.pack(side="left", padx=10)
        self.lcl_total_weight = ctk.CTkLabel(self.lcl_total_frame, text="G.W: 0.00 KG")
        self.lcl_total_weight.pack(side="left", padx=10)
        self.lcl_total_rt = ctk.CTkLabel(self.lcl_total_frame, text="R/T: 0.00")
        self.lcl_total_rt.pack(side="left", padx=10)

        self.fcl_frame.grid_remove()
        self.lcl_frame.grid_remove()

        # === Cargo Description ===
        cargo_detail_frame = ctk.CTkFrame(scroll, fg_color="#FFF3E0", corner_radius=10)
        cargo_detail_frame.grid(row=16, column=0, sticky="ew", padx=20, pady=(5, 10))
        
        ctk.CTkLabel(cargo_detail_frame, text="📋 Cargo Description", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        
        cargo_body = ctk.CTkFrame(cargo_detail_frame, fg_color="#FFFFFF")
        cargo_body.pack(fill="x", padx=10, pady=(0, 10))
        
        cargo_row1 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        cargo_row1.pack(fill="x", pady=5)
        ctk.CTkLabel(cargo_row1, text="HS CODE:").pack(side="left", padx=5)
        self.hs_code = ctk.CTkEntry(cargo_row1, width=120)
        self.hs_code.pack(side="left", padx=5)
        ctk.CTkLabel(cargo_row1, text="INCOTERMS:").pack(side="left", padx=10)
        self.incoterms = ctk.CTkComboBox(cargo_row1, values=["FOB", "CIF", "CFR", "EXW", "DDP", "DAP", "FCA", "CPT", "CIP"], width=100)
        self.incoterms.pack(side="left", padx=5)
        ctk.CTkLabel(cargo_row1, text="CARGO VALUE:").pack(side="left", padx=10)
        self.cargo_value = ctk.CTkEntry(cargo_row1, width=100)
        self.cargo_value.pack(side="left", padx=5)
        
        cargo_row2 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        cargo_row2.pack(fill="x", pady=5)
        ctk.CTkLabel(cargo_row2, text="COMMODITY:").pack(side="left", padx=5)
        self.commodity = ctk.CTkEntry(cargo_row2, width=500)
        self.commodity.pack(side="left", padx=5)
        
        cargo_row3 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        cargo_row3.pack(fill="x", pady=5)
        ctk.CTkLabel(cargo_row3, text="MARKS:").pack(side="left", padx=5)
        self.marks = ctk.CTkEntry(cargo_row3, width=200)
        self.marks.pack(side="left", padx=5)
        ctk.CTkLabel(cargo_row3, text="REMARKS:").pack(side="left", padx=10)
        self.remarks = ctk.CTkEntry(cargo_row3, width=300)
        self.remarks.pack(side="left", padx=5)

        # === Bottom Buttons ===
        bottom_bar = ctk.CTkFrame(self, fg_color="#FFFFFF")
        bottom_bar.pack(fill="x", padx=20, pady=(0, 20))
        ctk.CTkButton(bottom_bar, text="Reset", width=120, fg_color="#FFCDD2", text_color="#B71C1C", command=self._confirm_reset).grid(row=0, column=0, padx=2)
        ctk.CTkButton(bottom_bar, text="Save", width=120, fg_color="#3B82F6", command=self._save_operation).grid(row=0, column=1, padx=2)
        ctk.CTkButton(bottom_bar, text="Save & Close", width=140, fg_color="#E5E5EA", text_color="#333", command=self._save_and_close).grid(row=0, column=2, padx=2)

        self._load_customer_data()

    def _toggle_ts_section(self):
        """Toggle T/S section visibility"""
        if self.ts_enabled_var.get():
            # T/S frame appears between toggle (row 8) and separator (row 9)
            self.ts_frame.grid(row=8, column=0, sticky="ew", padx=20, pady=(5, 10))
        else:
            self.ts_frame.grid_forget()
            # Clear T/S rows when hidden
            for row in self.ts_rows:
                row["frame"].destroy()
            self.ts_rows = []

    def _add_ts_row(self):
        row_frame = ctk.CTkFrame(self.ts_rows_frame, fg_color="transparent")
        row_frame.pack(fill="x", pady=2)
        
        row = {"frame": row_frame}
        row["port"] = ttk.Combobox(row_frame, width=18)
        row["port"]["values"] = [self.pol_combo._format_port(p) for p in self.pol_combo.ports]
        row["port"].pack(side="left", padx=5)
        row["vessel"] = ctk.CTkEntry(row_frame, width=120)
        row["vessel"].pack(side="left", padx=5)
        row["voyage"] = ctk.CTkEntry(row_frame, width=80)
        row["voyage"].pack(side="left", padx=5)
        row["etd"] = ctk.CTkEntry(row_frame, width=100, placeholder_text="YYYY-MM-DD")
        row["etd"].pack(side="left", padx=5)
        row["eta"] = ctk.CTkEntry(row_frame, width=100, placeholder_text="YYYY-MM-DD")
        row["eta"].pack(side="left", padx=5)
        row["delete"] = ctk.CTkButton(row_frame, text="🗑", width=32, fg_color="#FFCDD2", text_color="#B71C1C", 
                                      command=lambda rf=row_frame: self._del_ts_row(rf))
        row["delete"].pack(side="left", padx=5)
        self.ts_rows.append(row)

    def _del_ts_row(self, row_frame):
        for i, row in enumerate(self.ts_rows):
            if row["frame"] == row_frame:
                row_frame.destroy()
                self.ts_rows.pop(i)
                break

    def _add_fcl_row(self):
        row_frame = ctk.CTkFrame(self.fcl_body, fg_color="transparent")
        row_frame.pack(fill="x", pady=2)
        
        row = {"frame": row_frame}
        row["cntr"] = ctk.CTkEntry(row_frame, width=140)
        row["cntr"].pack(side="left", padx=5)
        row["type"] = ctk.CTkComboBox(row_frame, values=["20GP", "40GP", "40HC", "45HC", "20RF", "40RF", "20OT", "40OT", "20FR", "40FR"], width=100)
        row["type"].pack(side="left", padx=5)
        row["seal"] = ctk.CTkEntry(row_frame, width=100)
        row["seal"].pack(side="left", padx=5)
        row["weight"] = ctk.CTkEntry(row_frame, width=80)
        row["weight"].pack(side="left", padx=5)
        row["cbm"] = ctk.CTkEntry(row_frame, width=60)
        row["cbm"].pack(side="left", padx=5)
        row["delete"] = ctk.CTkButton(row_frame, text="🗑", width=32, fg_color="#FFCDD2", text_color="#B71C1C",
                                      command=lambda rf=row_frame: self._del_fcl_row(rf))
        row["delete"].pack(side="left", padx=5)
        self.fcl_rows.append(row)

    def _del_fcl_row(self, row_frame):
        for i, row in enumerate(self.fcl_rows):
            if row["frame"] == row_frame:
                row_frame.destroy()
                self.fcl_rows.pop(i)
                break

    def _add_lcl_row(self):
        row_frame = ctk.CTkFrame(self.lcl_body, fg_color="transparent")
        row_frame.pack(fill="x", pady=2)
        
        row = {"frame": row_frame}
        row["pcs"] = ctk.CTkEntry(row_frame, width=50)
        row["pcs"].pack(side="left", padx=3)
        row["pkg"] = ctk.CTkComboBox(row_frame, values=["CTN", "PLT", "PKG", "DRUM", "BAG", "ROLL"], width=80)
        row["pkg"].pack(side="left", padx=3)
        row["l"] = ctk.CTkEntry(row_frame, width=60)
        row["l"].pack(side="left", padx=3)
        row["w"] = ctk.CTkEntry(row_frame, width=60)
        row["w"].pack(side="left", padx=3)
        row["h"] = ctk.CTkEntry(row_frame, width=60)
        row["h"].pack(side="left", padx=3)
        row["cbm"] = ctk.CTkEntry(row_frame, width=70)
        row["cbm"].pack(side="left", padx=3)
        row["weight"] = ctk.CTkEntry(row_frame, width=70)
        row["weight"].pack(side="left", padx=3)
        row["rt"] = ctk.CTkEntry(row_frame, width=60)
        row["rt"].pack(side="left", padx=3)
        row["delete"] = ctk.CTkButton(row_frame, text="🗑", width=32, fg_color="#FFCDD2", text_color="#B71C1C",
                                      command=lambda rf=row_frame: self._del_lcl_row(rf))
        row["delete"].pack(side="left", padx=3)
        
        # Bind auto-calculation
        def calc_cbm_rt(*args):
            l_val = row["l"].get()
            w_val = row["w"].get()
            h_val = row["h"].get()
            weight_val = row["weight"].get()
            pcs_val = row["pcs"].get()
            
            try:
                pcs = int(pcs_val) if pcs_val else 1
            except:
                pcs = 1
            
            cbm = CargoDetailCalculator.calc_cbm(l_val, w_val, h_val, "cm") * pcs
            row["cbm"].delete(0, "end")
            row["cbm"].insert(0, f"{cbm:.4f}")
            
            rt = CargoDetailCalculator.calc_revenue_ton(weight_val, cbm)
            row["rt"].delete(0, "end")
            row["rt"].insert(0, f"{rt:.4f}")
            
            self._update_lcl_totals()
        
        for key in ["l", "w", "h", "weight", "pcs"]:
            row[key].bind("<KeyRelease>", calc_cbm_rt)
        
        self.lcl_rows.append(row)

    def _del_lcl_row(self, row_frame):
        for i, row in enumerate(self.lcl_rows):
            if row["frame"] == row_frame:
                row_frame.destroy()
                self.lcl_rows.pop(i)
                self._update_lcl_totals()
                break

    def _update_lcl_totals(self):
        total_pcs = 0
        total_cbm = 0
        total_weight = 0
        total_rt = 0
        for row in self.lcl_rows:
            try:
                total_pcs += int(row["pcs"].get() or 0)
            except: pass
            try:
                total_cbm += float(row["cbm"].get() or 0)
            except: pass
            try:
                total_weight += float(row["weight"].get() or 0)
            except: pass
            try:
                total_rt += float(row["rt"].get() or 0)
            except: pass
        
        self.lcl_total_pcs.configure(text=f"PCS: {total_pcs}")
        self.lcl_total_cbm.configure(text=f"CBM: {total_cbm:.2f}")
        self.lcl_total_weight.configure(text=f"G.W: {total_weight:.2f} KG")
        self.lcl_total_rt.configure(text=f"R/T: {total_rt:.2f}")

    def _setup_customer_combo(self, combo):
        customers = fetch_customers_for_combo()
        combo["values"] = [f"{c[0]} - {c[1]}" for c in customers if c[0] and c[1]]

    def _load_customer_data(self):
        # Load Shipping Lines from Provider (type='Shipping Line')
        shipping_lines = fetch_shipping_lines()
        if shipping_lines:
            self.shipping_line_combo["values"] = [f"{c[0]} - {c[1]}" for c in shipping_lines if c[0] and c[1]]
        else:
            # Fallback to customers if no shipping lines defined
            customers = fetch_customers_for_combo()
            self.shipping_line_combo["values"] = [f"{c[0]} - {c[1]}" for c in customers if c[0] and c[1]]

    def _update_op(self):
        pol = self.pol_combo.get_code().upper()
        op = "EXPO" if "MX" in pol else "IMPO"
        self.op_entry.configure(state="normal")
        self.op_entry.delete(0, "end")
        self.op_entry.insert(0, op)
        self.op_entry.configure(state="disabled")

    def _on_customer_selected(self, customer_code):
        """Handle customer selection - hide parties_frame for Trucker/Airline/Shipping Line"""
        if not customer_code:
            self.parties_frame.grid()  # Show by default
            return
        
        # Check company type from database
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT company_type, type FROM companies WHERE code = ?
            """, (customer_code,))
            row = cur.fetchone()
            conn.close()
            
            if row:
                company_type = (row[0] or "").upper()
                old_type = (row[1] or "").upper()
                
                # Hide parties_frame for these types
                hide_types = ['TRUCKER', 'AIRLINE', 'SHIPPING_LINE', 'SHIPPING LINE', 
                              'CARRIER', 'TRUCKING', 'TRANSPORTER']
                
                should_hide = any(t in company_type or t in old_type for t in hide_types)
                
                if should_hide:
                    self.parties_frame.grid_remove()
                    # Clear parties data
                    self.shipper_combo.clear()
                    self.consignee_combo.clear()
                    self.notify_combo.clear()
                else:
                    self.parties_frame.grid()
            else:
                self.parties_frame.grid()  # Show by default
        except Exception as e:
            print(f"Error checking company type: {e}")
            self.parties_frame.grid()  # Show on error

    def _copy_cnee_to_noti(self):
        self.notify_combo.code_var.set(self.consignee_combo.get_code())
        self.notify_combo.name_var.set(self.consignee_combo.get_name())
        if self.notify_combo.show_address:
            self.notify_combo.addr_var.set(self.consignee_combo.get_address())

    def _switch_cargo_type(self):
        t = self.cargo_type.get()
        if t == "FCL":
            self.fcl_frame.grid()
            self.lcl_frame.grid_remove()
        elif t == "LCL":
            self.lcl_frame.grid()
            self.fcl_frame.grid_remove()

    def _confirm_reset(self):
        if messagebox.askyesno("Reset", "Reset all fields?"):
            self._reset_all()

    def _reset_all(self):
        for e in [self.quote_ref, self.mbl, self.hbl, self.booking, self.vessel, self.voyage, self.etd, self.eta,
                  self.hs_code, self.cargo_value, self.commodity, self.marks, self.remarks]:
            try: e.delete(0, "end")
            except: pass
        self.shipping_line_code.set("")
        self.pol_combo.clear()
        self.pod_combo.clear()
        self.customer_combo.clear()
        self.partner_combo.clear()
        self.shipper_combo.clear()
        self.consignee_combo.clear()
        self.notify_combo.clear()
        self.cargo_type.set("")
        self.incoterms.set("")
        self.fcl_frame.grid_remove()
        self.lcl_frame.grid_remove()
        # Clear T/S rows
        for row in self.ts_rows:
            row["frame"].destroy()
        self.ts_rows = []
        # Clear FCL rows and add one
        for row in self.fcl_rows:
            row["frame"].destroy()
        self.fcl_rows = []
        self._add_fcl_row()
        # Clear LCL rows and add one
        for row in self.lcl_rows:
            row["frame"].destroy()
        self.lcl_rows = []
        self._add_lcl_row()

    def _save_job(self):
        """Save job (new or update existing)"""
        if self.current_job_id:
            self._update_existing_job()
        else:
            self._save_operation()
    
    def _update_existing_job(self):
        """Update existing job with duplicate check"""
        # HBL 중복 체크 (자기 자신 제외)
        hbl_val = self.hbl.get().strip()
        if hbl_val and check_hbl_duplicate(hbl_val, exclude_job_id=self.current_job_id):
            messagebox.showerror("Duplicate HBL", f"HBL '{hbl_val}' already exists in another job.")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""UPDATE jobs SET 
                mbl=?, hbl=?, carrier=?, booking_no=?, vessel=?, voyage=?,
                pol=?, pod=?, etd=?, eta=?,
                customer_name=?, customer_code=?, shipper=?, consignee=?,
                notify=?, partner=?, incoterms=?, remark=?, updated_at=?
                WHERE id=?""", (
                self.mbl.get(), hbl_val, self.shipping_line_code.get(),
                self.booking.get(), self.vessel.get(), self.voyage.get(),
                self.pol_combo.get_code(), self.pod_combo.get_code(),
                self.etd.get(), self.eta.get(),
                self.customer_combo.get_name(), self.customer_combo.get_code(),
                self.shipper_combo.get_name(), self.consignee_combo.get_name(),
                self.notify_combo.get_name(), self.partner_combo.get_name(),
                self.incoterms_combo.get() if hasattr(self, 'incoterms_combo') else "",
                self.remark.get("1.0", "end-1c") if hasattr(self, 'remark') else "",
                now_str(), self.current_job_id
            ))
            
            # Update containers
            cur.execute("DELETE FROM containers WHERE job_id=?", (self.current_job_id,))
            for row in self.fcl_rows:
                cntr = row["cntr"].get().strip()
                if cntr:
                    cur.execute("""INSERT INTO containers (job_id, container_no, container_type, weight, cbm, status)
                        VALUES (?, ?, ?, ?, ?, 'BOOKED')""",
                        (self.current_job_id, cntr, row["type"].get(), row["weight"].get(), row["cbm"].get()))
            
            conn.commit()
            self._status_label.configure(text=f"✅ Updated: Job #{self.current_job_id}", text_color="#059669")
            messagebox.showinfo("Updated", f"Job updated successfully.")
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Update failed: {e}")
        finally:
            conn.close()
    
    def _load_job_dialog(self):
        """Open dialog to load existing job"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Load Job")
        dialog.geometry("400x200")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        ctk.CTkLabel(dialog, text="Load Existing Job", font=("SF Pro Display", 16, "bold")).pack(pady=15)
        
        form = ctk.CTkFrame(dialog, fg_color="#F5F5F5")
        form.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(form, text="Enter Job No, MBL, or HBL:").pack(anchor="w", padx=15, pady=(10,5))
        search_var = tk.StringVar()
        search_entry = ctk.CTkEntry(form, textvariable=search_var, width=300, placeholder_text="e.g., JOS20260108001 or HDMU1234567")
        search_entry.pack(padx=15, pady=5)
        search_entry.focus()
        
        def do_load():
            keyword = search_var.get().strip()
            if not keyword:
                messagebox.showwarning("Warning", "Please enter a search term.")
                return
            if self._load_job_by_keyword(keyword):
                dialog.destroy()
            else:
                messagebox.showwarning("Not Found", f"No job found for: {keyword}")
        
        search_entry.bind("<Return>", lambda e: do_load())
        
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Load", width=100, fg_color="#374151", command=do_load).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#E5E5EA", text_color="#333", 
                     command=dialog.destroy).pack(side="right", padx=5)
    
    def _load_job_by_keyword(self, keyword):
        """Load job by job_no, MBL, or HBL"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""SELECT * FROM jobs WHERE job_no=? OR mbl=? OR hbl=? LIMIT 1""", 
                       (keyword, keyword, keyword))
            row = cur.fetchone()
            if not row:
                return False
            
            # Get column names
            cols = [d[0] for d in cur.description]
            job = dict(zip(cols, row))
            
            self._reset_all()
            self.current_job_id = job['id']
            
            # Populate fields
            self.job_order.configure(state="normal")
            self.job_order.delete(0, "end")
            self.job_order.insert(0, job.g_t('job_no', ''))
            self.job_order.configure(state="disabled")
            
            self.mbl.delete(0, "end")
            self.mbl.insert(0, job.g_t('mbl', '') or '')
            
            self.hbl.delete(0, "end")
            self.hbl.insert(0, job.g_t('hbl', '') or '')
            
            self.shipping_line_code.set(job.g_t('carrier', '') or '')
            
            self.booking.delete(0, "end")
            self.booking.insert(0, job.g_t('booking_no', '') or '')
            
            self.vessel.delete(0, "end")
            self.vessel.insert(0, job.g_t('vessel', '') or '')
            
            self.voyage.delete(0, "end")
            self.voyage.insert(0, job.g_t('voyage', '') or '')
            
            self.pol_combo.set_value(job.g_t('pol', '') or '')
            self.pod_combo.set_value(job.g_t('pod', '') or '')
            
            self.etd.delete(0, "end")
            self.etd.insert(0, job.g_t('etd', '') or '')
            
            self.eta.delete(0, "end")
            self.eta.insert(0, job.g_t('eta', '') or '')
            
            if job.g_t('customer_code'):
                self.customer_combo.set_by_code(job['customer_code'])
            
            # Load containers
            cur.execute("SELECT * FROM containers WHERE job_id=?", (job['id'],))
            containers = cur.fetchall()
            if containers:
                container_cols = [d[0] for d in cur.description]
                for i, cntr_row in enumerate(containers):
                    cntr = dict(zip(container_cols, cntr_row))
                    if i >= len(self.fcl_rows):
                        self._add_fcl_row()
                    if i < len(self.fcl_rows):
                        self.fcl_rows[i]["cntr"].delete(0, "end")
                        self.fcl_rows[i]["cntr"].insert(0, cntr.g_t('container_no', ''))
                        self.fcl_rows[i]["type"].set(cntr.g_t('container_type', '20GP'))
                        self.fcl_rows[i]["weight"].delete(0, "end")
                        self.fcl_rows[i]["weight"].insert(0, str(cntr.g_t('weight', '')))
                        self.fcl_rows[i]["cbm"].delete(0, "end")
                        self.fcl_rows[i]["cbm"].insert(0, str(cntr.g_t('cbm', '')))
            
            self._status_label.configure(text=f"📂 Loaded: {job.g_t('job_no', '')}", text_color="#374151")
            conn.close()
            return True
        except Exception as e:
            print(f"Load error: {e}")
            conn.close()
            return False
    
    def _new_job(self):
        """Start new job"""
        if self._is_dirty:
            if not messagebox.askyesno("Unsaved Changes", "Discard unsaved changes?"):
                return
        self._reset_all()
        self.current_job_id = None
        self._status_label.configure(text="🆕 New Job", text_color="#FF9800")

    def _generate_job_no(self):
        conn = get_connection()
        cur = conn.cursor()
        prefix = f"JOS{datetime.datetime.now().strftime('%Y%m%d')}"
        try:
            cur.execute("SELECT job_no FROM jobs WHERE job_no LIKE ? ORDER BY job_no DESC LIMIT 1", (f"{prefix}%",))
            row = cur.fetchone()
            seq = int(row[0][-3:]) + 1 if row else 1
            return f"{prefix}{str(seq).zfill(3)}"
        except:
            return f"{prefix}001"
        finally:
            conn.close()

    def _save_operation(self):
        from db import validate_dates, check_month_editable
        
        customer = self.customer_combo.get_code() or self.customer_combo.get_name()
        if not customer:
            messagebox.showwarning("Required", "Customer is required.")
            return

        hbl_val = self.hbl.get().strip()
        # 수정 시에는 자기 자신은 제외하고 중복 체크
        if hbl_val and check_hbl_duplicate(hbl_val, exclude_job_id=self.current_job_id):
            messagebox.showerror("Duplicate HBL", f"HBL '{hbl_val}' already exists in another job.")
            return

        # 날짜 유효성 검사
        etd = self.etd.get()
        eta = self.eta.get()
        is_valid, date_error = validate_dates(etd=etd, eta=eta)
        if not is_valid:
            messagebox.showerror("Date Error", date_error)
            return
        
        # 월마감 체크
        is_editable, lock_msg = check_month_editable(etd)
        if not is_editable:
            messagebox.showerror("Month Closed", lock_msg)
            return

        job_no = self._generate_job_no()
        conn = get_connection()
        cur = conn.cursor()
        try:
            shipping_line = self.shipping_line_code.get().split(" - ")[0] if " - " in self.shipping_line_code.get() else self.shipping_line_code.get()
            partner = self.partner_combo.get_code() or self.partner_combo.get_name()
            
            cur.execute("""
                INSERT INTO jobs (job_no, mode, mbl, hbl, shipper, consignee, notify, customer, partner, carrier, vessel, voyage, pol, pod, etd, eta, status, remarks, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (job_no, "OCEAN", self.mbl.get(), hbl_val, 
                  self.shipper_combo.get_name(), self.consignee_combo.get_name(), self.notify_combo.get_name(),
                  customer, partner, shipping_line, self.vessel.get(), self.voyage.get(),
                  self.pol_combo.get_code(), self.pod_combo.get_code(), etd, eta, 
                  "OPEN", self.remarks.get(), now_str(), now_str()))
            job_id = cur.lastrowid

            if self.cargo_type.get() == "FCL":
                for row in self.fcl_rows:
                    cntr = row["cntr"].get()
                    if cntr:
                        cur.execute("INSERT INTO containers (job_id, cntr_no, cntr_type, weight, cbm, status) VALUES (?, ?, ?, ?, ?, ?)",
                                   (job_id, cntr, row["type"].get(), row["weight"].get(), row["cbm"].get(), "BOOKED"))
            conn.commit()
            
            # Send email notification
            try:
                from automation import notify_new_job
                notify_new_job(job_no, customer, "OCEAN")
            except ImportError:
                pass
            
            messagebox.showinfo("Saved", f"Job {job_no} saved successfully.")
            self._reset_all()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed to save: {e}")
        finally:
            conn.close()

    def _save_and_close(self): self._save_operation()
    def set_provider(self, p): self._provider = p
    def load(self, id=None): self._reset_all()
    def save(self): return {"ok": True}
    def get_state(self): return {}
    def is_dirty(self): return getattr(self, "_is_dirty", False)
    def reset(self): self._reset_all(); self._is_dirty = False


# ============================================================
# AIR REGISTRATION FRAME
# ============================================================
class AirRegFrame(ctk.CTkFrame):
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FAFAFA", width=width, height=height)
        self._is_dirty = False
        self.ts_rows = []
        self.cargo_rows = []

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        self.scroll.pack(fill="both", expand=True, padx=8, pady=(38, 8))
        scroll = self.scroll  # For backward compatibility

        # Job Order / Quote Ref
        job_row = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        job_row.grid(row=0, column=0, sticky="w", padx=20, pady=(10, 10))

        ctk.CTkLabel(job_row, text="Job Order").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.job_order = ctk.CTkEntry(job_row, width=180)
        self.job_order.grid(row=0, column=1, sticky="w", padx=20, pady=3)
        self.job_order.insert(0, "AUTO")
        self.job_order.configure(state="disabled")

        ctk.CTkLabel(job_row, text="Quote Ref").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        self.quote_ref = ctk.CTkEntry(job_row, width=150)
        self.quote_ref.grid(row=0, column=3, sticky="w", padx=5, pady=3)
        ctk.CTkButton(job_row, text="🔍", width=32, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: search_quote_ref(self, self.quote_ref)).grid(row=0, column=4, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=1, column=0, sticky="ew", padx=20, pady=3)

        # Basic
        basic = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        basic.grid(row=2, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(basic, text="OP").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.op_var = ctk.StringVar()
        self.op_entry = ctk.CTkEntry(basic, width=100, textvariable=self.op_var, state="disabled")
        self.op_entry.grid(row=0, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="MAWB").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.mawb = ctk.CTkEntry(basic, width=180)
        self.mawb.grid(row=1, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="HAWB").grid(row=1, column=2, sticky="w", padx=5, pady=3)
        self.hawb = ctk.CTkEntry(basic, width=180)
        self.hawb.grid(row=1, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="AIRLINE").grid(row=2, column=0, sticky="w", padx=5, pady=3)
        self.airline_var = tk.StringVar()
        self.airline_combo = ttk.Combobox(basic, textvariable=self.airline_var, width=20)
        self.airline_combo.grid(row=2, column=1, sticky="w", padx=5, pady=3)
        self._setup_customer_combo(self.airline_combo)

        ctk.CTkLabel(basic, text="FLIGHT NO").grid(row=2, column=2, sticky="w", padx=5, pady=3)
        self.flight_no = ctk.CTkEntry(basic, width=180)
        self.flight_no.grid(row=2, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=3, column=0, sticky="ew", padx=20, pady=3)

        # AOL / AOD
        routing = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        routing.grid(row=4, column=0, sticky="w", padx=20, pady=(0, 10))

        self.aol_combo = PortComboBox(routing, "AOL", "AIR")
        self.aol_combo.grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.aol_combo.port_combo.bind("<KeyRelease>", lambda e: self._update_op())

        self.aod_combo = PortComboBox(routing, "AOD", "AIR")
        self.aod_combo.grid(row=0, column=1, sticky="w", padx=20, pady=3)

        # ETD / ETA
        etd_eta = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        etd_eta.grid(row=5, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(etd_eta, text="ETD").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.etd = ctk.CTkEntry(etd_eta, width=130, placeholder_text="YYYY-MM-DD")
        self.etd.grid(row=0, column=1, sticky="w", padx=5, pady=3)
        ctk.CTkButton(etd_eta, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.etd, self)).grid(row=0, column=2, padx=4, pady=3)

        ctk.CTkLabel(etd_eta, text="ETA").grid(row=0, column=3, sticky="w", padx=5, pady=3)
        self.eta = ctk.CTkEntry(etd_eta, width=130, placeholder_text="YYYY-MM-DD")
        self.eta.grid(row=0, column=4, sticky="w", padx=5, pady=3)
        ctk.CTkButton(etd_eta, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.eta, self)).grid(row=0, column=5, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=6, column=0, sticky="ew", padx=20, pady=3)

        # === T/S Toggle Checkbox ===
        ts_toggle_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        ts_toggle_frame.grid(row=7, column=0, sticky="w", padx=20, pady=(5, 0))
        
        self.ts_enabled_var = tk.BooleanVar(value=False)
        self.ts_checkbox = ctk.CTkCheckBox(ts_toggle_frame, text="🔄 T/S (Transshipment)", 
                                           variable=self.ts_enabled_var, command=self._toggle_ts_section,
                                           font=("SF Pro Display", 12, "bold"))
        self.ts_checkbox.pack(side="left", padx=5)

        # === T/S Section - Initially Hidden ===
        self.ts_frame = ctk.CTkFrame(scroll, fg_color="#FFF8E1", corner_radius=10)
        # Don't grid initially
        
        ts_header = ctk.CTkFrame(self.ts_frame, fg_color="transparent")
        ts_header.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(ts_header, text="T/S Details", font=("SF Pro Display", 11)).pack(side="left")
        ctk.CTkButton(ts_header, text="+ Add T/S", width=80, fg_color="#FFA000", command=self._add_ts_row).pack(side="right")

        self.ts_body = ctk.CTkFrame(self.ts_frame, fg_color="#FFFFFF")
        self.ts_body.pack(fill="x", padx=10, pady=(0, 10))

        ts_lbl = ctk.CTkFrame(self.ts_body, fg_color="transparent")
        ts_lbl.pack(fill="x", pady=(5, 0))
        for txt, w in [("T/S AIRPORT", 150), ("FLIGHT", 100), ("ETD", 100), ("ETA", 100)]:
            ctk.CTkLabel(ts_lbl, text=txt, width=w, font=("SF Pro Display", 10)).pack(side="left", padx=5)

        self.ts_rows_frame = ctk.CTkFrame(self.ts_body, fg_color="transparent")
        self.ts_rows_frame.pack(fill="x")

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=8, column=0, sticky="ew", padx=20, pady=3)

        # CUSTOMER / PARTNER
        cust_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        cust_frame.grid(row=9, column=0, sticky="w", padx=20, pady=(6, 10))

        self.customer_combo = CustomerComboBox(cust_frame, "CUSTOMER", show_address=False)
        self.customer_combo.grid(row=0, column=0, sticky="w", padx=5, pady=3)

        self.partner_combo = CustomerComboBox(cust_frame, "PARTNER", show_address=False)
        self.partner_combo.grid(row=0, column=1, sticky="w", padx=20, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=10, column=0, sticky="ew", padx=20, pady=3)

        # SHPR / CNEE / NOTI
        self.parties_frame = ctk.CTkFrame(scroll, fg_color="#F9FAFB", corner_radius=10)
        self.parties_frame.grid(row=11, column=0, sticky="ew", padx=20, pady=(10, 10))

        ctk.CTkLabel(self.parties_frame, text="Parties Information", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 4))

        self.shipper_combo = CustomerComboBox(self.parties_frame, "SHIPPER", show_address=True, exclude_carriers=True)
        self.shipper_combo.grid(row=1, column=0, columnspan=2, sticky="w", padx=10, pady=5)

        self.consignee_combo = CustomerComboBox(self.parties_frame, "CONSIGNEE", show_address=True, exclude_carriers=True)
        self.consignee_combo.grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=5)

        noti_frame = ctk.CTkFrame(self.parties_frame, fg_color="transparent")
        noti_frame.grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=5)
        self.notify_combo = CustomerComboBox(noti_frame, "NOTIFY", show_address=True, exclude_carriers=True)
        self.notify_combo.grid(row=0, column=0, sticky="w")
        ctk.CTkButton(noti_frame, text="SAME AS CNEE", width=110, fg_color="#E5E5EA", text_color="#333", command=self._copy_cnee_to_noti).grid(row=0, column=1, padx=10)
        
        # Bind customer selection to check company type
        self.customer_combo.on_select_callback = self._on_customer_selected

        # Cargo Detail with L×W×H auto-calculation
        cargo_frame = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=10)
        cargo_frame.grid(row=12, column=0, sticky="ew", padx=20, pady=(5, 10))
        
        cargo_header = ctk.CTkFrame(cargo_frame, fg_color="transparent")
        cargo_header.pack(fill="x", padx=10, pady=(8, 4))
        ctk.CTkLabel(cargo_header, text="📦 Cargo Details", font=("SF Pro Display", 12, "bold")).pack(side="left")
        ctk.CTkButton(cargo_header, text="+ Add Cargo", width=100, fg_color="#374151", command=self._add_cargo_row).pack(side="right")

        cargo_lbl = ctk.CTkFrame(cargo_frame, fg_color="transparent")
        cargo_lbl.pack(fill="x", padx=10)
        for txt, w in [("PCS", 50), ("L(cm)", 60), ("W(cm)", 60), ("H(cm)", 60), ("CBM", 70), ("G.W(KG)", 70), ("C.W(KG)", 70)]:
            ctk.CTkLabel(cargo_lbl, text=txt, width=w, font=("SF Pro Display", 10)).pack(side="left", padx=3)

        self.cargo_body = ctk.CTkFrame(cargo_frame, fg_color="#FFFFFF")
        self.cargo_body.pack(fill="x", padx=10, pady=(0, 10))
        self._add_cargo_row()

        # Cargo Total
        self.cargo_total_frame = ctk.CTkFrame(cargo_frame, fg_color="transparent")
        self.cargo_total_frame.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkLabel(self.cargo_total_frame, text="TOTAL:", font=("SF Pro Display", 11, "bold")).pack(side="left", padx=5)
        self.cargo_total_pcs = ctk.CTkLabel(self.cargo_total_frame, text="PCS: 0")
        self.cargo_total_pcs.pack(side="left", padx=10)
        self.cargo_total_cbm = ctk.CTkLabel(self.cargo_total_frame, text="CBM: 0.00")
        self.cargo_total_cbm.pack(side="left", padx=10)
        self.cargo_total_gw = ctk.CTkLabel(self.cargo_total_frame, text="G.W: 0.00 KG")
        self.cargo_total_gw.pack(side="left", padx=10)
        self.cargo_total_cw = ctk.CTkLabel(self.cargo_total_frame, text="C.W: 0.00 KG")
        self.cargo_total_cw.pack(side="left", padx=10)

        # Commodity
        comm_frame = ctk.CTkFrame(cargo_frame, fg_color="transparent")
        comm_frame.pack(fill="x", padx=10, pady=(0, 10))
        ctk.CTkLabel(comm_frame, text="COMMODITY:").pack(side="left", padx=5)
        self.commodity = ctk.CTkEntry(comm_frame, width=400)
        self.commodity.pack(side="left", padx=5)
        ctk.CTkLabel(comm_frame, text="HS CODE:").pack(side="left", padx=10)
        self.hs_code = ctk.CTkEntry(comm_frame, width=120)
        self.hs_code.pack(side="left", padx=5)

        # Bottom Buttons
        bottom_bar = ctk.CTkFrame(self, fg_color="#FFFFFF")
        bottom_bar.pack(fill="x", padx=20, pady=(0, 20))
        ctk.CTkButton(bottom_bar, text="Reset", width=120, fg_color="#FFCDD2", text_color="#B71C1C", command=self._confirm_reset).grid(row=0, column=0, padx=2)
        ctk.CTkButton(bottom_bar, text="Save", width=120, fg_color="#3B82F6", command=self._save_operation).grid(row=0, column=1, padx=2)
        ctk.CTkButton(bottom_bar, text="Save & Close", width=140, fg_color="#E5E5EA", text_color="#333", command=self._save_and_close).grid(row=0, column=2, padx=2)

    def _toggle_ts_section(self):
        """Toggle T/S section visibility"""
        if self.ts_enabled_var.get():
            self.ts_frame.grid(row=7, column=0, sticky="ew", padx=20, pady=(5, 10))
        else:
            self.ts_frame.grid_forget()
            for row in self.ts_rows:
                row["frame"].destroy()
            self.ts_rows = []

    def _add_ts_row(self):
        row_frame = ctk.CTkFrame(self.ts_rows_frame, fg_color="transparent")
        row_frame.pack(fill="x", pady=2)
        
        row = {"frame": row_frame}
        row["port"] = ttk.Combobox(row_frame, width=18)
        row["port"]["values"] = [self.aol_combo._format_port(p) for p in self.aol_combo.ports]
        row["port"].pack(side="left", padx=5)
        row["flight"] = ctk.CTkEntry(row_frame, width=100)
        row["flight"].pack(side="left", padx=5)
        row["etd"] = ctk.CTkEntry(row_frame, width=100, placeholder_text="YYYY-MM-DD")
        row["etd"].pack(side="left", padx=5)
        row["eta"] = ctk.CTkEntry(row_frame, width=100, placeholder_text="YYYY-MM-DD")
        row["eta"].pack(side="left", padx=5)
        row["delete"] = ctk.CTkButton(row_frame, text="🗑", width=32, fg_color="#FFCDD2", text_color="#B71C1C", 
                                      command=lambda rf=row_frame: self._del_ts_row(rf))
        row["delete"].pack(side="left", padx=5)
        self.ts_rows.append(row)

    def _del_ts_row(self, row_frame):
        for i, row in enumerate(self.ts_rows):
            if row["frame"] == row_frame:
                row_frame.destroy()
                self.ts_rows.pop(i)
                break

    def _add_cargo_row(self):
        row_frame = ctk.CTkFrame(self.cargo_body, fg_color="transparent")
        row_frame.pack(fill="x", pady=2)
        
        row = {"frame": row_frame}
        row["pcs"] = ctk.CTkEntry(row_frame, width=50)
        row["pcs"].pack(side="left", padx=3)
        row["l"] = ctk.CTkEntry(row_frame, width=60)
        row["l"].pack(side="left", padx=3)
        row["w"] = ctk.CTkEntry(row_frame, width=60)
        row["w"].pack(side="left", padx=3)
        row["h"] = ctk.CTkEntry(row_frame, width=60)
        row["h"].pack(side="left", padx=3)
        row["cbm"] = ctk.CTkEntry(row_frame, width=70)
        row["cbm"].pack(side="left", padx=3)
        row["gw"] = ctk.CTkEntry(row_frame, width=70)
        row["gw"].pack(side="left", padx=3)
        row["cw"] = ctk.CTkEntry(row_frame, width=70)
        row["cw"].pack(side="left", padx=3)
        row["delete"] = ctk.CTkButton(row_frame, text="🗑", width=32, fg_color="#FFCDD2", text_color="#B71C1C",
                                      command=lambda rf=row_frame: self._del_cargo_row(rf))
        row["delete"].pack(side="left", padx=3)
        
        # Bind auto-calculation
        def calc_cbm_cw(*args):
            l_val = row["l"].get()
            w_val = row["w"].get()
            h_val = row["h"].get()
            gw_val = row["gw"].get()
            pcs_val = row["pcs"].get()
            
            try:
                pcs = int(pcs_val) if pcs_val else 1
            except:
                pcs = 1
            
            cbm = CargoDetailCalculator.calc_cbm(l_val, w_val, h_val, "cm") * pcs
            row["cbm"].delete(0, "end")
            row["cbm"].insert(0, f"{cbm:.4f}")
            
            cw = CargoDetailCalculator.calc_chargeable_weight(gw_val, cbm)
            row["cw"].delete(0, "end")
            row["cw"].insert(0, f"{cw:.2f}")
            
            self._update_cargo_totals()
        
        for key in ["l", "w", "h", "gw", "pcs"]:
            row[key].bind("<KeyRelease>", calc_cbm_cw)
        
        self.cargo_rows.append(row)

    def _del_cargo_row(self, row_frame):
        for i, row in enumerate(self.cargo_rows):
            if row["frame"] == row_frame:
                row_frame.destroy()
                self.cargo_rows.pop(i)
                self._update_cargo_totals()
                break

    def _update_cargo_totals(self):
        total_pcs = 0
        total_cbm = 0
        total_gw = 0
        total_cw = 0
        for row in self.cargo_rows:
            try: total_pcs += int(row["pcs"].get() or 0)
            except: pass
            try: total_cbm += float(row["cbm"].get() or 0)
            except: pass
            try: total_gw += float(row["gw"].get() or 0)
            except: pass
            try: total_cw += float(row["cw"].get() or 0)
            except: pass
        
        self.cargo_total_pcs.configure(text=f"PCS: {total_pcs}")
        self.cargo_total_cbm.configure(text=f"CBM: {total_cbm:.2f}")
        self.cargo_total_gw.configure(text=f"G.W: {total_gw:.2f} KG")
        self.cargo_total_cw.configure(text=f"C.W: {total_cw:.2f} KG")

    def _setup_customer_combo(self, combo):
        # Load Airlines from Provider (type='Airline')
        airlines = fetch_airlines()
        if airlines:
            combo["values"] = [f"{c[0]} - {c[1]}" for c in airlines if c[0] and c[1]]
        else:
            # Fallback to customers if no airlines defined
            customers = fetch_customers_for_combo()
            combo["values"] = [f"{c[0]} - {c[1]}" for c in customers if c[0] and c[1]]

    def _update_op(self):
        aol = self.aol_combo.get_code().upper()
        op = "EXPO" if "MX" in aol else "IMPO"
        self.op_entry.configure(state="normal")
        self.op_entry.delete(0, "end")
        self.op_entry.insert(0, op)
        self.op_entry.configure(state="disabled")

    def _on_customer_selected(self, customer_code):
        """Handle customer selection - hide parties_frame for Trucker/Airline/Shipping Line"""
        if not customer_code:
            self.parties_frame.grid()  # Show by default
            return
        
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT company_type, type FROM companies WHERE code = ?", (customer_code,))
            row = cur.fetchone()
            conn.close()
            
            if row:
                company_type = (row[0] or "").upper()
                old_type = (row[1] or "").upper()
                hide_types = ['TRUCKER', 'AIRLINE', 'SHIPPING_LINE', 'SHIPPING LINE', 
                              'CARRIER', 'TRUCKING', 'TRANSPORTER']
                
                should_hide = any(t in company_type or t in old_type for t in hide_types)
                
                if should_hide:
                    self.parties_frame.grid_remove()
                    self.shipper_combo.clear()
                    self.consignee_combo.clear()
                    self.notify_combo.clear()
                else:
                    self.parties_frame.grid()
            else:
                self.parties_frame.grid()
        except Exception as e:
            print(f"Error checking company type: {e}")
            self.parties_frame.grid()

    def _copy_cnee_to_noti(self):
        self.notify_combo.code_var.set(self.consignee_combo.get_code())
        self.notify_combo.name_var.set(self.consignee_combo.get_name())
        if self.notify_combo.show_address:
            self.notify_combo.addr_var.set(self.consignee_combo.get_address())

    def _confirm_reset(self):
        if messagebox.askyesno("Reset", "Reset all fields?"):
            self._reset_all()

    def _reset_all(self):
        for e in [self.quote_ref, self.mawb, self.hawb, self.flight_no, self.etd, self.eta, self.commodity, self.hs_code]:
            try: e.delete(0, "end")
            except: pass
        self.airline_var.set("")
        self.aol_combo.clear()
        self.aod_combo.clear()
        self.customer_combo.clear()
        self.partner_combo.clear()
        self.shipper_combo.clear()
        self.consignee_combo.clear()
        self.notify_combo.clear()
        for row in self.ts_rows:
            row["frame"].destroy()
        self.ts_rows = []
        for row in self.cargo_rows:
            row["frame"].destroy()
        self.cargo_rows = []
        self._add_cargo_row()

    def _generate_job_no(self):
        conn = get_connection()
        cur = conn.cursor()
        prefix = f"JAI{datetime.datetime.now().strftime('%Y%m%d')}"
        try:
            cur.execute("SELECT job_no FROM jobs WHERE job_no LIKE ? ORDER BY job_no DESC LIMIT 1", (f"{prefix}%",))
            row = cur.fetchone()
            seq = int(row[0][-3:]) + 1 if row else 1
            return f"{prefix}{str(seq).zfill(3)}"
        except:
            return f"{prefix}001"
        finally:
            conn.close()

    def _save_operation(self):
        customer = self.customer_combo.get_code() or self.customer_combo.get_name()
        if not customer:
            messagebox.showwarning("Required", "Customer is required.")
            return

        hawb_val = self.hawb.get().strip()
        if hawb_val and check_hbl_duplicate(hawb_val):
            messagebox.showerror("Duplicate HAWB", f"HAWB '{hawb_val}' already exists.")
            return

        job_no = self._generate_job_no()
        conn = get_connection()
        cur = conn.cursor()
        try:
            airline = self.airline_var.get().split(" - ")[0] if " - " in self.airline_var.get() else self.airline_var.get()
            partner = self.partner_combo.get_code() or self.partner_combo.get_name()
            
            cur.execute("""
                INSERT INTO jobs (job_no, mode, mbl, hbl, shipper, consignee, notify, customer, partner, carrier, pol, pod, etd, eta, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (job_no, "AIR", self.mawb.get(), hawb_val,
                  self.shipper_combo.get_name(), self.consignee_combo.get_name(), self.notify_combo.get_name(),
                  customer, partner, airline, self.aol_combo.get_code(), self.aod_combo.get_code(),
                  self.etd.get(), self.eta.get(), "OPEN", now_str(), now_str()))
            conn.commit()
            messagebox.showinfo("Saved", f"Job {job_no} saved successfully.")
            self._reset_all()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed to save: {e}")
        finally:
            conn.close()

    def _save_and_close(self): self._save_operation()
    def set_provider(self, p): self._provider = p
    def load(self, id=None): self._reset_all()
    def save(self): return {"ok": True}
    def get_state(self): return {}
    def is_dirty(self): return getattr(self, "_is_dirty", False)
    def reset(self): self._reset_all(); self._is_dirty = False


# ============================================================
# LAND REGISTRATION FRAME
# ============================================================
class LandRegFrame(ctk.CTkFrame):
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FAFAFA", width=width, height=height)
        self._is_dirty = False

        scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        scroll.pack(fill="both", expand=True, padx=8, pady=(38, 8))

        # Job Order / Quote Ref
        job_row = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        job_row.grid(row=0, column=0, sticky="w", padx=20, pady=(10, 10))

        ctk.CTkLabel(job_row, text="Job Order").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.job_order = ctk.CTkEntry(job_row, width=180)
        self.job_order.grid(row=0, column=1, sticky="w", padx=20, pady=3)
        self.job_order.insert(0, "AUTO")
        self.job_order.configure(state="disabled")

        ctk.CTkLabel(job_row, text="Quote Ref").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        self.quote_ref = ctk.CTkEntry(job_row, width=150)
        self.quote_ref.grid(row=0, column=3, sticky="w", padx=5, pady=3)
        ctk.CTkButton(job_row, text="🔍", width=32, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: search_quote_ref(self, self.quote_ref)).grid(row=0, column=4, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=1, column=0, sticky="ew", padx=20, pady=3)

        # Basic
        basic = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        basic.grid(row=2, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(basic, text="OP").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.op_var = ctk.StringVar()
        self.op_entry = ctk.CTkEntry(basic, width=100, textvariable=self.op_var, state="disabled")
        self.op_entry.grid(row=0, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="TRUCKER").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.trucker_combo = CustomerComboBox(basic, "", show_address=False, provider_type="Trucker")
        self.trucker_combo.grid(row=1, column=1, columnspan=2, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="VEHICLE NO").grid(row=2, column=0, sticky="w", padx=5, pady=3)
        self.vehicle_no = ctk.CTkEntry(basic, width=180)
        self.vehicle_no.grid(row=2, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="DRIVER NAME").grid(row=2, column=2, sticky="w", padx=5, pady=3)
        self.driver_name = ctk.CTkEntry(basic, width=180)
        self.driver_name.grid(row=2, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="DRIVER PHONE").grid(row=3, column=0, sticky="w", padx=5, pady=3)
        self.driver_phone = ctk.CTkEntry(basic, width=180)
        self.driver_phone.grid(row=3, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=3, column=0, sticky="ew", padx=20, pady=3)

        # Routing - Origin / Destination (like POL/POD)
        routing = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=8)
        routing.grid(row=4, column=0, sticky="ew", padx=20, pady=(0, 10))
        
        ctk.CTkLabel(routing, text="🚚 Route Information", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        
        route_body = ctk.CTkFrame(routing, fg_color="transparent")
        route_body.pack(fill="x", padx=10, pady=(0, 10))

        # Origin (like POL)
        origin_row = ctk.CTkFrame(route_body, fg_color="transparent")
        origin_row.pack(fill="x", pady=3)
        
        ctk.CTkLabel(origin_row, text="ORIGIN", width=80).pack(side="left", padx=5)
        self.origin_combo = PortComboBox(origin_row, "", "LAND")
        self.origin_combo.pack(side="left", padx=5)
        self.origin_combo.port_combo.bind("<KeyRelease>", lambda e: self._update_op())
        
        # Destination (like POD)
        dest_row = ctk.CTkFrame(route_body, fg_color="transparent")
        dest_row.pack(fill="x", pady=3)
        
        ctk.CTkLabel(dest_row, text="DESTINATION", width=80).pack(side="left", padx=5)
        self.dest_combo = PortComboBox(dest_row, "", "LAND")
        self.dest_combo.pack(side="left", padx=5)
        
        # Pickup/Delivery Address (detailed)
        addr_row = ctk.CTkFrame(route_body, fg_color="transparent")
        addr_row.pack(fill="x", pady=5)
        
        ctk.CTkLabel(addr_row, text="PICKUP ADDR", width=80).pack(side="left", padx=5)
        self.pickup_var = ctk.StringVar()
        self.pickup_entry = ctk.CTkEntry(addr_row, width=400, textvariable=self.pickup_var,
                                        placeholder_text="Full pickup address...")
        self.pickup_entry.pack(side="left", padx=5)
        
        deliv_row = ctk.CTkFrame(route_body, fg_color="transparent")
        deliv_row.pack(fill="x", pady=3)
        
        ctk.CTkLabel(deliv_row, text="DELIVERY ADDR", width=80).pack(side="left", padx=5)
        self.delivery_var = ctk.StringVar()
        self.delivery_entry = ctk.CTkEntry(deliv_row, width=400, textvariable=self.delivery_var,
                                          placeholder_text="Full delivery address...")
        self.delivery_entry.pack(side="left", padx=5)

        # Dates
        date_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        date_frame.grid(row=5, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(date_frame, text="PICKUP DATE").grid(row=0, column=0, padx=5, pady=3)
        self.pickup_date = ctk.CTkEntry(date_frame, width=130, placeholder_text="YYYY-MM-DD")
        self.pickup_date.grid(row=0, column=1, padx=5, pady=3)
        ctk.CTkButton(date_frame, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.pickup_date, self)).grid(row=0, column=2, padx=4)

        ctk.CTkLabel(date_frame, text="DELIVERY DATE").grid(row=0, column=3, padx=5, pady=3)
        self.delivery_date = ctk.CTkEntry(date_frame, width=130, placeholder_text="YYYY-MM-DD")
        self.delivery_date.grid(row=0, column=4, padx=5, pady=3)
        ctk.CTkButton(date_frame, text="📅", width=32, fg_color="#E5E5EA", text_color="#333", command=lambda: _open_date_picker(self.delivery_date, self)).grid(row=0, column=5, padx=4)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=6, column=0, sticky="ew", padx=20, pady=3)

        # CUSTOMER / PARTNER
        cust_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        cust_frame.grid(row=7, column=0, sticky="w", padx=20, pady=(6, 10))

        self.customer_combo = CustomerComboBox(cust_frame, "CUSTOMER", show_address=False)
        self.customer_combo.grid(row=0, column=0, sticky="w", padx=5, pady=3)

        self.partner_combo = CustomerComboBox(cust_frame, "PARTNER", show_address=False)
        self.partner_combo.grid(row=0, column=1, sticky="w", padx=20, pady=3)

        # Cargo Detail
        cargo_frame = ctk.CTkFrame(scroll, fg_color="#E8F5E9", corner_radius=10)
        cargo_frame.grid(row=8, column=0, sticky="ew", padx=20, pady=(5, 10))
        
        ctk.CTkLabel(cargo_frame, text="📦 Cargo / Vehicle Details", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        
        cargo_body = ctk.CTkFrame(cargo_frame, fg_color="#FFFFFF")
        cargo_body.pack(fill="x", padx=10, pady=(0, 10))
        
        row1 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        row1.pack(fill="x", pady=5)
        ctk.CTkLabel(row1, text="CNTR NO:").pack(side="left", padx=5)
        self.cntr_no = ctk.CTkEntry(row1, width=140)
        self.cntr_no.pack(side="left", padx=5)
        ctk.CTkLabel(row1, text="TYPE:").pack(side="left", padx=10)
        self.cntr_type = ctk.CTkComboBox(row1, values=["1 Ton", "3.5 Tons", "5 Tons", "8 Tons", "11 Tons", "15 Tons", "53ft", "Flatbed", "Lowbed", "Lowboy", "Container"], width=120)
        self.cntr_type.pack(side="left", padx=5)
        ctk.CTkLabel(row1, text="PCS:").pack(side="left", padx=10)
        self.pcs = ctk.CTkEntry(row1, width=60)
        self.pcs.pack(side="left", padx=5)
        ctk.CTkLabel(row1, text="PALLETS:").pack(side="left", padx=10)
        self.pallets = ctk.CTkEntry(row1, width=60)
        self.pallets.pack(side="left", padx=5)
        
        # Dimension row with auto-calculation
        row2 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        row2.pack(fill="x", pady=5)
        ctk.CTkLabel(row2, text="L(cm):").pack(side="left", padx=5)
        self.length = ctk.CTkEntry(row2, width=70)
        self.length.pack(side="left", padx=3)
        ctk.CTkLabel(row2, text="W(cm):").pack(side="left", padx=5)
        self.width_entry = ctk.CTkEntry(row2, width=70)
        self.width_entry.pack(side="left", padx=3)
        ctk.CTkLabel(row2, text="H(cm):").pack(side="left", padx=5)
        self.height = ctk.CTkEntry(row2, width=70)
        self.height.pack(side="left", padx=3)
        ctk.CTkLabel(row2, text="CBM:").pack(side="left", padx=10)
        self.cbm = ctk.CTkEntry(row2, width=80)
        self.cbm.pack(side="left", padx=3)
        ctk.CTkLabel(row2, text="R/T:").pack(side="left", padx=10)
        self.rt = ctk.CTkEntry(row2, width=70)
        self.rt.pack(side="left", padx=3)
        
        row3 = ctk.CTkFrame(cargo_body, fg_color="transparent")
        row3.pack(fill="x", pady=5)
        ctk.CTkLabel(row3, text="WEIGHT(KG):").pack(side="left", padx=5)
        self.weight = ctk.CTkEntry(row3, width=80)
        self.weight.pack(side="left", padx=5)
        ctk.CTkLabel(row3, text="COMMODITY:").pack(side="left", padx=10)
        self.commodity = ctk.CTkEntry(row3, width=400)
        self.commodity.pack(side="left", padx=5)
        
        # Bind auto-calculation for L×W×H→CBM and R/T
        def calc_cbm_rt(*args):
            l_val = self.length.get()
            w_val = self.width_entry.get()
            h_val = self.height.get()
            weight_val = self.weight.get()
            pcs_val = self.pcs.get()
            
            try:
                pcs = int(pcs_val) if pcs_val else 1
            except:
                pcs = 1
            
            cbm = CargoDetailCalculator.calc_cbm(l_val, w_val, h_val, "cm") * pcs
            self.cbm.delete(0, "end")
            self.cbm.insert(0, f"{cbm:.4f}")
            
            rt = CargoDetailCalculator.calc_revenue_ton(weight_val, cbm)
            self.rt.delete(0, "end")
            self.rt.insert(0, f"{rt:.4f}")
        
        for entry in [self.length, self.width_entry, self.height, self.weight, self.pcs]:
            entry.bind("<KeyRelease>", calc_cbm_rt)

        # Bottom Buttons
        bottom = ctk.CTkFrame(self, fg_color="#FFFFFF")
        bottom.pack(fill="x", padx=20, pady=(0, 20))
        ctk.CTkButton(bottom, text="Reset", width=120, fg_color="#FFCDD2", text_color="#B71C1C", command=self._confirm_reset).grid(row=0, column=0, padx=2)
        ctk.CTkButton(bottom, text="Save", width=120, fg_color="#3B82F6", command=self._save_operation).grid(row=0, column=1, padx=2)
        ctk.CTkButton(bottom, text="Save & Close", width=140, fg_color="#E5E5EA", text_color="#333", command=self._save_and_close).grid(row=0, column=2, padx=2)

    def _update_op(self):
        origin = self.origin_combo.get_code().upper()
        op = "EXPO" if origin.startswith("MX") or "MEXICO" in origin else "IMPO"
        self.op_entry.configure(state="normal")
        self.op_entry.delete(0, "end")
        self.op_entry.insert(0, op)
        self.op_entry.configure(state="disabled")

    def _confirm_reset(self):
        if messagebox.askyesno("Reset", "Reset?"): self._reset_all()

    def _reset_all(self):
        for e in [self.quote_ref, self.vehicle_no, self.driver_name, self.driver_phone, self.pickup_date, self.delivery_date,
                  self.cntr_no, self.pcs, self.weight, self.cbm, self.pallets, self.commodity, 
                  self.length, self.width_entry, self.height, self.rt]:
            try: e.delete(0, "end")
            except: pass
        self.pickup_var.set("")
        self.delivery_var.set("")
        self.cntr_type.set("")
        self.origin_combo.clear()
        self.dest_combo.clear()
        self.trucker_combo.clear()
        self.customer_combo.clear()
        self.partner_combo.clear()

    def _generate_job_no(self):
        conn = get_connection()
        cur = conn.cursor()
        prefix = f"JLA{datetime.datetime.now().strftime('%Y%m%d')}"
        try:
            cur.execute("SELECT job_no FROM jobs WHERE job_no LIKE ? ORDER BY job_no DESC LIMIT 1", (f"{prefix}%",))
            row = cur.fetchone()
            seq = int(row[0][-3:]) + 1 if row else 1
            return f"{prefix}{str(seq).zfill(3)}"
        except:
            return f"{prefix}001"
        finally:
            conn.close()

    def _save_operation(self):
        customer = self.customer_combo.get_code() or self.customer_combo.get_name()
        if not customer:
            messagebox.showwarning("Required", "Customer is required.")
            return

        job_no = self._generate_job_no()
        conn = get_connection()
        cur = conn.cursor()
        try:
            trucker = self.trucker_combo.get_code() or self.trucker_combo.get_name()
            partner = self.partner_combo.get_code() or self.partner_combo.get_name()
            
            # Use origin/destination codes for POL/POD fields
            origin = self.origin_combo.get_code()
            destination = self.dest_combo.get_code()
            
            # Store pickup/delivery addresses in remarks or separate fields
            pickup_addr = self.pickup_var.get()
            delivery_addr = self.delivery_var.get()
            remarks = f"Pickup: {pickup_addr}\nDelivery: {delivery_addr}" if pickup_addr or delivery_addr else ""
            
            cur.execute("""
                INSERT INTO jobs (job_no, mode, customer, partner, carrier, truck_line, 
                                  pol, pod, etd, eta, remarks, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (job_no, "LAND", customer, partner, trucker, trucker,
                  origin, destination,
                  self.pickup_date.get(), self.delivery_date.get(),
                  remarks, "OPEN", now_str(), now_str()))
            conn.commit()
            messagebox.showinfo("Saved", f"Job {job_no} saved.\nOrigin: {origin} → Destination: {destination}")
            self._reset_all()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed: {e}")
        finally:
            conn.close()

    def _save_and_close(self): self._save_operation()
    def set_provider(self, p): self._provider = p
    def load(self, id=None): self._reset_all()
    def save(self): return {"ok": True}
    def get_state(self): return {}
    def is_dirty(self): return getattr(self, "_is_dirty", False)
    def reset(self): self._reset_all(); self._is_dirty = False
