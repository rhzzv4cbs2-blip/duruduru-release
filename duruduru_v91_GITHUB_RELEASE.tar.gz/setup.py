#!/usr/bin/env python3
# setup.py
# DURUDURU Freight System Setup

from setuptools import setup, find_packages
import os

# Read README
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

# Read requirements
def read_requirements(filename):
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

setup(
    name='duruduru-freight',
    version='10.0.0',
    author='DURUDURU Team',
    author_email='support@duruduru.com',
    description='Freight Forwarding Management System',
    long_description=read_file('README.md') if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/duruduru/freight-system',
    
    packages=find_packages(exclude=['tests*']),
    py_modules=[
        'main', 'db', 'auth',
        'ui_order_reg', 'ui_status', 'ui_settlement', 
        'ui_accounting', 'ui_settings', 'ui_dashboard', 'ui_quotation',
        'pdf_export', 'styles', 'provider_mock', 'autocomplete_util', 'ui_components'
    ],
    
    include_package_data=True,
    package_data={
        '': ['app_icon.iconset/*'],
    },
    
    install_requires=[
        'customtkinter>=5.0.0',
        'Pillow>=9.0.0',
        'reportlab>=3.6.0',
        'tkcalendar>=1.6.0',
    ],
    
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=4.0.0',
            'pytest-html>=3.0.0',
            'flake8>=5.0.0',
            'black>=22.0.0',
            'isort>=5.0.0',
            'mypy>=0.990',
        ],
        'build': [
            'pyinstaller>=5.0.0',
            'py2app>=0.28',
        ],
    },
    
    entry_points={
        'console_scripts': [
            'duruduru=main:main',
        ],
        'gui_scripts': [
            'duruduru-gui=main:main',
        ],
    },
    
    python_requires='>=3.9',
    
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: MacOS X',
        'Environment :: Win32 (MS Windows)',
        'Environment :: X11 Applications :: GTK',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Office/Business',
    ],
    
    keywords='freight forwarding logistics shipping management',
    
    project_urls={
        'Documentation': 'https://github.com/duruduru/freight-system/docs',
        'Source': 'https://github.com/duruduru/freight-system',
        'Tracker': 'https://github.com/duruduru/freight-system/issues',
    },
)
