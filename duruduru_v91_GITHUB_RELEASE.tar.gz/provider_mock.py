# provider_mock.py
import time

class MockProvider:
    def __init__(self):
        self._store = {}
        self._next_id = 1

    def get_shipment(self, id):
        if id is None:
            return {}
        return self._store.get(id, {})

    def save_shipment(self, data):
        sid = data.get("id")
        if sid:
            self._store[sid] = data
            return {"ok": True, "id": sid}
        new_id = self._next_id
        self._next_id += 1
        data["id"] = new_id
        data["saved_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._store[new_id] = data
        return {"ok": True, "id": new_id}

    def list_customers(self):
        return ["Customer A", "Customer B", "Customer C"]

    def list_partners(self):
        return ["Partner X", "Partner Y", "Partner Z"]