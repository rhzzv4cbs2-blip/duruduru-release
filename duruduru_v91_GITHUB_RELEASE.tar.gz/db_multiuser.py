# db_multiuser.py
# Multi-User Database Access with Locking Support
# v37 - 2026-01-09

import sqlite3
import threading
import time
import os
import socket
from datetime import datetime
from contextlib import contextmanager

# =============================================================================
# CONFIGURATION
# =============================================================================
DB_PATH = os.path.join(os.path.expanduser("~"), ".duruduru", "duruduru.db")
LOCK_TIMEOUT = 30  # seconds
MAX_RETRIES = 3
RETRY_DELAY = 0.5  # seconds


# =============================================================================
# CONNECTION POOL
# =============================================================================
class ConnectionPool:
    """Thread-safe connection pool for SQLite"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self._local = threading.local()
        self._connections = {}
        self._connection_lock = threading.Lock()
        self._initialized = True
    
    def get_connection(self):
        """Get connection for current thread"""
        thread_id = threading.current_thread().ident
        
        with self._connection_lock:
            if thread_id not in self._connections:
                conn = sqlite3.connect(
                    DB_PATH,
                    timeout=LOCK_TIMEOUT,
                    check_same_thread=False,
                    isolation_level="DEFERRED"
                )
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA busy_timeout=30000")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.row_factory = sqlite3.Row
                self._connections[thread_id] = conn
            
            return self._connections[thread_id]
    
    def close_all(self):
        """Close all connections"""
        with self._connection_lock:
            for conn in self._connections.values():
                try:
                    conn.close()
                except:
                    pass
            self._connections.clear()


# Global pool instance
_pool = ConnectionPool()


def get_connection():
    """Get database connection from pool"""
    return _pool.get_connection()


def close_connections():
    """Close all connections"""
    _pool.close_all()


# =============================================================================
# TRANSACTION MANAGEMENT
# =============================================================================
@contextmanager
def transaction():
    """
    Context manager for database transactions with automatic retry
    
    Usage:
        with transaction() as cur:
            cur.execute("INSERT INTO ...")
            cur.execute("UPDATE ...")
        # Auto-commit on success, auto-rollback on exception
    """
    conn = get_connection()
    cur = conn.cursor()
    
    for attempt in range(MAX_RETRIES):
        try:
            cur.execute("BEGIN IMMEDIATE")
            yield cur
            conn.commit()
            return
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() and attempt < MAX_RETRIES - 1:
                conn.rollback()
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                conn.rollback()
                raise
        except Exception:
            conn.rollback()
            raise


# =============================================================================
# RECORD LOCKING
# =============================================================================
def ensure_lock_table():
    """Create record lock table"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS record_locks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        table_name TEXT NOT NULL,
        record_id INTEGER NOT NULL,
        locked_by TEXT NOT NULL,
        locked_at TEXT NOT NULL,
        machine_id TEXT,
        expires_at TEXT,
        UNIQUE(table_name, record_id)
    )""")
    conn.commit()


def acquire_lock(table_name: str, record_id: int, username: str, 
                 timeout_seconds: int = 300) -> bool:
    """
    Acquire a lock on a specific record
    
    Args:
        table_name: Table name (jobs, quotes, settlements, etc.)
        record_id: Record ID
        username: Current user
        timeout_seconds: Lock expiration time
    
    Returns:
        True if lock acquired, False if already locked by another user
    """
    ensure_lock_table()
    
    machine_id = f"{socket.gethostname()}_{os.getpid()}"
    now = datetime.now()
    expires = datetime.fromtimestamp(now.timestamp() + timeout_seconds)
    
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        # Check existing lock
        cur.execute("""SELECT locked_by, expires_at FROM record_locks 
                      WHERE table_name=? AND record_id=?""",
                   (table_name, record_id))
        row = cur.fetchone()
        
        if row:
            # Check if expired
            expires_at = datetime.fromisoformat(row["expires_at"]) if row["expires_at"] else None
            
            if expires_at and expires_at < now:
                # Lock expired, can take over
                cur.execute("""UPDATE record_locks 
                              SET locked_by=?, locked_at=?, machine_id=?, expires_at=?
                              WHERE table_name=? AND record_id=?""",
                           (username, now.isoformat(), machine_id, expires.isoformat(),
                            table_name, record_id))
                conn.commit()
                return True
            elif row["locked_by"] == username:
                # Same user, extend lock
                cur.execute("""UPDATE record_locks SET expires_at=?
                              WHERE table_name=? AND record_id=?""",
                           (expires.isoformat(), table_name, record_id))
                conn.commit()
                return True
            else:
                # Locked by another user
                return False
        else:
            # No existing lock
            cur.execute("""INSERT INTO record_locks 
                          (table_name, record_id, locked_by, locked_at, machine_id, expires_at)
                          VALUES (?, ?, ?, ?, ?, ?)""",
                       (table_name, record_id, username, now.isoformat(), 
                        machine_id, expires.isoformat()))
            conn.commit()
            return True
            
    except sqlite3.IntegrityError:
        # Race condition - another process got the lock
        return False


def release_lock(table_name: str, record_id: int, username: str = None) -> bool:
    """
    Release a lock on a specific record
    
    Args:
        table_name: Table name
        record_id: Record ID
        username: If provided, only release if locked by this user
    
    Returns:
        True if released, False otherwise
    """
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        if username:
            cur.execute("""DELETE FROM record_locks 
                          WHERE table_name=? AND record_id=? AND locked_by=?""",
                       (table_name, record_id, username))
        else:
            cur.execute("""DELETE FROM record_locks 
                          WHERE table_name=? AND record_id=?""",
                       (table_name, record_id))
        
        conn.commit()
        return cur.rowcount > 0
    except:
        return False


def get_lock_info(table_name: str, record_id: int) -> dict:
    """
    Get lock information for a record
    
    Returns:
        {"locked": bool, "locked_by": str, "expires_at": str} or {"locked": False}
    """
    ensure_lock_table()
    
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("""SELECT locked_by, locked_at, expires_at FROM record_locks 
                  WHERE table_name=? AND record_id=?""",
               (table_name, record_id))
    row = cur.fetchone()
    
    if row:
        expires_at = datetime.fromisoformat(row["expires_at"]) if row["expires_at"] else None
        if expires_at and expires_at < datetime.now():
            # Lock expired
            return {"locked": False}
        
        return {
            "locked": True,
            "locked_by": row["locked_by"],
            "locked_at": row["locked_at"],
            "expires_at": row["expires_at"]
        }
    
    return {"locked": False}


def cleanup_expired_locks():
    """Remove all expired locks"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""DELETE FROM record_locks WHERE expires_at < ?""",
               (datetime.now().isoformat(),))
    deleted = cur.rowcount
    conn.commit()
    return deleted


def get_user_locks(username: str) -> list:
    """Get all locks held by a user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""SELECT table_name, record_id, locked_at, expires_at 
                  FROM record_locks WHERE locked_by=?""",
               (username,))
    return [dict(row) for row in cur.fetchall()]


def release_all_user_locks(username: str) -> int:
    """Release all locks held by a user (e.g., on logout)"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM record_locks WHERE locked_by=?", (username,))
    count = cur.rowcount
    conn.commit()
    return count


# =============================================================================
# CONCURRENT UPDATE CHECK
# =============================================================================
def check_version(table_name: str, record_id: int, expected_version: int) -> bool:
    """
    Check if record version matches (optimistic locking)
    
    Requires table to have 'version' column
    """
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute(f"SELECT version FROM {table_name} WHERE id=?", (record_id,))
    row = cur.fetchone()
    
    if row:
        return row["version"] == expected_version
    return False


def increment_version(table_name: str, record_id: int):
    """Increment record version number"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(f"UPDATE {table_name} SET version = version + 1 WHERE id=?", (record_id,))
    conn.commit()


# =============================================================================
# USER SESSION MANAGEMENT
# =============================================================================
def register_session(username: str) -> str:
    """Register a user session"""
    ensure_session_table()
    
    session_id = f"{username}_{socket.gethostname()}_{os.getpid()}_{int(time.time())}"
    
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""INSERT INTO user_sessions (session_id, username, machine_name, started_at, last_activity)
                  VALUES (?, ?, ?, ?, ?)""",
               (session_id, username, socket.gethostname(), 
                datetime.now().isoformat(), datetime.now().isoformat()))
    conn.commit()
    
    return session_id


def update_session_activity(session_id: str):
    """Update last activity time for a session"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_sessions SET last_activity=? WHERE session_id=?",
               (datetime.now().isoformat(), session_id))
    conn.commit()


def end_session(session_id: str):
    """End a user session and release all locks"""
    conn = get_connection()
    cur = conn.cursor()
    
    # Get username
    cur.execute("SELECT username FROM user_sessions WHERE session_id=?", (session_id,))
    row = cur.fetchone()
    
    if row:
        release_all_user_locks(row["username"])
    
    cur.execute("DELETE FROM user_sessions WHERE session_id=?", (session_id,))
    conn.commit()


def get_active_users() -> list:
    """Get list of active users (last activity within 5 minutes)"""
    ensure_session_table()
    
    conn = get_connection()
    cur = conn.cursor()
    
    threshold = datetime.fromtimestamp(time.time() - 300).isoformat()
    
    cur.execute("""SELECT DISTINCT username, machine_name, last_activity 
                  FROM user_sessions WHERE last_activity > ?""",
               (threshold,))
    
    return [dict(row) for row in cur.fetchall()]


def ensure_session_table():
    """Create session table"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS user_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT UNIQUE,
        username TEXT,
        machine_name TEXT,
        started_at TEXT,
        last_activity TEXT
    )""")
    conn.commit()


# =============================================================================
# CONFLICT DETECTION
# =============================================================================
class ConflictError(Exception):
    """Raised when a concurrent modification conflict is detected"""
    pass


def save_with_conflict_check(table_name: str, record_id: int, 
                             update_func, username: str):
    """
    Save record with conflict detection
    
    Args:
        table_name: Table name
        record_id: Record ID (None for new records)
        update_func: Function(cursor) that performs the update
        username: Current user
    
    Raises:
        ConflictError if record is locked by another user
    """
    if record_id:
        # Check lock for existing record
        lock_info = get_lock_info(table_name, record_id)
        if lock_info["locked"] and lock_info["locked_by"] != username:
            raise ConflictError(
                f"Record is being edited by {lock_info['locked_by']}"
            )
        
        # Acquire lock
        if not acquire_lock(table_name, record_id, username):
            raise ConflictError("Could not acquire lock on record")
    
    try:
        with transaction() as cur:
            result = update_func(cur)
        
        return result
    finally:
        if record_id:
            release_lock(table_name, record_id, username)


# =============================================================================
# UTILITY
# =============================================================================
def now_str():
    """Get current timestamp as string"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =============================================================================
# TEST
# =============================================================================
if __name__ == "__main__":
    print("Multi-User Database Test")
    print("=" * 50)
    
    # Test connection pool
    conn = get_connection()
    print(f"✓ Connection established")
    
    # Test locking
    ensure_lock_table()
    
    result = acquire_lock("jobs", 1, "user1")
    print(f"✓ Lock acquired: {result}")
    
    info = get_lock_info("jobs", 1)
    print(f"✓ Lock info: {info}")
    
    result2 = acquire_lock("jobs", 1, "user2")
    print(f"✓ Second lock attempt (should fail): {result2}")
    
    release_lock("jobs", 1, "user1")
    print(f"✓ Lock released")
    
    # Test session
    session = register_session("testuser")
    print(f"✓ Session registered: {session[:30]}...")
    
    users = get_active_users()
    print(f"✓ Active users: {len(users)}")
    
    end_session(session)
    print(f"✓ Session ended")
    
    print("\nAll tests passed!")


# =============================================================================
# AUDIT TRAIL
# =============================================================================

def ensure_audit_table():
    """Create audit trail table"""
    conn = get_multiuser_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_trail (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            username TEXT NOT NULL,
            action TEXT NOT NULL,
            table_name TEXT,
            record_id INTEGER,
            old_values TEXT,
            new_values TEXT,
            ip_address TEXT,
            machine_id TEXT
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_trail(timestamp)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_table ON audit_trail(table_name, record_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_trail(username)")
    conn.commit()


def log_audit(username: str, action: str, table_name: str = None, record_id: int = None,
              old_values: dict = None, new_values: dict = None):
    """Log an audit trail entry"""
    import json
    
    ensure_audit_table()
    conn = get_multiuser_connection()
    cur = conn.cursor()
    
    try:
        cur.execute("""
            INSERT INTO audit_trail (timestamp, username, action, table_name, record_id,
                                     old_values, new_values, ip_address, machine_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            username,
            action,
            table_name,
            record_id,
            json.dumps(old_values) if old_values else None,
            json.dumps(new_values) if new_values else None,
            socket.gethostbyname(socket.gethostname()),
            get_machine_id()
        ))
        conn.commit()
    except Exception as e:
        print(f"Audit log error: {e}")


def get_audit_history(table_name: str = None, record_id: int = None, 
                      username: str = None, limit: int = 100) -> list:
    """Get audit trail history"""
    import json
    
    ensure_audit_table()
    conn = get_multiuser_connection()
    cur = conn.cursor()
    
    query = "SELECT * FROM audit_trail WHERE 1=1"
    params = []
    
    if table_name:
        query += " AND table_name = ?"
        params.append(table_name)
    if record_id:
        query += " AND record_id = ?"
        params.append(record_id)
    if username:
        query += " AND username = ?"
        params.append(username)
    
    query += " ORDER BY timestamp DESC LIMIT ?"
    params.append(limit)
    
    cur.execute(query, params)
    columns = [desc[0] for desc in cur.description]
    
    results = []
    for row in cur.fetchall():
        entry = dict(zip(columns, row))
        if entry.get('old_values'):
            try:
                entry['old_values'] = json.loads(entry['old_values'])
            except:
                pass
        if entry.get('new_values'):
            try:
                entry['new_values'] = json.loads(entry['new_values'])
            except:
                pass
        results.append(entry)
    
    return results


# =============================================================================
# OPTIMISTIC LOCKING (Version Control)
# =============================================================================

def get_record_version(table_name: str, record_id: int) -> int:
    """Get current version of a record"""
    conn = get_multiuser_connection()
    cur = conn.cursor()
    
    try:
        # Check if table has version column
        cur.execute(f"PRAGMA table_info({table_name})")
        columns = [row[1] for row in cur.fetchall()]
        
        if 'version' not in columns:
            # Add version column if not exists
            cur.execute(f"ALTER TABLE {table_name} ADD COLUMN version INTEGER DEFAULT 1")
            conn.commit()
            return 1
        
        cur.execute(f"SELECT version FROM {table_name} WHERE id = ?", (record_id,))
        row = cur.fetchone()
        return row[0] if row else 1
        
    except Exception as e:
        print(f"Get version error: {e}")
        return 1


def check_and_update_version(table_name: str, record_id: int, expected_version: int) -> bool:
    """
    Check version and increment if matches (optimistic locking)
    Returns True if update succeeded, False if version mismatch
    """
    conn = get_multiuser_connection()
    cur = conn.cursor()
    
    try:
        cur.execute(f"""
            UPDATE {table_name} 
            SET version = version + 1 
            WHERE id = ? AND version = ?
        """, (record_id, expected_version))
        
        conn.commit()
        return cur.rowcount > 0
        
    except Exception as e:
        print(f"Version update error: {e}")
        return False


def save_with_version_check(table_name: str, record_id: int, data: dict, 
                            expected_version: int, username: str) -> tuple:
    """
    Save record with optimistic locking
    Returns (success: bool, new_version: int, error_msg: str)
    """
    conn = get_multiuser_connection()
    cur = conn.cursor()
    
    try:
        # Get current version
        current_version = get_record_version(table_name, record_id)
        
        if current_version != expected_version:
            return (False, current_version, 
                   f"Record was modified by another user. Your version: {expected_version}, Current: {current_version}")
        
        # Build update query
        set_clause = ", ".join([f"{k} = ?" for k in data.keys()])
        values = list(data.values()) + [record_id, expected_version]
        
        cur.execute(f"""
            UPDATE {table_name} 
            SET {set_clause}, version = version + 1, updated_at = ?
            WHERE id = ? AND version = ?
        """.replace("version = version + 1, updated_at = ?", 
                   f"version = version + 1, updated_at = '{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'"),
           values)
        
        if cur.rowcount == 0:
            return (False, get_record_version(table_name, record_id),
                   "Update failed - record may have been modified")
        
        conn.commit()
        new_version = expected_version + 1
        
        # Log audit
        log_audit(username, "UPDATE", table_name, record_id, new_values=data)
        
        return (True, new_version, None)
        
    except Exception as e:
        return (False, expected_version, str(e))

