# db.py
# Robust SQLite helper with fixed DB location, safe schema initialization,
# automatic migration (add missing columns), and backup/migration utilities.

import sqlite3
import os
import shutil
from datetime import datetime
from typing import List, Tuple, Optional

# --- Configuration: canonical DB location in user's home directory
DB_DIR = os.path.join(os.path.expanduser("~"), ".duruduru")
DB_FILE = os.path.join(DB_DIR, "duruduru.db")


def _ensure_db_dir():
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR, exist_ok=True)


def _db_path() -> str:
    _ensure_db_dir()
    return os.path.abspath(DB_FILE)


# --- Connection factory: always opens canonical DB and ensures schema
def get_connection() -> sqlite3.Connection:
    """
    Get database connection with optimized settings.
    
    Performance optimizations:
    - WAL mode for better concurrent access
    - Increased cache size
    - Memory-based temp storage
    - Foreign keys enabled
    """
    db_path = _db_path()
    conn = sqlite3.connect(db_path, timeout=30.0)
    
    # Performance optimizations
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=10000")  # ~40MB cache
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA mmap_size=268435456")  # 256MB memory-mapped I/O
    conn.execute("PRAGMA foreign_keys=ON")
    
    ensure_db_initialized(conn)
    return conn


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# -------------------------
# Schema initialization + safe migration
# -------------------------
def ensure_db_initialized(conn: Optional[sqlite3.Connection] = None):
    """
    Create required tables if they don't exist.
    If tables exist but lack expected columns, add them (ALTER TABLE ADD COLUMN).
    Idempotent and safe to call multiple times.
    """
    close_conn = False
    if conn is None:
        conn = sqlite3.connect(_db_path())
        close_conn = True

    cur = conn.cursor()

    # ============================================================
    # JOBS (통합 작업 테이블)
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_no TEXT UNIQUE,
            mode TEXT,
            mbl TEXT,
            hbl TEXT,
            shipper TEXT,
            consignee TEXT,
            notify TEXT,
            customer TEXT,
            partner TEXT,
            carrier TEXT,
            vessel TEXT,
            voyage TEXT,
            pol TEXT,
            pod TEXT,
            etd TEXT,
            eta TEXT,
            atd TEXT,
            ata TEXT,
            status TEXT DEFAULT 'OPEN',
            profit REAL DEFAULT 0.0,
            remarks TEXT,
            created_at TEXT,
            updated_at TEXT
        )
        """
    )

    # ============================================================
    # CONTAINERS (Ocean FCL)
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS containers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER,
            cntr_no TEXT,
            cntr_type TEXT,
            seal_no TEXT,
            pcs TEXT,
            cbm TEXT,
            weight TEXT,
            ata TEXT,
            dispatch TEXT,
            delivery TEXT,
            status TEXT,
            location TEXT,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        )
        """
    )
    
    # Migration: Add missing columns to containers table
    cur.execute("PRAGMA table_info(containers)")
    existing_container_cols = [row[1] for row in cur.fetchall()]
    
    desired_container_columns = {
        "seal_no": "TEXT",
        "pcs": "TEXT",
    }
    
    for col, col_type in desired_container_columns.items():
        if col not in existing_container_cols:
            try:
                cur.execute(f"ALTER TABLE containers ADD COLUMN {col} {col_type}")
            except Exception:
                pass

    # ============================================================
    # AIR_JOBS (Air 전용 추가 정보)
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS air_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER,
            mawb TEXT,
            hawb TEXT,
            airline TEXT,
            flight_no TEXT,
            pcs INTEGER,
            weight REAL,
            volume REAL,
            chargeable_weight REAL,
            ata TEXT,
            delivery TEXT,
            status TEXT,
            location TEXT,
            ts_info TEXT,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        )
        """
    )

    # ============================================================
    # LAND_JOBS (Land 전용 추가 정보)
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS land_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER,
            job_no TEXT,
            trucker TEXT,
            vehicle_no TEXT,
            driver_name TEXT,
            driver_phone TEXT,
            pickup_location TEXT,
            delivery_location TEXT,
            pickup_date TEXT,
            delivery_date TEXT,
            pcs INTEGER,
            weight REAL,
            cbm REAL,
            pallet_count INTEGER,
            cntr_no TEXT,
            cntr_type TEXT,
            delivery TEXT,
            status TEXT,
            location TEXT,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        )
        """
    )

    # ============================================================
    # PORTS
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS ports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            name TEXT,
            city TEXT,
            province TEXT,
            country TEXT,
            type TEXT DEFAULT 'SEA'
        )
        """
    )

    # Seed ports if empty
    cur.execute("SELECT COUNT(*) FROM ports")
    try:
        count = cur.fetchone()[0]
    except Exception:
        count = 0
    if count == 0:
        sample_ports: List[Tuple[str, str, str, str, str]] = [
            ("KRPUS", "BUSAN", "BUSAN", "KOREA", "SEA"),
            ("KRINC", "INCHEON", "INCHEON", "KOREA", "SEA"),
            ("CNSHA", "SHANGHAI", "SHANGHAI", "CHINA", "SEA"),
            ("CNSZX", "SHENZHEN", "SHENZHEN", "CHINA", "SEA"),
            ("ICN", "INCHEON AIRPORT", "INCHEON", "KOREA", "AIR"),
            ("NRT", "NARITA AIRPORT", "TOKYO", "JAPAN", "AIR"),
            ("LAX", "LOS ANGELES AIRPORT", "LOS ANGELES", "USA", "AIR"),
        ]
        cur.executemany(
            "INSERT INTO ports (code, name, city, country, type) VALUES (?,?,?,?,?)",
            sample_ports,
        )

    # Ensure ports table has expected columns (safe migration)
    cur.execute("PRAGMA table_info(ports)")
    existing_port_cols = [row[1] for row in cur.fetchall()]

    desired_port_columns = {
        "code": "TEXT",
        "name": "TEXT",
        "city": "TEXT",
        "province": "TEXT",
        "country": "TEXT",
        "type": "TEXT"
    }

    for col, col_type in desired_port_columns.items():
        if col not in existing_port_cols:
            try:
                cur.execute(f"ALTER TABLE ports ADD COLUMN {col} {col_type}")
            except Exception:
                pass

    # ============================================================
    # COMPANIES
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_type TEXT,
            type TEXT,
            code TEXT,
            name TEXT,
            address TEXT,
            tax_id TEXT,
            bank_account TEXT,
            contact TEXT,
            phone TEXT,
            email TEXT,
            created_at TEXT,
            updated_at TEXT
        )
        """
    )

    # If companies existed with fewer columns, add missing columns
    cur.execute("PRAGMA table_info(companies)")
    existing_cols = [row[1] for row in cur.fetchall()]

    desired_columns = {
        "company_type": "TEXT",
        "type": "TEXT",
        "code": "TEXT",
        "name": "TEXT",
        "address": "TEXT",
        "tax_id": "TEXT",
        "bank_account": "TEXT",
        "contact": "TEXT",
        "phone": "TEXT",
        "email": "TEXT",
        "created_at": "TEXT",
        "updated_at": "TEXT",
    }

    for col, col_type in desired_columns.items():
        if col not in existing_cols:
            try:
                cur.execute(f"ALTER TABLE companies ADD COLUMN {col} {col_type}")
            except Exception:
                pass

    # ============================================================
    # QUOTES (견적서)
    # ============================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quote_ref TEXT UNIQUE,
            company TEXT,
            recipient TEXT,
            mode TEXT,
            type TEXT,
            origin TEXT,
            dest TEXT,
            valid_from TEXT,
            valid_to TEXT,
            incoterms TEXT,
            cargo TEXT,
            status TEXT,
            created_at TEXT
        )
    """)

    # ============================================================
    # QUOTE_ITEMS (견적서 항목)
    # ============================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS quote_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quote_ref TEXT,
            item TEXT,
            unit TEXT,
            curr TEXT,
            price TEXT,
            qty REAL,
            amount REAL,
            vat_pct TEXT,
            vat REAL,
            total REAL,
            remark TEXT,
            FOREIGN KEY(quote_ref) REFERENCES quotes(quote_ref)
        )
    """)

    # ============================================================
    # SETTLEMENT (정산 테이블)
    # ============================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS settlement (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bl_no TEXT,
            customer TEXT,
            charge_code TEXT,
            amount REAL,
            currency TEXT DEFAULT 'USD',
            type TEXT,
            mode TEXT,
            status TEXT DEFAULT 'UNPAID',
            due_date TEXT,
            paid_date TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)

    # ============================================================
    # SETTLEMENT_ITEMS (매출/매입 상세 항목)
    # ============================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS settlement_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER,
            item_type TEXT,
            customer TEXT,
            freight_code TEXT,
            freight_desc TEXT,
            currency TEXT DEFAULT 'USD',
            rate REAL DEFAULT 0,
            qty REAL DEFAULT 1,
            amount REAL DEFAULT 0,
            vat REAL DEFAULT 0,
            total REAL DEFAULT 0,
            invoice_no TEXT,
            folio TEXT,
            invoice_date TEXT,
            status TEXT DEFAULT 'PENDING',
            created_at TEXT,
            updated_at TEXT,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        )
    """)

    # Migration: Add missing columns to settlement_items
    cur.execute("PRAGMA table_info(settlement_items)")
    existing_settlement_cols = [row[1] for row in cur.fetchall()]
    
    desired_settlement_columns = {
        "job_id": "INTEGER",
        "item_type": "TEXT",
        "customer": "TEXT",
        "freight_code": "TEXT",
        "freight_desc": "TEXT",
        "currency": "TEXT DEFAULT 'USD'",
        "rate": "REAL DEFAULT 0",
        "qty": "REAL DEFAULT 1",
        "amount": "REAL DEFAULT 0",
        "vat": "REAL DEFAULT 0",
        "total": "REAL DEFAULT 0",
        "invoice_no": "TEXT",
        "folio": "TEXT",
        "invoice_date": "TEXT",
        "status": "TEXT DEFAULT 'PENDING'",
        "created_at": "TEXT",
        "updated_at": "TEXT",
    }
    
    for col, col_type in desired_settlement_columns.items():
        if col not in existing_settlement_cols:
            try:
                cur.execute(f"ALTER TABLE settlement_items ADD COLUMN {col} {col_type}")
            except Exception:
                pass

    # ============================================================
    # FREIGHT_CODES (운임 코드)
    # ============================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS freight_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            description TEXT,
            default_currency TEXT DEFAULT 'USD'
        )
    """)

    # Seed default freight codes if empty
    cur.execute("SELECT COUNT(*) FROM freight_codes")
    if cur.fetchone()[0] == 0:
        default_codes = [
            ("OFR", "Ocean Freight", "USD"),
            ("AFR", "Air Freight", "USD"),
            ("LFR", "Land Freight", "USD"),
            ("THC", "Terminal Handling Charge", "USD"),
            ("DOC", "Documentation Fee", "USD"),
            ("CFS", "CFS Charge", "USD"),
            ("DEM", "Demurrage", "USD"),
            ("DET", "Detention", "USD"),
            ("STG", "Storage", "USD"),
            ("HAZ", "Hazardous Cargo Surcharge", "USD"),
            ("INS", "Insurance", "USD"),
            ("CUS", "Customs Clearance", "MXN"),
            ("DEL", "Delivery", "MXN"),
            ("PKP", "Pickup", "MXN"),
            ("ADM", "Admin Fee", "USD"),
        ]
        cur.executemany("INSERT INTO freight_codes (code, description, default_currency) VALUES (?, ?, ?)", default_codes)

    # ============================================================
    # EXCHANGE RATES (환율 테이블)
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS exchange_rates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            from_currency TEXT NOT NULL DEFAULT 'USD',
            to_currency TEXT NOT NULL DEFAULT 'MXN',
            rate REAL NOT NULL,
            source TEXT DEFAULT 'MANUAL',
            created_at TEXT,
            UNIQUE(date, from_currency, to_currency)
        )
        """
    )

    # ============================================================
    # SLIPS (전표 테이블) - Invoice 연계
    # ============================================================
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS slips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slip_no TEXT UNIQUE,
            date TEXT,
            type TEXT,
            customer_code TEXT,
            customer_name TEXT,
            job_id INTEGER,
            job_no TEXT,
            mbl TEXT,
            hbl TEXT,
            invoice_no TEXT,
            description TEXT,
            amount REAL DEFAULT 0,
            currency TEXT DEFAULT 'USD',
            exchange_rate REAL DEFAULT 1,
            amount_mxn REAL DEFAULT 0,
            status TEXT DEFAULT 'PENDING',
            created_at TEXT,
            updated_at TEXT,
            FOREIGN KEY (job_id) REFERENCES jobs(id)
        )
        """
    )
    
    # ============================================================
    # MIGRATION: Handle old exchange_rates schema (rate_date → date)
    # ============================================================
    try:
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        
        if 'rate_date' in cols and 'date' not in cols:
            # Old schema - migrate data to new table
            cur.execute("""
                CREATE TABLE IF NOT EXISTS exchange_rates_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    from_currency TEXT NOT NULL DEFAULT 'USD',
                    to_currency TEXT NOT NULL DEFAULT 'MXN',
                    rate REAL NOT NULL,
                    source TEXT DEFAULT 'MANUAL',
                    created_at TEXT,
                    UNIQUE(date, from_currency, to_currency)
                )
            """)
            cur.execute("""
                INSERT OR IGNORE INTO exchange_rates_new (date, from_currency, to_currency, rate, source, created_at)
                SELECT rate_date, from_currency, to_currency, rate, source, created_at 
                FROM exchange_rates WHERE rate_date IS NOT NULL
            """)
            cur.execute("DROP TABLE exchange_rates")
            cur.execute("ALTER TABLE exchange_rates_new RENAME TO exchange_rates")
            conn.commit()
    except Exception as e:
        # Table might not exist yet, that's OK
        pass

    conn.commit()
    if close_conn:
        conn.close()


def get_exchange_rate_for_date(date_str: str, from_curr: str = "USD", to_curr: str = "MXN") -> float:
    """Get exchange rate for a specific date, handles both old and new schema"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which column exists
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        
        cur.execute(f"""
            SELECT rate FROM exchange_rates 
            WHERE {date_col} = ? AND from_currency = ? AND to_currency = ?
        """, (date_str, from_curr, to_curr))
        row = cur.fetchone()
        if row:
            return row[0]
        
        # Fallback: get closest rate before this date
        cur.execute(f"""
            SELECT rate FROM exchange_rates 
            WHERE {date_col} <= ? AND from_currency = ? AND to_currency = ?
            ORDER BY {date_col} DESC LIMIT 1
        """, (date_str, from_curr, to_curr))
        row = cur.fetchone()
        if row:
            return row[0]
        
        return 20.0  # Default fallback
    except Exception as e:
        print(f"Exchange rate query error: {e}")
        return 20.0
    finally:
        conn.close()


def save_exchange_rate(date_str: str, rate: float, from_curr: str = "USD", to_curr: str = "MXN", source: str = "MANUAL"):
    """Save or update exchange rate for a date, handles both old and new schema"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which columns exist
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        has_source = 'source' in cols
        
        if has_source:
            cur.execute(f"""
                INSERT OR REPLACE INTO exchange_rates ({date_col}, from_currency, to_currency, rate, source, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (date_str, from_curr, to_curr, rate, source, now_str()))
        else:
            cur.execute(f"""
                INSERT OR REPLACE INTO exchange_rates ({date_col}, from_currency, to_currency, rate, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (date_str, from_curr, to_curr, rate, now_str()))
        conn.commit()
    except Exception as e:
        print(f"Save exchange rate error: {e}")
    finally:
        conn.close()


# -------------------------
# Backwards-compatible init_db
# -------------------------
def init_db():
    ensure_db_initialized()


# -------------------------
# Backup / Migration utilities
# -------------------------
def backup_db(backup_path: Optional[str] = None) -> str:
    """
    Create a timestamped backup of the DB. Returns backup file path.
    """
    src = _db_path()
    if backup_path:
        dst = os.path.abspath(backup_path)
        dst_dir = os.path.dirname(dst)
        if dst_dir and not os.path.exists(dst_dir):
            os.makedirs(dst_dir, exist_ok=True)
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dst = os.path.join(DB_DIR, f"duruduru_backup_{ts}.db")
    shutil.copy2(src, dst)
    return dst


def migrate_existing_db(existing_db_path: str) -> str:
    """
    Copy an existing DB file into the canonical DB_DIR.
    """
    existing_db_path = os.path.abspath(existing_db_path)
    if not os.path.exists(existing_db_path):
        raise FileNotFoundError(f"Source DB not found: {existing_db_path}")
    dst = _db_path()
    if os.path.abspath(existing_db_path) == os.path.abspath(dst):
        return dst
    if os.path.exists(dst):
        backup_db()
    shutil.copy2(existing_db_path, dst)
    conn = sqlite3.connect(dst)
    ensure_db_initialized(conn)
    conn.close()
    return dst


# -------------------------
# Helper functions
# -------------------------
def compute_ocean_cntr_status(job_atd, ata, dispatch, delivery):
    if delivery:
        return "DELIVERED"
    if dispatch:
        return "CLEARED"
    if ata:
        return "TERMINAL"
    if job_atd:
        return "ON BOARD"
    return "BOOKED"


def compute_air_status(atd, ata, delivery):
    if delivery:
        return "DELIVERED"
    if ata:
        return "TERMINAL"
    if atd:
        return "ON BOARD"
    return "BOOKED"


def compute_land_status(pickup_date, delivery):
    if delivery:
        return "DELIVERED"
    if pickup_date:
        return "ON BOARD"
    return "BOOKED"


def get_sea_ports() -> List[str]:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT code, name, country FROM ports WHERE type='SEA'")
    rows = cur.fetchall()
    conn.close()
    return [f"{r[0]} - {r[1]}, {r[2]}" for r in rows]


def get_air_ports() -> List[str]:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT code, name, country FROM ports WHERE type='AIR'")
    rows = cur.fetchall()
    conn.close()
    return [f"{r[0]} - {r[1]}, {r[2]}" for r in rows]


# ============================================================
# EXCHANGE RATE AUTO-FETCH (DOF/Banxico)
# ============================================================
def fetch_exchange_rate_dof(date_str: str = None) -> Optional[float]:
    """
    Fetch USD/MXN exchange rate from multiple sources with fallback.
    
    Priority:
    1. Free APIs (open.er-api, exchangerate-api, frankfurter)
    2. DB cached value
    3. Default value (20.50)
    """
    import urllib.request
    import json
    import ssl
    
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    # List of free APIs to try
    free_apis = [
        {
            'name': 'open.er-api.com',
            'url': 'https://open.er-api.com/v6/latest/USD',
            'parser': lambda d: d.get('rates', {}).get('MXN')
        },
        {
            'name': 'exchangerate-api.com',
            'url': 'https://api.exchangerate-api.com/v4/latest/USD',
            'parser': lambda d: d.get('rates', {}).get('MXN')
        },
        {
            'name': 'frankfurter.app',
            'url': 'https://api.frankfurter.app/latest?from=USD&to=MXN',
            'parser': lambda d: d.get('rates', {}).get('MXN')
        }
    ]
    
    # Create SSL context that doesn't verify certificates (for testing)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    # Try each API
    for api in free_apis:
        try:
            req = urllib.request.Request(api['url'])
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            req.add_header('Accept', 'application/json')
            
            with urllib.request.urlopen(req, timeout=10, context=ctx) as response:
                data = json.loads(response.read().decode())
                rate = api['parser'](data)
                if rate and rate > 0:
                    print(f"Fetched exchange rate from {api['name']}: {rate}")
                    return float(rate)
        except urllib.error.URLError as e:
            print(f"Network error with {api['name']}: {e}")
        except Exception as e:
            print(f"Error with {api['name']}: {e}")
    
    # If all APIs fail, try to get from DB
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which column exists
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        
        cur.execute(f"""
            SELECT rate FROM exchange_rates 
            WHERE from_currency='USD' AND to_currency='MXN' 
            ORDER BY {date_col} DESC LIMIT 1
        """)
        row = cur.fetchone()
        if row and row[0]:
            print(f"Using cached rate from DB: {row[0]}")
            return row[0]
    except Exception as e:
        print(f"DB fallback error: {e}")
        pass
    finally:
        conn.close()
    
    # Return default rate as last resort
    print("Using default rate: 20.50")
    return 20.50


def auto_fetch_and_save_exchange_rate(date_str: str = None) -> Optional[float]:
    """
    Auto-fetch exchange rate and save to database
    Returns the rate if successful, None otherwise
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    # First check if we already have rate for this date
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which column exists
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        
        cur.execute(f"""
            SELECT rate FROM exchange_rates 
            WHERE {date_col} = ? AND from_currency = 'USD' AND to_currency = 'MXN'
        """, (date_str,))
        row = cur.fetchone()
        if row:
            return row[0]  # Already have rate for this date
    except Exception as e:
        print(f"Check rate error: {e}")
    finally:
        conn.close()
    
    # Fetch from API
    rate = fetch_exchange_rate_dof(date_str)
    
    if rate:
        save_exchange_rate(date_str, rate, "USD", "MXN", "DOF_API")
        return rate
    
    return None


def get_or_fetch_exchange_rate(date_str: str = None) -> float:
    """
    Get exchange rate for date, fetching from API if not in DB
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    # Try to get from DB first
    rate = get_exchange_rate_for_date(date_str, "USD", "MXN")
    
    # If no rate in DB, try to fetch
    if rate == 20.0:  # Default fallback means no rate found
        fetched_rate = auto_fetch_and_save_exchange_rate(date_str)
        if fetched_rate:
            return fetched_rate
    
    return rate


def sync_exchange_rates_for_month(year: int, month: int):
    """
    Sync exchange rates for an entire month
    Useful for batch updates
    """
    import calendar
    
    _, last_day = calendar.monthrange(year, month)
    
    for day in range(1, last_day + 1):
        date_str = f"{year:04d}-{month:02d}-{day:02d}"
        try:
            auto_fetch_and_save_exchange_rate(date_str)
        except Exception as e:
            print(f"Error fetching rate for {date_str}: {e}")


def init_exchange_rates_2026():
    """
    Initialize exchange rates for January 2026
    Call this once to populate initial data
    """
    # Pre-populate with approximate rates (will be updated with real data)
    jan_2026_rates = {
        "2026-01-01": 20.50,
        "2026-01-02": 20.52,
        "2026-01-03": 20.48,
        "2026-01-06": 20.55,
        "2026-01-07": 20.55,  # Today
    }
    
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which column exists
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        has_source = 'source' in cols
        
        for date_str, rate in jan_2026_rates.items():
            if has_source:
                cur.execute(f"""
                    INSERT OR IGNORE INTO exchange_rates ({date_col}, from_currency, to_currency, rate, source, created_at)
                    VALUES (?, 'USD', 'MXN', ?, 'INIT', ?)
                """, (date_str, rate, now_str()))
            else:
                cur.execute(f"""
                    INSERT OR IGNORE INTO exchange_rates ({date_col}, from_currency, to_currency, rate, created_at)
                    VALUES (?, 'USD', 'MXN', ?, ?)
                """, (date_str, rate, now_str()))
        conn.commit()
    except Exception as e:
        print(f"Init exchange rates error: {e}")
    finally:
        conn.close()
    
    # Now try to fetch real rates from API
    try:
        rate = fetch_exchange_rate_dof()
        if rate:
            save_exchange_rate(datetime.now().strftime("%Y-%m-%d"), rate, "USD", "MXN", "DOF_API")
    except:
        pass


def get_all_exchange_rates() -> List[Tuple]:
    """Get all stored exchange rates"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which column exists
        cur.execute("PRAGMA table_info(exchange_rates)")
        cols = [row[1] for row in cur.fetchall()]
        date_col = 'date' if 'date' in cols else 'rate_date'
        has_source = 'source' in cols
        
        if has_source:
            cur.execute(f"""
                SELECT {date_col}, from_currency, to_currency, rate, source, created_at 
                FROM exchange_rates 
                ORDER BY {date_col} DESC
            """)
        else:
            cur.execute(f"""
                SELECT {date_col}, from_currency, to_currency, rate, 'MANUAL', created_at 
                FROM exchange_rates 
                ORDER BY {date_col} DESC
            """)
        return cur.fetchall()
    except Exception as e:
        print(f"Get all rates error: {e}")
        return []
    finally:
        conn.close()