# notification.py
# Email Notification System for DURUDURU
# v37 - 2026-01-09

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os
from datetime import datetime
import json

try:
    from db import get_connection, now_str
except:
    def get_connection():
        import sqlite3
        return sqlite3.connect("duruduru.db")
    def now_str():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =============================================================================
# CONFIGURATION
# =============================================================================
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".duruduru")
EMAIL_CONFIG_FILE = os.path.join(CONFIG_DIR, "email_config.json")

DEFAULT_CONFIG = {
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "use_tls": True,
    "username": "",
    "password": "",
    "from_email": "",
    "from_name": "DURUDURU System",
    "enabled": False
}


# =============================================================================
# EMAIL TEMPLATES
# =============================================================================
TEMPLATES = {
    "job_created": {
        "subject": "[DURUDURU] New Job Created - {job_no}",
        "body": """
<html>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <h2 style="color: #007AFF;">New Job Created</h2>
    <p>A new job has been created in the DURUDURU system.</p>
    
    <table style="border-collapse: collapse; width: 100%; max-width: 500px;">
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Job No</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{job_no}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Customer</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{customer}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Mode</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{mode}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Route</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{pol} → {pod}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Created</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{created_at}</td>
        </tr>
    </table>
    
    <p style="margin-top: 20px; color: #666;">
        This is an automated message from DURUDURU Freight Forwarding System.
    </p>
</body>
</html>
"""
    },
    
    "status_update": {
        "subject": "[DURUDURU] Status Update - {job_no}",
        "body": """
<html>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <h2 style="color: #FF9500;">Job Status Updated</h2>
    
    <p>The status of job <strong>{job_no}</strong> has been updated.</p>
    
    <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0;"><strong>Previous Status:</strong> {old_status}</p>
        <p style="margin: 10px 0 0 0;"><strong>New Status:</strong> <span style="color: #34C759;">{new_status}</span></p>
    </div>
    
    <p style="color: #666;">Updated at: {updated_at}</p>
</body>
</html>
"""
    },
    
    "quote_sent": {
        "subject": "[DURUDURU] Quotation - {quote_no}",
        "body": """
<html>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <h2 style="color: #007AFF;">Quotation</h2>
    
    <p>Dear {customer},</p>
    
    <p>Please find attached our quotation for your shipment.</p>
    
    <table style="border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;">
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Quote No</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{quote_no}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Valid Until</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{valid_until}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Route</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{pol} → {pod}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Total</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd; color: #007AFF; font-weight: bold;">${total}</td>
        </tr>
    </table>
    
    <p>If you have any questions, please don't hesitate to contact us.</p>
    
    <p>Best regards,<br>DURUDURU Team</p>
</body>
</html>
"""
    },
    
    "settlement_notice": {
        "subject": "[DURUDURU] Settlement Notice - {settlement_no}",
        "body": """
<html>
<body style="font-family: Arial, sans-serif; padding: 20px;">
    <h2 style="color: #34C759;">Settlement Notice</h2>
    
    <p>Dear {customer},</p>
    
    <p>Please find below the settlement details for your shipment.</p>
    
    <table style="border-collapse: collapse; width: 100%; max-width: 500px; margin: 20px 0;">
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Settlement No</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{settlement_no}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Job No</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{job_no}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Total Amount</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd; color: #007AFF; font-weight: bold;">${total}</td>
        </tr>
        <tr>
            <td style="padding: 8px; border: 1px solid #ddd; background: #f5f5f5;"><strong>Due Date</strong></td>
            <td style="padding: 8px; border: 1px solid #ddd;">{due_date}</td>
        </tr>
    </table>
    
    <p>Please remit payment by the due date.</p>
    
    <p>Best regards,<br>DURUDURU Team</p>
</body>
</html>
"""
    }
}


# =============================================================================
# CONFIGURATION MANAGEMENT
# =============================================================================
def load_email_config():
    """Load email configuration"""
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        if os.path.exists(EMAIL_CONFIG_FILE):
            with open(EMAIL_CONFIG_FILE, "r") as f:
                config = json.load(f)
                return {**DEFAULT_CONFIG, **config}
    except:
        pass
    return DEFAULT_CONFIG.copy()


def save_email_config(config):
    """Save email configuration"""
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(EMAIL_CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        print(f"Save config error: {e}")
        return False


# =============================================================================
# EMAIL SENDING
# =============================================================================
def send_email(to_email, subject, body, attachments=None, is_html=True):
    """
    Send email using configured SMTP server
    
    Args:
        to_email: Recipient email address(es) - string or list
        subject: Email subject
        body: Email body (HTML or plain text)
        attachments: List of file paths to attach
        is_html: Whether body is HTML
    
    Returns:
        True if sent successfully, False otherwise
    """
    config = load_email_config()
    
    if not config.get("enabled"):
        print("Email notifications are disabled")
        return False
    
    if not config.get("username") or not config.get("password"):
        print("Email credentials not configured")
        return False
    
    try:
        # Create message
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = f"{config['from_name']} <{config['from_email'] or config['username']}>"
        
        if isinstance(to_email, list):
            msg["To"] = ", ".join(to_email)
            recipients = to_email
        else:
            msg["To"] = to_email
            recipients = [to_email]
        
        # Add body
        if is_html:
            msg.attach(MIMEText(body, "html"))
        else:
            msg.attach(MIMEText(body, "plain"))
        
        # Add attachments
        if attachments:
            for filepath in attachments:
                if os.path.exists(filepath):
                    with open(filepath, "rb") as f:
                        part = MIMEBase("application", "octet-stream")
                        part.set_payload(f.read())
                    encoders.encode_base64(part)
                    filename = os.path.basename(filepath)
                    part.add_header("Content-Disposition", f"attachment; filename={filename}")
                    msg.attach(part)
        
        # Send
        server = smtplib.SMTP(config["smtp_server"], config["smtp_port"])
        
        if config.get("use_tls"):
            server.starttls()
        
        server.login(config["username"], config["password"])
        server.sendmail(config["username"], recipients, msg.as_string())
        server.quit()
        
        # Log
        _log_email(to_email, subject, "SENT")
        
        return True
        
    except Exception as e:
        print(f"Email send error: {e}")
        _log_email(to_email, subject, f"FAILED: {e}")
        return False


def send_template_email(template_name, to_email, data, attachments=None):
    """
    Send email using a predefined template
    
    Args:
        template_name: Name of template (job_created, status_update, etc.)
        to_email: Recipient email
        data: Dictionary of data to fill template
        attachments: Optional file attachments
    
    Returns:
        True if sent successfully
    """
    if template_name not in TEMPLATES:
        print(f"Unknown template: {template_name}")
        return False
    
    template = TEMPLATES[template_name]
    
    try:
        subject = template["subject"].format(**data)
        body = template["body"].format(**data)
        
        return send_email(to_email, subject, body, attachments)
        
    except KeyError as e:
        print(f"Missing template data: {e}")
        return False


# =============================================================================
# NOTIFICATION TRIGGERS
# =============================================================================
def notify_job_created(job_no, customer, customer_email, mode, pol, pod):
    """Send notification when job is created"""
    if not customer_email:
        return False
    
    data = {
        "job_no": job_no,
        "customer": customer,
        "mode": mode,
        "pol": pol,
        "pod": pod,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    
    return send_template_email("job_created", customer_email, data)


def notify_status_update(job_no, customer_email, old_status, new_status):
    """Send notification when job status changes"""
    if not customer_email:
        return False
    
    data = {
        "job_no": job_no,
        "old_status": old_status,
        "new_status": new_status,
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    
    return send_template_email("status_update", customer_email, data)


def notify_quote_sent(quote_no, customer, customer_email, valid_until, pol, pod, total, attachment_path=None):
    """Send quotation to customer"""
    if not customer_email:
        return False
    
    data = {
        "quote_no": quote_no,
        "customer": customer,
        "valid_until": valid_until,
        "pol": pol,
        "pod": pod,
        "total": f"{total:,.2f}"
    }
    
    attachments = [attachment_path] if attachment_path else None
    
    return send_template_email("quote_sent", customer_email, data, attachments)


# =============================================================================
# LOGGING
# =============================================================================
def _log_email(to_email, subject, status):
    """Log email to database"""
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        cur.execute("""CREATE TABLE IF NOT EXISTS email_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            to_email TEXT,
            subject TEXT,
            status TEXT,
            created_at TEXT
        )""")
        
        cur.execute("""INSERT INTO email_log (to_email, subject, status, created_at)
                      VALUES (?, ?, ?, ?)""",
                   (str(to_email), subject, status, now_str()))
        
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Log email error: {e}")


# =============================================================================
# TEST
# =============================================================================
def test_email_connection():
    """Test email configuration"""
    config = load_email_config()
    
    if not config.get("enabled"):
        return False, "Email notifications are disabled"
    
    if not config.get("username") or not config.get("password"):
        return False, "Email credentials not configured"
    
    try:
        server = smtplib.SMTP(config["smtp_server"], config["smtp_port"])
        if config.get("use_tls"):
            server.starttls()
        server.login(config["username"], config["password"])
        server.quit()
        return True, "Connection successful"
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    # Test
    print("Email Configuration:")
    config = load_email_config()
    print(f"  Server: {config['smtp_server']}:{config['smtp_port']}")
    print(f"  Enabled: {config['enabled']}")
    
    success, msg = test_email_connection()
    print(f"  Connection Test: {'✓' if success else '✗'} {msg}")
