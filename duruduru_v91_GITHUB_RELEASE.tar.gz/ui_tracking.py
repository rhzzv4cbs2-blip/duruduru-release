# ui_tracking.py
# Carrier Tracking Module - Real API Integration
# Supports: ShipsGo API, TrackingMore API, JSONCargo API
# Created: 2026-01-08 v27

import tkinter as tk

# I18N
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"
from tkinter import ttk, messagebox
import customtkinter as ctk
from datetime import datetime
import threading
import urllib.request
import urllib.parse
import ssl
import json
import os

try:
    from db import get_connection, now_str
except ImportError:
    def get_connection():
        import sqlite3
        return sqlite3.connect("duruduru.db")
    def now_str():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# SSL context
def get_ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


# ============================================================
# TRACKING API CONFIGURATION
# ============================================================
# Users can configure their API keys in the Settings or here
TRACKING_CONFIG = {
    # ShipsGo - Free account provides 3 credits
    # Sign up at: https://shipsgo.com/
    "SHIPSGO_API_KEY": os.environ.get("SHIPSGO_API_KEY", ""),
    
    # TrackingMore - 7-day free trial
    # Sign up at: https://www.trackingmore.com/
    "TRACKINGMORE_API_KEY": os.environ.get("TRACKINGMORE_API_KEY", ""),
    
    # JSONCargo - Free tier available
    # Sign up at: https://jsoncargo.com/
    "JSONCARGO_API_KEY": os.environ.get("JSONCARGO_API_KEY", ""),
}

# Carrier information with BL transformation rules
CARRIERS = {
    "MAERSK": {"name": "Maersk", "code": "MAERSK LINE", "prefix": ["MAEU", "MSKU", "MRKU"],
               "track_url": "https://www.maersk.com/tracking/{bl}",
               "bl_transform": None},
    "MSC": {"name": "MSC", "code": "MSC", "prefix": ["MEDU", "MSCU", "MSDU"],
            "track_url": "https://www.msc.com/track-a-shipment?agencyPath=mex&trackingNumber={bl}",
            "bl_transform": None},
    "COSCO": {"name": "COSCO", "code": "COSCO", "prefix": ["COSU", "CBHU", "CCLU"],
              "track_url": "https://elines.coscoshipping.com/ebtracking/public/cntrTracking?trackingNumber={bl}",
              "bl_transform": None},
    "EVERGREEN": {"name": "Evergreen", "code": "EVERGREEN", "prefix": ["EGLV", "EGHU"],
                  "track_url": "https://www.evergreen-line.com/cargo-tracking?searchType=BL&searchNumber={bl}",
                  "bl_transform": None},
    "HAPAG": {"name": "Hapag-Lloyd", "code": "HAPAG LLOYD", "prefix": ["HLCU", "HLXU"],
              "track_url": "https://www.hapag-lloyd.com/en/online-business/track/track-by-booking-solution.html?blno={bl}",
              "bl_transform": None},
    "ONE": {"name": "ONE", "code": "ONE LINE", "prefix": ["ONEY", "ONEU"],
            "track_url": "https://ecomm.one-line.com/one-ecom/manage-shipment/cargo-tracking?trakNoParam={bl}",
            "bl_transform": None},
    "CMA": {"name": "CMA CGM", "code": "CMA CGM", "prefix": ["CMAU", "CGMU"],
            "track_url": "https://www.cma-cgm.com/ebusiness/tracking/search?SearchBy=BL&Reference={bl}",
            "bl_transform": None},
    "YANGMING": {"name": "Yang Ming", "code": "YANG MING", "prefix": ["YMLU", "YMMU"],
                 "track_url": "https://www.yangming.com/e-service/Track_Trace/track_trace_cargo_tracking.aspx?rdolType=BL&txtBLNo={bl}",
                 "bl_transform": None},
    "HMM": {"name": "HMM", "code": "HYUNDAI MM", "prefix": ["HDMU", "HDHU"],
            "track_url": "https://www.hmm21.com/e-service/general/trackNTrace/TrackNTrace.do?blNo={bl}",
            "bl_transform": "remove_prefix"},  # HMM requires BL without HDMU prefix
    "ZIM": {"name": "ZIM", "code": "ZIM LINE", "prefix": ["ZIMU", "ZCSU"],
            "track_url": "https://www.zim.com/tools/track-a-shipment?consnumber={bl}",
            "bl_transform": None},
    "PIL": {"name": "PIL", "code": "PIL", "prefix": ["PCIU"],
            "track_url": "https://www.pilship.com/en-our-services-ecommerce-track-a-shipment/100038.html?trackingNo={bl}",
            "bl_transform": None},
    "WANHAI": {"name": "Wan Hai", "code": "WAN HAI LINES", "prefix": ["WHLU", "WHSU"],
               "track_url": "https://www.wanhai.com/views/cargoTrack/CargoTrack.xhtml?bl_no={bl}",
               "bl_transform": None},
}


def transform_bl_for_carrier(carrier_code: str, bl_no: str) -> str:
    """Transform BL number based on carrier requirements"""
    carrier = CARRIERS.get(carrier_code.upper())
    if not carrier:
        return bl_no
    
    transform = carrier.get("bl_transform")
    
    if transform == "remove_prefix":
        # HMM: Remove first 4 characters (HDMU1234567890 → 1234567890)
        if len(bl_no) > 4 and bl_no[:4].isalpha():
            return bl_no[4:]
    
    return bl_no


def get_carrier_tracking_url(carrier_code: str, bl_no: str) -> str:
    """Get carrier tracking URL with BL number filled in (transformed if needed)"""
    carrier = CARRIERS.get(carrier_code.upper())
    if carrier and "track_url" in carrier:
        transformed_bl = transform_bl_for_carrier(carrier_code, bl_no)
        return carrier["track_url"].replace("{bl}", transformed_bl)
    return ""


class TrackingAPI:
    """Unified tracking API interface supporting multiple providers"""
    
    @staticmethod
    def track(carrier_code: str, tracking_no: str, api_key: str = None, provider: str = "auto") -> dict:
        """
        Track a container/shipment using configured API.
        
        Args:
            carrier_code: Carrier code (MAERSK, MSC, etc.)
            tracking_no: B/L, Container, or Booking number
            api_key: Optional API key override
            provider: 'shipsgo', 'trackingmore', 'jsoncargo', or 'auto'
            
        Returns:
            dict with tracking information
        """
        # Try providers in order
        providers = []
        
        if provider == "auto":
            if TRACKING_CONFIG["SHIPSGO_API_KEY"]:
                providers.append(("shipsgo", TRACKING_CONFIG["SHIPSGO_API_KEY"]))
            if TRACKING_CONFIG["TRACKINGMORE_API_KEY"]:
                providers.append(("trackingmore", TRACKING_CONFIG["TRACKINGMORE_API_KEY"]))
            if TRACKING_CONFIG["JSONCARGO_API_KEY"]:
                providers.append(("jsoncargo", TRACKING_CONFIG["JSONCARGO_API_KEY"]))
        elif provider == "shipsgo":
            providers.append(("shipsgo", api_key or TRACKING_CONFIG["SHIPSGO_API_KEY"]))
        elif provider == "trackingmore":
            providers.append(("trackingmore", api_key or TRACKING_CONFIG["TRACKINGMORE_API_KEY"]))
        elif provider == "jsoncargo":
            providers.append(("jsoncargo", api_key or TRACKING_CONFIG["JSONCARGO_API_KEY"]))
        
        # Try each provider
        for prov, key in providers:
            if not key:
                continue
            
            try:
                if prov == "shipsgo":
                    result = TrackingAPI._track_shipsgo(carrier_code, tracking_no, key)
                elif prov == "trackingmore":
                    result = TrackingAPI._track_trackingmore(tracking_no, key)
                elif prov == "jsoncargo":
                    result = TrackingAPI._track_jsoncargo(tracking_no, key)
                else:
                    continue
                
                if result and "error" not in result:
                    result["provider"] = prov
                    return result
            except Exception as e:
                print(f"Provider {prov} failed: {e}")
                continue
        
        # Try carrier-specific web scraping (no API key needed)
        try:
            if carrier_code.upper() == "HMM":
                result = TrackingAPI._scrape_hmm(tracking_no)
                if result and "error" not in result:
                    result["provider"] = "HMM Web"
                    return result
        except Exception as e:
            print(f"Web scraping failed: {e}")
        
        # No API configured - return demo data
        return TrackingAPI._get_demo_data(carrier_code, tracking_no)
    
    @staticmethod
    def _track_shipsgo(carrier_code: str, tracking_no: str, api_key: str) -> dict:
        """Track using ShipsGo API v2"""
        # ShipsGo requires creating a shipment first, then polling
        # For simplicity, we use their container lookup endpoint
        
        carrier_name = CARRIERS.get(carrier_code, {}).get("code", carrier_code)
        
        # Create tracking request
        url = "https://shipsgo.com/api/v1.1/ContainerService/GetContainerInfo"
        params = {
            "authCode": api_key,
            "containerNumber": tracking_no,
        }
        
        full_url = f"{url}?{urllib.parse.urlencode(params)}"
        
        req = urllib.request.Request(full_url, headers={
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'application/json',
        })
        
        with urllib.request.urlopen(req, timeout=15, context=get_ssl_context()) as response:
            data = json.loads(response.read().decode())
            
            if not data or data.get("errorCode"):
                return {"error": data.get("errorMessage", "Unknown error")}
            
            return TrackingAPI._parse_shipsgo_response(data)
    
    @staticmethod
    def _parse_shipsgo_response(data: dict) -> dict:
        """Parse ShipsGo API response"""
        result = {
            "status": data.get("containerStatus", "UNKNOWN"),
            "vessel": data.get("vesselName", ""),
            "voyage": data.get("voyage", ""),
            "pol": data.get("polLocode", ""),
            "pol_name": data.get("polName", ""),
            "pod": data.get("podLocode", ""),
            "pod_name": data.get("podName", ""),
            "etd": data.get("polEtdDate", ""),
            "eta": data.get("podEtaDate", ""),
            "atd": data.get("polAtdDate", ""),
            "ata": data.get("podAtaDate", ""),
            "events": [],
        }
        
        # Parse events/milestones
        movements = data.get("containerMovements", [])
        for mov in movements:
            result["events"].append({
                "date": mov.get("movementDate", ""),
                "location": mov.get("locationName", ""),
                "status": mov.get("movementType", ""),
                "description": mov.get("movementDescription", ""),
            })
        
        return result
    
    @staticmethod
    def _track_trackingmore(tracking_no: str, api_key: str) -> dict:
        """Track using TrackingMore API"""
        url = f"https://api.trackingmore.com/v3/trackings/realtime"
        
        payload = json.dumps({
            "tracking_number": tracking_no,
            "carrier_code": "maersk"  # Will be auto-detected
        }).encode('utf-8')
        
        req = urllib.request.Request(url, data=payload, headers={
            'Content-Type': 'application/json',
            'Tracking-Api-Key': api_key,
        })
        
        with urllib.request.urlopen(req, timeout=15, context=get_ssl_context()) as response:
            data = json.loads(response.read().decode())
            
            if data.get("meta", {}).get("code") != 200:
                return {"error": data.get("meta", {}).get("message", "Unknown error")}
            
            return TrackingAPI._parse_trackingmore_response(data.get("data", {}))
    
    @staticmethod
    def _parse_trackingmore_response(data: dict) -> dict:
        """Parse TrackingMore API response"""
        result = {
            "status": data.get("delivery_status", "UNKNOWN").upper(),
            "vessel": "",
            "voyage": "",
            "pol": data.get("origin", ""),
            "pod": data.get("destination", ""),
            "etd": "",
            "eta": data.get("expected_delivery", ""),
            "atd": "",
            "ata": "",
            "events": [],
        }
        
        # Parse tracking history
        origin_info = data.get("origin_info", {})
        trackinfo = origin_info.get("trackinfo", [])
        
        for track in trackinfo:
            result["events"].append({
                "date": track.get("Date", ""),
                "location": track.get("Details", ""),
                "status": track.get("StatusDescription", ""),
                "description": track.get("Details", ""),
            })
        
        return result
    
    @staticmethod
    def _track_jsoncargo(tracking_no: str, api_key: str) -> dict:
        """Track using JSONCargo API"""
        url = f"https://jsoncargo.com/api/v1/container/{tracking_no}"
        
        req = urllib.request.Request(url, headers={
            'Authorization': f'Bearer {api_key}',
            'Accept': 'application/json',
        })
        
        with urllib.request.urlopen(req, timeout=15, context=get_ssl_context()) as response:
            data = json.loads(response.read().decode())
            
            if data.get("error"):
                return {"error": data.get("message", "Unknown error")}
            
            return TrackingAPI._parse_jsoncargo_response(data)
    
    @staticmethod
    def _parse_jsoncargo_response(data: dict) -> dict:
        """Parse JSONCargo API response"""
        return {
            "status": data.get("status", "UNKNOWN"),
            "vessel": data.get("vessel", {}).get("name", ""),
            "voyage": data.get("vessel", {}).get("voyage", ""),
            "pol": data.get("pol", {}).get("code", ""),
            "pol_name": data.get("pol", {}).get("name", ""),
            "pod": data.get("pod", {}).get("code", ""),
            "pod_name": data.get("pod", {}).get("name", ""),
            "etd": data.get("etd", ""),
            "eta": data.get("eta", ""),
            "atd": data.get("atd", ""),
            "ata": data.get("ata", ""),
            "events": data.get("events", []),
        }
    
    @staticmethod
    def _scrape_hmm(tracking_no: str) -> dict:
        """
        Scrape tracking info from HMM website
        
        HMM BL format: HDMU1234567890 → Search with 1234567890
        
        Note: HMM website may block automated requests
        """
        import re
        
        # Transform BL: Remove HDMU/HDHU prefix if present
        bl = transform_bl_for_carrier("HMM", tracking_no)
        original_bl = tracking_no
        
        result = {
            "status": "UNKNOWN",
            "vessel": "",
            "voyage": "",
            "pol": "",
            "pol_name": "",
            "pod": "",
            "pod_name": "",
            "etd": "",
            "eta": "",
            "atd": "",
            "ata": "",
            "events": [],
            "bl_no": bl,
            "original_bl": original_bl,
            "source": "HMM Web",
        }
        
        # Method 1: Try HMM's cargo tracking page directly
        try:
            url = f"https://www.hmm21.com/e-service/general/trackNTrace/TrackNTrace.do?blNo={bl}"
            
            req = urllib.request.Request(url, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': 'https://www.hmm21.com/',
                'Connection': 'keep-alive',
            })
            
            with urllib.request.urlopen(req, timeout=20, context=get_ssl_context()) as response:
                html = response.read().decode('utf-8', errors='ignore')
                
                # Look for schedule data in the page
                # HMM typically shows dates in format: YYYY-MM-DD or DD-MMM-YYYY
                
                # ETD patterns
                etd_patterns = [
                    r'ETD[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'ETD[:\s]*(\d{2}-[A-Z]{3}-\d{4})',
                    r'Estimated\s+Departure[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'"etd"[:\s]*"(\d{4}-\d{2}-\d{2})"',
                    r'polEtd["\s:]+(\d{4}-\d{2}-\d{2})',
                ]
                for pattern in etd_patterns:
                    match = re.search(pattern, html, re.IGNORECASE)
                    if match:
                        result["etd"] = match.group(1)
                        break
                
                # ETA patterns
                eta_patterns = [
                    r'ETA[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'ETA[:\s]*(\d{2}-[A-Z]{3}-\d{4})',
                    r'Estimated\s+Arrival[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'"eta"[:\s]*"(\d{4}-\d{2}-\d{2})"',
                    r'podEta["\s:]+(\d{4}-\d{2}-\d{2})',
                ]
                for pattern in eta_patterns:
                    match = re.search(pattern, html, re.IGNORECASE)
                    if match:
                        result["eta"] = match.group(1)
                        break
                
                # ATD patterns
                atd_patterns = [
                    r'ATD[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'ATD[:\s]*(\d{2}-[A-Z]{3}-\d{4})',
                    r'Actual\s+Departure[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'"atd"[:\s]*"(\d{4}-\d{2}-\d{2})"',
                    r'polAtd["\s:]+(\d{4}-\d{2}-\d{2})',
                ]
                for pattern in atd_patterns:
                    match = re.search(pattern, html, re.IGNORECASE)
                    if match:
                        result["atd"] = match.group(1)
                        break
                
                # ATA patterns
                ata_patterns = [
                    r'ATA[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'ATA[:\s]*(\d{2}-[A-Z]{3}-\d{4})',
                    r'Actual\s+Arrival[:\s]*(\d{4}-\d{2}-\d{2})',
                    r'"ata"[:\s]*"(\d{4}-\d{2}-\d{2})"',
                    r'podAta["\s:]+(\d{4}-\d{2}-\d{2})',
                ]
                for pattern in ata_patterns:
                    match = re.search(pattern, html, re.IGNORECASE)
                    if match:
                        result["ata"] = match.group(1)
                        break
                
                # Vessel name
                vessel_patterns = [
                    r'"vslNm"[:\s]*"([^"]+)"',
                    r'[Vv]essel[:\s]*([A-Z][A-Z0-9\s]{3,30})',
                    r'VSL[:\s]*([A-Z][A-Z0-9\s]+)',
                ]
                for pattern in vessel_patterns:
                    match = re.search(pattern, html)
                    if match:
                        result["vessel"] = match.group(1).strip()
                        break
                
                # Voyage
                voyage_patterns = [
                    r'"voyNo"[:\s]*"([^"]+)"',
                    r'[Vv]oyage[:\s]*([A-Z0-9]+)',
                    r'VOY[:\s]*([A-Z0-9]+)',
                ]
                for pattern in voyage_patterns:
                    match = re.search(pattern, html)
                    if match:
                        result["voyage"] = match.group(1).strip()
                        break
                
                # POL/POD
                pol_match = re.search(r'"polCd"[:\s]*"([^"]+)"', html)
                if pol_match:
                    result["pol"] = pol_match.group(1)
                
                pod_match = re.search(r'"podCd"[:\s]*"([^"]+)"', html)
                if pod_match:
                    result["pod"] = pod_match.group(1)
                
                # Determine status
                if result["ata"]:
                    result["status"] = "ARRIVED"
                elif result["atd"]:
                    result["status"] = "IN TRANSIT"
                elif result["etd"]:
                    result["status"] = "BOOKED"
                
                # Check if we got any data
                if any([result["etd"], result["eta"], result["atd"], result["ata"], result["vessel"]]):
                    print(f"HMM tracking found: ETD={result['etd']}, ETA={result['eta']}, ATD={result['atd']}, ATA={result['ata']}")
                    return result
                else:
                    # Check if page shows "no data" message
                    if "조회된 데이터가 없습니다" in html or "No data" in html:
                        return {"error": f"No tracking data found for BL: {bl}"}
                    
                    print(f"HMM: Could not parse tracking data from HTML (length: {len(html)})")
        except Exception as e:
            print(f"HMM scraping error: {e}")
        
        # If we got here with some data, return it
        if any([result["etd"], result["eta"], result["atd"], result["ata"]]):
            return result
        
        # Return with message about manual check
        result["message"] = f"Unable to auto-fetch. Please check HMM website manually with BL: {bl}"
        result["track_url"] = f"https://www.hmm21.com/e-service/general/trackNTrace/TrackNTrace.do?blNo={bl}"
        return result
    
    @staticmethod
    def _get_demo_data(carrier_code: str, tracking_no: str) -> dict:
        """Return demo data when no API is configured"""
        now = datetime.now()
        
        return {
            "status": "IN TRANSIT",
            "vessel": f"DEMO {carrier_code} EXPRESS",
            "voyage": f"V{now.strftime('%y%m')}E",
            "pol": "KRPUS",
            "pol_name": "Busan, Korea",
            "pod": "MXMZL",
            "pod_name": "Manzanillo, Mexico",
            "etd": (now.replace(day=max(1, now.day-2))).strftime("%Y-%m-%d"),
            "eta": (now.replace(day=min(28, now.day+18))).strftime("%Y-%m-%d"),
            "atd": (now.replace(day=max(1, now.day-2))).strftime("%Y-%m-%d"),
            "ata": "",
            "events": [
                {"date": (now.replace(day=max(1, now.day-1))).strftime("%Y-%m-%d %H:%M"), 
                 "location": "BUSAN, KOREA", "status": "DEPARTED", 
                 "description": "Vessel departed from port of loading"},
                {"date": (now.replace(day=max(1, now.day-2))).strftime("%Y-%m-%d %H:%M"), 
                 "location": "BUSAN, KOREA", "status": "LOADED", 
                 "description": "Container loaded on vessel"},
                {"date": (now.replace(day=max(1, now.day-3))).strftime("%Y-%m-%d %H:%M"), 
                 "location": "BUSAN, KOREA", "status": "GATE IN", 
                 "description": "Container received at terminal"},
                {"date": (now.replace(day=max(1, now.day-5))).strftime("%Y-%m-%d %H:%M"), 
                 "location": "INCHEON, KOREA", "status": "PICKED UP", 
                 "description": "Container picked up from shipper"},
            ],
            "demo": True,
            "no_api_message": "API 키가 설정되지 않았습니다. Settings에서 API 키를 설정하세요.",
        }


class TrackingFrame(ctk.CTkFrame):
    """Carrier Tracking Interface with Real API Support"""
    
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)
        
        self.current_job = None
        self._tracking_result = None
        self._build_ui()
        self._load_api_config()
        self._load_recent_jobs()
    
    def _load_api_config(self):
        """Load API configuration from database"""
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT key, value FROM settings WHERE key LIKE 'tracking_%'")
            for row in cur.fetchall():
                key = row[0].upper().replace("TRACKING_", "")
                if key + "_API_KEY" in TRACKING_CONFIG:
                    TRACKING_CONFIG[key + "_API_KEY"] = row[1]
                elif key == "SHIPSGO_API_KEY":
                    TRACKING_CONFIG["SHIPSGO_API_KEY"] = row[1]
                elif key == "TRACKINGMORE_API_KEY":
                    TRACKING_CONFIG["TRACKINGMORE_API_KEY"] = row[1]
            conn.close()
        except Exception as e:
            print(f"Load API config error: {e}")
    
    def _build_ui(self):
        """Build the UI"""
        # Top spacer
        ctk.CTkFrame(self, fg_color="transparent", height=40).pack(fill="x")
        
        # Title bar with API status
        title_frame = ctk.CTkFrame(self, fg_color="#00695C", corner_radius=0, height=50)
        title_frame.pack(fill="x")
        title_frame.pack_propagate(False)
        
        title_inner = ctk.CTkFrame(title_frame, fg_color="transparent")
        title_inner.pack(fill="x", expand=True, padx=20, pady=10)
        
        ctk.CTkLabel(title_inner, text="🔍 CARRIER TRACKING", 
                    font=("SF Pro Display", 20, "bold"), 
                    text_color="white").pack(side="left")
        
        # API settings button
        ctk.CTkButton(title_inner, text="⚙️ API Settings", width=120, height=30,
                     fg_color="#004D40", hover_color="#00796B",
                     command=self._open_api_settings).pack(side="right")
        
        # Main container
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=15, pady=10)
        
        # Left panel
        left = ctk.CTkFrame(main, fg_color="#F8F9FA", width=320, corner_radius=10)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        
        self._build_quick_track(left)
        self._build_job_list(left)
        
        # Right panel
        right = ctk.CTkFrame(main, fg_color="#FFFFFF", corner_radius=10)
        right.pack(side="left", fill="both", expand=True)
        
        self._build_result_panel(right)
    
    def _build_quick_track(self, parent):
        """Build quick track section"""
        frame = ctk.CTkFrame(parent, fg_color="#E3F2FD", corner_radius=8)
        frame.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(frame, text="⚡ Quick Track", 
                    font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        # Carrier
        row1 = ctk.CTkFrame(frame, fg_color="transparent")
        row1.pack(fill="x", padx=15, pady=5)
        
        ctk.CTkLabel(row1, text="Carrier:", width=70).pack(side="left")
        self.carrier_var = tk.StringVar(value="MAERSK")
        carrier_combo = ttk.Combobox(row1, textvariable=self.carrier_var,
                                     values=list(CARRIERS.keys()), width=18, state="readonly")
        carrier_combo.pack(side="left", fill="x", expand=True)
        
        # Tracking number
        row2 = ctk.CTkFrame(frame, fg_color="transparent")
        row2.pack(fill="x", padx=15, pady=5)
        
        ctk.CTkLabel(row2, text="B/L/CNTR:", width=70).pack(side="left")
        self.bl_var = tk.StringVar()
        bl_entry = ctk.CTkEntry(row2, textvariable=self.bl_var,
                               placeholder_text="Enter B/L or Container No")
        bl_entry.pack(side="left", fill="x", expand=True)
        bl_entry.bind("<Return>", lambda e: self._do_tracking())
        
        # Track button
        btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=(10, 15))
        
        self.track_btn = ctk.CTkButton(btn_frame, text="🔍 TRACK", width=120, height=40,
                                       font=("SF Pro Display", 13, "bold"),
                                       fg_color="#1565C0", hover_color="#0D47A1",
                                       command=self._do_tracking)
        self.track_btn.pack(side="left", padx=(0, 5))
        
        # Open carrier website button
        ctk.CTkButton(btn_frame, text="🌐 Website", width=80, height=40,
                     font=("SF Pro Display", 12),
                     fg_color="#00695C", hover_color="#004D40",
                     command=self._open_carrier_website).pack(side="left", padx=(0, 5))
        
        ctk.CTkButton(btn_frame, text="🔄", width=40, height=40,
                     fg_color="#6C757D", hover_color="#5A6268",
                     command=self._clear_results).pack(side="left")
        
        # API status indicator
        self.api_status_label = ctk.CTkLabel(frame, text="", 
                                             font=("SF Pro Display", 10),
                                             text_color="#666666")
        self.api_status_label.pack(anchor="w", padx=15, pady=(0, 10))
        self._update_api_status()
    
    def _update_api_status(self):
        """Update API status indicator"""
        apis = []
        if TRACKING_CONFIG.get("SHIPSGO_API_KEY"):
            apis.append("ShipsGo")
        if TRACKING_CONFIG.get("TRACKINGMORE_API_KEY"):
            apis.append("TrackingMore")
        if TRACKING_CONFIG.get("JSONCARGO_API_KEY"):
            apis.append("JSONCargo")
        
        if apis:
            self.api_status_label.configure(text=f"✅ API: {', '.join(apis)}", text_color="#2E7D32")
        else:
            self.api_status_label.configure(text="⚠️ No API configured - Using demo data", text_color="#FF9800")
    
    def _build_job_list(self, parent):
        """Build job list section"""
        ctk.CTkLabel(parent, text="📋 Recent Jobs", 
                    font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(15, 5))
        
        # Search
        search_frame = ctk.CTkFrame(parent, fg_color="transparent")
        search_frame.pack(fill="x", padx=10, pady=5)
        
        self.search_var = tk.StringVar()
        ctk.CTkEntry(search_frame, textvariable=self.search_var,
                    placeholder_text="Search...", height=28).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(search_frame, text="🔍", width=30, height=28,
                     command=self._search_jobs).pack(side="left", padx=(5, 0))
        
        # Job list
        list_frame = ctk.CTkFrame(parent, fg_color="white", corner_radius=5)
        list_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        cols = ("job_no", "bl", "carrier")
        self.job_tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=10)
        
        self.job_tree.heading("job_no", text="JOB NO")
        self.job_tree.heading("bl", text="B/L")
        self.job_tree.heading("carrier", text="CARRIER")
        
        self.job_tree.column("job_no", width=80)
        self.job_tree.column("bl", width=100)
        self.job_tree.column("carrier", width=65)
        
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.job_tree.yview)
        self.job_tree.configure(yscrollcommand=vsb.set)
        
        self.job_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        self.job_tree.bind("<<TreeviewSelect>>", self._on_job_select)
        self.job_tree.bind("<Double-1>", lambda e: self._do_tracking())
    
    def _build_result_panel(self, parent):
        """Build result display panel"""
        # Header
        header = ctk.CTkFrame(parent, fg_color="#E8F5E9", corner_radius=8, height=80)
        header.pack(fill="x", padx=15, pady=15)
        header.pack_propagate(False)
        
        header_inner = ctk.CTkFrame(header, fg_color="transparent")
        header_inner.pack(fill="both", expand=True, padx=15, pady=10)
        
        self.status_label = ctk.CTkLabel(header_inner, text="Ready to Track",
                                         font=("SF Pro Display", 18, "bold"),
                                         text_color="#2E7D32")
        self.status_label.pack(side="left")
        
        self.loading_label = ctk.CTkLabel(header_inner, text="",
                                          font=("SF Pro Display", 12),
                                          text_color="#666666")
        self.loading_label.pack(side="right")
        
        # Info cards
        info_frame = ctk.CTkFrame(parent, fg_color="transparent")
        info_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        # Vessel card
        vessel_card = ctk.CTkFrame(info_frame, fg_color="#FFF8E1", corner_radius=8)
        vessel_card.pack(side="left", fill="both", expand=True, padx=(0, 5))
        
        ctk.CTkLabel(vessel_card, text="🚢 Vessel / Voyage",
                    font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        
        self.vessel_label = ctk.CTkLabel(vessel_card, text="-",
                                         font=("SF Pro Display", 12))
        self.vessel_label.pack(anchor="w", padx=10, pady=(0, 8))
        
        # Route card
        route_card = ctk.CTkFrame(info_frame, fg_color="#E3F2FD", corner_radius=8)
        route_card.pack(side="left", fill="both", expand=True, padx=5)
        
        ctk.CTkLabel(route_card, text="📍 Route",
                    font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        
        self.route_label = ctk.CTkLabel(route_card, text="-",
                                        font=("SF Pro Display", 12))
        self.route_label.pack(anchor="w", padx=10, pady=(0, 8))
        
        # Schedule card
        sched_card = ctk.CTkFrame(info_frame, fg_color="#F3E5F5", corner_radius=8)
        sched_card.pack(side="left", fill="both", expand=True, padx=(5, 0))
        
        ctk.CTkLabel(sched_card, text="📅 Schedule",
                    font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        
        self.schedule_label = ctk.CTkLabel(sched_card, text="-",
                                           font=("SF Pro Display", 12))
        self.schedule_label.pack(anchor="w", padx=10, pady=(0, 8))
        
        # Events section
        events_frame = ctk.CTkFrame(parent, fg_color="#F5F5F5", corner_radius=8)
        events_frame.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        
        events_header = ctk.CTkFrame(events_frame, fg_color="transparent")
        events_header.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(events_header, text="📋 Tracking Events",
                    font=("SF Pro Display", 13, "bold")).pack(side="left")
        
        self.event_count_label = ctk.CTkLabel(events_header, text="",
                                              font=("SF Pro Display", 11),
                                              text_color="#666666")
        self.event_count_label.pack(side="right")
        
        # Events table
        table_frame = ctk.CTkFrame(events_frame, fg_color="white", corner_radius=5)
        table_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        cols = ("date", "location", "status", "description")
        self.event_tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=8)
        
        self.event_tree.heading("date", text="Date/Time")
        self.event_tree.heading("location", text="Location")
        self.event_tree.heading("status", text="Status")
        self.event_tree.heading("description", text="Description")
        
        self.event_tree.column("date", width=130)
        self.event_tree.column("location", width=140)
        self.event_tree.column("status", width=100)
        self.event_tree.column("description", width=250)
        
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.event_tree.yview)
        self.event_tree.configure(yscrollcommand=vsb.set)
        
        self.event_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        # Notice label
        self.notice_label = ctk.CTkLabel(parent, text="",
                                         font=("SF Pro Display", 10),
                                         text_color="#FF9800")
        self.notice_label.pack(anchor="w", padx=20, pady=(0, 5))
        
        # Action buttons
        action_frame = ctk.CTkFrame(parent, fg_color="transparent")
        action_frame.pack(fill="x", padx=15, pady=(0, 10))
        
        ctk.CTkButton(action_frame, text="💾 Update Job", width=120, height=35,
                     fg_color="#4CAF50", hover_color="#388E3C",
                     command=self._update_job).pack(side="left", padx=(0, 10))
        
        ctk.CTkButton(action_frame, text="📋 Copy", width=80, height=35,
                     fg_color="#2196F3", hover_color="#1976D2",
                     command=self._copy_info).pack(side="left")
    
    def _load_recent_jobs(self):
        """Load recent jobs"""
        self.job_tree.delete(*self.job_tree.get_children())
        
        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                SELECT job_no, COALESCE(mbl, hbl, '') as bl, COALESCE(carrier, '') as carrier
                FROM jobs 
                WHERE (mbl IS NOT NULL AND mbl != '') OR (hbl IS NOT NULL AND hbl != '')
                ORDER BY created_at DESC LIMIT 50
            """)
            
            for row in cur.fetchall():
                self.job_tree.insert("", "end", values=row)
            
            conn.close()
        except Exception as e:
            print(f"Load jobs error: {e}")
    
    def _search_jobs(self):
        """Search jobs"""
        keyword = self.search_var.get().strip()
        self.job_tree.delete(*self.job_tree.get_children())
        
        try:
            conn = get_connection()
            cur = conn.cursor()
            
            if keyword:
                cur.execute("""
                    SELECT job_no, COALESCE(mbl, hbl, '') as bl, COALESCE(carrier, '') as carrier
                    FROM jobs 
                    WHERE (job_no LIKE ? OR mbl LIKE ? OR hbl LIKE ? OR carrier LIKE ?)
                    ORDER BY created_at DESC LIMIT 50
                """, tuple(f"%{keyword}%" for _ in range(4)))
            else:
                self._load_recent_jobs()
                return
            
            for row in cur.fetchall():
                self.job_tree.insert("", "end", values=row)
            
            conn.close()
        except Exception as e:
            print(f"Search error: {e}")
    
    def _on_job_select(self, event):
        """Handle job selection"""
        selection = self.job_tree.selection()
        if not selection:
            return
        
        values = self.job_tree.item(selection[0], "values")
        job_no, bl, carrier = values[0], values[1], values[2]
        
        if bl:
            self.bl_var.set(bl)
        
        # Match carrier
        if carrier:
            carrier_upper = carrier.upper()
            for code, info in CARRIERS.items():
                if code in carrier_upper or info["name"].upper() in carrier_upper:
                    self.carrier_var.set(code)
                    break
        
        self.current_job = {"job_no": job_no, "bl": bl, "carrier": carrier}
    
    def _open_carrier_website(self):
        """Open carrier tracking website in default browser"""
        import webbrowser
        
        carrier = self.carrier_var.get()
        bl = self.bl_var.get().strip()
        
        if not bl:
            messagebox.showwarning("Warning", "Please enter a B/L number.")
            return
        
        url = get_carrier_tracking_url(carrier, bl)
        
        if url:
            webbrowser.open(url)
            self.status_label.configure(text=f"🌐 Opened {carrier} tracking website", text_color="#00695C")
        else:
            messagebox.showinfo("Info", f"No tracking URL available for {carrier}.\n\nPlease visit the carrier website manually.")
    
    def _do_tracking(self):
        """Perform tracking"""
        carrier = self.carrier_var.get()
        bl = self.bl_var.get().strip()
        
        if not bl:
            messagebox.showwarning("Warning", "Please enter a B/L or Container number.")
            return
        
        # Transform BL if needed (e.g., HMM: HDMU1234567 → 1234567)
        transformed_bl = transform_bl_for_carrier(carrier, bl)
        if transformed_bl != bl:
            self.status_label.configure(
                text=f"⏳ Tracking {carrier}... (BL: {bl} → {transformed_bl})", 
                text_color="#FF9800"
            )
        else:
            self.status_label.configure(text="⏳ Tracking...", text_color="#FF9800")
        
        self.loading_label.configure(text="Fetching data...")
        self.track_btn.configure(state="disabled")
        self.update_idletasks()
        
        # Run in background
        def do_track():
            result = TrackingAPI.track(carrier, bl)
            self.after(0, lambda: self._display_result(result))
        
        thread = threading.Thread(target=do_track, daemon=True)
        thread.start()
    
    def _display_result(self, result: dict):
        """Display tracking result"""
        self.track_btn.configure(state="normal")
        self.loading_label.configure(text="")
        
        if "error" in result:
            self.status_label.configure(text=f"❌ {result['error']}", text_color="#F44336")
            return
        
        self._tracking_result = result
        
        # Status
        status = result.get("status", "UNKNOWN")
        status_colors = {
            "DELIVERED": "#4CAF50",
            "ARRIVED": "#2196F3",
            "IN TRANSIT": "#FF9800",
            "LOADED": "#9C27B0",
            "DEPARTED": "#FF9800",
            "BOOKED": "#607D8B",
        }
        color = status_colors.get(status.upper(), "#666666")
        self.status_label.configure(text=f"✓ {status}", text_color=color)
        
        # Vessel
        vessel = result.get("vessel", "-")
        voyage = result.get("voyage", "")
        self.vessel_label.configure(text=f"{vessel} / {voyage}" if voyage else vessel or "-")
        
        # Route
        pol = result.get("pol", "") or result.get("pol_name", "")
        pod = result.get("pod", "") or result.get("pod_name", "")
        self.route_label.configure(text=f"{pol} → {pod}" if pol and pod else "-")
        
        # Schedule
        etd = result.get("etd", "")
        eta = result.get("eta", "")
        atd = result.get("atd", "")
        ata = result.get("ata", "")
        
        parts = []
        if atd:
            parts.append(f"ATD: {atd}")
        elif etd:
            parts.append(f"ETD: {etd}")
        if ata:
            parts.append(f"ATA: {ata}")
        elif eta:
            parts.append(f"ETA: {eta}")
        
        self.schedule_label.configure(text=" | ".join(parts) if parts else "-")
        
        # Events
        self.event_tree.delete(*self.event_tree.get_children())
        events = result.get("events", [])
        
        for event in events:
            self.event_tree.insert("", "end", values=(
                event.get("date", "-"),
                event.get("location", "-"),
                event.get("status", "-"),
                event.get("description", "-")
            ))
        
        self.event_count_label.configure(text=f"{len(events)} events")
        
        # Notice
        if result.get("demo"):
            self.notice_label.configure(
                text=f"⚠️ Demo data - {result.g_t('no_api_message', 'API 키를 설정하세요')}")
        elif result.get("provider"):
            self.notice_label.configure(
                text=f"✅ Data from {result['provider'].upper()}", 
                text_color="#2E7D32")
        else:
            self.notice_label.configure(text="")
    
    def _clear_results(self):
        """Clear results"""
        self.status_label.configure(text="Ready to Track", text_color="#2E7D32")
        self.vessel_label.configure(text="-")
        self.route_label.configure(text="-")
        self.schedule_label.configure(text="-")
        self.event_tree.delete(*self.event_tree.get_children())
        self.event_count_label.configure(text="")
        self.notice_label.configure(text="")
        self._tracking_result = None
    
    def _update_job(self):
        """Update job with tracking data"""
        if not self.current_job:
            messagebox.showinfo("Info", "Please select a job first.")
            return
        
        if not self._tracking_result:
            messagebox.showinfo("Info", "Please track first.")
            return
        
        result = self._tracking_result
        job_no = self.current_job.get("job_no")
        
        updates = []
        params = []
        
        if result.get("atd"):
            updates.append("atd = ?")
            params.append(result["atd"])
        
        if result.get("ata"):
            updates.append("ata = ?")
            params.append(result["ata"])
        
        if result.get("vessel"):
            updates.append("vessel = ?")
            params.append(result["vessel"])
        
        if result.get("voyage"):
            updates.append("voyage = ?")
            params.append(result["voyage"])
        
        if not updates:
            messagebox.showinfo("Info", "No updates available.")
            return
        
        updates.append("updated_at = ?")
        params.append(now_str())
        params.append(job_no)
        
        try:
            conn = get_connection()
            cur = conn.cursor()
            query = f"UPDATE jobs SET {', '.join(updates)} WHERE job_no = ?"
            cur.execute(query, params)
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Success", f"Job {job_no} updated.")
        except Exception as e:
            messagebox.showerror("Error", f"Update failed: {e}")
    
    def _copy_info(self):
        """Copy tracking info"""
        if not self._tracking_result:
            return
        
        r = self._tracking_result
        text = f"""Tracking Info
Status: {r.g_t('status', '-')}
Vessel: {r.g_t('vessel', '-')} / {r.g_t('voyage', '-')}
Route: {r.g_t('pol', '-')} → {r.g_t('pod', '-')}
ETD: {r.g_t('etd', '-')} | ETA: {r.g_t('eta', '-')}
ATD: {r.g_t('atd', '-')} | ATA: {r.g_t('ata', '-')}
"""
        
        self.clipboard_clear()
        self.clipboard_append(text)
        messagebox.showinfo("Copied", "Tracking info copied.")
    
    def _open_api_settings(self):
        """Open API settings dialog"""
        win = ctk.CTkToplevel(self)
        win.title("Tracking API Settings")
        win.geometry("500x400")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        
        main = ctk.CTkFrame(win, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(main, text="🔑 Tracking API Configuration",
                    font=("SF Pro Display", 16, "bold")).pack(anchor="w", pady=(0, 15))
        
        ctk.CTkLabel(main, text="Configure API keys to get real tracking data.\n"
                    "Free accounts available at each provider.",
                    font=("SF Pro Display", 11),
                    text_color="#666666").pack(anchor="w", pady=(0, 15))
        
        # ShipsGo
        ctk.CTkLabel(main, text="ShipsGo API Key (shipsgo.com - 3 free credits):",
                    font=("SF Pro Display", 11)).pack(anchor="w")
        shipsgo_var = tk.StringVar(value=TRACKING_CONFIG.get("SHIPSGO_API_KEY", ""))
        ctk.CTkEntry(main, textvariable=shipsgo_var, width=400).pack(anchor="w", pady=(0, 10))
        
        # TrackingMore
        ctk.CTkLabel(main, text="TrackingMore API Key (trackingmore.com - 7 day trial):",
                    font=("SF Pro Display", 11)).pack(anchor="w")
        trackingmore_var = tk.StringVar(value=TRACKING_CONFIG.get("TRACKINGMORE_API_KEY", ""))
        ctk.CTkEntry(main, textvariable=trackingmore_var, width=400).pack(anchor="w", pady=(0, 10))
        
        # JSONCargo
        ctk.CTkLabel(main, text="JSONCargo API Key (jsoncargo.com - free tier):",
                    font=("SF Pro Display", 11)).pack(anchor="w")
        jsoncargo_var = tk.StringVar(value=TRACKING_CONFIG.get("JSONCARGO_API_KEY", ""))
        ctk.CTkEntry(main, textvariable=jsoncargo_var, width=400).pack(anchor="w", pady=(0, 20))
        
        def save_config():
            TRACKING_CONFIG["SHIPSGO_API_KEY"] = shipsgo_var.get().strip()
            TRACKING_CONFIG["TRACKINGMORE_API_KEY"] = trackingmore_var.get().strip()
            TRACKING_CONFIG["JSONCARGO_API_KEY"] = jsoncargo_var.get().strip()
            
            # Save to database
            try:
                conn = get_connection()
                cur = conn.cursor()
                
                for key, value in [
                    ("tracking_shipsgo_api_key", TRACKING_CONFIG["SHIPSGO_API_KEY"]),
                    ("tracking_trackingmore_api_key", TRACKING_CONFIG["TRACKINGMORE_API_KEY"]),
                    ("tracking_jsoncargo_api_key", TRACKING_CONFIG["JSONCARGO_API_KEY"]),
                ]:
                    cur.execute("""
                        INSERT OR REPLACE INTO settings (key, value, updated_at)
                        VALUES (?, ?, ?)
                    """, (key, value, now_str()))
                
                conn.commit()
                conn.close()
                
                self._update_api_status()
                messagebox.showinfo("Saved", "API configuration saved.", parent=win)
                win.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Save failed: {e}", parent=win)
        
        btn_frame = ctk.CTkFrame(main, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(10, 0))
        
        ctk.CTkButton(btn_frame, text="Save", width=100, command=save_config).pack(side="left")
        ctk.CTkButton(btn_frame, text="Cancel", width=100, 
                     fg_color="#6C757D", command=win.destroy).pack(side="left", padx=(10, 0))


if __name__ == "__main__":
    root = ctk.CTk()
    root.title("Tracking Test")
    root.geometry("1200x800")
    
    frame = TrackingFrame(root)
    frame.pack(fill="both", expand=True)
    
    root.mainloop()
