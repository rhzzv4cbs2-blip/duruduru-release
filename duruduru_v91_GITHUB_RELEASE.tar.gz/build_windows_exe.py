# build_windows_exe.py
# Windows EXE Build Script using PyInstaller
# Run this on Windows: python build_windows_exe.py

import os
import sys
import shutil
import subprocess

APP_NAME = "DURUDURU"
APP_VERSION = "1.0.90"
MAIN_SCRIPT = "main.py"
ICON_FILE = "icon_1024x1024.png"

# Files to include in the build
DATA_FILES = [
    "db.py",
    "auth.py", 
    "config.py",
    "utils.py",
    "provider_mock.py",
    "automation.py",
    "carrier_tracking.py",
    "auto_updater.py",
    "ui_status.py",
    "ui_accounting.py",
    "ui_dashboard.py",
    "ui_order_reg.py",
    "ui_order_reg_land.py",
    "ui_settings.py",
    "ui_settlement.py",
    "ui_quotation.py",
    "ui_tracking.py",
    "ui_design.py",
    "ui_vendor_quote.py",
    "autocomplete_util.py",
    "styles.py",
    "theme.py",
    "db_migration.py",
    "i18n.py",
    "theme_manager.py",
    "pdf_export.py",
    "pdf_quote.py",
    "pdf_invoice.py",
    "error_handler.py",
    "db_backup.py",
    "db_multiuser.py",
    "file_attachment.py",
    "notification.py",
    "seed_ports.py",
]

def check_requirements():
    """Check if required packages are installed"""
    print("Checking requirements...")
    
    required = ['pyinstaller', 'customtkinter', 'pillow', 'reportlab']
    missing = []
    
    for pkg in required:
        try:
            __import__(pkg.replace('-', '_'))
        except ImportError:
            missing.append(pkg)
    
    if missing:
        print(f"Installing missing packages: {missing}")
        subprocess.run([sys.executable, '-m', 'pip', 'install'] + missing)
    
    print("✓ All requirements satisfied")


def create_spec_file():
    """Create PyInstaller spec file"""
    
    # Build data files list
    datas = []
    for f in DATA_FILES:
        if os.path.exists(f):
            datas.append(f"('{f}', '.')")
    
    # Add icon
    if os.path.exists(ICON_FILE):
        datas.append(f"('{ICON_FILE}', '.')")
    
    datas_str = ",\n             ".join(datas)
    
    spec_content = f'''# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['{MAIN_SCRIPT}'],
    pathex=[],
    binaries=[],
    datas=[{datas_str}],
    hiddenimports=[
        'customtkinter',
        'PIL',
        'PIL._tkinter_finder',
        'reportlab',
        'reportlab.graphics',
        'reportlab.lib',
        'reportlab.pdfgen',
        'sqlite3',
        'json',
        'threading',
        'urllib',
        'ssl',
    ],
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='{APP_NAME}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # Set to True for debugging
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='{ICON_FILE}' if os.path.exists('{ICON_FILE}') else None,
    version='file_version_info.txt',
)
'''
    
    with open(f'{APP_NAME}.spec', 'w') as f:
        f.write(spec_content)
    
    print(f"✓ Created {APP_NAME}.spec")


def create_version_info():
    """Create Windows version info file"""
    
    version_parts = APP_VERSION.split('.')
    while len(version_parts) < 4:
        version_parts.append('0')
    
    version_tuple = ', '.join(version_parts[:4])
    
    version_info = f'''# UTF-8
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=({version_tuple}),
    prodvers=({version_tuple}),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo(
      [
        StringTable(
          u'040904B0',
          [
            StringStruct(u'CompanyName', u'DURUDURU'),
            StringStruct(u'FileDescription', u'DURUDURU Freight Forwarding System'),
            StringStruct(u'FileVersion', u'{APP_VERSION}'),
            StringStruct(u'InternalName', u'{APP_NAME}'),
            StringStruct(u'LegalCopyright', u'© 2026 DURUDURU'),
            StringStruct(u'OriginalFilename', u'{APP_NAME}.exe'),
            StringStruct(u'ProductName', u'{APP_NAME}'),
            StringStruct(u'ProductVersion', u'{APP_VERSION}'),
          ]
        )
      ]
    ),
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)
'''
    
    with open('file_version_info.txt', 'w', encoding='utf-8') as f:
        f.write(version_info)
    
    print("✓ Created file_version_info.txt")


def convert_icon():
    """Convert PNG icon to ICO for Windows"""
    if not os.path.exists(ICON_FILE):
        print(f"⚠ Icon file not found: {ICON_FILE}")
        return
    
    try:
        from PIL import Image
        
        img = Image.open(ICON_FILE)
        ico_file = ICON_FILE.replace('.png', '.ico')
        
        # Create ICO with multiple sizes
        img.save(ico_file, format='ICO', sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)])
        
        print(f"✓ Created {ico_file}")
        return ico_file
        
    except Exception as e:
        print(f"⚠ Could not convert icon: {e}")
        return None


def build_exe():
    """Build the EXE using PyInstaller"""
    print("\n" + "="*50)
    print("Building Windows EXE...")
    print("="*50 + "\n")
    
    # Clean previous build
    for folder in ['build', 'dist']:
        if os.path.exists(folder):
            shutil.rmtree(folder)
            print(f"✓ Cleaned {folder}/")
    
    # Run PyInstaller
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--clean',
        '--noconfirm',
        f'{APP_NAME}.spec'
    ]
    
    result = subprocess.run(cmd)
    
    if result.returncode == 0:
        exe_path = os.path.join('dist', f'{APP_NAME}.exe')
        if os.path.exists(exe_path):
            size_mb = os.path.getsize(exe_path) / (1024 * 1024)
            print("\n" + "="*50)
            print(f"✓ BUILD SUCCESSFUL!")
            print(f"  Output: {exe_path}")
            print(f"  Size: {size_mb:.1f} MB")
            print("="*50)
            return True
    
    print("\n✗ Build failed!")
    return False


def create_installer():
    """Create Windows installer using Inno Setup (optional)"""
    
    inno_script = f'''[Setup]
AppName={APP_NAME}
AppVersion={APP_VERSION}
AppPublisher=DURUDURU
DefaultDirName={{autopf}}\\{APP_NAME}
DefaultGroupName={APP_NAME}
OutputDir=dist
OutputBaseFilename={APP_NAME}_Setup_{APP_VERSION}
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Files]
Source: "dist\\{APP_NAME}.exe"; DestDir: "{{app}}"; Flags: ignoreversion

[Icons]
Name: "{{group}}\\{APP_NAME}"; Filename: "{{app}}\\{APP_NAME}.exe"
Name: "{{commondesktop}}\\{APP_NAME}"; Filename: "{{app}}\\{APP_NAME}.exe"

[Run]
Filename: "{{app}}\\{APP_NAME}.exe"; Description: "Launch {APP_NAME}"; Flags: nowait postinstall skipifsilent
'''
    
    with open(f'{APP_NAME}_installer.iss', 'w') as f:
        f.write(inno_script)
    
    print(f"✓ Created {APP_NAME}_installer.iss (for Inno Setup)")
    print("  To create installer: Run Inno Setup Compiler with this script")


def main():
    print("="*50)
    print(f"  {APP_NAME} Windows Build Tool")
    print(f"  Version: {APP_VERSION}")
    print("="*50)
    
    if sys.platform != 'win32':
        print("\n⚠ WARNING: This script is designed for Windows.")
        print("  For cross-compilation, consider using a Windows VM or CI/CD.")
        print("  Continuing anyway for spec file generation...\n")
    
    check_requirements()
    convert_icon()
    create_version_info()
    create_spec_file()
    
    if sys.platform == 'win32':
        if build_exe():
            create_installer()
    else:
        print("\n" + "="*50)
        print("Spec files created. To build on Windows:")
        print("  1. Copy all files to Windows machine")
        print("  2. Install Python 3.9+ and requirements")
        print("  3. Run: pip install pyinstaller customtkinter pillow reportlab")
        print(f"  4. Run: pyinstaller {APP_NAME}.spec")
        print("="*50)


if __name__ == "__main__":
    main()
