# styles.py
# Elite Monochrome Minimal Design System
# Clean, unified, professional - Less colorful, more elegant

"""
Elite Monochrome Design System
==============================

Design Principles:
- Monochrome base with minimal accent colors
- Clean lines, consistent spacing
- Professional and unified look
- Subtle, elegant interactions
"""

# ============================================================
# MONOCHROME MINIMAL COLOR PALETTE
# ============================================================

class Colors:
    """Elite monochrome palette - unified and professional"""
    
    # Primary Colors - Slate/Gray based
    PRIMARY = "#374151"           # Slate 700 - Main actions
    PRIMARY_DARK = "#1F2937"      # Slate 800 - Hover
    PRIMARY_LIGHT = "#F3F4F6"     # Slate 100 - Backgrounds
    
    # Accent - Single warm accent for highlights
    ACCENT = "#6B7280"            # Gray 500 - Secondary
    ACCENT_WARM = "#92400E"       # Amber 800 - Minimal warm accent
    
    # Semantic Colors - Muted versions
    SUCCESS = "#059669"           # Emerald 600
    SUCCESS_LIGHT = "#ECFDF5"
    WARNING = "#D97706"           # Amber 600
    WARNING_LIGHT = "#FFFBEB"
    ERROR = "#DC2626"             # Red 600
    ERROR_LIGHT = "#FEF2F2"
    INFO = "#374151"              # Same as primary
    INFO_LIGHT = "#F3F4F6"
    
    # Neutral Colors - Cool grays
    WHITE = "#FFFFFF"
    BACKGROUND = "#F9FAFB"        # Gray 50
    BG_WARM = "#F9FAFB"           # Same as background
    SURFACE = "#FFFFFF"
    SURFACE_ALT = "#F3F4F6"       # Gray 100
    BORDER = "#E5E7EB"            # Gray 200
    DIVIDER = "#E5E7EB"           # Gray 200
    
    # Text Colors
    TEXT_PRIMARY = "#111827"      # Gray 900
    TEXT_SECONDARY = "#6B7280"    # Gray 500
    TEXT_TERTIARY = "#9CA3AF"     # Gray 400
    TEXT_DISABLED = "#D1D5DB"     # Gray 300
    TEXT_ON_PRIMARY = "#FFFFFF"
    
    # Status Colors - Unified muted palette
    STATUS_OPEN = "#374151"       # Slate
    STATUS_IN_TRANSIT = "#D97706" # Amber
    STATUS_ARRIVED = "#059669"    # Emerald
    STATUS_DELIVERED = "#374151"  # Slate
    STATUS_CLOSED = "#9CA3AF"     # Gray
    
    # Mode Colors - Minimal differentiation
    MODE_OCEAN = "#374151"        # Slate
    MODE_AIR = "#374151"          # Slate
    MODE_LAND = "#374151"         # Slate
    
    # Section Colors - Subtle variations
    SECTION_TS = "#F9FAFB"        # Very light
    SECTION_FCL = "#F3F4F6"       # Light gray
    SECTION_LCL = "#F3F4F6"       # Light gray
    SECTION_CARGO_DESC = "#F9FAFB"
    SECTION_AIR_CARGO = "#F3F4F6"
    SECTION_LAND_CARGO = "#F3F4F6"
    
    # Card/Panel styles
    CARD_BG = "#FFFFFF"
    CARD_SHADOW = "rgba(0,0,0,0.04)"
    CARD_BORDER = "#E5E7EB"
    
    # Input Fields
    INPUT_BG = "#FFFFFF"
    INPUT_BORDER = "#D1D5DB"
    INPUT_FOCUS = "#374151"
    
    # Table - Minimal
    TABLE_HEADER = "#F9FAFB"
    TABLE_ROW_ODD = "#FFFFFF"
    TABLE_ROW_EVEN = "#F9FAFB"
    TABLE_ROW_HOVER = "#F3F4F6"
    TABLE_BORDER = "#E5E7EB"
    
    # Frame Controls - Subtle
    FRAME_CLOSE = "#EF4444"       # Red 500
    FRAME_MINIMIZE = "#F59E0B"    # Amber 500
    FRAME_ZOOM = "#10B981"        # Emerald 500
    
    # Buttons
    BTN_PRIMARY = "#374151"       # Slate 700
    BTN_PRIMARY_HOVER = "#1F2937" # Slate 800
    BTN_SECONDARY = "#6B7280"     # Gray 500
    BTN_SECONDARY_HOVER = "#4B5563" # Gray 600
    BTN_DANGER = "#DC2626"        # Red 600
    BTN_SUCCESS = "#059669"       # Emerald 600


# ============================================================
# TYPOGRAPHY
# ============================================================

class Typography:
    """Typography settings inspired by SF Pro"""
    
    # Font Family
    FONT_FAMILY = "SF Pro Display"
    FONT_FAMILY_MONO = "SF Mono"
    
    # Font Sizes
    SIZE_H1 = 24
    SIZE_H2 = 20
    SIZE_H3 = 16
    SIZE_H4 = 14
    SIZE_BODY = 13
    SIZE_SMALL = 11
    SIZE_CAPTION = 10
    
    # Font Weights
    WEIGHT_LIGHT = "normal"
    WEIGHT_REGULAR = "normal"
    WEIGHT_MEDIUM = "normal"
    WEIGHT_SEMIBOLD = "bold"
    WEIGHT_BOLD = "bold"


# ============================================================
# SPACING
# ============================================================

class Spacing:
    """Consistent spacing values"""
    
    # Base unit (4px)
    UNIT = 4
    
    # Margins
    MARGIN_XS = 4
    MARGIN_SM = 8
    MARGIN_MD = 16
    MARGIN_LG = 24
    MARGIN_XL = 32
    
    # Padding
    PADDING_XS = 4
    PADDING_SM = 8
    PADDING_MD = 12
    PADDING_LG = 16
    PADDING_XL = 24
    
    # Component spacing
    CARD_PADDING = 16
    SECTION_GAP = 20
    FORM_GAP = 12
    BUTTON_GAP = 8


# ============================================================
# DIMENSIONS
# ============================================================

class Dimensions:
    """Standard dimensions for UI components"""
    
    # Border Radius
    RADIUS_SM = 4
    RADIUS_MD = 8
    RADIUS_LG = 12
    RADIUS_XL = 16
    RADIUS_ROUND = 9999
    
    # Button Heights
    BUTTON_HEIGHT_SM = 28
    BUTTON_HEIGHT_MD = 32
    BUTTON_HEIGHT_LG = 40
    
    # Input Heights
    INPUT_HEIGHT = 32
    TEXTAREA_HEIGHT = 80
    
    # Card Dimensions
    CARD_MIN_HEIGHT = 80
    CARD_BORDER_WIDTH = 1
    
    # Sidebar
    SIDEBAR_WIDTH = 200
    SIDEBAR_COLLAPSED_WIDTH = 60
    
    # Table
    TABLE_ROW_HEIGHT = 32
    TABLE_HEADER_HEIGHT = 36


# ============================================================
# BUTTON STYLES
# ============================================================

class ButtonStyles:
    """Button style presets"""
    
    # Primary Button (Blue)
    PRIMARY = {
        "fg_color": Colors.PRIMARY,
        "hover_color": Colors.PRIMARY_DARK,
        "text_color": Colors.TEXT_ON_PRIMARY,
        "corner_radius": Dimensions.RADIUS_MD,
        "font": (Typography.FONT_FAMILY, Typography.SIZE_BODY),
    }
    
    # Secondary Button (Gray)
    SECONDARY = {
        "fg_color": "#E5E5EA",
        "hover_color": "#D1D1D6",
        "text_color": Colors.TEXT_PRIMARY,
        "corner_radius": Dimensions.RADIUS_MD,
        "font": (Typography.FONT_FAMILY, Typography.SIZE_BODY),
    }
    
    # Success Button (Green)
    SUCCESS = {
        "fg_color": Colors.SUCCESS,
        "hover_color": "#2DB84D",
        "text_color": Colors.TEXT_ON_PRIMARY,
        "corner_radius": Dimensions.RADIUS_MD,
        "font": (Typography.FONT_FAMILY, Typography.SIZE_BODY),
    }
    
    # Danger Button (Red)
    DANGER = {
        "fg_color": Colors.ERROR,
        "hover_color": "#E63329",
        "text_color": Colors.TEXT_ON_PRIMARY,
        "corner_radius": Dimensions.RADIUS_MD,
        "font": (Typography.FONT_FAMILY, Typography.SIZE_BODY),
    }
    
    # Ghost Button (Transparent)
    GHOST = {
        "fg_color": "transparent",
        "hover_color": "#F5F5F7",
        "text_color": Colors.PRIMARY,
        "corner_radius": Dimensions.RADIUS_MD,
        "font": (Typography.FONT_FAMILY, Typography.SIZE_BODY),
    }


# ============================================================
# STATUS BADGES
# ============================================================

class StatusBadge:
    """Status badge style configurations"""
    
    STYLES = {
        "OPEN": {"bg": Colors.PRIMARY_LIGHT, "fg": Colors.PRIMARY},
        "IN TRANSIT": {"bg": Colors.WARNING_LIGHT, "fg": Colors.WARNING},
        "ARRIVED": {"bg": Colors.SUCCESS_LIGHT, "fg": Colors.SUCCESS},
        "DELIVERED": {"bg": "#EDE7F6", "fg": Colors.SECONDARY},
        "CLOSED": {"bg": "#F5F5F5", "fg": Colors.TEXT_SECONDARY},
        "PAID": {"bg": Colors.SUCCESS_LIGHT, "fg": Colors.SUCCESS},
        "PENDING": {"bg": Colors.WARNING_LIGHT, "fg": Colors.WARNING},
        "OVERDUE": {"bg": Colors.ERROR_LIGHT, "fg": Colors.ERROR},
    }
    
    @staticmethod
    def get_style(status):
        """Get badge style for a given status"""
        return StatusBadge.STYLES.get(status.upper(), 
                                      {"bg": Colors.BACKGROUND, "fg": Colors.TEXT_SECONDARY})


# ============================================================
# ICONS
# ============================================================

class Icons:
    """Unicode icons for buttons and labels"""
    
    # Navigation
    MENU = "☰"
    BACK = "←"
    FORWARD = "→"
    UP = "↑"
    DOWN = "↓"
    EXPAND = "▼"
    COLLAPSE = "▲"
    
    # Actions
    SEARCH = "🔍"
    ADD = "+"
    REMOVE = "−"
    DELETE = "🗑"
    EDIT = "✏️"
    SAVE = "💾"
    REFRESH = "🔄"
    EXPORT = "📥"
    IMPORT = "📤"
    PRINT = "🖨️"
    PDF = "📄"
    
    # Status
    SUCCESS = "✓"
    ERROR = "✗"
    WARNING = "⚠️"
    INFO = "ℹ️"
    
    # Transport Modes
    OCEAN = "🚢"
    AIR = "✈️"
    LAND = "🚚"
    
    # Business
    CUSTOMER = "👤"
    COMPANY = "🏢"
    MONEY = "💰"
    CHART = "📊"
    CALENDAR = "📅"
    SETTINGS = "⚙️"
    
    # Documents
    DOCUMENT = "📄"
    FOLDER = "📁"
    CLIPBOARD = "📋"


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def apply_macos_theme(root):
    """
    Apply macOS-inspired theme to the application
    
    Args:
        root: The root CTk window
    """
    import customtkinter as ctk
    from tkinter import ttk
    
    # Set appearance mode
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    
    # Configure ttk styles
    style = ttk.Style()
    
    # Treeview styling
    style.configure("Treeview",
                   background=Colors.WHITE,
                   foreground=Colors.TEXT_PRIMARY,
                   rowheight=Dimensions.TABLE_ROW_HEIGHT,
                   fieldbackground=Colors.WHITE,
                   font=(Typography.FONT_FAMILY, Typography.SIZE_SMALL))
    
    style.configure("Treeview.Heading",
                   background=Colors.BACKGROUND,
                   foreground=Colors.TEXT_PRIMARY,
                   font=(Typography.FONT_FAMILY, Typography.SIZE_SMALL, "bold"))
    
    style.map("Treeview",
             background=[("selected", Colors.PRIMARY_LIGHT)],
             foreground=[("selected", Colors.TEXT_PRIMARY)])
    
    # Combobox styling
    style.configure("TCombobox",
                   font=(Typography.FONT_FAMILY, Typography.SIZE_BODY))


def create_styled_button(parent, text, style="primary", **kwargs):
    """
    Create a styled button with consistent appearance
    
    Args:
        parent: Parent widget
        text: Button text
        style: Button style preset ('primary', 'secondary', 'success', 'danger', 'ghost')
        **kwargs: Additional CTkButton arguments
    
    Returns:
        CTkButton instance
    """
    import customtkinter as ctk
    
    style_map = {
        "primary": ButtonStyles.PRIMARY,
        "secondary": ButtonStyles.SECONDARY,
        "success": ButtonStyles.SUCCESS,
        "danger": ButtonStyles.DANGER,
        "ghost": ButtonStyles.GHOST,
    }
    
    button_style = style_map.get(style, ButtonStyles.PRIMARY)
    
    return ctk.CTkButton(
        parent,
        text=text,
        fg_color=button_style.get("fg_color"),
        hover_color=button_style.get("hover_color"),
        text_color=button_style.get("text_color"),
        corner_radius=button_style.get("corner_radius", Dimensions.RADIUS_MD),
        font=button_style.get("font"),
        **kwargs
    )


def create_section_frame(parent, title, color=None):
    """
    Create a styled section frame with title
    
    Args:
        parent: Parent widget
        title: Section title
        color: Background color (default: Colors.BACKGROUND)
    
    Returns:
        Tuple of (frame, title_label)
    """
    import customtkinter as ctk
    
    frame = ctk.CTkFrame(
        parent,
        fg_color=color or Colors.BACKGROUND,
        corner_radius=Dimensions.RADIUS_MD
    )
    
    title_label = ctk.CTkLabel(
        frame,
        text=title,
        font=(Typography.FONT_FAMILY, Typography.SIZE_H4, "bold"),
        text_color=Colors.TEXT_PRIMARY
    )
    title_label.pack(anchor="w", padx=Spacing.PADDING_MD, pady=(Spacing.PADDING_MD, Spacing.PADDING_SM))
    
    return frame, title_label


def get_mode_color(mode):
    """Get color for transport mode"""
    colors = {
        "OCEAN": Colors.MODE_OCEAN,
        "AIR": Colors.MODE_AIR,
        "LAND": Colors.MODE_LAND,
    }
    return colors.get(mode.upper(), Colors.TEXT_SECONDARY)


def get_status_color(status):
    """Get color for job status"""
    colors = {
        "OPEN": Colors.STATUS_OPEN,
        "IN TRANSIT": Colors.STATUS_IN_TRANSIT,
        "ARRIVED": Colors.STATUS_ARRIVED,
        "DELIVERED": Colors.STATUS_DELIVERED,
        "CLOSED": Colors.STATUS_CLOSED,
    }
    return colors.get(status.upper(), Colors.TEXT_SECONDARY)
