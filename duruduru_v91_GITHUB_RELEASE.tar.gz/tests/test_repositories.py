#!/usr/bin/env python3
# tests/test_repositories.py
# Unit Tests for Repository Layer

"""
Repository Layer Tests
Tests data access layer functionality.
"""

import unittest
import sys
import os
import tempfile
import sqlite3

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestSettlementRepository(unittest.TestCase):
    """Tests for SettlementRepository"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        # Use temporary database for tests
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        # Initialize database
        from db import ensure_db_initialized, get_connection
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from repositories.settlement_repo import SettlementRepository, SettlementItem
        self.repo = SettlementRepository()
        self.SettlementItem = SettlementItem
        
        # Create test job
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, customer, created_at, updated_at)
            VALUES ('OJ250101001', 'OCEAN', 'TEST CUSTOMER', ?, ?)
        """, (now_str(), now_str()))
        self.test_job_id = cur.lastrowid
        conn.commit()
        conn.close()
    
    def tearDown(self):
        """Clean up after each test"""
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM settlement_items WHERE job_id=?", (self.test_job_id,))
        cur.execute("DELETE FROM jobs WHERE id=?", (self.test_job_id,))
        conn.commit()
        conn.close()
    
    def test_save_new_item(self):
        """Test saving a new settlement item"""
        item = self.SettlementItem(
            job_id=self.test_job_id,
            item_type="REVENUE",
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00,
            qty=1,
            amount=1500.00,
            currency="USD"
        )
        
        item_id = self.repo.save(item)
        
        self.assertIsNotNone(item_id)
        self.assertGreater(item_id, 0)
    
    def test_find_by_id(self):
        """Test finding item by ID"""
        # Create item
        item = self.SettlementItem(
            job_id=self.test_job_id,
            item_type="REVENUE",
            freight_code="THC",
            freight_desc="Terminal Handling",
            rate=250.00,
            qty=1,
            amount=250.00
        )
        item_id = self.repo.save(item)
        
        # Find it
        found = self.repo.find_by_id(item_id)
        
        self.assertIsNotNone(found)
        self.assertEqual(found.freight_code, "THC")
        self.assertEqual(found.rate, 250.00)
    
    def test_find_by_job(self):
        """Test finding items by job ID"""
        # Create multiple items
        for code, desc, rate in [("OFR", "Ocean Freight", 1500), ("THC", "THC", 250), ("DOC", "DOC", 50)]:
            item = self.SettlementItem(
                job_id=self.test_job_id,
                item_type="REVENUE",
                freight_code=code,
                freight_desc=desc,
                rate=float(rate),
                qty=1,
                amount=float(rate)
            )
            self.repo.save(item)
        
        # Find all
        items = self.repo.find_by_job(self.test_job_id)
        
        self.assertEqual(len(items), 3)
    
    def test_find_revenue_by_job(self):
        """Test finding only revenue items"""
        # Create revenue and cost items
        for item_type, code in [("REVENUE", "OFR"), ("COST", "OFR"), ("REVENUE", "THC")]:
            item = self.SettlementItem(
                job_id=self.test_job_id,
                item_type=item_type,
                freight_code=code,
                rate=100.00,
                qty=1,
                amount=100.00
            )
            self.repo.save(item)
        
        revenue_items = self.repo.find_revenue_by_job(self.test_job_id)
        
        self.assertEqual(len(revenue_items), 2)
        for item in revenue_items:
            self.assertEqual(item.item_type, "REVENUE")
    
    def test_update_item(self):
        """Test updating an existing item"""
        # Create item
        item = self.SettlementItem(
            job_id=self.test_job_id,
            item_type="REVENUE",
            freight_code="OFR",
            rate=1500.00,
            qty=1,
            amount=1500.00
        )
        item_id = self.repo.save(item)
        
        # Update it
        item.id = item_id
        item.rate = 1800.00
        item.amount = 1800.00
        self.repo.save(item)
        
        # Verify
        updated = self.repo.find_by_id(item_id)
        self.assertEqual(updated.rate, 1800.00)
    
    def test_delete_item(self):
        """Test deleting an item"""
        # Create item
        item = self.SettlementItem(
            job_id=self.test_job_id,
            item_type="REVENUE",
            freight_code="OFR",
            rate=1500.00,
            qty=1,
            amount=1500.00
        )
        item_id = self.repo.save(item)
        
        # Delete it
        result = self.repo.delete(item_id)
        
        self.assertTrue(result)
        self.assertIsNone(self.repo.find_by_id(item_id))
    
    def test_get_totals_by_job(self):
        """Test calculating totals"""
        # Create revenue items
        for rate in [1000, 500, 300]:
            item = self.SettlementItem(
                job_id=self.test_job_id,
                item_type="REVENUE",
                rate=float(rate),
                qty=1,
                total=float(rate)
            )
            self.repo.save(item)
        
        # Create cost items
        for rate in [800, 200]:
            item = self.SettlementItem(
                job_id=self.test_job_id,
                item_type="COST",
                rate=float(rate),
                qty=1,
                total=float(rate)
            )
            self.repo.save(item)
        
        totals = self.repo.get_totals_by_job(self.test_job_id)
        
        self.assertEqual(totals['revenue'], 1800)
        self.assertEqual(totals['cost'], 1000)
        self.assertEqual(totals['profit'], 800)


class TestJobRepository(unittest.TestCase):
    """Tests for JobRepository"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from repositories.job_repo import JobRepository, Job
        self.repo = JobRepository()
        self.Job = Job
    
    def tearDown(self):
        """Clean up after each test"""
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM jobs WHERE job_no LIKE 'TEST%'")
        conn.commit()
        conn.close()
    
    def test_save_new_job(self):
        """Test saving a new job"""
        job = self.Job(
            job_no="TEST001",
            mode="OCEAN",
            op="IMP",
            customer="TEST CUSTOMER"
        )
        
        job_id = self.repo.save(job)
        
        self.assertIsNotNone(job_id)
        self.assertGreater(job_id, 0)
    
    def test_find_by_job_no(self):
        """Test finding job by number"""
        job = self.Job(
            job_no="TEST002",
            mode="AIR",
            customer="AIR CUSTOMER"
        )
        self.repo.save(job)
        
        found = self.repo.find_by_job_no("TEST002")
        
        self.assertIsNotNone(found)
        self.assertEqual(found.mode, "AIR")
    
    def test_search_jobs(self):
        """Test searching jobs"""
        # Create multiple jobs
        for i in range(5):
            job = self.Job(
                job_no=f"TEST00{i}",
                mode="OCEAN",
                mbl=f"MBL{i}",
                hbl=f"HBL{i}"
            )
            self.repo.save(job)
        
        # Search by MBL
        results = self.repo.search("MBL2")
        
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].job_no, "TEST002")
    
    def test_get_next_job_no(self):
        """Test job number generation"""
        next_no = self.repo.get_next_job_no("OCEAN", "2601")
        
        self.assertTrue(next_no.startswith("OJ2601"))


class TestCompanyRepository(unittest.TestCase):
    """Tests for CompanyRepository"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from repositories.company_repo import CompanyRepository, Company
        self.repo = CompanyRepository()
        self.Company = Company
    
    def test_find_by_type(self):
        """Test finding companies by type"""
        # Create test companies
        for name, comp_type in [("MSC", "Shipping Line"), ("AA", "Airline"), ("TRUCKO", "Trucker")]:
            company = self.Company(
                code=name,
                name=f"{name} Company",
                type=comp_type
            )
            self.repo.save(company)
        
        # Find shipping lines
        shipping_lines = self.repo.find_by_type("Shipping Line")
        
        self.assertGreaterEqual(len(shipping_lines), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
