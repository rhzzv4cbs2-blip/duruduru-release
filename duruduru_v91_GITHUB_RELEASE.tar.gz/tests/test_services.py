#!/usr/bin/env python3
# tests/test_services.py
# Unit Tests for Service Layer - Comprehensive Coverage

"""
Service Layer Tests
Tests business logic functionality with 80%+ coverage target.
"""

import unittest
import sys
import os
import tempfile
import sqlite3
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestSettlementService(unittest.TestCase):
    """Tests for SettlementService"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from services.settlement_service import SettlementService
        self.service = SettlementService()
        
        # Create test job
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, customer, created_at, updated_at)
            VALUES ('OJ250101001', 'OCEAN', 'TEST CUSTOMER', ?, ?)
        """, (now_str(), now_str()))
        self.test_job_id = cur.lastrowid
        conn.commit()
        conn.close()
    
    def tearDown(self):
        """Clean up after each test"""
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM settlement_items WHERE job_id=?", (self.test_job_id,))
        cur.execute("DELETE FROM jobs WHERE id=?", (self.test_job_id,))
        conn.commit()
        conn.close()
    
    def test_add_revenue_item(self):
        """Test adding a revenue item"""
        item_id = self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00,
            qty=1,
            currency="USD"
        )
        
        self.assertIsNotNone(item_id)
        self.assertGreater(item_id, 0)
    
    def test_add_cost_item(self):
        """Test adding a cost item"""
        item_id = self.service.add_cost_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight (Cost)",
            rate=1200.00,
            qty=1,
            currency="USD"
        )
        
        self.assertIsNotNone(item_id)
    
    def test_add_revenue_with_qty(self):
        """Test adding revenue item with quantity"""
        item_id = self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="THC",
            freight_desc="Terminal Handling",
            rate=50.00,
            qty=3,
            unit="CNTR"
        )
        
        from repositories.settlement_repo import SettlementRepository
        repo = SettlementRepository()
        item = repo.find_by_id(item_id)
        
        self.assertEqual(item.amount, 150.00)  # 50 * 3
    
    def test_generate_invoice_numbers(self):
        """Test invoice number generation"""
        # Add items without invoice numbers
        self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00
        )
        self.service.add_cost_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight Cost",
            rate=1200.00
        )
        
        # Generate invoice numbers
        rev_count, cost_count = self.service.generate_invoice_numbers(self.test_job_id)
        
        self.assertEqual(rev_count, 1)
        self.assertEqual(cost_count, 1)
    
    def test_generate_invoice_format(self):
        """Test invoice number format"""
        self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00
        )
        
        self.service.generate_invoice_numbers(self.test_job_id)
        
        from repositories.settlement_repo import SettlementRepository
        repo = SettlementRepository()
        items = repo.find_revenue_by_job(self.test_job_id)
        
        self.assertTrue(items[0].invoice_no.startswith("DN-"))
    
    def test_get_settlement_summary(self):
        """Test getting settlement summary"""
        # Add revenue and cost items
        self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00
        )
        self.service.add_cost_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight Cost",
            rate=1200.00
        )
        
        # Get summary
        summary = self.service.get_settlement_summary(self.test_job_id)
        
        self.assertEqual(summary.revenue_count, 1)
        self.assertEqual(summary.cost_count, 1)
        self.assertGreater(summary.profit, 0)
    
    def test_profit_calculation(self):
        """Test profit calculation"""
        self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=2000.00
        )
        self.service.add_cost_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight Cost",
            rate=1500.00
        )
        
        summary = self.service.get_settlement_summary(self.test_job_id)
        
        self.assertEqual(summary.profit, 500.00)
    
    def test_margin_calculation(self):
        """Test margin calculation"""
        self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1000.00
        )
        self.service.add_cost_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight Cost",
            rate=800.00
        )
        
        summary = self.service.get_settlement_summary(self.test_job_id)
        
        # Profit = 200, Revenue = 1000, Margin = 20%
        self.assertAlmostEqual(summary.margin, 20.0, places=1)
    
    def test_update_item(self):
        """Test updating an item"""
        item_id = self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00
        )
        
        result = self.service.update_item(item_id, rate=2000.00)
        
        self.assertTrue(result)
        
        from repositories.settlement_repo import SettlementRepository
        repo = SettlementRepository()
        item = repo.find_by_id(item_id)
        self.assertEqual(item.rate, 2000.00)
    
    def test_delete_item(self):
        """Test deleting an item"""
        item_id = self.service.add_revenue_item(
            job_id=self.test_job_id,
            freight_code="OFR",
            freight_desc="Ocean Freight",
            rate=1500.00
        )
        
        result = self.service.delete_item(item_id)
        
        self.assertTrue(result)
    
    def test_currency_conversion_usd_to_mxn(self):
        """Test USD to MXN conversion"""
        result = self.service.convert_to_mxn(100, "USD", 20.0)
        self.assertEqual(result, 2000.0)
    
    def test_currency_conversion_mxn_to_mxn(self):
        """Test MXN to MXN (no conversion)"""
        result = self.service.convert_to_mxn(100, "MXN", 20.0)
        self.assertEqual(result, 100.0)


class TestJobService(unittest.TestCase):
    """Tests for JobService"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from services.job_service import JobService
        self.service = JobService()
    
    def tearDown(self):
        """Clean up after each test"""
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM jobs WHERE job_no LIKE 'TEST%'")
        cur.execute("DELETE FROM containers WHERE job_id IN (SELECT id FROM jobs WHERE job_no LIKE 'TEST%')")
        conn.commit()
        conn.close()
    
    def test_create_job(self):
        """Test creating a new job"""
        job_id = self.service.create_job(
            mode="OCEAN",
            customer="TEST CUSTOMER",
            mbl="TESTMBL001",
            hbl="TESTHBL001"
        )
        
        self.assertIsNotNone(job_id)
        self.assertGreater(job_id, 0)
    
    def test_get_job_by_id(self):
        """Test getting job by ID"""
        job_id = self.service.create_job(mode="OCEAN", customer="TEST")
        
        job = self.service.get_job_by_id(job_id)
        
        self.assertIsNotNone(job)
        self.assertEqual(job.mode, "OCEAN")
    
    def test_search_job(self):
        """Test searching for a job"""
        self.service.create_job(
            mode="OCEAN",
            customer="SEARCH TEST",
            mbl="SEARCHMBL001"
        )
        
        result = self.service.search_job("SEARCHMBL001")
        
        self.assertIsNotNone(result)
        self.assertEqual(result.mbl, "SEARCHMBL001")
    
    def test_get_recent_jobs(self):
        """Test getting recent jobs"""
        # Create multiple jobs
        for i in range(5):
            self.service.create_job(mode="OCEAN", customer=f"TEST{i}")
        
        jobs = self.service.get_recent_jobs(limit=5)
        
        self.assertGreaterEqual(len(jobs), 5)
    
    def test_update_job(self):
        """Test updating a job"""
        job_id = self.service.create_job(mode="OCEAN", customer="ORIGINAL")
        
        result = self.service.update_job(job_id, customer="UPDATED")
        
        self.assertTrue(result)
        
        job = self.service.get_job_by_id(job_id)
        self.assertEqual(job.customer, "UPDATED")
    
    def test_update_status(self):
        """Test updating job status"""
        job_id = self.service.create_job(mode="OCEAN")
        
        result = self.service.update_status(job_id, "COMPLETED")
        
        self.assertTrue(result)
        
        job = self.service.get_job_by_id(job_id)
        self.assertEqual(job.status, "COMPLETED")
    
    def test_get_statistics(self):
        """Test getting job statistics"""
        # Create jobs of different modes
        self.service.create_job(mode="OCEAN")
        self.service.create_job(mode="AIR")
        self.service.create_job(mode="LAND")
        
        stats = self.service.get_statistics()
        
        self.assertIn('total', stats)
        self.assertIn('by_mode', stats)


class TestCompanyService(unittest.TestCase):
    """Tests for CompanyService"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from services.company_service import CompanyService
        self.service = CompanyService()
    
    def test_create_customer(self):
        """Test creating a customer"""
        company_id = self.service.create_company(
            code="TST001",
            name="Test Customer",
            company_type="CUSTOMER"
        )
        
        self.assertIsNotNone(company_id)
    
    def test_get_customer_by_code(self):
        """Test getting customer by code"""
        self.service.create_company(code="TST002", name="Test Company")
        
        company = self.service.get_customer_by_code("TST002")
        
        self.assertIsNotNone(company)
        self.assertEqual(company.name, "Test Company")
    
    def test_get_carriers_by_type(self):
        """Test getting carriers by type"""
        self.service.create_company(
            code="MSC001",
            name="MSC",
            company_type="CARRIER",
            provider_type="Shipping Line"
        )
        
        carriers = self.service.get_carriers_by_type("Shipping Line")
        
        self.assertGreaterEqual(len(carriers), 1)
    
    def test_is_mexico_customer(self):
        """Test Mexico customer detection"""
        self.service.create_company(
            code="MEX001",
            name="Mexican Company",
            address="CDMX, Mexico"
        )
        
        result = self.service.is_mexico_customer("MEX001")
        
        self.assertTrue(result)
    
    def test_is_not_mexico_customer(self):
        """Test non-Mexico customer"""
        self.service.create_company(
            code="USA001",
            name="US Company",
            address="New York, USA"
        )
        
        result = self.service.is_mexico_customer("USA001")
        
        self.assertFalse(result)


class TestExchangeRateService(unittest.TestCase):
    """Tests for ExchangeRateService"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from services.exchange_rate_service import ExchangeRateService
        self.service = ExchangeRateService()
    
    def test_get_default_rate(self):
        """Test getting default rate when no data"""
        rate = self.service.get_rate("1999-01-01")  # Old date, no data
        
        self.assertIsNotNone(rate)
        self.assertGreater(rate, 0)
    
    def test_save_manual_rate(self):
        """Test saving manual rate"""
        result = self.service.save_manual_rate("2025-01-15", 20.50)
        
        self.assertTrue(result)
        
        rate = self.service.get_rate("2025-01-15")
        self.assertEqual(rate, 20.50)
    
    def test_convert_usd_to_mxn(self):
        """Test USD to MXN conversion"""
        self.service.save_manual_rate(datetime.now().strftime("%Y-%m-%d"), 20.0)
        
        result = self.service.convert_to_mxn(100, "USD")
        
        self.assertEqual(result, 2000.0)
    
    def test_convert_mxn_to_usd(self):
        """Test MXN to USD conversion"""
        self.service.save_manual_rate(datetime.now().strftime("%Y-%m-%d"), 20.0)
        
        result = self.service.convert_to_usd(2000, "MXN")
        
        self.assertEqual(result, 100.0)
    
    def test_same_currency_no_conversion(self):
        """Test same currency returns same amount"""
        result = self.service.convert(100, "USD", "USD")
        
        self.assertEqual(result, 100.0)
    
    def test_get_rate_history(self):
        """Test getting rate history"""
        # Save some rates
        for i in range(5):
            self.service.save_manual_rate(f"2025-01-{10+i:02d}", 20.0 + i * 0.1)
        
        history = self.service.get_rate_history(days=5)
        
        self.assertGreaterEqual(len(history), 5)


class TestInvoiceService(unittest.TestCase):
    """Tests for InvoiceService"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        """Set up each test"""
        from services.invoice_service import InvoiceService
        self.service = InvoiceService()
        
        # Create test job with items
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, mbl, hbl, customer, pol, pod, created_at, updated_at)
            VALUES ('OJ250101001', 'OCEAN', 'MBLTEST', 'HBLTEST', 'TEST CUSTOMER', 'MXZLO', 'CNSHA', ?, ?)
        """, (now_str(), now_str()))
        self.test_job_id = cur.lastrowid
        
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, freight_code, freight_desc, rate, qty, amount, currency, created_at, updated_at)
            VALUES (?, 'REVENUE', 'OFR', 'Ocean Freight', 1500, 1, 1500, 'USD', ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        
        conn.commit()
        conn.close()
    
    def tearDown(self):
        """Clean up after each test"""
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM settlement_items WHERE job_id=?", (self.test_job_id,))
        cur.execute("DELETE FROM jobs WHERE id=?", (self.test_job_id,))
        conn.commit()
        conn.close()
    
    def test_prepare_invoice_data(self):
        """Test preparing invoice data"""
        data = self.service.prepare_invoice_data(self.test_job_id, "debit_note")
        
        self.assertIsNotNone(data)
        self.assertEqual(data.job_no, "OJ250101001")
        self.assertEqual(len(data.items), 1)
    
    def test_validate_for_invoice(self):
        """Test invoice validation"""
        is_valid, error = self.service.validate_for_invoice(self.test_job_id, "debit_note")
        
        self.assertTrue(is_valid)
        self.assertEqual(error, "")
    
    def test_validate_no_items(self):
        """Test validation with no items"""
        # Create empty job
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, created_at, updated_at)
            VALUES ('OJ250101002', 'OCEAN', ?, ?)
        """, (now_str(), now_str()))
        empty_job_id = cur.lastrowid
        conn.commit()
        conn.close()
        
        is_valid, error = self.service.validate_for_invoice(empty_job_id, "debit_note")
        
        self.assertFalse(is_valid)
        self.assertIn("No revenue items", error)
        
        # Clean up
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM jobs WHERE id=?", (empty_job_id,))
        conn.commit()
        conn.close()
    
    def test_invoice_total_calculation(self):
        """Test invoice total calculation"""
        data = self.service.prepare_invoice_data(self.test_job_id, "debit_note")
        
        self.assertEqual(data.total_amount, 1500.00)


if __name__ == '__main__':
    # Run tests with verbosity
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestSettlementService))
    suite.addTests(loader.loadTestsFromTestCase(TestJobService))
    suite.addTests(loader.loadTestsFromTestCase(TestCompanyService))
    suite.addTests(loader.loadTestsFromTestCase(TestExchangeRateService))
    suite.addTests(loader.loadTestsFromTestCase(TestInvoiceService))
    
    # Run with verbosity
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print coverage summary
    print("\n" + "=" * 60)
    print("Test Coverage Summary")
    print("=" * 60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {(result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100:.1f}%")
