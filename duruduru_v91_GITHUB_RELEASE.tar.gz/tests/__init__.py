# tests/__init__.py
# Unit Tests for DURUDURU Freight System

"""
Test Suite for DURUDURU

Run all tests:
    python -m pytest tests/

Run specific test:
    python -m pytest tests/test_repositories.py -v

Run with coverage:
    python -m pytest tests/ --cov=. --cov-report=html
"""
