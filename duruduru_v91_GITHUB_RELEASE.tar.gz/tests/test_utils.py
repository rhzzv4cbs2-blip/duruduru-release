# tests/test_utils.py
# Unit tests for centralized utilities module

import pytest
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDateTimeUtilities:
    """Tests for date/time utility functions"""
    
    def test_now_str_format(self):
        """Test now_str returns correct format"""
        from utils import now_str
        
        result = now_str()
        
        # Should be YYYY-MM-DD HH:MM:SS format
        assert len(result) == 19
        assert result[4] == '-'
        assert result[7] == '-'
        assert result[10] == ' '
        assert result[13] == ':'
        assert result[16] == ':'
    
    def test_today_str_format(self):
        """Test today_str returns correct format"""
        from utils import today_str
        
        result = today_str()
        
        # Should be YYYY-MM-DD format
        assert len(result) == 10
        assert result[4] == '-'
        assert result[7] == '-'
    
    def test_format_date(self):
        """Test date formatting"""
        from utils import format_date
        
        dt = datetime(2026, 1, 15, 10, 30, 45)
        
        assert format_date(dt) == "2026-01-15"
        assert format_date(dt, "%Y/%m/%d") == "2026/01/15"
        assert format_date(dt, "%d-%m-%Y") == "15-01-2026"
        assert format_date(None) == ""
    
    def test_parse_date(self):
        """Test date parsing"""
        from utils import parse_date
        
        result = parse_date("2026-01-15")
        assert result is not None
        assert result.year == 2026
        assert result.month == 1
        assert result.day == 15
        
        # Invalid date
        assert parse_date("invalid") is None
        assert parse_date("") is None
        assert parse_date(None) is None


class TestNumberFormatting:
    """Tests for number formatting functions"""
    
    def test_format_currency_usd(self):
        """Test USD currency formatting"""
        from utils import format_currency
        
        assert format_currency(1000) == "$1,000.00"
        assert format_currency(1234.56) == "$1,234.56"
        assert format_currency(0) == "$0.00"
        assert format_currency(1000000) == "$1,000,000.00"
    
    def test_format_currency_mxn(self):
        """Test MXN currency formatting"""
        from utils import format_currency
        
        assert format_currency(1000, "MXN") == "$1,000.00 MXN"
        assert format_currency(20500, "MXN") == "$20,500.00 MXN"
    
    def test_format_currency_decimals(self):
        """Test currency formatting with different decimal places"""
        from utils import format_currency
        
        assert format_currency(1234.5678, decimals=4) == "$1,234.5678"
        assert format_currency(1234.5, decimals=0) == "$1,234"
    
    def test_parse_number(self):
        """Test number parsing"""
        from utils import parse_number
        
        assert parse_number("1234.56") == 1234.56
        assert parse_number("1,234.56") == 1234.56
        assert parse_number("$1,234.56") == 1234.56
        assert parse_number(100) == 100.0
        assert parse_number(None) == 0.0
        assert parse_number("invalid") == 0.0
        assert parse_number("", 10.0) == 10.0  # Custom default
    
    def test_format_percent(self):
        """Test percentage formatting"""
        from utils import format_percent
        
        assert format_percent(25.5) == "25.5%"
        assert format_percent(100) == "100.0%"
        assert format_percent(33.333, decimals=2) == "33.33%"


class TestValidation:
    """Tests for validation utilities"""
    
    def test_is_valid_email(self):
        """Test email validation"""
        from utils import is_valid_email
        
        assert is_valid_email("test@example.com") is True
        assert is_valid_email("user.name@domain.org") is True
        assert is_valid_email("user+tag@example.com") is True
        
        assert is_valid_email("invalid") is False
        assert is_valid_email("@example.com") is False
        assert is_valid_email("test@") is False
        assert is_valid_email("") is False
        assert is_valid_email(None) is False
    
    def test_is_valid_phone(self):
        """Test phone validation"""
        from utils import is_valid_phone
        
        assert is_valid_phone("5551234567") is True
        assert is_valid_phone("555-123-4567") is True
        assert is_valid_phone("+1 (555) 123-4567") is True
        assert is_valid_phone("12345678901") is True
        
        assert is_valid_phone("123") is False  # Too short
        assert is_valid_phone("") is False
        assert is_valid_phone(None) is False
    
    def test_sanitize_filename(self):
        """Test filename sanitization"""
        from utils import sanitize_filename
        
        assert sanitize_filename("normal_file.txt") == "normal_file.txt"
        assert sanitize_filename("file<with>chars.txt") == "file_with_chars.txt"
        assert sanitize_filename('file"name".txt') == "file_name_.txt"
        assert sanitize_filename("file:name.txt") == "file_name.txt"
        assert sanitize_filename("") == "untitled"
        assert sanitize_filename(None) == "untitled"


class TestStringUtilities:
    """Tests for string utility functions"""
    
    def test_truncate(self):
        """Test string truncation"""
        from utils import truncate
        
        assert truncate("Hello World", 50) == "Hello World"
        assert truncate("Hello World", 8) == "Hello..."
        assert truncate("Hello World", 8, "..") == "Hello.."
        assert truncate("", 10) == ""
        assert truncate(None, 10) == ""
    
    def test_clean_whitespace(self):
        """Test whitespace cleaning"""
        from utils import clean_whitespace
        
        assert clean_whitespace("  Hello   World  ") == "Hello World"
        assert clean_whitespace("Hello\n\nWorld") == "Hello World"
        assert clean_whitespace("Hello\t\tWorld") == "Hello World"
        assert clean_whitespace("") == ""
        assert clean_whitespace(None) == ""
    
    def test_generate_code(self):
        """Test code generation"""
        from utils import generate_code
        
        assert generate_code("JOB", 1) == "JOB-0001"
        assert generate_code("JOB", 123) == "JOB-0123"
        assert generate_code("JOB", 12345) == "JOB-12345"
        assert generate_code("INV", 1, width=6) == "INV-000001"


class TestCaching:
    """Tests for caching utilities"""
    
    def test_cached_query(self):
        """Test query caching"""
        from utils import cached_query, clear_cache
        
        # Clear any existing cache
        clear_cache()
        
        call_count = [0]
        
        def expensive_query():
            call_count[0] += 1
            return {"data": "result"}
        
        # First call
        result1 = cached_query("test_key", expensive_query, ttl=60)
        assert result1 == {"data": "result"}
        assert call_count[0] == 1
        
        # Second call (should use cache)
        result2 = cached_query("test_key", expensive_query, ttl=60)
        assert result2 == {"data": "result"}
        assert call_count[0] == 1  # Should not increment
    
    def test_clear_cache(self):
        """Test cache clearing"""
        from utils import cached_query, clear_cache
        
        call_count = [0]
        
        def query():
            call_count[0] += 1
            return "data"
        
        # First call
        cached_query("key1", query)
        assert call_count[0] == 1
        
        # Clear cache
        clear_cache()
        
        # Should call again
        cached_query("key1", query)
        assert call_count[0] == 2
    
    def test_clear_cache_with_prefix(self):
        """Test cache clearing with prefix"""
        from utils import cached_query, clear_cache
        
        cached_query("user_1", lambda: "user1")
        cached_query("user_2", lambda: "user2")
        cached_query("job_1", lambda: "job1")
        
        # Clear only user keys
        clear_cache(prefix="user_")
        
        # user keys should be cleared, job should remain
        call_count = [0]
        
        def counter():
            call_count[0] += 1
            return call_count[0]
        
        cached_query("job_1", counter)  # Should use cache
        assert call_count[0] == 0  # Not called because cached


class TestExchangeRate:
    """Tests for exchange rate utilities"""
    
    def test_convert_currency_same(self):
        """Test same currency conversion"""
        from utils import convert_currency
        
        assert convert_currency(1000, "USD", "USD") == 1000
        assert convert_currency(5000, "MXN", "MXN") == 5000
    
    def test_convert_currency_with_rate(self):
        """Test currency conversion with explicit rate"""
        from utils import convert_currency
        
        # USD to MXN
        assert convert_currency(100, "USD", "MXN", rate=20.0) == 2000.0
        
        # MXN to USD (would need inverse rate)
        # Note: This test assumes the function multiplies by rate
        # In real implementation, you'd need to handle direction


class TestLogging:
    """Tests for logging utilities"""
    
    def test_setup_logger(self):
        """Test logger setup"""
        from utils import setup_logger
        import logging
        
        logger = setup_logger("test_module")
        
        assert logger is not None
        assert logger.name == "test_module"
        assert logger.level == logging.INFO
    
    def test_setup_logger_custom_level(self):
        """Test logger with custom level"""
        from utils import setup_logger
        import logging
        
        logger = setup_logger("debug_module", level=logging.DEBUG)
        
        assert logger.level == logging.DEBUG


# ============================================================
# RUN TESTS
# ============================================================
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
