# tests/test_integration.py
# Integration Tests for DURUDURU
# Tests complete workflows across modules

"""
Integration Tests
=================
Tests for complete business workflows:
- Job registration to settlement
- Quote to invoice
- Customer management
- Truck line operations
"""

import pytest
import sqlite3
import tempfile
import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDatabaseIntegration:
    """Test database operations across tables"""
    
    @pytest.fixture
    def db_connection(self):
        """Create temporary database"""
        fd, path = tempfile.mkstemp(suffix='.db')
        conn = sqlite3.connect(path)
        conn.row_factory = sqlite3.Row
        
        # Create tables
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS companies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                company_type TEXT DEFAULT 'CUSTOMER',
                type TEXT,
                address TEXT,
                city TEXT,
                country TEXT,
                phone TEXT,
                email TEXT,
                tax_id TEXT,
                created_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_no TEXT UNIQUE NOT NULL,
                mode TEXT NOT NULL DEFAULT 'OCEAN',
                op_type TEXT DEFAULT 'EXPO',
                mbl TEXT,
                hbl TEXT,
                shipper TEXT,
                consignee TEXT,
                customer TEXT,
                customer_code TEXT,
                partner TEXT,
                carrier TEXT,
                truck_line TEXT,
                vessel TEXT,
                voyage TEXT,
                pol TEXT,
                pod TEXT,
                etd TEXT,
                eta TEXT,
                atd TEXT,
                ata TEXT,
                status TEXT DEFAULT 'OPEN',
                remarks TEXT,
                created_at TEXT,
                updated_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS containers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER NOT NULL,
                cntr_no TEXT,
                cntr_type TEXT,
                seal_no TEXT,
                weight REAL DEFAULT 0,
                cbm REAL DEFAULT 0,
                pcs INTEGER DEFAULT 0,
                status TEXT DEFAULT 'BOOKED',
                location TEXT,
                FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
            );
            
            CREATE TABLE IF NOT EXISTS settlement_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id INTEGER,
                job_no TEXT,
                customer_code TEXT,
                customer_name TEXT,
                item_type TEXT DEFAULT 'REVENUE',
                description TEXT,
                qty REAL DEFAULT 1,
                rate REAL DEFAULT 0,
                amount REAL DEFAULT 0,
                currency TEXT DEFAULT 'USD',
                invoice_no TEXT,
                created_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quote_no TEXT UNIQUE NOT NULL,
                date TEXT,
                valid_until TEXT,
                customer_name TEXT,
                customer_code TEXT,
                revenue_total REAL DEFAULT 0,
                cost_total REAL DEFAULT 0,
                profit REAL DEFAULT 0,
                margin REAL DEFAULT 0,
                status TEXT DEFAULT 'DRAFT',
                created_at TEXT
            );
            
            CREATE TABLE IF NOT EXISTS exchange_rates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_currency TEXT DEFAULT 'USD',
                to_currency TEXT DEFAULT 'MXN',
                rate REAL NOT NULL,
                rate_date TEXT,
                source TEXT DEFAULT 'MANUAL',
                created_at TEXT
            );
        """)
        conn.commit()
        
        yield conn
        
        conn.close()
        os.close(fd)
        os.unlink(path)
    
    def test_complete_job_workflow(self, db_connection):
        """Test complete job workflow: create -> update -> settlement"""
        conn = db_connection
        cur = conn.cursor()
        
        # 1. Create customer
        cur.execute("""
            INSERT INTO companies (code, name, company_type, city, country)
            VALUES ('CUST001', 'Test Customer', 'CUSTOMER', 'Mexico City', 'Mexico')
        """)
        
        # 2. Create job with truck_line
        cur.execute("""
            INSERT INTO jobs (job_no, mode, customer, customer_code, pol, pod, etd, status, truck_line)
            VALUES ('JSE20260108001', 'OCEAN', 'Test Customer', 'CUST001', 'MXMZL', 'CNSHA', '2026-01-15', 'OPEN', 'TRANSPORTES ABC')
        """)
        job_id = cur.lastrowid
        
        # 3. Add container
        cur.execute("""
            INSERT INTO containers (job_id, cntr_no, cntr_type, weight, cbm, status)
            VALUES (?, 'MSCU1234567', '40HC', 20000, 65.5, 'BOOKED')
        """, (job_id,))
        
        # 4. Update job status and truck_line (simulating inline edit)
        cur.execute("""
            UPDATE jobs SET status = 'IN TRANSIT', atd = '2026-01-15', truck_line = 'UPDATED TRUCKER' 
            WHERE id = ?
        """, (job_id,))
        
        # 5. Create settlement items (revenue + cost)
        cur.execute("""
            INSERT INTO settlement_items (job_id, job_no, customer_code, item_type, description, qty, rate, amount, currency)
            VALUES (?, 'JSE20260108001', 'CUST001', 'REVENUE', 'Ocean Freight', 1, 2500, 2500, 'USD')
        """, (job_id,))
        
        cur.execute("""
            INSERT INTO settlement_items (job_id, job_no, item_type, description, qty, rate, amount, currency)
            VALUES (?, 'JSE20260108001', 'COST', 'Carrier Cost', 1, 1800, 1800, 'USD')
        """, (job_id,))
        
        conn.commit()
        
        # Verify workflow
        cur.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        job = cur.fetchone()
        assert job['status'] == 'IN TRANSIT'
        assert job['truck_line'] == 'UPDATED TRUCKER'
        
        cur.execute("SELECT * FROM containers WHERE job_id = ?", (job_id,))
        container = cur.fetchone()
        assert container['cntr_no'] == 'MSCU1234567'
        
        # Calculate profit
        cur.execute("""
            SELECT 
                SUM(CASE WHEN item_type = 'REVENUE' THEN amount ELSE 0 END) as revenue,
                SUM(CASE WHEN item_type = 'COST' THEN amount ELSE 0 END) as cost
            FROM settlement_items WHERE job_id = ?
        """, (job_id,))
        result = cur.fetchone()
        
        profit = result['revenue'] - result['cost']
        assert profit == 700  # 2500 - 1800
    
    def test_truck_line_search_and_update(self, db_connection):
        """Test truck_line column search and inline update - KEY TEST"""
        conn = db_connection
        cur = conn.cursor()
        
        # Create jobs with truck_line
        cur.execute("""
            INSERT INTO jobs (job_no, mode, truck_line, status)
            VALUES ('JLA20260108001', 'LAND', 'TRANSPORTES ABC', 'OPEN')
        """)
        cur.execute("""
            INSERT INTO jobs (job_no, mode, truck_line, status)
            VALUES ('JLA20260108002', 'LAND', 'FLETES XYZ', 'OPEN')
        """)
        cur.execute("""
            INSERT INTO jobs (job_no, mode, truck_line, status)
            VALUES ('JSE20260108001', 'OCEAN', '', 'OPEN')
        """)
        conn.commit()
        
        # Search by truck_line (simulating STATUS filter)
        cur.execute("""
            SELECT job_no, truck_line FROM jobs 
            WHERE truck_line LIKE '%ABC%'
        """)
        results = cur.fetchall()
        assert len(results) == 1
        assert results[0]['job_no'] == 'JLA20260108001'
        
        # Update truck_line via inline edit (simulating double-click edit)
        cur.execute("""
            UPDATE jobs SET truck_line = 'UPDATED TRUCKER' WHERE job_no = 'JLA20260108002'
        """)
        conn.commit()
        
        cur.execute("SELECT truck_line FROM jobs WHERE job_no = 'JLA20260108002'")
        result = cur.fetchone()
        assert result['truck_line'] == 'UPDATED TRUCKER'
        
        # Test search with empty truck_line
        cur.execute("""
            SELECT job_no FROM jobs 
            WHERE truck_line IS NULL OR truck_line = ''
        """)
        empty_results = cur.fetchall()
        assert len(empty_results) == 1
        assert empty_results[0]['job_no'] == 'JSE20260108001'
    
    def test_land_job_with_trucker(self, db_connection):
        """Test LAND mode job creation with trucker info"""
        conn = db_connection
        cur = conn.cursor()
        
        # Create trucker company
        cur.execute("""
            INSERT INTO companies (code, name, company_type)
            VALUES ('TRCK001', 'Fast Trucking Co', 'TRUCKER')
        """)
        
        # Create LAND job
        cur.execute("""
            INSERT INTO jobs (job_no, mode, customer, carrier, truck_line, pol, pod, etd, eta, status)
            VALUES ('JLA20260108001', 'LAND', 'Test Customer', 'TRCK001', 'Fast Trucking Co', 
                    'Mexico City', 'Monterrey', '2026-01-08', '2026-01-09', 'OPEN')
        """)
        job_id = cur.lastrowid
        conn.commit()
        
        # Verify LAND job
        cur.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        job = cur.fetchone()
        
        assert job['mode'] == 'LAND'
        assert job['truck_line'] == 'Fast Trucking Co'
        assert job['carrier'] == 'TRCK001'
        assert job['pol'] == 'Mexico City'
        assert job['pod'] == 'Monterrey'
    
    def test_exchange_rate_lookup(self, db_connection):
        """Test exchange rate lookup with date fallback"""
        conn = db_connection
        cur = conn.cursor()
        
        # Add exchange rates
        cur.execute("""
            INSERT INTO exchange_rates (from_currency, to_currency, rate, rate_date, source)
            VALUES ('USD', 'MXN', 20.50, '2026-01-05', 'API')
        """)
        cur.execute("""
            INSERT INTO exchange_rates (from_currency, to_currency, rate, rate_date, source)
            VALUES ('USD', 'MXN', 20.65, '2026-01-08', 'MANUAL')
        """)
        conn.commit()
        
        # Test exact date lookup
        cur.execute("""
            SELECT rate FROM exchange_rates 
            WHERE from_currency = 'USD' AND to_currency = 'MXN' AND rate_date = '2026-01-08'
        """)
        result = cur.fetchone()
        assert result['rate'] == 20.65
        
        # Test fallback to most recent
        cur.execute("""
            SELECT rate FROM exchange_rates 
            WHERE from_currency = 'USD' AND to_currency = 'MXN'
            ORDER BY rate_date DESC LIMIT 1
        """)
        result = cur.fetchone()
        assert result['rate'] == 20.65


class TestConfigIntegration:
    """Test config module integration"""
    
    def test_config_imports(self):
        """Test config module can be imported"""
        from config import COLORS, FONTS, SPACING, SIZES, PERFORMANCE
        
        assert COLORS.PRIMARY == "#1565C0"
        assert FONTS.SIZE_BASE == 12
        assert SPACING.MD == 12
        assert SIZES.BUTTON_HEIGHT_MD == 32
        assert PERFORMANCE.DEFAULT_PAGE_SIZE == 100
    
    def test_color_consistency(self):
        """Test color values are valid hex"""
        from config import COLORS
        import re
        
        hex_pattern = re.compile(r'^#[0-9A-Fa-f]{6}$')
        
        # Check all color attributes
        for attr in dir(COLORS):
            if not attr.startswith('_'):
                value = getattr(COLORS, attr)
                if isinstance(value, str) and value.startswith('#'):
                    assert hex_pattern.match(value), f"Invalid color: {attr}={value}"
    
    def test_status_color_mapping(self):
        """Test status colors are mapped correctly"""
        from config import get_status_color, COLORS
        
        assert get_status_color('OPEN') == COLORS.STATUS_OPEN
        assert get_status_color('IN TRANSIT') == COLORS.STATUS_TRANSIT
        assert get_status_color('DELIVERED') == COLORS.STATUS_DELIVERED


class TestPaginationLogic:
    """Test pagination calculations"""
    
    def test_page_calculation(self):
        """Test total pages calculation"""
        def calc_pages(total, page_size):
            return max(1, (total + page_size - 1) // page_size)
        
        assert calc_pages(0, 100) == 1
        assert calc_pages(50, 100) == 1
        assert calc_pages(100, 100) == 1
        assert calc_pages(101, 100) == 2
        assert calc_pages(250, 100) == 3
        assert calc_pages(1000, 100) == 10
    
    def test_offset_calculation(self):
        """Test offset calculation"""
        def calc_offset(page, page_size):
            return (page - 1) * page_size
        
        assert calc_offset(1, 100) == 0
        assert calc_offset(2, 100) == 100
        assert calc_offset(3, 100) == 200


class TestDataValidation:
    """Test data validation functions"""
    
    def test_job_number_format(self):
        """Test job number format validation"""
        import re
        
        pattern = re.compile(r'^J(SE|AI|LA)\d{8}\d{3}$')
        
        # Valid job numbers
        assert pattern.match('JSE20260108001')
        assert pattern.match('JAI20260108123')
        assert pattern.match('JLA20260108999')
        
        # Invalid job numbers
        assert not pattern.match('J2026010801')
        assert not pattern.match('JSE2026010')
    
    def test_date_format(self):
        """Test date format validation"""
        from datetime import datetime
        
        def is_valid_date(date_str):
            try:
                datetime.strptime(date_str, '%Y-%m-%d')
                return True
            except:
                return False
        
        assert is_valid_date('2026-01-08')
        assert is_valid_date('2026-12-31')
        assert not is_valid_date('01-08-2026')
        assert not is_valid_date('invalid')


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
