#!/usr/bin/env python3
# tests/test_settlement_accounting_v2.py
# Unit Tests for Enhanced Settlement & Accounting Services

"""
Tests for:
- Charge Templates
- Credit Limit Management
- Invoice Workflow
- Accrual vs Actual
- Payment Application
- Double Entry Bookkeeping
- Audit Trail
"""

import unittest
import sys
import os
import tempfile
import sqlite3
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestSettlementServiceV2(unittest.TestCase):
    """Tests for Enhanced Settlement Service"""
    
    @classmethod
    def setUpClass(cls):
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        from services.settlement_service_v2 import SettlementServiceV2
        self.service = SettlementServiceV2()
        
        # Create test job
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, customer, created_at, updated_at)
            VALUES ('OJ250101001', 'OCEAN', 'TEST CUSTOMER', ?, ?)
        """, (now_str(), now_str()))
        self.test_job_id = cur.lastrowid
        conn.commit()
        conn.close()
    
    def tearDown(self):
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM settlement_items WHERE job_id=?", (self.test_job_id,))
        cur.execute("DELETE FROM jobs WHERE id=?", (self.test_job_id,))
        conn.commit()
        conn.close()
    
    # ============================================================
    # Charge Template Tests
    # ============================================================
    
    def test_get_charge_templates(self):
        """Test retrieving charge templates"""
        templates = self.service.get_charge_templates()
        
        self.assertGreater(len(templates), 0)
        self.assertTrue(any(t.template_code == "FCL-IMP" for t in templates))
    
    def test_get_templates_by_mode(self):
        """Test filtering templates by mode"""
        ocean_templates = self.service.get_charge_templates(mode="OCEAN")
        air_templates = self.service.get_charge_templates(mode="AIR")
        
        self.assertTrue(all(t.mode == "OCEAN" for t in ocean_templates))
        self.assertTrue(all(t.mode == "AIR" for t in air_templates))
    
    def test_apply_template(self):
        """Test applying charge template to job"""
        rev_count, cost_count = self.service.apply_template(
            self.test_job_id, "FCL-IMP", "TEST001"
        )
        
        self.assertGreater(rev_count + cost_count, 0)
        
        # Verify items created
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM settlement_items WHERE job_id=?", (self.test_job_id,))
        count = cur.fetchone()[0]
        conn.close()
        
        self.assertEqual(count, rev_count + cost_count)
    
    def test_template_items_have_correct_type(self):
        """Test that template items are correctly marked as revenue/cost"""
        self.service.apply_template(self.test_job_id, "FCL-IMP", "")
        
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT item_type, COUNT(*) FROM settlement_items 
            WHERE job_id=? GROUP BY item_type
        """, (self.test_job_id,))
        rows = cur.fetchall()
        conn.close()
        
        types = {row[0]: row[1] for row in rows}
        self.assertIn("REVENUE", types)
    
    # ============================================================
    # Credit Limit Tests
    # ============================================================
    
    def test_set_credit_limit(self):
        """Test setting credit limit"""
        self.service.set_credit_limit("CUST001", 50000.00, 30)
        
        credit = self.service.get_customer_credit("CUST001")
        
        self.assertEqual(credit.credit_limit, 50000.00)
        self.assertEqual(credit.payment_terms, 30)
    
    def test_check_credit_within_limit(self):
        """Test credit check within limit"""
        self.service.set_credit_limit("CUST002", 10000.00)
        
        allowed, message = self.service.check_credit_limit("CUST002", 5000.00)
        
        self.assertTrue(allowed)
    
    def test_check_credit_exceeds_limit(self):
        """Test credit check exceeding limit"""
        self.service.set_credit_limit("CUST003", 1000.00)
        self.service.update_customer_balance("CUST003", 800.00, True)
        
        allowed, message = self.service.check_credit_limit("CUST003", 500.00)
        
        self.assertFalse(allowed)
        self.assertIn("exceeded", message.lower())
    
    def test_update_customer_balance(self):
        """Test updating customer balance"""
        self.service.set_credit_limit("CUST004", 10000.00)
        
        # Add charge
        self.service.update_customer_balance("CUST004", 1000.00, True)
        credit = self.service.get_customer_credit("CUST004")
        self.assertEqual(credit.current_balance, 1000.00)
        
        # Apply payment
        self.service.update_customer_balance("CUST004", 500.00, False)
        credit = self.service.get_customer_credit("CUST004")
        self.assertEqual(credit.current_balance, 500.00)
    
    # ============================================================
    # Invoice Workflow Tests
    # ============================================================
    
    def test_invoice_status_transition(self):
        """Test valid invoice status transitions"""
        from services.settlement_service_v2 import InvoiceStatus
        
        # Create item
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, rate, amount, total, status, created_at, updated_at)
            VALUES (?, 'REVENUE', 1000, 1000, 1000, 'DRAFT', ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        item_id = cur.lastrowid
        conn.commit()
        conn.close()
        
        # Valid transition: DRAFT -> PENDING_APPROVAL
        result = self.service.update_invoice_status(item_id, InvoiceStatus.PENDING_APPROVAL, "test_user")
        self.assertTrue(result)
        
        # Valid transition: PENDING_APPROVAL -> APPROVED
        result = self.service.update_invoice_status(item_id, InvoiceStatus.APPROVED, "approver")
        self.assertTrue(result)
    
    def test_due_date_calculation(self):
        """Test due date calculation based on payment terms"""
        self.service.set_credit_limit("CUST005", 10000.00, 45)  # 45 days
        
        today = datetime.now().strftime("%Y-%m-%d")
        due_date = self.service.get_due_date(today, "CUST005")
        
        expected = (datetime.now() + timedelta(days=45)).strftime("%Y-%m-%d")
        self.assertEqual(due_date, expected)
    
    def test_get_overdue_invoices(self):
        """Test retrieving overdue invoices"""
        # Create overdue invoice
        from db import get_connection, now_str
        past_date = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")
        
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO settlement_items 
            (job_id, item_type, rate, total, status, due_date, invoice_no, created_at, updated_at)
            VALUES (?, 'REVENUE', 1000, 1000, 'SENT', ?, 'DN-TEST-001', ?, ?)
        """, (self.test_job_id, past_date, now_str(), now_str()))
        conn.commit()
        conn.close()
        
        overdue = self.service.get_overdue_invoices()
        
        self.assertGreater(len(overdue), 0)
        self.assertTrue(any(inv['invoice_no'] == 'DN-TEST-001' for inv in overdue))
    
    # ============================================================
    # Accrual vs Actual Tests
    # ============================================================
    
    def test_add_accrual_cost(self):
        """Test adding accrued cost"""
        item_id = self.service.add_accrual_cost(
            self.test_job_id, "OFR", "Ocean Freight (Estimate)",
            rate=1500.00, qty=1, currency="USD"
        )
        
        self.assertIsNotNone(item_id)
        
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT cost_status, accrued_amount FROM settlement_items WHERE id=?", (item_id,))
        row = cur.fetchone()
        conn.close()
        
        self.assertEqual(row[0], "ACCRUAL")
        self.assertEqual(row[1], 1500.00)
    
    def test_convert_to_actual(self):
        """Test converting accrual to actual"""
        item_id = self.service.add_accrual_cost(
            self.test_job_id, "OFR", "Ocean Freight",
            rate=1500.00
        )
        
        # Convert with different actual rate
        result = self.service.convert_to_actual(item_id, 1600.00, "INV-001")
        self.assertTrue(result)
        
        from db import get_connection
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT cost_status, rate, amount, variance FROM settlement_items WHERE id=?
        """, (item_id,))
        row = cur.fetchone()
        conn.close()
        
        self.assertEqual(row[0], "ACTUAL")
        self.assertEqual(row[1], 1600.00)
        self.assertEqual(row[3], 100.00)  # variance
    
    def test_variance_report(self):
        """Test accrual vs actual variance report"""
        # Add accrual and convert
        item_id = self.service.add_accrual_cost(
            self.test_job_id, "THC", "Terminal Handling",
            rate=200.00
        )
        self.service.convert_to_actual(item_id, 250.00)
        
        report = self.service.get_accrual_variance_report(self.test_job_id)
        
        self.assertGreater(len(report), 0)
        variance_item = report[0]
        self.assertEqual(variance_item['accrued'], 200.00)
        self.assertEqual(variance_item['actual'], 250.00)
        self.assertEqual(variance_item['variance'], 50.00)
    
    # ============================================================
    # Profit Monitoring Tests
    # ============================================================
    
    def test_profit_alert_healthy(self):
        """Test profit alert with healthy margin"""
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        # Add revenue
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, total, created_at, updated_at)
            VALUES (?, 'REVENUE', 2000, ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        # Add cost
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, total, created_at, updated_at)
            VALUES (?, 'COST', 1500, ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        conn.commit()
        conn.close()
        
        alert = self.service.get_job_profit_alert(self.test_job_id, min_margin=10.0)
        
        self.assertFalse(alert['alert'])
        self.assertEqual(alert['profit'], 500.00)
    
    def test_profit_alert_low_margin(self):
        """Test profit alert with low margin"""
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, total, created_at, updated_at)
            VALUES (?, 'REVENUE', 1000, ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        cur.execute("""
            INSERT INTO settlement_items (job_id, item_type, total, created_at, updated_at)
            VALUES (?, 'COST', 950, ?, ?)
        """, (self.test_job_id, now_str(), now_str()))
        conn.commit()
        conn.close()
        
        alert = self.service.get_job_profit_alert(self.test_job_id, min_margin=10.0)
        
        self.assertTrue(alert['alert'])
        self.assertIn("LOW MARGIN", alert['message'])


class TestAccountingService(unittest.TestCase):
    """Tests for Enhanced Accounting Service"""
    
    @classmethod
    def setUpClass(cls):
        cls.test_db = tempfile.mktemp(suffix='.db')
        os.environ['DURUDURU_TEST_DB'] = cls.test_db
        
        from db import ensure_db_initialized
        conn = sqlite3.connect(cls.test_db)
        ensure_db_initialized(conn)
        conn.close()
    
    @classmethod
    def tearDownClass(cls):
        if os.path.exists(cls.test_db):
            os.remove(cls.test_db)
    
    def setUp(self):
        from services.accounting_service import AccountingService
        self.service = AccountingService()
    
    # ============================================================
    # Chart of Accounts Tests
    # ============================================================
    
    def test_coa_seeded(self):
        """Test that default COA is seeded"""
        accounts = self.service.get_accounts()
        
        self.assertGreater(len(accounts), 0)
        codes = [a.account_code for a in accounts]
        self.assertIn("1000", codes)  # Assets
        self.assertIn("4000", codes)  # Revenue
        self.assertIn("5000", codes)  # Expense
    
    def test_get_accounts_by_type(self):
        """Test filtering accounts by type"""
        assets = self.service.get_accounts(account_type="ASSET")
        revenues = self.service.get_accounts(account_type="REVENUE")
        
        self.assertTrue(all(a.account_type.value == "ASSET" for a in assets))
        self.assertTrue(all(a.account_type.value == "REVENUE" for a in revenues))
    
    def test_add_account(self):
        """Test adding a new account"""
        from services.accounting_service import Account, AccountType, NormalBalance
        
        account = Account(
            account_code="1150",
            account_name="Petty Cash",
            account_type=AccountType.ASSET,
            parent_code="1100",
            normal_balance=NormalBalance.DEBIT
        )
        
        account_id = self.service.add_account(account)
        
        self.assertIsNotNone(account_id)
        
        # Verify
        accounts = self.service.get_accounts()
        self.assertTrue(any(a.account_code == "1150" for a in accounts))
    
    # ============================================================
    # Journal Entry Tests
    # ============================================================
    
    def test_create_balanced_journal(self):
        """Test creating a balanced journal entry"""
        from services.accounting_service import JournalEntry, JournalLine, JournalStatus
        
        entry = JournalEntry(
            entry_date=datetime.now().strftime("%Y-%m-%d"),
            reference_type="MANUAL",
            description="Test entry",
            status=JournalStatus.POSTED,
            lines=[
                JournalLine(account_code="1120", debit=1000, credit=0, description="Bank increase"),
                JournalLine(account_code="4110", debit=0, credit=1000, description="Revenue"),
            ],
            created_by="test_user"
        )
        
        entry_id = self.service.create_journal_entry(entry)
        
        self.assertIsNotNone(entry_id)
        self.assertGreater(entry_id, 0)
    
    def test_unbalanced_journal_rejected(self):
        """Test that unbalanced journal entry is rejected"""
        from services.accounting_service import JournalEntry, JournalLine, JournalStatus
        
        entry = JournalEntry(
            entry_date=datetime.now().strftime("%Y-%m-%d"),
            description="Unbalanced entry",
            status=JournalStatus.DRAFT,
            lines=[
                JournalLine(account_code="1120", debit=1000, credit=0),
                JournalLine(account_code="4110", debit=0, credit=500),  # Not balanced!
            ]
        )
        
        with self.assertRaises(ValueError):
            self.service.create_journal_entry(entry)
    
    def test_account_balance(self):
        """Test account balance calculation"""
        from services.accounting_service import JournalEntry, JournalLine, JournalStatus
        
        # Create journal entry
        entry = JournalEntry(
            entry_date=datetime.now().strftime("%Y-%m-%d"),
            status=JournalStatus.POSTED,
            lines=[
                JournalLine(account_code="1120", debit=5000, credit=0),
                JournalLine(account_code="3100", debit=0, credit=5000),
            ]
        )
        self.service.create_journal_entry(entry)
        
        balance = self.service.get_account_balance("1120")
        
        self.assertGreater(balance, 0)
    
    # ============================================================
    # Payment Application Tests
    # ============================================================
    
    def test_create_payment(self):
        """Test creating a payment"""
        from services.accounting_service import Payment
        
        payment = Payment(
            payment_type="RECEIPT",
            customer_code="CUST001",
            customer_name="Test Customer",
            payment_date=datetime.now().strftime("%Y-%m-%d"),
            amount=1000.00,
            currency="USD",
            reference="CHK-12345"
        )
        
        payment_id = self.service.create_payment(payment)
        
        self.assertIsNotNone(payment_id)
    
    def test_apply_payment_to_invoice(self):
        """Test applying payment to invoice"""
        # Create invoice (settlement item)
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, created_at, updated_at)
            VALUES ('TEST-JOB', 'OCEAN', ?, ?)
        """, (now_str(), now_str()))
        job_id = cur.lastrowid
        
        cur.execute("""
            INSERT INTO settlement_items 
            (job_id, item_type, customer, invoice_no, total, paid_amount, status, created_at, updated_at)
            VALUES (?, 'REVENUE', 'CUST001', 'DN-TEST-002', 1000, 0, 'SENT', ?, ?)
        """, (job_id, now_str(), now_str()))
        invoice_id = cur.lastrowid
        conn.commit()
        conn.close()
        
        # Create payment
        from services.accounting_service import Payment
        payment = Payment(
            payment_type="RECEIPT",
            customer_code="CUST001",
            customer_name="Test Customer",
            amount=1000.00
        )
        payment_id = self.service.create_payment(payment)
        
        # Apply payment
        result = self.service.apply_payment_to_invoice(payment_id, invoice_id, 1000.00)
        
        self.assertTrue(result)
        
        # Verify invoice is paid
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT status, paid_amount FROM settlement_items WHERE id=?", (invoice_id,))
        row = cur.fetchone()
        conn.close()
        
        self.assertEqual(row[0], "PAID")
        self.assertEqual(row[1], 1000.00)
    
    def test_partial_payment(self):
        """Test partial payment application"""
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, created_at, updated_at)
            VALUES ('TEST-JOB2', 'OCEAN', ?, ?)
        """, (now_str(), now_str()))
        job_id = cur.lastrowid
        
        cur.execute("""
            INSERT INTO settlement_items 
            (job_id, item_type, invoice_no, total, paid_amount, status, created_at, updated_at)
            VALUES (?, 'REVENUE', 'DN-TEST-003', 1000, 0, 'SENT', ?, ?)
        """, (job_id, now_str(), now_str()))
        invoice_id = cur.lastrowid
        conn.commit()
        conn.close()
        
        from services.accounting_service import Payment
        payment = Payment(payment_type="RECEIPT", amount=500.00)
        payment_id = self.service.create_payment(payment)
        
        result = self.service.apply_payment_to_invoice(payment_id, invoice_id, 500.00)
        
        self.assertTrue(result)
        
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT status, paid_amount, balance FROM settlement_items WHERE id=?", (invoice_id,))
        row = cur.fetchone()
        conn.close()
        
        self.assertEqual(row[0], "PARTIALLY_PAID")
        self.assertEqual(row[1], 500.00)
        self.assertEqual(row[2], 500.00)
    
    def test_get_open_invoices(self):
        """Test retrieving open invoices"""
        # Create open invoice
        from db import get_connection, now_str
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO jobs (job_no, mode, created_at, updated_at)
            VALUES ('TEST-JOB3', 'OCEAN', ?, ?)
        """, (now_str(), now_str()))
        job_id = cur.lastrowid
        
        cur.execute("""
            INSERT INTO settlement_items 
            (job_id, item_type, customer_code, invoice_no, total, paid_amount, status, created_at, updated_at)
            VALUES (?, 'REVENUE', 'CUST001', 'DN-OPEN-001', 2000, 500, 'PARTIALLY_PAID', ?, ?)
        """, (job_id, now_str(), now_str()))
        conn.commit()
        conn.close()
        
        invoices = self.service.get_open_invoices("CUST001")
        
        self.assertGreater(len(invoices), 0)
        open_inv = next((i for i in invoices if i['invoice_no'] == 'DN-OPEN-001'), None)
        self.assertIsNotNone(open_inv)
        self.assertEqual(open_inv['balance'], 1500.00)
    
    # ============================================================
    # Audit Trail Tests
    # ============================================================
    
    def test_audit_log_created(self):
        """Test that audit log is created for operations"""
        from services.accounting_service import Payment
        
        payment = Payment(payment_type="RECEIPT", amount=100.00)
        payment_id = self.service.create_payment(payment)
        
        logs = self.service.get_audit_log(table_name="payments", record_id=payment_id)
        
        self.assertGreater(len(logs), 0)
        self.assertEqual(logs[0].action, "INSERT")
    
    # ============================================================
    # Financial Report Tests
    # ============================================================
    
    def test_trial_balance(self):
        """Test trial balance generation"""
        trial_balance = self.service.get_trial_balance()
        
        self.assertGreater(len(trial_balance), 0)
        
        # Check totals row
        totals = trial_balance[-1]
        self.assertEqual(totals['account_name'], 'TOTAL')
        # Debit should equal Credit
        self.assertAlmostEqual(totals['debit'], totals['credit'], places=2)
    
    def test_profit_loss(self):
        """Test P&L generation"""
        today = datetime.now().strftime("%Y-%m-%d")
        start = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        
        pl = self.service.get_profit_loss(start, today)
        
        self.assertIn('revenue', pl)
        self.assertIn('expenses', pl)
        self.assertIn('net_profit', pl)


if __name__ == '__main__':
    unittest.main(verbosity=2)
