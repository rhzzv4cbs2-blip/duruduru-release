# tests/test_core.py
# Core Unit Tests for DURUDURU
# Created: 2026-01-08

import pytest
import os
import sys
import sqlite3
import tempfile
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestDatabase:
    """Database tests"""
    
    @pytest.fixture
    def temp_db(self):
        """Create temporary database"""
        fd, path = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        yield path
        os.unlink(path)
    
    def test_create_connection(self, temp_db):
        """Test database connection"""
        conn = sqlite3.connect(temp_db)
        assert conn is not None
        conn.close()
    
    def test_create_tables(self, temp_db):
        """Test table creation"""
        conn = sqlite3.connect(temp_db)
        cur = conn.cursor()
        
        # Create basic tables
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT UNIQUE,
                password_hash TEXT
            )
        """)
        
        cur.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY,
                job_no TEXT UNIQUE,
                mode TEXT,
                status TEXT
            )
        """)
        
        conn.commit()
        
        # Verify tables exist
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cur.fetchall()]
        
        assert 'users' in tables
        assert 'jobs' in tables
        
        conn.close()
    
    def test_insert_and_query(self, temp_db):
        """Test data insertion and querying"""
        conn = sqlite3.connect(temp_db)
        cur = conn.cursor()
        
        cur.execute("""
            CREATE TABLE jobs (
                id INTEGER PRIMARY KEY,
                job_no TEXT UNIQUE,
                customer TEXT,
                status TEXT DEFAULT 'OPEN'
            )
        """)
        
        # Insert
        cur.execute("INSERT INTO jobs (job_no, customer) VALUES (?, ?)", 
                   ("JOB001", "Test Customer"))
        conn.commit()
        
        # Query
        cur.execute("SELECT job_no, customer, status FROM jobs WHERE job_no = ?", ("JOB001",))
        row = cur.fetchone()
        
        assert row is not None
        assert row[0] == "JOB001"
        assert row[1] == "Test Customer"
        assert row[2] == "OPEN"
        
        conn.close()


class TestI18n:
    """Internationalization tests"""
    
    def test_default_language(self):
        """Test default language is English"""
        from i18n import I18n
        
        # Reset to default
        I18n.set_language("en")
        assert I18n.get_language() == "en"
    
    def test_translation_en(self):
        """Test English translations"""
        from i18n import I18n, t
        
        I18n.set_language("en")
        
        assert t("action.save") == "Save"
        assert t("action.cancel") == "Cancel"
        assert t("label.customer") == "Customer"
    
    def test_translation_es(self):
        """Test Spanish translations"""
        from i18n import I18n, t
        
        I18n.set_language("es")
        
        assert t("action.save") == "Guardar"
        assert t("action.cancel") == "Cancelar"
        assert t("label.customer") == "Cliente"
    
    def test_translation_ko(self):
        """Test Korean translations"""
        from i18n import I18n, t
        
        I18n.set_language("ko")
        
        assert t("action.save") == "저장"
        assert t("action.cancel") == "취소"
        assert t("label.customer") == "고객"
    
    def test_missing_key(self):
        """Test missing translation key returns key"""
        from i18n import t
        
        assert t("nonexistent.key") == "nonexistent.key"


class TestDbMigration:
    """Database migration tests"""
    
    @pytest.fixture
    def temp_db(self):
        """Create temporary database"""
        fd, path = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        yield path
        os.unlink(path)
    
    def test_migration_init(self, temp_db):
        """Test migration initialization"""
        from db_migration import DatabaseMigration
        
        migration = DatabaseMigration(temp_db)
        
        # Check migration table was created
        conn = sqlite3.connect(temp_db)
        cur = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'")
        row = cur.fetchone()
        conn.close()
        
        assert row is not None
    
    def test_current_version_empty(self, temp_db):
        """Test current version on empty database"""
        from db_migration import DatabaseMigration
        
        migration = DatabaseMigration(temp_db)
        assert migration.get_current_version() == 0
    
    def test_pending_migrations(self, temp_db):
        """Test pending migrations detection"""
        from db_migration import DatabaseMigration
        
        migration = DatabaseMigration(temp_db)
        pending = migration.get_pending_migrations()
        
        assert len(pending) > 0
        assert pending[0][0] == 1  # First migration should be version 1


class TestConfig:
    """Configuration tests"""
    
    def test_config_colors(self):
        """Test config module colors"""
        from config import Colors
        
        assert Colors.PRIMARY is not None
        assert Colors.SUCCESS is not None
        assert Colors.DANGER is not None
    
    def test_config_sizes(self):
        """Test config module sizes"""
        from config import Sizes
        
        assert Sizes.BUTTON_WIDTH > 0
        assert Sizes.INPUT_HEIGHT > 0
    
    def test_config_fonts(self):
        """Test config module fonts"""
        from config import Typography
        
        assert Typography.FONT_FAMILY is not None
        assert Typography.TITLE_SIZE > 0


class TestValidation:
    """Validation tests"""
    
    def test_job_number_format(self):
        """Test job number format validation"""
        import re
        
        # Valid formats
        valid_patterns = [
            "JSE20260108001",
            "JAI20260108002",
            "JLA20260108003",
        ]
        
        pattern = r"^J[A-Z]{2}\d{8}\d{3}$"
        
        for job_no in valid_patterns:
            assert re.match(pattern, job_no) is not None
    
    def test_email_format(self):
        """Test email format validation"""
        import re
        
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        
        valid_emails = ["test@example.com", "user.name@company.org"]
        invalid_emails = ["invalid", "missing@dot", "@nodomain.com"]
        
        for email in valid_emails:
            assert re.match(pattern, email) is not None
        
        for email in invalid_emails:
            assert re.match(pattern, email) is None
    
    def test_date_format(self):
        """Test date format validation"""
        from datetime import datetime
        
        valid_dates = ["2026-01-08", "2025-12-31"]
        invalid_dates = ["2026/01/08", "01-08-2026", "invalid"]
        
        for date_str in valid_dates:
            try:
                datetime.strptime(date_str, "%Y-%m-%d")
                assert True
            except:
                assert False
        
        for date_str in invalid_dates:
            try:
                datetime.strptime(date_str, "%Y-%m-%d")
                assert False
            except:
                assert True


class TestExchangeRate:
    """Exchange rate tests"""
    
    def test_rate_range(self):
        """Test exchange rate is within valid range"""
        # MXN/USD should be between 15 and 25
        min_rate = 15.0
        max_rate = 25.0
        
        test_rate = 20.50  # Default fallback
        assert min_rate <= test_rate <= max_rate
    
    def test_rate_precision(self):
        """Test exchange rate precision"""
        rate = 20.5123
        rounded = round(rate, 4)
        
        assert rounded == 20.5123


class TestQuotation:
    """Quotation tests"""
    
    def test_profit_calculation(self):
        """Test profit calculation"""
        revenue = 1000.0
        cost = 700.0
        expected_profit = 300.0
        
        profit = revenue - cost
        assert profit == expected_profit
    
    def test_margin_calculation(self):
        """Test margin calculation"""
        revenue = 1000.0
        profit = 300.0
        expected_margin = 30.0
        
        margin = (profit / revenue) * 100 if revenue > 0 else 0
        assert margin == expected_margin
    
    def test_quote_number_generation(self):
        """Test quote number format"""
        from datetime import datetime
        
        date_str = datetime.now().strftime("%Y%m%d")
        quote_no = f"QT{date_str}001"
        
        assert quote_no.startswith("QT")
        assert len(quote_no) == 14


class TestContainerCalculations:
    """Container and cargo calculation tests"""
    
    def test_cbm_calculation(self):
        """Test CBM calculation from dimensions"""
        # L x W x H in cm
        length = 100
        width = 100
        height = 100
        
        cbm = (length * width * height) / 1000000
        assert cbm == 1.0
    
    def test_revenue_ton(self):
        """Test Revenue Ton calculation"""
        weight_kg = 2000
        cbm = 3.0
        
        # R/T = max(weight/1000, CBM)
        rt = max(weight_kg / 1000, cbm)
        assert rt == 3.0
    
    def test_container_types(self):
        """Test container type constants"""
        container_types = ["20'GP", "40'GP", "40'HC", "20'RF", "40'RF"]
        
        for ct in container_types:
            assert len(ct) > 0


class TestPagination:
    """Pagination tests"""
    
    def test_page_calculation(self):
        """Test page calculation"""
        total_records = 250
        page_size = 100
        
        total_pages = (total_records + page_size - 1) // page_size
        assert total_pages == 3
    
    def test_offset_calculation(self):
        """Test offset calculation"""
        page = 2
        page_size = 100
        
        offset = (page - 1) * page_size
        assert offset == 100
    
    def test_boundary_pages(self):
        """Test page boundary handling"""
        total_pages = 5
        
        # Test min boundary
        page = max(1, 0)  # Request page 0
        assert page == 1
        
        # Test max boundary
        page = min(10, total_pages)  # Request page 10
        assert page == 5


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
