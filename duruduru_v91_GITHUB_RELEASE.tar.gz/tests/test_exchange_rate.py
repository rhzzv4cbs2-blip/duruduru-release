#!/usr/bin/env python3
# tests/test_exchange_rate.py
# Exchange Rate API Test Script

"""
Exchange Rate API Test
Run this script locally to verify API connectivity.

Usage:
    python tests/test_exchange_rate.py
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime
import urllib.request
import json


def test_open_exchange_rate_api():
    """Test open.er-api.com"""
    print("\n=== Testing open.er-api.com ===")
    try:
        url = "https://open.er-api.com/v6/latest/USD"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode())
            
            if 'rates' in data and 'MXN' in data['rates']:
                rate = data['rates']['MXN']
                print(f"✅ SUCCESS: USD/MXN = {rate:.4f}")
                print(f"   Last update: {data.get('time_last_update_utc', 'N/A')}")
                return rate
            else:
                print(f"❌ FAILED: Unexpected response format")
                return None
    except Exception as e:
        print(f"❌ FAILED: {e}")
        return None


def test_exchangerate_api():
    """Test exchangerate-api.com"""
    print("\n=== Testing exchangerate-api.com ===")
    try:
        url = "https://api.exchangerate-api.com/v4/latest/USD"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode())
            
            if 'rates' in data and 'MXN' in data['rates']:
                rate = data['rates']['MXN']
                print(f"✅ SUCCESS: USD/MXN = {rate:.4f}")
                print(f"   Provider: {data.get('provider', 'N/A')}")
                return rate
            else:
                print(f"❌ FAILED: Unexpected response format")
                return None
    except Exception as e:
        print(f"❌ FAILED: {e}")
        return None


def test_db_functions():
    """Test database functions"""
    print("\n=== Testing Database Functions ===")
    
    try:
        from db import (
            get_connection, 
            fetch_exchange_rate_dof, 
            save_exchange_rate,
            get_or_fetch_exchange_rate
        )
        
        # Test fetch from API
        print("Testing fetch_exchange_rate_dof()...")
        rate = fetch_exchange_rate_dof()
        if rate:
            print(f"✅ API fetch successful: {rate:.4f}")
        else:
            print("❌ API fetch failed")
        
        # Test save to database
        print("\nTesting save_exchange_rate()...")
        today = datetime.now().strftime("%Y-%m-%d")
        if rate:
            save_exchange_rate(today, rate, "USD", "MXN", "TEST")
            print(f"✅ Saved rate {rate:.4f} for {today}")
        
        # Test get or fetch
        print("\nTesting get_or_fetch_exchange_rate()...")
        result = get_or_fetch_exchange_rate(today)
        if result:
            print(f"✅ Got rate: {result:.4f}")
        else:
            print("❌ Get/fetch failed")
        
        # Verify in database
        print("\nVerifying in database...")
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT date, rate, source FROM exchange_rates 
            WHERE from_currency='USD' AND to_currency='MXN'
            ORDER BY date DESC LIMIT 5
        """)
        rows = cur.fetchall()
        conn.close()
        
        if rows:
            print("Recent exchange rates:")
            for row in rows:
                print(f"   {row[0]}: {row[1]:.4f} ({row[2]})")
        else:
            print("No rates found in database")
            
    except ImportError as e:
        print(f"❌ Import error: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()


def main():
    print("=" * 60)
    print("Exchange Rate API Test")
    print(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # Test APIs
    rate1 = test_open_exchange_rate_api()
    rate2 = test_exchangerate_api()
    
    # Test DB functions
    test_db_functions()
    
    # Summary
    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    
    if rate1 or rate2:
        print("✅ At least one API is working")
        avg_rate = (rate1 or 0) + (rate2 or 0)
        if rate1 and rate2:
            avg_rate /= 2
        print(f"   Current USD/MXN rate: ~{avg_rate:.4f}")
    else:
        print("❌ All APIs failed - check network connectivity")
    
    print("\nNote: Run this script locally where network access is available.")


if __name__ == "__main__":
    main()
