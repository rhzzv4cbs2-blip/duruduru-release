# DURUDURU 배포 가이드
# Deployment Guide for Windows & macOS

## 📦 버전 정보
- 현재 버전: 1.0.90
- 자동 업데이트: 지원 (GitHub Releases 기반)

---

## 🖥️ Windows 배포 방법

### 방법 1: Windows PC에서 직접 빌드 (권장)

1. **Windows PC 준비**
   - Windows 10/11
   - Python 3.9+ 설치 (python.org)
   - Git 설치 (선택)

2. **파일 복사**
   ```cmd
   # 모든 .py 파일과 icon_1024x1024.png를 Windows PC로 복사
   ```

3. **필수 패키지 설치**
   ```cmd
   pip install pyinstaller customtkinter pillow reportlab
   ```

4. **EXE 빌드**
   ```cmd
   python build_windows_exe.py
   ```

5. **결과물**
   ```
   dist/
   └── DURUDURU.exe    # 단일 실행 파일 (약 50-80MB)
   ```

### 방법 2: 가상 머신 사용 (macOS에서)

1. **Parallels Desktop 또는 VMware 설치**

2. **Windows VM 생성**
   - Windows 10/11 설치
   - Python 설치

3. **공유 폴더로 파일 전송 후 빌드**


### 방법 3: GitHub Actions (CI/CD) - 자동화

`.github/workflows/build.yml` 파일 생성:

```yaml
name: Build Windows EXE

on:
  push:
    tags:
      - 'v*'

jobs:
  build:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          pip install pyinstaller customtkinter pillow reportlab
      
      - name: Build EXE
        run: python build_windows_exe.py
      
      - name: Upload artifact
        uses: actions/upload-artifact@v3
        with:
          name: DURUDURU-Windows
          path: dist/DURUDURU.exe
      
      - name: Create Release
        uses: softprops/action-gh-release@v1
        with:
          files: dist/DURUDURU.exe
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

## 🍎 macOS 배포 방법 (현재 사용 중)

### 방법 1: 직접 Python 실행 (개발용)

```bash
# 필수 패키지 설치
pip3 install customtkinter pillow reportlab

# 실행
python3 main.py
```

### 방법 2: macOS App 번들 생성

```bash
# py2app 설치
pip3 install py2app

# setup.py로 앱 빌드
python3 setup.py py2app

# 결과: dist/DURUDURU.app
```

### 방법 3: Automator 앱 (간단)

1. **Automator 실행** (Spotlight → Automator)
2. **"애플리케이션" 선택**
3. **"셸 스크립트 실행" 추가**
4. **스크립트 입력:**
   ```bash
   cd /path/to/duruduru
   /usr/local/bin/python3 main.py
   ```
5. **저장** → DURUDURU.app

---

## 🔄 자동 업데이트 설정

### 1. GitHub Repository 생성

```bash
# GitHub에 duruduru 저장소 생성
git init
git add .
git commit -m "Initial release v1.0.90"
git remote add origin https://github.com/YOUR_USERNAME/duruduru.git
git push -u origin main
```

### 2. auto_updater.py 설정 수정

```python
# auto_updater.py 파일에서 수정
GITHUB_OWNER = "your-github-username"  # ← 실제 GitHub 사용자명
GITHUB_REPO = "duruduru"               # ← 저장소 이름
```

### 3. GitHub Release 생성

1. GitHub → Repository → Releases → "Create a new release"
2. Tag: `v1.0.91` (새 버전)
3. Title: `DURUDURU v1.0.91`
4. 설명 작성 (What's New)
5. **Assets 업로드:**
   - `DURUDURU.exe` (Windows용)
   - `DURUDURU.dmg` (macOS용, 선택)
   - Source code (자동)

### 4. 업데이트 흐름

```
사용자가 앱 실행
    ↓
로그인 성공
    ↓
백그라운드에서 GitHub API 확인
    ↓
새 버전 발견 시 알림 표시
    ↓
[Update Now] 클릭
    ↓
다운로드 → 설치 → 재시작
```

---

## 📋 배포 체크리스트

### Windows 배포
- [ ] build_windows_exe.py 실행
- [ ] dist/DURUDURU.exe 생성 확인
- [ ] 테스트 PC에서 실행 확인
- [ ] GitHub Release에 업로드

### 업데이트 시
- [ ] auto_updater.py의 APP_VERSION 업데이트
- [ ] 변경 사항 커밋
- [ ] 새 버전 태그 생성 (v1.0.XX)
- [ ] Windows EXE 빌드
- [ ] GitHub Release 생성 및 파일 업로드

---

## 🛠️ 문제 해결

### Windows 빌드 오류

**"ModuleNotFoundError"**
```cmd
pip install [missing_module]
```

**"DLL load failed"**
```cmd
# Microsoft Visual C++ Redistributable 설치
# https://aka.ms/vs/17/release/vc_redist.x64.exe
```

### 자동 업데이트 안 됨

1. **GitHub Rate Limit** - API 호출 제한 (60/hour)
2. **네트워크 차단** - 방화벽 확인
3. **Release 설정** - Assets에 파일 업로드 확인

---

## 📞 지원

문제 발생 시:
1. 로그 확인 (터미널 출력)
2. GitHub Issues에 보고
3. 에러 메시지 포함하여 문의

---

**버전 히스토리**
- v1.0.90: 자동 업데이트 시스템 추가
- v1.0.89: bank_transactions 테이블 수정
- v1.0.88: Counterpart 자동 입력

