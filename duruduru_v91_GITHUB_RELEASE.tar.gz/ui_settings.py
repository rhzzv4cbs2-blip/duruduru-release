# ui_settings.py
# Settings UI module with Customer, Port, Freight Management
# Updated: Added TAX ID, Bank Account fields

import tkinter as tk

# I18N
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"
from tkinter import ttk, messagebox
import customtkinter as ctk
from typing import List, Dict, Any, Optional
from db import get_connection
from datetime import datetime
import platform


def get_modifier_key():
    """Return Command for macOS, Control for others"""
    return "Command" if platform.system() == "Darwin" else "Control"


# -------------------------
# CUSTOMER MANAGEMENT FRAME
# -------------------------
class CustomerMgmtFrame(ctk.CTkFrame):
    """Customer management frame with TAX ID and Bank Account"""

    def __init__(self, master, width=900, height=550, **kwargs):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height, **kwargs)

        parent_bg = "#FFFFFF"
        self.top = ctk.CTkFrame(self, fg_color=parent_bg, corner_radius=0)
        self.top.pack(fill="x", padx=20, pady=(32, 0))

        for i in range(9):
            weight = 1 if i == 5 else 0
            self.top.grid_columnconfigure(i, weight=weight)

        # TYPE
        ctk.CTkLabel(self.top, text="TYPE", text_color="#444444", fg_color=parent_bg).grid(row=0, column=0, padx=6, pady=6, sticky="e")
        self.type_var = tk.StringVar()
        self.type_combo = ttk.Combobox(self.top, textvariable=self.type_var, state="readonly", width=14)
        self.type_combo["values"] = ["", "Client", "Trucker", "Airline", "Shipping Line", "Forwarder", "ETC"]
        self.type_combo.current(0)
        self.type_combo.grid(row=0, column=1, padx=6, pady=6, sticky="w")

        # CODE
        ctk.CTkLabel(self.top, text="CODE", text_color="#444444", fg_color=parent_bg).grid(row=0, column=2, padx=6, pady=6, sticky="e")
        self.code_var = tk.StringVar()
        self.code_combo = ttk.Combobox(self.top, textvariable=self.code_var, width=18)
        self.code_combo.grid(row=0, column=3, padx=6, pady=6, sticky="w")
        self.code_combo.bind("<<ComboboxSelected>>", self._on_code_selected)
        self.code_combo.bind("<Return>", lambda e: self._auto_fill_name_from_code())

        # NAME
        ctk.CTkLabel(self.top, text="NAME", text_color="#444444", fg_color=parent_bg).grid(row=0, column=4, padx=6, pady=6, sticky="e")
        self.name_var = tk.StringVar()
        self.name_combo = ttk.Combobox(self.top, textvariable=self.name_var, width=30)
        self.name_combo.grid(row=0, column=5, padx=6, pady=6, sticky="we")

        # SEARCH / ADD / DELETE
        self._search_btn = ctk.CTkButton(self.top, text="🔍", width=48, height=32, command=self.search)
        self._search_btn.grid(row=0, column=6, padx=8, pady=6, sticky="e")

        self._add_btn = ctk.CTkButton(self.top, text="+", width=40, command=self.open_add_window)
        self._add_btn.grid(row=0, column=7, padx=(8, 0), pady=6, sticky="e")

        self._delete_btn = ctk.CTkButton(self.top, text="-", width=40, fg_color="#D9534F", hover_color="#C9302C", text_color="white", command=self.delete_selected)
        self._delete_btn.grid(row=0, column=8, padx=(8, 0), pady=6, sticky="e")

        # Table
        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(6, 16))

        cols = ["id", "type", "code", "name", "contact", "phone", "email", "tax_id", "bank_account", "address"]
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("type", text="TYPE")
        self.tree.heading("code", text="CODE")
        self.tree.heading("name", text="NAME")
        self.tree.heading("contact", text="CONTACT")
        self.tree.heading("phone", text="PHONE")
        self.tree.heading("email", text="EMAIL")
        self.tree.heading("tax_id", text="TAX ID")
        self.tree.heading("bank_account", text="BANK ACCOUNT")
        self.tree.heading("address", text="ADDRESS")
        self.tree.column("id", width=0, stretch=False)
        self.tree.column("type", width=70, anchor="center")
        self.tree.column("code", width=90, anchor="center")
        self.tree.column("name", width=160)
        self.tree.column("contact", width=100)
        self.tree.column("phone", width=100)
        self.tree.column("email", width=140)
        self.tree.column("tax_id", width=120)
        self.tree.column("bank_account", width=140)
        self.tree.column("address", width=200)

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(list_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        self.tree.bind("<Button-2>", self._on_tree_right_click)
        self.tree.bind("<Button-3>", self._on_tree_right_click)
        self.tree.bind("<Double-1>", self._on_double_click)

        self._refresh_comboboxes()
        self.search()

    def _refresh_comboboxes(self):
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT DISTINCT code FROM companies WHERE company_type = 'CUSTOMER' ORDER BY code")
            codes = [r[0] for r in cur.fetchall()]
            self.code_combo["values"] = codes

            cur.execute("SELECT DISTINCT name FROM companies WHERE company_type = 'CUSTOMER' ORDER BY name COLLATE NOCASE")
            names = [r[0] for r in cur.fetchall()]
            self.name_combo["values"] = names
        except:
            pass
        finally:
            conn.close()

    def _on_code_selected(self, event=None):
        code = self.code_var.get().strip()
        if code:
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("SELECT name FROM companies WHERE company_type = 'CUSTOMER' AND code = ?", (code,))
                row = cur.fetchone()
                if row:
                    self.name_var.set(row[0])
            except:
                pass
            finally:
                conn.close()

    def _auto_fill_name_from_code(self):
        self._on_code_selected()

    def _clear_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

    def search(self):
        type_filter = self.type_var.get().strip()
        code = self.code_var.get().strip()
        name = self.name_var.get().strip()
        conn = get_connection()
        cur = conn.cursor()
        q = "SELECT id, type, code, name, contact, phone, email, tax_id, bank_account, address FROM companies WHERE company_type = 'CUSTOMER'"
        params = []
        if type_filter:
            q += " AND type = ?"
            params.append(type_filter)
        if code:
            q += " AND code LIKE ?"
            params.append(f"%{code}%")
        if name:
            q += " AND name LIKE ?"
            params.append(f"%{name}%")
        q += " ORDER BY name COLLATE NOCASE"
        try:
            cur.execute(q, params)
            rows = cur.fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        self._clear_tree()
        for r in rows:
            self.tree.insert("", "end", values=r)

    def _on_tree_right_click(self, event):
        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return
        self.tree.selection_set(row_id)
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Edit", command=lambda: self._open_edit_window(row_id))
        menu.add_command(label="Delete", command=lambda: self._confirm_delete_row(row_id))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _on_double_click(self, event):
        row_id = self.tree.identify_row(event.y)
        if row_id:
            self._open_edit_window(row_id)

    def _open_edit_window(self, tree_item_id):
        """Edit customer window"""
        values = self.tree.item(tree_item_id, "values")
        if not values:
            return
        
        record_id = values[0]
        
        # Get full data from DB
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT type, code, name, contact, phone, email, tax_id, bank_account, address FROM companies WHERE id = ?", (record_id,))
        row = cur.fetchone()
        conn.close()
        
        if not row:
            return

        win = ctk.CTkToplevel(self)
        win.title(f'Edit Customer - {row[2]}')
        win.geometry("650x580")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        parent_bg = "#FFFFFF"
        main_frame = ctk.CTkFrame(win, fg_color=parent_bg)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        title_label = ctk.CTkLabel(main_frame, text="Edit Customer", font=("SF Pro Display", 18, "bold"), text_color="#222222")
        title_label.pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color=parent_bg)
        form_frame.pack(fill="both", expand=True)

        labels = ["TYPE", "CODE", "NAME", "CONTACT", "PHONE", "EMAIL", "TAX ID", "BANK ACCOUNT", "ADDRESS"]
        db_values = list(row)
        entries = {}

        for idx, lbl in enumerate(labels):
            row_frame = ctk.CTkFrame(form_frame, fg_color=parent_bg)
            row_frame.pack(fill="x", pady=6)
            
            label = ctk.CTkLabel(row_frame, text=lbl, width=120, text_color="#444444", anchor="w")
            label.pack(side="left", padx=(0, 10))
            
            if lbl == "TYPE":
                var = tk.StringVar(value=db_values[idx] or "")
                entry = ttk.Combobox(row_frame, textvariable=var, state="readonly", width=30)
                entry["values"] = ["Client", "Provider"]
                entries[lbl] = (entry, var)
            elif lbl == "ADDRESS":
                var = tk.StringVar(value=db_values[idx] or "")
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=400)
                entries[lbl] = (entry, var)
            else:
                var = tk.StringVar(value=db_values[idx] or "")
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=350)
                entries[lbl] = (entry, var)
            
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color=parent_bg)
        btn_frame.pack(pady=(20, 0))

        def save_customer():
            type_val = entries["TYPE"][1].get().strip()
            code = entries["CODE"][1].get().strip()
            name = entries["NAME"][1].get().strip()
            contact = entries["CONTACT"][1].get().strip()
            phone = entries["PHONE"][1].get().strip()
            email = entries["EMAIL"][1].get().strip()
            tax_id = entries["TAX ID"][1].get().strip()
            bank_account = entries["BANK ACCOUNT"][1].get().strip()
            address = entries["ADDRESS"][1].get().strip()

            if not type_val or not code or not name:
                messagebox.showwarning("Input Required", "TYPE, CODE, and NAME are required.", parent=win)
                return

            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("""
                    UPDATE companies SET type=?, code=?, name=?, contact=?, phone=?, email=?, tax_id=?, bank_account=?, address=?
                    WHERE id=?
                """, (type_val, code, name, contact, phone, email, tax_id, bank_account, address, record_id))
                conn.commit()
                messagebox.showinfo("Success", f'Customer "{name}" updated successfully.', parent=win)
                win.destroy()
                self._refresh_comboboxes()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update: {e}", parent=win)
            finally:
                conn.close()

        save_btn = ctk.CTkButton(btn_frame, text="Save", width=120, command=save_customer)
        save_btn.pack(side="left", padx=5)

        cancel_btn = ctk.CTkButton(btn_frame, text="Cancel", width=120, fg_color="#6C757D", command=win.destroy)
        cancel_btn.pack(side="left", padx=5)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("No Selection", "Please select a customer to delete.")
            return
        self._confirm_delete_row(sel[0])

    def _confirm_delete_row(self, tree_item_id):
        values = self.tree.item(tree_item_id, "values")
        if not values:
            return
        name = values[3] if len(values) > 3 else "this record"
        if not messagebox.askyesno("Confirm Delete", f'Delete customer "{name}"?'):
            return
        record_id = values[0]
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM companies WHERE id = ?", (record_id,))
            conn.commit()
        except Exception as e:
            messagebox.showerror("Delete Error", f"Failed to delete: {e}")
            return
        finally:
            conn.close()
        self.tree.delete(tree_item_id)
        self._refresh_comboboxes()
        self.search()
        messagebox.showinfo("Deleted", f'"{name}" has been deleted.')

    def open_add_window(self, prefill=None):
        """Opens a new window for adding customer details"""
        win = ctk.CTkToplevel(self)
        win.title("Add Customer")
        win.geometry("650x580")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        parent_bg = "#FFFFFF"
        main_frame = ctk.CTkFrame(win, fg_color=parent_bg)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        title_label = ctk.CTkLabel(main_frame, text="Add Customer", font=("SF Pro Display", 18, "bold"), text_color="#222222")
        title_label.pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color=parent_bg)
        form_frame.pack(fill="both", expand=True)

        labels = ["TYPE", "CODE", "NAME", "CONTACT", "PHONE", "EMAIL", "TAX ID", "BANK ACCOUNT", "ADDRESS"]
        entries = {}

        for idx, lbl in enumerate(labels):
            row_frame = ctk.CTkFrame(form_frame, fg_color=parent_bg)
            row_frame.pack(fill="x", pady=6)
            
            label = ctk.CTkLabel(row_frame, text=lbl, width=120, text_color="#444444", anchor="w")
            label.pack(side="left", padx=(0, 10))
            
            if lbl == "TYPE":
                var = tk.StringVar()
                entry = ttk.Combobox(row_frame, textvariable=var, state="readonly", width=30)
                entry["values"] = ["Client", "Trucker", "Airline", "Shipping Line", "Forwarder", "ETC"]
                entries[lbl] = (entry, var)
            elif lbl == "ADDRESS":
                var = tk.StringVar()
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=400)
                entries[lbl] = (entry, var)
            else:
                var = tk.StringVar()
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=350)
                entries[lbl] = (entry, var)
            
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color=parent_bg)
        btn_frame.pack(pady=(20, 0))

        def save_customer():
            type_val = entries["TYPE"][1].get().strip()
            code = entries["CODE"][1].get().strip()
            name = entries["NAME"][1].get().strip()
            contact = entries["CONTACT"][1].get().strip()
            phone = entries["PHONE"][1].get().strip()
            email = entries["EMAIL"][1].get().strip()
            tax_id = entries["TAX ID"][1].get().strip()
            bank_account = entries["BANK ACCOUNT"][1].get().strip()
            address = entries["ADDRESS"][1].get().strip()

            if not type_val or not code or not name:
                messagebox.showwarning("Input Required", "TYPE, CODE, and NAME are required.", parent=win)
                return

            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT INTO companies (company_type, type, code, name, contact, phone, email, tax_id, bank_account, address)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, ("CUSTOMER", type_val, code, name, contact, phone, email, tax_id, bank_account, address))
                conn.commit()
                messagebox.showinfo("Success", f'Customer "{name}" added successfully.', parent=win)
                win.destroy()
                self._refresh_comboboxes()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add: {e}", parent=win)
            finally:
                conn.close()

        save_btn = ctk.CTkButton(btn_frame, text="Save", width=120, command=save_customer)
        save_btn.pack(side="left", padx=5)

        cancel_btn = ctk.CTkButton(btn_frame, text="Cancel", width=120, fg_color="#6C757D", command=win.destroy)
        cancel_btn.pack(side="left", padx=5)


# ============================================================
# PORT MANAGEMENT FRAME
# ============================================================
class PortMgmtFrame(ctk.CTkFrame):
    """Port Management - TYPE, CODE, NAME, CITY, COUNTRY"""

    def __init__(self, master, width=1000, height=600):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        top = ctk.CTkFrame(self, fg_color="#FFFFFF", corner_radius=0)
        top.pack(fill="x", padx=20, pady=(32, 0))

        ctk.CTkLabel(top, text="TYPE", text_color="#444444").grid(row=0, column=0, padx=6, pady=6, sticky="e")
        self.type_var = tk.StringVar(value="")
        self.type_combo = ttk.Combobox(top, textvariable=self.type_var, state="readonly", width=12)
        self.type_combo["values"] = ["", "SEA", "AIR", "LAND"]
        self.type_combo.grid(row=0, column=1, padx=6, pady=6, sticky="w")

        ctk.CTkLabel(top, text="CODE", text_color="#444444").grid(row=0, column=2, padx=6, pady=6, sticky="e")
        self.code_var = tk.StringVar()
        self.code_entry = ctk.CTkEntry(top, width=140, textvariable=self.code_var)
        self.code_entry.grid(row=0, column=3, padx=6, pady=6, sticky="w")

        ctk.CTkLabel(top, text="CITY", text_color="#444444").grid(row=0, column=4, padx=6, pady=6, sticky="e")
        self.city_var = tk.StringVar()
        self.city_entry = ctk.CTkEntry(top, width=140, textvariable=self.city_var)
        self.city_entry.grid(row=0, column=5, padx=6, pady=6, sticky="w")

        self._search_btn = ctk.CTkButton(top, text="🔍", width=48, height=32, command=self.search)
        self._search_btn.grid(row=0, column=6, padx=8, pady=6, sticky="e")

        self._add_btn = ctk.CTkButton(top, text="+", width=40, command=self.open_add_window)
        self._add_btn.grid(row=0, column=7, padx=(8, 0), pady=6, sticky="e")

        self._delete_btn = ctk.CTkButton(top, text="-", width=40, fg_color="#D9534F", hover_color="#C9302C", text_color="white", command=self.delete_selected)
        self._delete_btn.grid(row=0, column=8, padx=(8, 0), pady=6, sticky="e")
        
        # Import worldwide ports button
        self._import_btn = ctk.CTkButton(top, text="🌍 Import Ports", width=120, 
                                         fg_color="#2E7D32", hover_color="#1B5E20",
                                         command=self._import_worldwide_ports)
        self._import_btn.grid(row=0, column=9, padx=(8, 0), pady=6, sticky="e")

        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(10, 16))

        cols = ["type", "code", "name", "city", "country"]
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        for c in cols:
            self.tree.heading(c, text=c.upper())
        self.tree.column("type", width=80, anchor="center")
        self.tree.column("code", width=120, anchor="center")
        self.tree.column("name", width=200)
        self.tree.column("city", width=180)
        self.tree.column("country", width=150)

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Button-3>", self._on_tree_right_click)
        self.tree.bind("<Button-2>", self._on_tree_right_click)
        self.tree.bind("<Double-1>", self._on_double_click)

        self.search()

    def search(self):
        type_filter = self.type_var.get().strip()
        code = self.code_var.get().strip()
        city = self.city_var.get().strip()
        
        conn = get_connection()
        cur = conn.cursor()
        q = "SELECT type, code, name, city, country FROM ports WHERE 1=1"
        params = []
        if type_filter:
            q += " AND type = ?"
            params.append(type_filter)
        if code:
            q += " AND code LIKE ?"
            params.append(f"%{code}%")
        if city:
            q += " AND (city LIKE ? OR name LIKE ?)"
            params.extend([f"%{city}%", f"%{city}%"])
        q += " ORDER BY code ASC"
        
        try:
            cur.execute(q, params)
            rows = cur.fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        for r in rows:
            self.tree.insert("", "end", values=r)

    def _on_tree_right_click(self, event):
        row_id = self.tree.identify_row(event.y)
        if not row_id:
            return
        self.tree.selection_set(row_id)
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Edit", command=lambda: self._open_edit_window(row_id))
        menu.add_command(label="Delete", command=lambda: self._confirm_delete_row(row_id))
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def _on_double_click(self, event):
        row_id = self.tree.identify_row(event.y)
        if row_id:
            self._open_edit_window(row_id)

    def _open_edit_window(self, tree_item_id):
        values = self.tree.item(tree_item_id, "values")
        if not values:
            return
        
        type_val, code, name, city, country = values[0], values[1], values[2] if len(values)>2 else "", values[3] if len(values)>3 else "", values[4] if len(values)>4 else ""
        
        win = ctk.CTkToplevel(self)
        win.title(f'Edit Port - {code}')
        win.geometry("500x450")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        main_frame = ctk.CTkFrame(win, fg_color="#FFFFFF")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(main_frame, text="Edit Port", font=("SF Pro Display", 18, "bold")).pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        form_frame.pack(fill="both", expand=True)

        labels = ["TYPE", "CODE", "NAME", "CITY", "COUNTRY"]
        db_values = [type_val, code, name, city, country]
        entries = {}

        for idx, lbl in enumerate(labels):
            row_frame = ctk.CTkFrame(form_frame, fg_color="#FFFFFF")
            row_frame.pack(fill="x", pady=8)
            
            label = ctk.CTkLabel(row_frame, text=lbl, width=100, text_color="#444444", anchor="w")
            label.pack(side="left", padx=(0, 10))
            
            if lbl == "TYPE":
                var = tk.StringVar(value=db_values[idx] or "")
                entry = ttk.Combobox(row_frame, textvariable=var, state="readonly", width=25)
                entry["values"] = ["SEA", "AIR"]
                entries[lbl] = (entry, var)
            else:
                var = tk.StringVar(value=db_values[idx] or "")
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=300)
                entries[lbl] = (entry, var)
            
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        btn_frame.pack(pady=(20, 0))

        def save_port():
            new_type = entries["TYPE"][1].get().strip()
            new_code = entries["CODE"][1].get().strip()
            new_name = entries["NAME"][1].get().strip()
            new_city = entries["CITY"][1].get().strip()
            new_country = entries["COUNTRY"][1].get().strip()

            if not new_type or not new_code:
                messagebox.showwarning("Input Required", "TYPE and CODE required.", parent=win)
                return

            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("UPDATE ports SET type=?, code=?, name=?, city=?, country=? WHERE code=?",
                           (new_type, new_code, new_name, new_city, new_country, code))
                conn.commit()
                messagebox.showinfo("Success", f'Port updated.', parent=win)
                win.destroy()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}", parent=win)
            finally:
                conn.close()

        ctk.CTkButton(btn_frame, text="Save", width=120, command=save_port).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=120, fg_color="#6C757D", command=win.destroy).pack(side="left", padx=5)

    def _confirm_delete_row(self, tree_item_id):
        values = self.tree.item(tree_item_id, "values")
        if not values:
            return
        code = values[1] if len(values) > 1 else ""
        if not messagebox.askyesno("Confirm", f'Delete port "{code}"?'):
            return
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM ports WHERE code = ?", (code,))
            conn.commit()
            self.tree.delete(tree_item_id)
            self.search()
            messagebox.showinfo("Deleted", f'Port "{code}" deleted.')
        except Exception as e:
            messagebox.showerror("Error", f"Failed: {e}")
        finally:
            conn.close()

    def delete_selected(self):
        sel = self.tree.selection()
        if sel:
            self._confirm_delete_row(sel[0])

    def open_add_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Add Port")
        win.geometry("500x450")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        main_frame = ctk.CTkFrame(win, fg_color="#FFFFFF")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(main_frame, text="Add Port", font=("SF Pro Display", 18, "bold")).pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        form_frame.pack(fill="both", expand=True)

        labels = ["TYPE", "CODE", "NAME", "CITY", "COUNTRY"]
        entries = {}

        for lbl in labels:
            row_frame = ctk.CTkFrame(form_frame, fg_color="#FFFFFF")
            row_frame.pack(fill="x", pady=8)
            
            label = ctk.CTkLabel(row_frame, text=lbl, width=100, text_color="#444444", anchor="w")
            label.pack(side="left", padx=(0, 10))
            
            if lbl == "TYPE":
                var = tk.StringVar()
                entry = ttk.Combobox(row_frame, textvariable=var, state="readonly", width=25)
                entry["values"] = ["SEA", "AIR"]
                entries[lbl] = (entry, var)
            else:
                var = tk.StringVar()
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=300)
                entries[lbl] = (entry, var)
            
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        btn_frame.pack(pady=(20, 0))

        def save_port():
            type_val = entries["TYPE"][1].get().strip()
            code = entries["CODE"][1].get().strip()
            name = entries["NAME"][1].get().strip()
            city = entries["CITY"][1].get().strip()
            country = entries["COUNTRY"][1].get().strip()

            if not type_val or not code:
                messagebox.showwarning("Input Required", "TYPE and CODE required.", parent=win)
                return

            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("INSERT INTO ports (type, code, name, city, country) VALUES (?, ?, ?, ?, ?)",
                           (type_val, code, name, city, country))
                conn.commit()
                messagebox.showinfo("Success", f'Port "{code}" added.', parent=win)
                win.destroy()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}", parent=win)
            finally:
                conn.close()

        ctk.CTkButton(btn_frame, text="Save", width=120, command=save_port).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=120, fg_color="#6C757D", command=win.destroy).pack(side="left", padx=5)

    def _import_worldwide_ports(self):
        """Import worldwide ports from seed_ports.py data"""
        if not messagebox.askyesno("Import Ports", 
            "This will import 500+ worldwide ports/cities.\n"
            "Existing ports will be updated, new ones will be added.\n\n"
            "Continue?"):
            return
        
        # Import the port data directly
        try:
            from seed_ports import WORLDWIDE_PORTS
        except ImportError:
            # Define inline if seed_ports not available
            messagebox.showerror("Error", "seed_ports.py not found.\nPlease ensure it's in the same directory.")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        
        inserted = 0
        updated = 0
        
        try:
            for port in WORLDWIDE_PORTS:
                code, name, port_type, city, country, country_code = port
                
                # Check if exists
                cur.execute("SELECT id FROM ports WHERE code = ?", (code,))
                existing = cur.fetchone()
                
                if existing:
                    cur.execute("""
                        UPDATE ports SET name=?, type=?, city=?, country=?, country_code=?, is_active=1
                        WHERE code=?
                    """, (name, port_type, city, country, country_code, code))
                    updated += 1
                else:
                    cur.execute("""
                        INSERT INTO ports (code, name, type, city, country, country_code, is_active, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                    """, (code, name, port_type, city, country, country_code, 
                          datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                    inserted += 1
            
            conn.commit()
            messagebox.showinfo("Import Complete", 
                f"✅ Ports imported successfully!\n\n"
                f"New ports added: {inserted}\n"
                f"Existing ports updated: {updated}\n"
                f"Total: {len(WORLDWIDE_PORTS)}")
            
            self.search()  # Refresh the list
            
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Import failed: {e}")
        finally:
            conn.close()


# ============================================================
# FREIGHT MANAGEMENT FRAME
# ============================================================
class FreightMgmtFrame(ctk.CTkFrame):
    """Freight Code Management"""

    def __init__(self, master, width=900, height=600):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=40)
        spacer.pack(fill="x")

        top = ctk.CTkFrame(self, fg_color="#FFFFFF")
        top.pack(fill="x", padx=20, pady=(10, 0))

        ctk.CTkLabel(top, text="Code:").grid(row=0, column=0, padx=6, pady=6)
        self.code_var = tk.StringVar()
        ctk.CTkEntry(top, textvariable=self.code_var, width=120).grid(row=0, column=1, padx=6, pady=6)

        ctk.CTkLabel(top, text="Description:").grid(row=0, column=2, padx=6, pady=6)
        self.desc_var = tk.StringVar()
        ctk.CTkEntry(top, textvariable=self.desc_var, width=200).grid(row=0, column=3, padx=6, pady=6)

        ctk.CTkButton(top, text="🔍", width=48, command=self.search).grid(row=0, column=4, padx=8, pady=6)
        ctk.CTkButton(top, text="+", width=40, command=self.open_add_window).grid(row=0, column=5, padx=4, pady=6)
        ctk.CTkButton(top, text="-", width=40, fg_color="#D9534F", command=self.delete_selected).grid(row=0, column=6, padx=4, pady=6)

        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(10, 16))

        cols = ["id", "code", "description", "default_currency"]
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("code", text="CODE")
        self.tree.heading("description", text="DESCRIPTION")
        self.tree.heading("default_currency", text="DEFAULT CURRENCY")
        self.tree.column("id", width=0, stretch=False)
        self.tree.column("code", width=150, anchor="center")
        self.tree.column("description", width=350)
        self.tree.column("default_currency", width=120, anchor="center")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", lambda e: self._on_double_click())

        self.search()

    def search(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        conn = get_connection()
        cur = conn.cursor()
        try:
            q = "SELECT id, code, description, default_currency FROM freight_codes WHERE 1=1"
            params = []
            code = self.code_var.get().strip()
            desc = self.desc_var.get().strip()
            if code:
                q += " AND code LIKE ?"
                params.append(f"%{code}%")
            if desc:
                q += " AND description LIKE ?"
                params.append(f"%{desc}%")
            q += " ORDER BY code"
            cur.execute(q, params)
            for row in cur.fetchall():
                self.tree.insert("", "end", values=row)
        except:
            pass
        finally:
            conn.close()

    def _on_double_click(self):
        sel = self.tree.selection()
        if sel:
            self._open_edit_window(sel[0])

    def _open_edit_window(self, tree_item_id):
        values = self.tree.item(tree_item_id, "values")
        if not values:
            return
        
        record_id, code, desc, curr = values[0], values[1], values[2], values[3] if len(values)>3 else "USD"
        
        win = ctk.CTkToplevel(self)
        win.title(f'Edit Freight Code - {code}')
        win.geometry("450x350")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        main_frame = ctk.CTkFrame(win, fg_color="#FFFFFF")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(main_frame, text="Edit Freight Code", font=("SF Pro Display", 18, "bold")).pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        form_frame.pack(fill="both", expand=True)

        entries = {}
        for lbl, val in [("CODE", code), ("DESCRIPTION", desc), ("CURRENCY", curr)]:
            row_frame = ctk.CTkFrame(form_frame, fg_color="#FFFFFF")
            row_frame.pack(fill="x", pady=8)
            ctk.CTkLabel(row_frame, text=lbl, width=100, anchor="w").pack(side="left", padx=(0, 10))
            if lbl == "CURRENCY":
                var = tk.StringVar(value=val)
                entry = ttk.Combobox(row_frame, textvariable=var, values=["USD", "MXN", "EUR"], width=15)
                entries[lbl] = var
            else:
                var = tk.StringVar(value=val)
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=250)
                entries[lbl] = var
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        btn_frame.pack(pady=(20, 0))

        def save():
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("UPDATE freight_codes SET code=?, description=?, default_currency=? WHERE id=?",
                           (entries["CODE"].get(), entries["DESCRIPTION"].get(), entries["CURRENCY"].get(), record_id))
                conn.commit()
                win.destroy()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}", parent=win)
            finally:
                conn.close()

        ctk.CTkButton(btn_frame, text="Save", width=100, command=save).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=100, fg_color="#6C757D", command=win.destroy).pack(side="left", padx=5)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], "values")
        if not messagebox.askyesno("Confirm", f'Delete "{values[1]}"?'):
            return
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM freight_codes WHERE id=?", (values[0],))
            conn.commit()
            self.search()
        except Exception as e:
            messagebox.showerror("Error", f"Failed: {e}")
        finally:
            conn.close()

    def open_add_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Add Freight Code")
        win.geometry("450x350")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        main_frame = ctk.CTkFrame(win, fg_color="#FFFFFF")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(main_frame, text="Add Freight Code", font=("SF Pro Display", 18, "bold")).pack(pady=(0, 20))

        form_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        form_frame.pack(fill="both", expand=True)

        entries = {}
        for lbl in ["CODE", "DESCRIPTION", "CURRENCY"]:
            row_frame = ctk.CTkFrame(form_frame, fg_color="#FFFFFF")
            row_frame.pack(fill="x", pady=8)
            ctk.CTkLabel(row_frame, text=lbl, width=100, anchor="w").pack(side="left", padx=(0, 10))
            if lbl == "CURRENCY":
                var = tk.StringVar(value="USD")
                entry = ttk.Combobox(row_frame, textvariable=var, values=["USD", "MXN", "EUR"], width=15)
                entries[lbl] = var
            else:
                var = tk.StringVar()
                entry = ctk.CTkEntry(row_frame, textvariable=var, width=250)
                entries[lbl] = var
            entry.pack(side="left", fill="x", expand=True)

        btn_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        btn_frame.pack(pady=(20, 0))

        def save():
            code = entries["CODE"].get().strip()
            desc = entries["DESCRIPTION"].get().strip()
            curr = entries["CURRENCY"].get()
            if not code:
                messagebox.showwarning("Required", "CODE is required", parent=win)
                return
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("INSERT INTO freight_codes (code, description, default_currency) VALUES (?, ?, ?)",
                           (code, desc, curr))
                conn.commit()
                win.destroy()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}", parent=win)
            finally:
                conn.close()

        ctk.CTkButton(btn_frame, text="Save", width=100, command=save).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=100, fg_color="#6C757D", command=win.destroy).pack(side="left", padx=5)


# ============================================================
# OFFER MANAGEMENT FRAME
# ============================================================
class OfferMgmtFrame(ctk.CTkFrame):
    """Offer Management"""

    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        title = ctk.CTkLabel(self, text="OFFER MANAGEMENT", font=("SF Pro Display", 22, "bold"))
        title.pack(anchor="w", padx=20, pady=(15, 5))

        top = ctk.CTkFrame(self, fg_color="#FFFFFF")
        top.pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(top, text="Company").grid(row=0, column=0, padx=6, pady=6)
        self.company_var = tk.StringVar()
        ctk.CTkEntry(top, width=200, textvariable=self.company_var).grid(row=0, column=1, padx=6, pady=6)

        ctk.CTkButton(top, text="🔍", width=48, command=self.search).grid(row=0, column=2, padx=8, pady=6)
        ctk.CTkButton(top, text="+ New Quote", width=120, command=self.open_add_window).grid(row=0, column=3, padx=8, pady=6)

        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(8, 16))

        cols = ["quote_ref", "company", "mode", "type", "status"]
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        for c in cols:
            self.tree.heading(c, text=c.upper())
            self.tree.column(c, width=150, anchor="center")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.search()

    def search(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

    def open_add_window(self):
        win = ctk.CTkToplevel(self)
        win.title("Add Quote")
        win.geometry("700x500")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        ctk.CTkLabel(win, text="Quote Form - Under Development", font=("SF Pro Display", 16)).pack(pady=50)
        ctk.CTkButton(win, text="Close", command=win.destroy).pack()


# ============================================================
# BRANCH MANAGEMENT FRAME
# ============================================================
class BranchMgmtFrame(ctk.CTkFrame):
    """Multi-Branch Management"""

    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)
        
        # Initialize service
        try:
            from services import get_services
            self._services = get_services()
            self.branch_service = self._services.branch
        except:
            self.branch_service = None

        # Title
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(15, 5))
        ctk.CTkLabel(title_frame, text="🏢 BRANCH MANAGEMENT", 
                    font=("SF Pro Display", 22, "bold")).pack(side="left")

        # Toolbar
        toolbar = ctk.CTkFrame(self, fg_color="#F5F5F7", corner_radius=10)
        toolbar.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkButton(toolbar, text="+ Add Branch", width=120, fg_color="#28A745",
                     command=self._add_branch).pack(side="left", padx=10, pady=10)
        ctk.CTkButton(toolbar, text="🔄 Refresh", width=100, fg_color="#6C757D",
                     command=self._load_data).pack(side="left", padx=5, pady=10)
        ctk.CTkButton(toolbar, text="📊 Statistics", width=100, fg_color="#007AFF",
                     command=self._show_statistics).pack(side="left", padx=5, pady=10)

        # Branch list
        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 15))

        cols = ["id", "code", "name", "city", "state", "country", "is_hq", "jobs", "revenue"]
        col_widths = [50, 80, 200, 120, 100, 100, 60, 80, 120]
        
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        for i, c in enumerate(cols):
            self.tree.heading(c, text=c.upper().replace("_", " "))
            self.tree.column(c, width=col_widths[i], anchor="center")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        # Context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Edit", command=self._edit_branch)
        self.context_menu.add_command(label="Delete", command=self._delete_branch)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Set as HQ", command=self._set_hq)
        
        self.tree.bind("<Button-3>", self._show_context_menu)
        self.tree.bind("<Double-1>", lambda e: self._edit_branch())

        self._load_data()

    def _load_data(self):
        """Load branch data"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        if self.branch_service:
            try:
                branches = self.branch_service.get_all_branches()
                stats = self.branch_service.get_branch_statistics()
                stats_map = {s.g_t('branch_id'): s for s in stats}
                
                for b in branches:
                    branch_stats = stats_map.get(b.id, {})
                    self.tree.insert("", "end", values=(
                        b.id, b.branch_code, b.branch_name, b.city, b.state, b.country,
                        "✓" if b.is_hq else "", 
                        branch_stats.g_t('job_count', 0),
                        f"${branch_stats.g_t('revenue', 0):,.2f}"
                    ))
            except Exception as e:
                print(f"Load branch error: {e}")
        else:
            # Fallback - show demo data
            demo = [
                (1, "HQ", "Headquarters - Mexico City", "Mexico City", "CDMX", "Mexico", "✓", 45, "$125,000"),
                (2, "GDL", "Guadalajara Office", "Guadalajara", "Jalisco", "Mexico", "", 28, "$78,500"),
                (3, "MTY", "Monterrey Office", "Monterrey", "Nuevo León", "Mexico", "", 32, "$95,200"),
            ]
            for row in demo:
                self.tree.insert("", "end", values=row)

    def _add_branch(self):
        """Open add branch dialog"""
        self._open_branch_dialog(None)
    
    def _edit_branch(self):
        """Edit selected branch"""
        sel = self.tree.selection()
        if sel:
            values = self.tree.item(sel[0], "values")
            self._open_branch_dialog(values)
    
    def _open_branch_dialog(self, existing_data):
        """Open branch add/edit dialog"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Branch" if existing_data else "Add Branch")
        dialog.geometry("500x450")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        # Form fields
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=20, pady=20)
        
        fields = [
            ("Branch Code:", tk.StringVar(value=existing_data[1] if existing_data else "")),
            ("Branch Name:", tk.StringVar(value=existing_data[2] if existing_data else "")),
            ("City:", tk.StringVar(value=existing_data[3] if existing_data else "")),
            ("State:", tk.StringVar(value=existing_data[4] if existing_data else "")),
            ("Country:", tk.StringVar(value=existing_data[5] if existing_data else "Mexico")),
        ]
        
        entries = {}
        for i, (label, var) in enumerate(fields):
            ctk.CTkLabel(form, text=label).grid(row=i, column=0, sticky="w", pady=8)
            entry = ctk.CTkEntry(form, textvariable=var, width=300)
            entry.grid(row=i, column=1, pady=8, padx=10)
            entries[label] = var
        
        is_hq_var = tk.BooleanVar(value=existing_data[6] == "✓" if existing_data else False)
        ctk.CTkCheckBox(form, text="Headquarters (HQ)", variable=is_hq_var).grid(row=len(fields), column=1, sticky="w", pady=10)
        
        def save():
            if self.branch_service:
                try:
                    from services.branch_service import Branch
                    branch = Branch(
                        id=int(existing_data[0]) if existing_data else None,
                        branch_code=entries["Branch Code:"].get(),
                        branch_name=entries["Branch Name:"].get(),
                        city=entries["City:"].get(),
                        state=entries["State:"].get(),
                        country=entries["Country:"].get(),
                        is_hq=is_hq_var.get()
                    )
                    if existing_data:
                        self.branch_service.update_branch(branch)
                    else:
                        self.branch_service.create_branch(branch)
                    dialog.destroy()
                    self._load_data()
                    messagebox.showinfo("Success", "Branch saved successfully")
                except Exception as e:
                    messagebox.showerror("Error", str(e))
            else:
                messagebox.showinfo("Info", "Branch service not available")
                dialog.destroy()
        
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(btn_frame, text="Save", fg_color="#28A745", command=save).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", fg_color="#6C757D", command=dialog.destroy).pack(side="left", padx=5)
    
    def _delete_branch(self):
        """Delete selected branch"""
        sel = self.tree.selection()
        if not sel:
            return
        if messagebox.askyesno("Confirm", "Delete this branch?"):
            values = self.tree.item(sel[0], "values")
            if self.branch_service:
                try:
                    self.branch_service.delete_branch(int(values[0]))
                    self._load_data()
                except Exception as e:
                    messagebox.showerror("Error", str(e))
    
    def _set_hq(self):
        """Set selected branch as headquarters"""
        sel = self.tree.selection()
        if sel:
            values = self.tree.item(sel[0], "values")
            if self.branch_service:
                try:
                    self.branch_service.set_headquarters(int(values[0]))
                    self._load_data()
                except Exception as e:
                    messagebox.showerror("Error", str(e))
    
    def _show_statistics(self):
        """Show branch statistics"""
        if self.branch_service:
            try:
                report = self.branch_service.get_consolidated_report()
                msg = "Branch Statistics\n\n"
                msg += f"Total Branches: {report.g_t('branch_count', 0)}\n"
                msg += f"Total Jobs: {report.g_t('total_jobs', 0)}\n"
                msg += f"Total Revenue: ${report.g_t('total_revenue', 0):,.2f}\n"
                msg += f"Total Cost: ${report.g_t('total_cost', 0):,.2f}\n"
                msg += f"Total Profit: ${report.g_t('total_profit', 0):,.2f}\n"
                messagebox.showinfo("Statistics", msg)
            except Exception as e:
                messagebox.showerror("Error", str(e))
    
    def _show_context_menu(self, event):
        """Show context menu on right-click"""
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self.context_menu.post(event.x_root, event.y_root)


# ============================================================
# BUDGET MANAGEMENT FRAME
# ============================================================
class BudgetMgmtFrame(ctk.CTkFrame):
    """Budget Tracking and Management"""

    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)
        
        # Initialize service
        try:
            from services import get_services
            self._services = get_services()
            self.budget_service = self._services.budget
        except:
            self.budget_service = None

        # Title
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(15, 5))
        ctk.CTkLabel(title_frame, text="📊 BUDGET MANAGEMENT", 
                    font=("SF Pro Display", 22, "bold")).pack(side="left")

        # Year selection
        year_frame = ctk.CTkFrame(self, fg_color="#F5F5F7", corner_radius=10)
        year_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(year_frame, text="Year:").pack(side="left", padx=10, pady=10)
        self.year_var = tk.StringVar(value="2026")
        year_cb = ttk.Combobox(year_frame, textvariable=self.year_var, 
                              values=["2024", "2025", "2026", "2027"], width=10, state="readonly")
        year_cb.pack(side="left", padx=5, pady=10)
        year_cb.bind("<<ComboboxSelected>>", lambda e: self._load_data())
        
        ctk.CTkButton(year_frame, text="+ Set Budget", width=120, fg_color="#28A745",
                     command=self._set_budget).pack(side="left", padx=10, pady=10)
        ctk.CTkButton(year_frame, text="📈 Forecast", width=100, fg_color="#FF9800",
                     command=self._show_forecast).pack(side="left", padx=5, pady=10)
        ctk.CTkButton(year_frame, text="🔄 Refresh", width=100, fg_color="#6C757D",
                     command=self._load_data).pack(side="left", padx=5, pady=10)

        # Budget vs Actual table
        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        cols = ["period", "category", "budget", "actual", "variance", "variance_pct", "status"]
        col_widths = [100, 100, 120, 120, 120, 100, 100]
        
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", selectmode="browse")
        for i, c in enumerate(cols):
            self.tree.heading(c, text=c.upper().replace("_", " "))
            self.tree.column(c, width=col_widths[i], anchor="center")

        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        # Summary
        summary_frame = ctk.CTkFrame(self, fg_color="#E3F2FD", corner_radius=10)
        summary_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        self.total_budget_lbl = ctk.CTkLabel(summary_frame, text="Total Budget: $0", font=("SF Pro Display", 14))
        self.total_budget_lbl.pack(side="left", padx=20, pady=10)
        self.total_actual_lbl = ctk.CTkLabel(summary_frame, text="Total Actual: $0", font=("SF Pro Display", 14))
        self.total_actual_lbl.pack(side="left", padx=20, pady=10)
        self.variance_lbl = ctk.CTkLabel(summary_frame, text="Variance: $0", font=("SF Pro Display", 14, "bold"))
        self.variance_lbl.pack(side="left", padx=20, pady=10)

        self._load_data()

    def _load_data(self):
        """Load budget vs actual data"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        year = int(self.year_var.get())
        
        if self.budget_service:
            try:
                report = self.budget_service.get_budget_vs_actual_report(year)
                total_budget = 0
                total_actual = 0
                
                for row in report:
                    variance = row.g_t('actual', 0) - row.g_t('budget', 0)
                    variance_pct = row.g_t('variance_pct', 0)
                    status = "✓ On Track" if variance_pct <= 100 else "⚠ Over" if variance_pct <= 110 else "❌ Critical"
                    
                    self.tree.insert("", "end", values=(
                        row.g_t('period', ''),
                        row.g_t('category', ''),
                        f"${row.g_t('budget', 0):,.2f}",
                        f"${row.g_t('actual', 0):,.2f}",
                        f"${variance:,.2f}",
                        f"{variance_pct:.1f}%",
                        status
                    ))
                    total_budget += row.g_t('budget', 0)
                    total_actual += row.g_t('actual', 0)
                
                self.total_budget_lbl.configure(text=f"Total Budget: ${total_budget:,.2f}")
                self.total_actual_lbl.configure(text=f"Total Actual: ${total_actual:,.2f}")
                variance = total_actual - total_budget
                color = "#28A745" if variance <= 0 else "#DC3545"
                self.variance_lbl.configure(text=f"Variance: ${variance:,.2f}", text_color=color)
            except Exception as e:
                print(f"Load budget error: {e}")
        else:
            # Demo data
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
            for m in months:
                budget = 50000
                actual = budget * (0.8 + 0.4 * (months.index(m) / 6))
                variance = actual - budget
                pct = (actual / budget) * 100
                status = "✓ On Track" if pct <= 100 else "⚠ Over"
                self.tree.insert("", "end", values=(
                    f"{m} {year}", "REVENUE", f"${budget:,.2f}", f"${actual:,.2f}",
                    f"${variance:,.2f}", f"{pct:.1f}%", status
                ))

    def _set_budget(self):
        """Open budget setting dialog"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Set Monthly Budget")
        dialog.geometry("600x500")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        year = int(self.year_var.get())
        
        ctk.CTkLabel(dialog, text=f"Monthly Budget for {year}", 
                    font=("SF Pro Display", 18, "bold")).pack(pady=15)
        
        form = ctk.CTkFrame(dialog, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=20)
        
        ctk.CTkLabel(form, text="Category:").grid(row=0, column=0, sticky="w", pady=5)
        cat_var = tk.StringVar(value="REVENUE")
        ttk.Combobox(form, textvariable=cat_var, values=["REVENUE", "COST", "PROFIT"], width=15).grid(row=0, column=1, pady=5)
        
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        month_vars = {}
        for i, m in enumerate(months):
            row = i // 3 + 1
            col = (i % 3) * 2
            ctk.CTkLabel(form, text=f"{m}:").grid(row=row, column=col, sticky="e", padx=5, pady=5)
            var = tk.StringVar(value="50000")
            ctk.CTkEntry(form, textvariable=var, width=100).grid(row=row, column=col+1, pady=5)
            month_vars[m] = var
        
        def save():
            try:
                amounts = [float(month_vars[m].get()) for m in months]
                if self.budget_service:
                    self.budget_service.create_monthly_budgets(year, cat_var.get(), amounts)
                dialog.destroy()
                self._load_data()
                messagebox.showinfo("Success", "Budget saved successfully")
            except Exception as e:
                messagebox.showerror("Error", str(e))
        
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Save", fg_color="#28A745", command=save).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", fg_color="#6C757D", command=dialog.destroy).pack(side="left", padx=5)

    def _show_forecast(self):
        """Show year-end forecast"""
        year = int(self.year_var.get())
        if self.budget_service:
            try:
                forecast = self.budget_service.forecast_year_end(year)
                msg = f"Year-End Forecast ({year})\n\n"
                msg += f"Projected Revenue: ${forecast.g_t('projected_revenue', 0):,.2f}\n"
                msg += f"Projected Cost: ${forecast.g_t('projected_cost', 0):,.2f}\n"
                msg += f"Projected Profit: ${forecast.g_t('projected_profit', 0):,.2f}\n"
                msg += f"Confidence: {forecast.g_t('confidence', 'N/A')}\n"
                messagebox.showinfo("Forecast", msg)
            except Exception as e:
                messagebox.showerror("Error", str(e))
        else:
            messagebox.showinfo("Info", "Budget service not available")


# -------------------------
# COMPANY PROFILE FRAME
# -------------------------
class CompanyProfileFrame(ctk.CTkFrame):
    """Company profile settings - used for PDF exports and invoices"""
    
    def __init__(self, master, width=900, height=600, **kwargs):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height, **kwargs)
        
        # Header
        header = ctk.CTkFrame(self, fg_color="#1565C0", corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(header, text="🏢 Company Profile", font=("SF Pro Display", 18, "bold"),
                    text_color="white").pack(pady=15)
        
        # Scrollable form
        scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        scroll.pack(fill="both", expand=True, padx=20, pady=15)
        
        # Basic Info Section
        basic_frame = ctk.CTkFrame(scroll, fg_color="#F5F5F5", corner_radius=10)
        basic_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(basic_frame, text="Basic Information", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(12, 8))
        
        # Company Name
        row1 = ctk.CTkFrame(basic_frame, fg_color="transparent")
        row1.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(row1, text="Company Name:", width=140).pack(side="left")
        self.company_name_var = tk.StringVar()
        ctk.CTkEntry(row1, textvariable=self.company_name_var, width=400, height=35).pack(side="left", padx=5)
        
        # Legal Name
        row2 = ctk.CTkFrame(basic_frame, fg_color="transparent")
        row2.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(row2, text="Legal Name:", width=140).pack(side="left")
        self.legal_name_var = tk.StringVar()
        ctk.CTkEntry(row2, textvariable=self.legal_name_var, width=400, height=35).pack(side="left", padx=5)
        
        # TAX ID (RFC)
        row3 = ctk.CTkFrame(basic_frame, fg_color="transparent")
        row3.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(row3, text="TAX ID (RFC):", width=140).pack(side="left")
        self.tax_id_var = tk.StringVar()
        ctk.CTkEntry(row3, textvariable=self.tax_id_var, width=200, height=35).pack(side="left", padx=5)
        
        # Regime Fiscal
        ctk.CTkLabel(row3, text="Régimen Fiscal:", width=100).pack(side="left", padx=(20, 5))
        self.regime_var = tk.StringVar()
        ctk.CTkEntry(row3, textvariable=self.regime_var, width=150, height=35).pack(side="left", padx=5)
        
        ctk.CTkFrame(basic_frame, height=10, fg_color="transparent").pack()
        
        # Contact Section
        contact_frame = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=10)
        contact_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(contact_frame, text="Contact Information", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(12, 8))
        
        # Address
        addr_row1 = ctk.CTkFrame(contact_frame, fg_color="transparent")
        addr_row1.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(addr_row1, text="Address:", width=140).pack(side="left")
        self.address_var = tk.StringVar()
        ctk.CTkEntry(addr_row1, textvariable=self.address_var, width=500, height=35).pack(side="left", padx=5)
        
        # City, State, ZIP
        addr_row2 = ctk.CTkFrame(contact_frame, fg_color="transparent")
        addr_row2.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(addr_row2, text="City:", width=140).pack(side="left")
        self.city_var = tk.StringVar()
        ctk.CTkEntry(addr_row2, textvariable=self.city_var, width=180, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(addr_row2, text="State:", width=50).pack(side="left", padx=(10, 5))
        self.state_var = tk.StringVar()
        ctk.CTkEntry(addr_row2, textvariable=self.state_var, width=150, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(addr_row2, text="ZIP:", width=40).pack(side="left", padx=(10, 5))
        self.zip_var = tk.StringVar()
        ctk.CTkEntry(addr_row2, textvariable=self.zip_var, width=100, height=35).pack(side="left", padx=5)
        
        # Phone, Email
        contact_row = ctk.CTkFrame(contact_frame, fg_color="transparent")
        contact_row.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(contact_row, text="Phone:", width=140).pack(side="left")
        self.phone_var = tk.StringVar()
        ctk.CTkEntry(contact_row, textvariable=self.phone_var, width=180, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(contact_row, text="Email:", width=50).pack(side="left", padx=(10, 5))
        self.email_var = tk.StringVar()
        ctk.CTkEntry(contact_row, textvariable=self.email_var, width=250, height=35).pack(side="left", padx=5)
        
        # Website
        web_row = ctk.CTkFrame(contact_frame, fg_color="transparent")
        web_row.pack(fill="x", padx=15, pady=(5, 12))
        ctk.CTkLabel(web_row, text="Website:", width=140).pack(side="left")
        self.website_var = tk.StringVar()
        ctk.CTkEntry(web_row, textvariable=self.website_var, width=300, height=35).pack(side="left", padx=5)
        
        # Bank Section
        bank_frame = ctk.CTkFrame(scroll, fg_color="#FFF3E0", corner_radius=10)
        bank_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(bank_frame, text="Bank Account Information (for Invoices)", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(12, 8))
        
        # Bank Name
        bank_row1 = ctk.CTkFrame(bank_frame, fg_color="transparent")
        bank_row1.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(bank_row1, text="Bank Name:", width=140).pack(side="left")
        self.bank_name_var = tk.StringVar()
        ctk.CTkEntry(bank_row1, textvariable=self.bank_name_var, width=300, height=35).pack(side="left", padx=5)
        
        # USD Account
        bank_row2 = ctk.CTkFrame(bank_frame, fg_color="transparent")
        bank_row2.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(bank_row2, text="USD Account:", width=140).pack(side="left")
        self.usd_account_var = tk.StringVar()
        ctk.CTkEntry(bank_row2, textvariable=self.usd_account_var, width=250, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(bank_row2, text="CLABE:", width=60).pack(side="left", padx=(10, 5))
        self.usd_clabe_var = tk.StringVar()
        ctk.CTkEntry(bank_row2, textvariable=self.usd_clabe_var, width=200, height=35).pack(side="left", padx=5)
        
        # MXN Account
        bank_row3 = ctk.CTkFrame(bank_frame, fg_color="transparent")
        bank_row3.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(bank_row3, text="MXN Account:", width=140).pack(side="left")
        self.mxn_account_var = tk.StringVar()
        ctk.CTkEntry(bank_row3, textvariable=self.mxn_account_var, width=250, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(bank_row3, text="CLABE:", width=60).pack(side="left", padx=(10, 5))
        self.mxn_clabe_var = tk.StringVar()
        ctk.CTkEntry(bank_row3, textvariable=self.mxn_clabe_var, width=200, height=35).pack(side="left", padx=5)
        
        # SWIFT Code
        bank_row4 = ctk.CTkFrame(bank_frame, fg_color="transparent")
        bank_row4.pack(fill="x", padx=15, pady=(5, 12))
        ctk.CTkLabel(bank_row4, text="SWIFT Code:", width=140).pack(side="left")
        self.swift_var = tk.StringVar()
        ctk.CTkEntry(bank_row4, textvariable=self.swift_var, width=150, height=35).pack(side="left", padx=5)
        
        # Logo Section
        logo_frame = ctk.CTkFrame(scroll, fg_color="#E8F5E9", corner_radius=10)
        logo_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(logo_frame, text="Company Logo (for PDF exports)", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(12, 8))
        
        logo_row = ctk.CTkFrame(logo_frame, fg_color="transparent")
        logo_row.pack(fill="x", padx=15, pady=(5, 12))
        ctk.CTkLabel(logo_row, text="Logo Path:", width=140).pack(side="left")
        self.logo_path_var = tk.StringVar()
        ctk.CTkEntry(logo_row, textvariable=self.logo_path_var, width=350, height=35).pack(side="left", padx=5)
        ctk.CTkButton(logo_row, text="Browse...", width=80, fg_color="#059669", hover_color="#388E3C",
                     command=self._browse_logo).pack(side="left", padx=5)
        
        # Buttons
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(btn_frame, text="💾 Save Profile", width=150, height=40, fg_color="#1565C0",
                     hover_color="#0D47A1", command=self._save_profile).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="🔄 Reload", width=100, height=40, fg_color="#6C757D",
                     hover_color="#5a6268", command=self._load_profile).pack(side="left", padx=5)
        
        # Load existing data
        self._ensure_table()
        self._load_profile()
    
    def _ensure_table(self):
        """Ensure company_profile table exists"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS company_profile (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT,
                    updated_at TEXT
                )
            """)
            conn.commit()
        except Exception as e:
            print(f"Error creating company_profile table: {e}")
        finally:
            conn.close()
    
    def _browse_logo(self):
        """Browse for logo file"""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="Select Company Logo",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif"), ("All files", "*.*")]
        )
        if path:
            self.logo_path_var.set(path)
    
    def _save_profile(self):
        """Save company profile to database"""
        from datetime import datetime
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        profile_data = {
            "company_name": self.company_name_var.get(),
            "legal_name": self.legal_name_var.get(),
            "tax_id": self.tax_id_var.get(),
            "regime_fiscal": self.regime_var.get(),
            "address": self.address_var.get(),
            "city": self.city_var.get(),
            "state": self.state_var.get(),
            "zip": self.zip_var.get(),
            "phone": self.phone_var.get(),
            "email": self.email_var.get(),
            "website": self.website_var.get(),
            "bank_name": self.bank_name_var.get(),
            "usd_account": self.usd_account_var.get(),
            "usd_clabe": self.usd_clabe_var.get(),
            "mxn_account": self.mxn_account_var.get(),
            "mxn_clabe": self.mxn_clabe_var.get(),
            "swift": self.swift_var.get(),
            "logo_path": self.logo_path_var.get(),
        }
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            for key, value in profile_data.items():
                cur.execute("""
                    INSERT OR REPLACE INTO company_profile (key, value, updated_at)
                    VALUES (?, ?, ?)
                """, (key, value, now))
            conn.commit()
            messagebox.showinfo("Success", "Company profile saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")
        finally:
            conn.close()
    
    def _load_profile(self):
        """Load company profile from database"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT key, value FROM company_profile")
            data = {row[0]: row[1] for row in cur.fetchall()}
            
            self.company_name_var.set(data.get("company_name", ""))
            self.legal_name_var.set(data.get("legal_name", ""))
            self.tax_id_var.set(data.get("tax_id", ""))
            self.regime_var.set(data.get("regime_fiscal", ""))
            self.address_var.set(data.get("address", ""))
            self.city_var.set(data.get("city", ""))
            self.state_var.set(data.get("state", ""))
            self.zip_var.set(data.get("zip", ""))
            self.phone_var.set(data.get("phone", ""))
            self.email_var.set(data.get("email", ""))
            self.website_var.set(data.get("website", ""))
            self.bank_name_var.set(data.get("bank_name", ""))
            self.usd_account_var.set(data.get("usd_account", ""))
            self.usd_clabe_var.set(data.get("usd_clabe", ""))
            self.mxn_account_var.set(data.get("mxn_account", ""))
            self.mxn_clabe_var.set(data.get("mxn_clabe", ""))
            self.swift_var.set(data.get("swift", ""))
            self.logo_path_var.set(data.get("logo_path", ""))
        except Exception as e:
            print(f"Error loading profile: {e}")
        finally:
            conn.close()


def get_company_profile() -> dict:
    """Get company profile data for PDF exports (callable from other modules)"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT key, value FROM company_profile")
        return {row[0]: row[1] for row in cur.fetchall()}
    except:
        return {}
    finally:
        conn.close()


# -------------------------
# AUTOMATION SETTINGS FRAME
# -------------------------
class AutomationSettingsFrame(ctk.CTkFrame):
    """Automation settings - Email, Tracking, Backup configuration"""

    def __init__(self, master, width=900, height=600, **kwargs):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height, **kwargs)
        
        # Scroll frame
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        self.scroll.pack(fill="both", expand=True, padx=20, pady=(38, 20))
        
        # Title
        ctk.CTkLabel(
            self.scroll, text="⚙️ Automation Settings",
            font=("SF Pro Display", 18, "bold"),
            text_color="#374151"
        ).pack(anchor="w", pady=(0, 20))
        
        # Load config
        self._load_config()
        
        # === EMAIL SECTION ===
        self._build_email_section()
        
        # === TRACKING SECTION ===
        self._build_tracking_section()
        
        # === BACKUP SECTION ===
        self._build_backup_section()
        
        # === SAVE BUTTON ===
        btn_frame = ctk.CTkFrame(self.scroll, fg_color="transparent")
        btn_frame.pack(fill="x", pady=20)
        
        ctk.CTkButton(
            btn_frame, text="💾 Save Settings",
            font=("SF Pro Display", 14, "bold"),
            fg_color="#374151", hover_color="#1F2937",
            width=200, height=40,
            command=self._save_config
        ).pack(side="left")
        
        ctk.CTkButton(
            btn_frame, text="🧪 Test Email",
            font=("SF Pro Display", 14),
            fg_color="#059669", hover_color="#047857",
            width=150, height=40,
            command=self._test_email
        ).pack(side="left", padx=20)
        
        ctk.CTkButton(
            btn_frame, text="📦 Backup Now",
            font=("SF Pro Display", 14),
            fg_color="#6B7280", hover_color="#4B5563",
            width=150, height=40,
            command=self._backup_now
        ).pack(side="left")

    def _load_config(self):
        """Load automation config"""
        try:
            from automation import load_config
            self.config = load_config()
        except ImportError:
            self.config = {
                "email": {"enabled": False, "smtp_server": "smtp.gmail.com", "smtp_port": 587},
                "tracking": {"enabled": False, "auto_refresh_interval": 3600},
                "backup": {"enabled": True, "interval_hours": 24, "keep_days": 30}
            }

    def _build_email_section(self):
        """Build email configuration section"""
        section = ctk.CTkFrame(self.scroll, fg_color="#F9FAFB", corner_radius=10)
        section.pack(fill="x", pady=10)
        
        # Header
        header = ctk.CTkFrame(section, fg_color="#374151", corner_radius=10)
        header.pack(fill="x")
        ctk.CTkLabel(
            header, text="📧 Email Notifications",
            font=("SF Pro Display", 14, "bold"),
            text_color="#FFFFFF"
        ).pack(side="left", padx=15, pady=8)
        
        self.email_enabled = ctk.BooleanVar(value=self.config["email"].get("enabled", False))
        ctk.CTkSwitch(
            header, text="Enabled", variable=self.email_enabled,
            onvalue=True, offvalue=False,
            font=("SF Pro Display", 12),
            text_color="#FFFFFF"
        ).pack(side="right", padx=15, pady=8)
        
        # Content
        content = ctk.CTkFrame(section, fg_color="transparent")
        content.pack(fill="x", padx=15, pady=15)
        
        # SMTP Server
        row1 = ctk.CTkFrame(content, fg_color="transparent")
        row1.pack(fill="x", pady=5)
        ctk.CTkLabel(row1, text="SMTP Server:", width=120, anchor="e").pack(side="left")
        self.smtp_server = ctk.CTkEntry(row1, width=250)
        self.smtp_server.insert(0, self.config["email"].get("smtp_server", "smtp.gmail.com"))
        self.smtp_server.pack(side="left", padx=10)
        ctk.CTkLabel(row1, text="Port:").pack(side="left", padx=(20, 5))
        self.smtp_port = ctk.CTkEntry(row1, width=80)
        self.smtp_port.insert(0, str(self.config["email"].get("smtp_port", 587)))
        self.smtp_port.pack(side="left")
        
        # Username/Password
        row2 = ctk.CTkFrame(content, fg_color="transparent")
        row2.pack(fill="x", pady=5)
        ctk.CTkLabel(row2, text="Username:", width=120, anchor="e").pack(side="left")
        self.smtp_user = ctk.CTkEntry(row2, width=250, placeholder_text="your-email@gmail.com")
        self.smtp_user.insert(0, self.config["email"].get("username", ""))
        self.smtp_user.pack(side="left", padx=10)
        ctk.CTkLabel(row2, text="Password:").pack(side="left", padx=(20, 5))
        self.smtp_pass = ctk.CTkEntry(row2, width=200, show="*", placeholder_text="App Password")
        self.smtp_pass.insert(0, self.config["email"].get("password", ""))
        self.smtp_pass.pack(side="left")
        
        # Gmail Help Note
        help_frame = ctk.CTkFrame(content, fg_color="#FEF3C7", corner_radius=5)
        help_frame.pack(fill="x", pady=8)
        help_text = """⚠️ Gmail 사용 시 App Password 필요:
1. Google 계정 → 보안 → 2단계 인증 활성화
2. 보안 → 앱 비밀번호 → "메일" 선택 → 16자리 비밀번호 생성
3. 생성된 비밀번호를 위 Password 필드에 입력 (일반 비밀번호 ❌)

⚠️ For Gmail, App Password required:
1. Google Account → Security → Enable 2-Step Verification
2. Security → App Passwords → Select "Mail" → Generate 16-char password
3. Use generated password above (NOT your regular password)"""
        ctk.CTkLabel(help_frame, text=help_text, font=("SF Pro Display", 10), 
                    text_color="#92400E", justify="left", anchor="w").pack(padx=10, pady=8, fill="x")
        
        # From Address
        row3 = ctk.CTkFrame(content, fg_color="transparent")
        row3.pack(fill="x", pady=5)
        ctk.CTkLabel(row3, text="From Address:", width=120, anchor="e").pack(side="left")
        self.from_addr = ctk.CTkEntry(row3, width=300, placeholder_text="same as Username for Gmail")
        self.from_addr.insert(0, self.config["email"].get("from_address", ""))
        self.from_addr.pack(side="left", padx=10)
        ctk.CTkLabel(row3, text="(Gmail: Username과 동일)", font=("SF Pro Display", 10), text_color="#666").pack(side="left")
        
        # Admin Emails
        row4 = ctk.CTkFrame(content, fg_color="transparent")
        row4.pack(fill="x", pady=5)
        ctk.CTkLabel(row4, text="Admin Emails:", width=120, anchor="e").pack(side="left")
        self.admin_emails = ctk.CTkEntry(row4, width=400, placeholder_text="recipient1@email.com, recipient2@email.com")
        emails = self.config["email"].get("admin_emails", [])
        self.admin_emails.insert(0, ", ".join(emails))
        self.admin_emails.pack(side="left", padx=10)
        ctk.CTkLabel(row4, text="(알림 수신자)", font=("SF Pro Display", 10), text_color="#666").pack(side="left")
        
        # Alert Types
        alerts_frame = ctk.CTkFrame(content, fg_color="#E5E7EB", corner_radius=5)
        alerts_frame.pack(fill="x", pady=10)
        ctk.CTkLabel(alerts_frame, text="Alert Types:", font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=10, pady=5)
        
        alerts = self.config["email"].get("alerts", {})
        self.alert_status = ctk.BooleanVar(value=alerts.get("status_change", True))
        self.alert_new_job = ctk.BooleanVar(value=alerts.get("new_job", True))
        self.alert_settlement = ctk.BooleanVar(value=alerts.get("settlement_created", True))
        self.alert_month = ctk.BooleanVar(value=alerts.get("month_closed", True))
        self.alert_overdue = ctk.BooleanVar(value=alerts.get("overdue_payment", True))
        
        checks = ctk.CTkFrame(alerts_frame, fg_color="transparent")
        checks.pack(fill="x", padx=10, pady=5)
        ctk.CTkCheckBox(checks, text="Status Change", variable=self.alert_status).pack(side="left", padx=10)
        ctk.CTkCheckBox(checks, text="New Job", variable=self.alert_new_job).pack(side="left", padx=10)
        ctk.CTkCheckBox(checks, text="Settlement", variable=self.alert_settlement).pack(side="left", padx=10)
        ctk.CTkCheckBox(checks, text="Month Closed", variable=self.alert_month).pack(side="left", padx=10)
        ctk.CTkCheckBox(checks, text="Overdue", variable=self.alert_overdue).pack(side="left", padx=10)

    def _build_tracking_section(self):
        """Build tracking configuration section"""
        section = ctk.CTkFrame(self.scroll, fg_color="#F9FAFB", corner_radius=10)
        section.pack(fill="x", pady=10)
        
        header = ctk.CTkFrame(section, fg_color="#374151", corner_radius=10)
        header.pack(fill="x")
        ctk.CTkLabel(
            header, text="🚢 Carrier Tracking",
            font=("SF Pro Display", 14, "bold"),
            text_color="#FFFFFF"
        ).pack(side="left", padx=15, pady=8)
        
        self.tracking_enabled = ctk.BooleanVar(value=self.config["tracking"].get("enabled", False))
        ctk.CTkSwitch(
            header, text="Auto Track", variable=self.tracking_enabled,
            font=("SF Pro Display", 12),
            text_color="#FFFFFF"
        ).pack(side="right", padx=15, pady=8)
        
        content = ctk.CTkFrame(section, fg_color="transparent")
        content.pack(fill="x", padx=15, pady=15)
        
        row1 = ctk.CTkFrame(content, fg_color="transparent")
        row1.pack(fill="x", pady=5)
        ctk.CTkLabel(row1, text="Refresh Interval:", width=120, anchor="e").pack(side="left")
        self.track_interval = ctk.CTkEntry(row1, width=100)
        interval = self.config["tracking"].get("auto_refresh_interval", 3600)
        self.track_interval.insert(0, str(interval // 60))
        self.track_interval.pack(side="left", padx=10)
        ctk.CTkLabel(row1, text="minutes").pack(side="left")
        
        ctk.CTkLabel(
            content, 
            text="Supported: MAERSK, MSC, HAPAG, ONE, EVERGREEN, COSCO",
            font=("SF Pro Display", 10),
            text_color="#6B7280"
        ).pack(anchor="w", pady=5)

    def _build_backup_section(self):
        """Build backup configuration section"""
        section = ctk.CTkFrame(self.scroll, fg_color="#F9FAFB", corner_radius=10)
        section.pack(fill="x", pady=10)
        
        header = ctk.CTkFrame(section, fg_color="#374151", corner_radius=10)
        header.pack(fill="x")
        ctk.CTkLabel(
            header, text="💾 Auto Backup",
            font=("SF Pro Display", 14, "bold"),
            text_color="#FFFFFF"
        ).pack(side="left", padx=15, pady=8)
        
        self.backup_enabled = ctk.BooleanVar(value=self.config["backup"].get("enabled", True))
        ctk.CTkSwitch(
            header, text="Enabled", variable=self.backup_enabled,
            font=("SF Pro Display", 12),
            text_color="#FFFFFF"
        ).pack(side="right", padx=15, pady=8)
        
        content = ctk.CTkFrame(section, fg_color="transparent")
        content.pack(fill="x", padx=15, pady=15)
        
        row1 = ctk.CTkFrame(content, fg_color="transparent")
        row1.pack(fill="x", pady=5)
        ctk.CTkLabel(row1, text="Backup Interval:", width=120, anchor="e").pack(side="left")
        self.backup_interval = ctk.CTkEntry(row1, width=80)
        self.backup_interval.insert(0, str(self.config["backup"].get("interval_hours", 24)))
        self.backup_interval.pack(side="left", padx=10)
        ctk.CTkLabel(row1, text="hours").pack(side="left")
        
        ctk.CTkLabel(row1, text="Keep:", width=80, anchor="e").pack(side="left", padx=(30, 0))
        self.backup_keep = ctk.CTkEntry(row1, width=80)
        self.backup_keep.insert(0, str(self.config["backup"].get("keep_days", 30)))
        self.backup_keep.pack(side="left", padx=10)
        ctk.CTkLabel(row1, text="days").pack(side="left")
        
        # Backup list
        try:
            from automation import AutoBackup
            backups = AutoBackup().list_backups()[:5]
            if backups:
                ctk.CTkLabel(
                    content, text="Recent Backups:",
                    font=("SF Pro Display", 11, "bold")
                ).pack(anchor="w", pady=(10, 5))
                
                for b in backups:
                    size_mb = b['size'] / (1024 * 1024)
                    ctk.CTkLabel(
                        content,
                        text=f"  • {b['filename']} ({size_mb:.1f} MB)",
                        font=("SF Pro Display", 10),
                        text_color="#6B7280"
                    ).pack(anchor="w")
        except:
            pass

    def _save_config(self):
        """Save automation config"""
        try:
            from automation import save_config
            
            # Parse admin emails
            admin_list = [e.strip() for e in self.admin_emails.get().split(",") if e.strip()]
            
            config = {
                "email": {
                    "enabled": self.email_enabled.get(),
                    "smtp_server": self.smtp_server.get(),
                    "smtp_port": int(self.smtp_port.get() or 587),
                    "username": self.smtp_user.get(),
                    "password": self.smtp_pass.get(),
                    "from_address": self.from_addr.get(),
                    "admin_emails": admin_list,
                    "alerts": {
                        "status_change": self.alert_status.get(),
                        "new_job": self.alert_new_job.get(),
                        "settlement_created": self.alert_settlement.get(),
                        "month_closed": self.alert_month.get(),
                        "overdue_payment": self.alert_overdue.get()
                    }
                },
                "tracking": {
                    "enabled": self.tracking_enabled.get(),
                    "auto_refresh_interval": int(self.track_interval.get() or 60) * 60
                },
                "backup": {
                    "enabled": self.backup_enabled.get(),
                    "auto_backup": self.backup_enabled.get(),
                    "interval_hours": int(self.backup_interval.get() or 24),
                    "keep_days": int(self.backup_keep.get() or 30)
                },
                "refresh": {"enabled": True, "interval_seconds": 300}
            }
            
            save_config(config)
            messagebox.showinfo("Success", "Automation settings saved successfully!")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")

    def _test_email(self):
        """Send test email"""
        try:
            from automation import EmailNotifier
            
            notifier = EmailNotifier()
            notifier.config = {
                "enabled": True,
                "smtp_server": self.smtp_server.get(),
                "smtp_port": int(self.smtp_port.get() or 587),
                "username": self.smtp_user.get(),
                "password": self.smtp_pass.get(),
                "from_address": self.from_addr.get(),
                "admin_emails": [e.strip() for e in self.admin_emails.get().split(",") if e.strip()]
            }
            
            if not notifier.config["admin_emails"]:
                messagebox.showwarning("Warning", "No admin email addresses configured")
                return
            
            success = notifier.send_email(
                notifier.config["admin_emails"],
                "Test Email - DURUDURU",
                "This is a test email from DURUDURU automation system.",
                "<h2>Test Email</h2><p>DURUDURU automation is working correctly!</p>"
            )
            
            if success:
                messagebox.showinfo("Success", "Test email sent successfully!")
            else:
                messagebox.showerror("Error", "Failed to send test email")
                
        except Exception as e:
            messagebox.showerror("Error", f"Email test failed: {e}")

    def _backup_now(self):
        """Create backup immediately"""
        try:
            from automation import AutoBackup
            
            backup = AutoBackup()
            filepath = backup.backup_now()
            
            if filepath:
                messagebox.showinfo("Success", f"Backup created:\n{filepath}")
            else:
                messagebox.showerror("Error", "Backup failed")
                
        except Exception as e:
            messagebox.showerror("Error", f"Backup failed: {e}")