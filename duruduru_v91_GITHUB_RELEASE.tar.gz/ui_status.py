# ui_status.py
# Operation and Performance frames with enhanced features
# Item 4,5,15: Column settings, multi-select, container-level for OCEAN, additional columns

import customtkinter as ctk
from tkinter import ttk, messagebox
import tkinter as tk
from db import get_connection, now_str
import json
import datetime
import os

# =============================================================================
# I18N IMPORT
# =============================================================================
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"

# Import unified config
try:
    from config import COLORS, FONTS, SIZES, SPACING
except ImportError:
    # Fallback colors
    class COLORS:
        PRIMARY = "#1565C0"
        PRIMARY_DARK = "#0D47A1"
        SUCCESS = "#059669"
        SUCCESS_DARK = "#388E3C"
        ERROR = "#DC2626"
        WARNING = "#FF9800"
        TEXT_PRIMARY = "#212121"
        TEXT_SECONDARY = "#757575"
        BACKGROUND = "#F5F5F5"
        SURFACE = "#FFFFFF"
        BORDER = "#E0E0E0"


class ColumnSettingsDialog(ctk.CTkToplevel):
    """Dialog for configuring visible columns with ordering support"""
    
    def __init__(self, parent, all_columns, visible_columns, callback):
        super().__init__(parent)
        self.title("⚙️ Column Settings")
        self.geometry("500x600")
        self.transient(parent)
        self.grab_set()
        
        self.all_columns = all_columns  # [(id, title), ...]
        self.visible_columns = visible_columns.copy()
        self.callback = callback
        
        ctk.CTkLabel(self, text="Column Settings", font=("SF Pro Display", 16, "bold")).pack(pady=(15, 5))
        ctk.CTkLabel(self, text="Check to show, use ↑↓ to reorder", font=("SF Pro Display", 11), text_color="#666").pack(pady=(0, 10))
        
        # Main container
        main_frame = ctk.CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Listbox frame
        list_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF")
        list_frame.pack(side="left", fill="both", expand=True)
        
        self.listbox = tk.Listbox(list_frame, font=("SF Pro Display", 11), height=20, 
                                  selectmode=tk.SINGLE, activestyle="dotbox")
        self.listbox.pack(side="left", fill="both", expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=scrollbar.set)
        
        # Build list: visible columns first (in order), then hidden columns
        self.col_map = {c[0]: c[1] for c in all_columns}
        self.items = []  # [(col_id, is_visible), ...]
        
        # Add visible columns in current order
        for col_id in visible_columns:
            if col_id in self.col_map:
                self.items.append((col_id, True))
        
        # Add hidden columns
        for col_id, _ in all_columns:
            if col_id not in visible_columns:
                self.items.append((col_id, False))
        
        self._refresh_listbox()
        
        # Right side buttons
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent", width=100)
        btn_frame.pack(side="right", fill="y", padx=(10, 0))
        
        ctk.CTkButton(btn_frame, text="↑ Up", width=80, command=self._move_up).pack(pady=5)
        ctk.CTkButton(btn_frame, text="↓ Down", width=80, command=self._move_down).pack(pady=5)
        ctk.CTkButton(btn_frame, text="✓ Toggle", width=80, fg_color="#28A745", command=self._toggle_selected).pack(pady=15)
        ctk.CTkButton(btn_frame, text="All On", width=80, fg_color="#6C757D", command=self._select_all).pack(pady=5)
        ctk.CTkButton(btn_frame, text="All Off", width=80, fg_color="#6C757D", command=self._clear_all).pack(pady=5)
        
        # Bottom buttons
        action_frame = ctk.CTkFrame(self, fg_color="transparent")
        action_frame.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(action_frame, text="Apply", width=100, fg_color="#007AFF", command=self._apply).pack(side="right", padx=5)
        ctk.CTkButton(action_frame, text="Cancel", width=100, fg_color="#E5E5EA", text_color="#333", command=self.destroy).pack(side="right", padx=5)
        ctk.CTkButton(action_frame, text="Reset Default", width=100, fg_color="#FF9500", command=self._reset_default).pack(side="left", padx=5)
        
        # Keyboard bindings
        self.listbox.bind("<Up>", lambda e: self._key_move_up())
        self.listbox.bind("<Down>", lambda e: self._key_move_down())
        self.listbox.bind("<space>", lambda e: self._toggle_selected())
        self.listbox.bind("<Double-1>", lambda e: self._toggle_selected())
    
    def _refresh_listbox(self):
        """Refresh listbox display"""
        self.listbox.delete(0, tk.END)
        for col_id, is_visible in self.items:
            title = self.col_map.get(col_id, col_id)
            prefix = "☑" if is_visible else "☐"
            self.listbox.insert(tk.END, f"{prefix} {title}")
    
    def _move_up(self):
        sel = self.listbox.curselection()
        if not sel or sel[0] == 0:
            return
        idx = sel[0]
        item = self.items.pop(idx)
        self.items.insert(idx - 1, item)
        self._refresh_listbox()
        self.listbox.selection_set(idx - 1)
        self.listbox.see(idx - 1)
    
    def _move_down(self):
        sel = self.listbox.curselection()
        if not sel or sel[0] >= len(self.items) - 1:
            return
        idx = sel[0]
        item = self.items.pop(idx)
        self.items.insert(idx + 1, item)
        self._refresh_listbox()
        self.listbox.selection_set(idx + 1)
        self.listbox.see(idx + 1)
    
    def _key_move_up(self):
        """Move with Shift+Up"""
        pass  # Standard up/down handled by listbox
    
    def _key_move_down(self):
        pass
    
    def _toggle_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        col_id, is_visible = self.items[idx]
        self.items[idx] = (col_id, not is_visible)
        self._refresh_listbox()
        self.listbox.selection_set(idx)
    
    def _select_all(self):
        self.items = [(col_id, True) for col_id, _ in self.items]
        self._refresh_listbox()
    
    def _clear_all(self):
        self.items = [(col_id, False) for col_id, _ in self.items]
        self._refresh_listbox()
    
    def _reset_default(self):
        """Reset to default columns"""
        default = ["job_no", "mode", "op", "mbl_mawb", "hbl_hawb", "shipper", "consignee", "customer", "pol", "pod", "etd", "eta", "status"]
        self.items = []
        for col_id in default:
            if col_id in self.col_map:
                self.items.append((col_id, True))
        for col_id, _ in self.all_columns:
            if col_id not in default:
                self.items.append((col_id, False))
        self._refresh_listbox()
    
    def _apply(self):
        selected = [col_id for col_id, is_visible in self.items if is_visible]
        if not selected:
            messagebox.showwarning("Warning", "Please select at least one column.")
            return
        self.callback(selected)
        self.destroy()


class OperationFrame(ctk.CTkFrame):
    """Operation Status - View and manage all jobs with enhanced features"""
    
    # All available columns
    ALL_COLUMNS = [
        ("job_no", "JOB NO", 110),
        ("mode", "MODE", 60),
        ("op", "OP", 50),
        ("mbl_mawb", "MBL/MAWB", 120),
        ("hbl_hawb", "HBL/HAWB", 120),
        ("shipper", "SHIPPER", 130),
        ("consignee", "CONSIGNEE", 130),
        ("customer", "CUSTOMER", 130),
        ("partner", "PARTNER", 100),
        ("carrier", "S.LINE/AIRLINE", 100),
        ("vessel_flight", "VESSEL/FLIGHT", 100),
        ("pol", "POL/AOL", 80),
        ("pod", "POD/AOD", 80),
        ("etd", "ETD", 90),
        ("eta", "ETA", 90),
        ("atd", "ATD", 90),
        ("ata", "ATA", 90),
        ("cy_open", "CY OPEN", 90),
        ("cy_cut", "CY CUT", 90),
        ("cy_out", "CY OUT", 90),
        ("delivery", "DELIVERY", 90),
        ("location", "LOCATION", 100),
        ("cntr_no", "CNTR NO", 120),
        ("cntr_type", "CNTR TYPE", 80),
        ("seal_no", "SEAL NO", 100),
        ("pcs", "PCS", 50),
        ("weight", "WEIGHT", 70),
        ("cbm", "CBM", 60),
        ("truck_line", "TRUCKER", 100),
        ("shipping_line", "S.LINE/AIRLINE", 100),
        ("status", "STATUS", 80),
        ("remarks", "REMARKS", 150),
    ]
    
    # Default visible columns
    DEFAULT_COLUMNS = ["job_no", "mode", "op", "mbl_mawb", "hbl_hawb", "shipper", "consignee", "customer", "pol", "pod", "etd", "eta", "status"]

    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)
        
        # Load saved column settings
        self.visible_columns = self._load_column_settings()
        self.show_container_level = True  # For OCEAN jobs
        
        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")
        
        # Title
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(10, 5))
        ctk.CTkLabel(title_frame, text="OPERATION STATUS", font=("SF Pro Display", 22, "bold"), text_color="#222222").pack(side="left")
        
        # Column settings button
        ctk.CTkButton(title_frame, text="⚙️ Columns", width=100, fg_color="#E5E5EA", text_color="#333",
                     hover_color="#D1D1D6", command=self._open_column_settings).pack(side="right", padx=5)
        
        # Excel Export button
        ctk.CTkButton(title_frame, text="📊 Excel", width=80, fg_color="#217346", text_color="white",
                     hover_color="#1D6340", command=self._export_to_excel).pack(side="right", padx=5)
        
        # Container level toggle (for OCEAN)
        self.cntr_level_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(title_frame, text="Container Level", variable=self.cntr_level_var, 
                       command=self.search).pack(side="right", padx=10)

        # Search section container
        self.search_container = ctk.CTkFrame(self, fg_color="#FFFFFF")
        self.search_container.pack(fill="x", padx=20, pady=(5, 10))

        # Row 1: MODE, OP, STATUS + expand button
        row1 = ctk.CTkFrame(self.search_container, fg_color="#FFFFFF")
        row1.pack(fill="x", pady=2)

        ctk.CTkLabel(row1, text="Mode:").pack(side="left", padx=(0, 5))
        self.mode_var = tk.StringVar(value="ALL")
        ttk.Combobox(row1, textvariable=self.mode_var, state="readonly", width=8, values=["ALL", "OCEAN", "AIR", "LAND"]).pack(side="left", padx=5)

        ctk.CTkLabel(row1, text="OP:").pack(side="left", padx=(15, 5))
        self.op_var = tk.StringVar(value="ALL")
        ttk.Combobox(row1, textvariable=self.op_var, state="readonly", width=8, values=["ALL", "EXPO", "IMPO"]).pack(side="left", padx=5)

        ctk.CTkLabel(row1, text="Status:").pack(side="left", padx=(15, 5))
        self.status_var = tk.StringVar(value="ALL")
        ttk.Combobox(row1, textvariable=self.status_var, state="readonly", width=12, values=["ALL", "OPEN", "IN TRANSIT", "ARRIVED", "DELIVERED", "CLOSED"]).pack(side="left", padx=5)

        ctk.CTkButton(row1, text="🔍", width=40, command=self.search).pack(side="left", padx=(20, 5))
        ctk.CTkButton(row1, text="🔄", width=40, fg_color="#6C757D", command=self._reset_filters).pack(side="left", padx=5)

        # Expand button (arrow)
        self.expanded = False
        self.expand_btn = ctk.CTkButton(row1, text="▼", width=40, fg_color="#E5E5EA", hover_color="#D1D1D6", text_color="#333333", command=self._toggle_expand)
        self.expand_btn.pack(side="right", padx=5)

        # Row 2+ (expandable detail filters)
        self.detail_frame = ctk.CTkFrame(self.search_container, fg_color="#F9FAFB", corner_radius=8)
        # Initially hidden

        # Detail row 1: Job No, Customer, Partner
        detail_row1 = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        detail_row1.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(detail_row1, text="Job No:").pack(side="left", padx=(0, 5))
        self.job_var = tk.StringVar()
        ctk.CTkEntry(detail_row1, textvariable=self.job_var, width=120).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row1, text="Customer:").pack(side="left", padx=(15, 5))
        self.customer_var = tk.StringVar()
        ctk.CTkEntry(detail_row1, textvariable=self.customer_var, width=150).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row1, text="Partner:").pack(side="left", padx=(15, 5))
        self.partner_var = tk.StringVar()
        ctk.CTkEntry(detail_row1, textvariable=self.partner_var, width=150).pack(side="left", padx=5)

        # Detail row 2: MBL/MAWB, HBL/HAWB, POL/AOL, POD/AOD
        detail_row2 = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        detail_row2.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(detail_row2, text="MBL/MAWB:").pack(side="left", padx=(0, 5))
        self.mbl_var = tk.StringVar()
        ctk.CTkEntry(detail_row2, textvariable=self.mbl_var, width=120).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row2, text="HBL/HAWB:").pack(side="left", padx=(15, 5))
        self.hbl_var = tk.StringVar()
        ctk.CTkEntry(detail_row2, textvariable=self.hbl_var, width=120).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row2, text="POL/AOL:").pack(side="left", padx=(15, 5))
        self.pol_var = tk.StringVar()
        ctk.CTkEntry(detail_row2, textvariable=self.pol_var, width=100).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row2, text="POD/AOD:").pack(side="left", padx=(15, 5))
        self.pod_var = tk.StringVar()
        ctk.CTkEntry(detail_row2, textvariable=self.pod_var, width=100).pack(side="left", padx=5)

        # Detail row 3: ETD From/To, ETA From/To
        detail_row3 = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        detail_row3.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(detail_row3, text="ETD:").pack(side="left", padx=(0, 5))
        self.etd_from_var = tk.StringVar()
        ctk.CTkEntry(detail_row3, textvariable=self.etd_from_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        ctk.CTkLabel(detail_row3, text="~").pack(side="left", padx=5)
        self.etd_to_var = tk.StringVar()
        ctk.CTkEntry(detail_row3, textvariable=self.etd_to_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)

        ctk.CTkLabel(detail_row3, text="ETA:").pack(side="left", padx=(20, 5))
        self.eta_from_var = tk.StringVar()
        ctk.CTkEntry(detail_row3, textvariable=self.eta_from_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        ctk.CTkLabel(detail_row3, text="~").pack(side="left", padx=5)
        self.eta_to_var = tk.StringVar()
        ctk.CTkEntry(detail_row3, textvariable=self.eta_to_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)

        # Detail row 4: Container No, Carrier, Truck Line
        detail_row4 = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        detail_row4.pack(fill="x", padx=10, pady=5)

        ctk.CTkLabel(detail_row4, text="CNTR NO:").pack(side="left", padx=(0, 5))
        self.cntr_var = tk.StringVar()
        ctk.CTkEntry(detail_row4, textvariable=self.cntr_var, width=120).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row4, text="Carrier:").pack(side="left", padx=(15, 5))
        self.carrier_var = tk.StringVar()
        ctk.CTkEntry(detail_row4, textvariable=self.carrier_var, width=120).pack(side="left", padx=5)

        ctk.CTkLabel(detail_row4, text="Truck Line:").pack(side="left", padx=(15, 5))
        self.truck_var = tk.StringVar()
        self.truck_combo = ttk.Combobox(detail_row4, textvariable=self.truck_var, width=18)
        self.truck_combo.pack(side="left", padx=5)
        self._load_truckers()  # Load trucker companies only

        # Quick Update section
        edit_frame = ctk.CTkFrame(self, fg_color="#F0F8FF", corner_radius=10)
        edit_frame.pack(fill="x", padx=20, pady=(0, 10))

        ctk.CTkLabel(edit_frame, text="Quick Update:", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, padx=10, pady=8)

        ctk.CTkLabel(edit_frame, text="Status:").grid(row=0, column=1, padx=5, pady=8)
        self.edit_status_var = tk.StringVar()
        ttk.Combobox(edit_frame, textvariable=self.edit_status_var, state="readonly", width=12, 
                    values=["OPEN", "IN TRANSIT", "ARRIVED", "DELIVERED", "CLOSED"]).grid(row=0, column=2, padx=5, pady=8)

        ctk.CTkLabel(edit_frame, text="ATD:").grid(row=0, column=3, padx=5, pady=8)
        self.edit_atd_var = tk.StringVar()
        ctk.CTkEntry(edit_frame, textvariable=self.edit_atd_var, width=100, placeholder_text="YYYY-MM-DD").grid(row=0, column=4, padx=5, pady=8)

        ctk.CTkLabel(edit_frame, text="ATA:").grid(row=0, column=5, padx=5, pady=8)
        self.edit_ata_var = tk.StringVar()
        ctk.CTkEntry(edit_frame, textvariable=self.edit_ata_var, width=100, placeholder_text="YYYY-MM-DD").grid(row=0, column=6, padx=5, pady=8)

        ctk.CTkLabel(edit_frame, text="Location:").grid(row=0, column=7, padx=5, pady=8)
        self.edit_location_var = tk.StringVar()
        ctk.CTkEntry(edit_frame, textvariable=self.edit_location_var, width=120).grid(row=0, column=8, padx=5, pady=8)

        ctk.CTkButton(edit_frame, text="💾 Update", width=100, fg_color="#28A745", hover_color="#218838", 
                     command=self._update_selected).grid(row=0, column=9, padx=10, pady=8)

        # Save indicator and button row
        save_row = ctk.CTkFrame(self, fg_color="transparent")
        save_row.pack(fill="x", padx=20, pady=(0, 5))
        
        self._unsaved_label = ctk.CTkLabel(save_row, text="", font=("SF Pro Display", 11), text_color="#FF6B00")
        self._unsaved_label.pack(side="left", padx=5)
        
        self._is_dirty = False
        self._pending_changes = {}  # {job_no: {field: value, ...}}
        
        ctk.CTkButton(save_row, text="💾 Save All Changes", width=150, height=32, 
                     fg_color="#1565C0", hover_color="#0D47A1",
                     command=self._save_all_changes).pack(side="right", padx=5)

        # Results table - with multi-select
        list_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 16))

        self.tree = ttk.Treeview(list_frame, show="headings", selectmode="extended")  # extended for multi-select
        
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(list_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        
        # Inline editing variables
        self._edit_entry = None
        self._edit_item = None
        self._edit_col = None
        
        # Column drag-and-drop variables
        self._drag_col = None
        self._drag_start_x = None
        
        # Clicked cell tracking for copy
        self._clicked_item = None
        self._clicked_col = None
        
        # Context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="📋 Copy Cell", command=self._copy_cell)
        self.context_menu.add_command(label="📋 Copy Row", command=self._copy_row)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="👁️ View Details", command=self._view_details)
        self.context_menu.add_command(label="✏️ Update Status", command=self._update_status_dialog)
        self.context_menu.add_command(label="💰 Go to Settlement", command=self._go_to_settlement)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="⚙️ Column Settings", command=self._open_column_settings)
        self.context_menu.add_command(label="↔️ Reorder Columns", command=self._open_column_order_dialog)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📊 Export to Excel", command=self._export_excel)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📄 Export PDF - B/L", command=lambda: self._export_pdf('bl'))
        self.context_menu.add_command(label="📄 Export PDF - AWB", command=lambda: self._export_pdf('awb'))
        self.context_menu.add_command(label="📄 Export PDF - Arrival Notice", command=lambda: self._export_pdf('arrival'))
        self.context_menu.add_command(label="📄 Export PDF - Delivery Order", command=lambda: self._export_pdf('delivery'))
        self.context_menu.add_command(label="📄 Export PDF - Invoice", command=lambda: self._export_pdf('invoice'))
        self.context_menu.add_command(label="📄 Export All PDFs", command=lambda: self._export_pdf('all'))
        self.context_menu.add_separator()
        self.context_menu.add_command(label="🗑️ Delete", command=self._delete_job)

        self.tree.bind("<Button-2>", self._show_context_menu)
        self.tree.bind("<Button-3>", self._show_context_menu)
        self.tree.bind("<Double-1>", self._on_double_click)
        
        # Cell click - primary binding for selection and copy
        self.tree.bind("<Button-1>", self._on_cell_click)
        
        # Keyboard shortcuts for copy
        self.tree.bind("<Command-c>", lambda e: self._copy_cell())  # macOS
        self.tree.bind("<Control-c>", lambda e: self._copy_cell())  # Windows/Linux
        
        # Column header drag bindings - only for heading region
        # These are handled inside _on_cell_click now by checking region

        # Status bar
        self.status_bar = ctk.CTkLabel(self, text="Ready", text_color="#666666")
        self.status_bar.pack(anchor="w", padx=20, pady=(0, 5))
        
        # Pagination controls
        self._page = 1
        self._page_size = 100
        self._total_records = 0
        self._total_pages = 1
        
        pag_frame = ctk.CTkFrame(self, fg_color="#F5F5F5", corner_radius=6, height=35)
        pag_frame.pack(fill="x", padx=20, pady=(0, 8))
        
        pag_inner = ctk.CTkFrame(pag_frame, fg_color="transparent")
        pag_inner.pack(fill="x", padx=10, pady=5)
        
        # Left side - Page info
        self.page_info_label = ctk.CTkLabel(pag_inner, text="Page 1 of 1 (0 records)", 
                                           font=("SF Pro Display", 10), text_color="#666")
        self.page_info_label.pack(side="left")
        
        # Right side - Navigation
        nav_frame = ctk.CTkFrame(pag_inner, fg_color="transparent")
        nav_frame.pack(side="right")
        
        ctk.CTkButton(nav_frame, text="⏮", width=30, height=24, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._go_to_page(1)).pack(side="left", padx=1)
        ctk.CTkButton(nav_frame, text="◀", width=30, height=24, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._go_to_page(self._page - 1)).pack(side="left", padx=1)
        
        self.page_entry_var = tk.StringVar(value="1")
        page_entry = ctk.CTkEntry(nav_frame, textvariable=self.page_entry_var, width=40, height=24, justify="center")
        page_entry.pack(side="left", padx=3)
        page_entry.bind("<Return>", lambda e: self._go_to_page(int(self.page_entry_var.get() or 1)))
        
        self.total_pages_label = ctk.CTkLabel(nav_frame, text="/ 1", font=("SF Pro Display", 10))
        self.total_pages_label.pack(side="left", padx=(0, 5))
        
        ctk.CTkButton(nav_frame, text="▶", width=30, height=24, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._go_to_page(self._page + 1)).pack(side="left", padx=1)
        ctk.CTkButton(nav_frame, text="⏭", width=30, height=24, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._go_to_page(self._total_pages)).pack(side="left", padx=1)
        
        # Page size selector
        ctk.CTkLabel(nav_frame, text="  |  Show:", font=("SF Pro Display", 10)).pack(side="left", padx=(10, 3))
        self.page_size_var = tk.StringVar(value="100")
        page_size_combo = ttk.Combobox(nav_frame, textvariable=self.page_size_var, width=5, 
                                       values=["50", "100", "200", "500"], state="readonly")
        page_size_combo.pack(side="left")
        page_size_combo.bind("<<ComboboxSelected>>", self._on_page_size_change)

        self._rebuild_columns()
        self.search()

    def _load_truckers(self):
        """Load only TRUCKER type companies for combo box"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT code, name FROM companies 
                WHERE company_type = 'TRUCKER' 
                   OR company_type LIKE '%TRUCK%'
                   OR type = 'Trucker'
                   OR type LIKE '%Truck%'
                ORDER BY name
            """)
            truckers = [f"{row[0]} - {row[1]}" for row in cur.fetchall() if row[0]]
            self.truck_combo["values"] = truckers
        except Exception as e:
            print(f"Load truckers error: {e}")
            self.truck_combo["values"] = []
        finally:
            conn.close()

    def _export_to_excel(self):
        """Export current grid data to Excel"""
        from tkinter import filedialog
        
        # Get all visible data
        items = self.tree.get_children()
        if not items:
            messagebox.showinfo("Info", "No data to export.")
            return
        
        # Ask for save location
        filename = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("CSV files", "*.csv")],
            initialfilename=f"STATUS_Export_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        if not filename:
            return
        
        try:
            if filename.endswith('.xlsx'):
                self._export_xlsx(filename, items)
            else:
                self._export_csv(filename, items)
            messagebox.showinfo("Success", f"Exported {len(items)} records to:\n{filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {e}")
    
    def _export_xlsx(self, filename, items):
        """Export to Excel format"""
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        except ImportError:
            # Fallback to CSV
            messagebox.showwarning("Warning", "openpyxl not installed. Exporting as CSV instead.")
            self._export_csv(filename.replace('.xlsx', '.csv'), items)
            return
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "STATUS Export"
        
        # Header style
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="1565C0", end_color="1565C0", fill_type="solid")
        header_align = Alignment(horizontal="center", vertical="center")
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # Get column headers
        col_map = {c[0]: c[1] for c in self.ALL_COLUMNS}
        headers = [col_map.get(col, col) for col in self.visible_columns]
        
        # Write headers
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_align
            cell.border = thin_border
        
        # Write data
        for row_idx, item in enumerate(items, 2):
            values = self.tree.item(item, "values")
            for col_idx, value in enumerate(values, 1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(horizontal="center")
        
        # Auto-adjust column widths
        for col in ws.columns:
            max_length = 0
            col_letter = col[0].column_letter
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            ws.column_dimensions[col_letter].width = min(max_length + 2, 40)
        
        wb.save(filename)
    
    def _export_csv(self, filename, items):
        """Export to CSV format"""
        import csv
        
        col_map = {c[0]: c[1] for c in self.ALL_COLUMNS}
        headers = [col_map.get(col, col) for col in self.visible_columns]
        
        with open(filename, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            
            for item in items:
                values = self.tree.item(item, "values")
                writer.writerow(values)

    def _open_column_settings(self):
        all_cols = [(c[0], c[1]) for c in self.ALL_COLUMNS]
        ColumnSettingsDialog(self, all_cols, self.visible_columns, self._apply_column_settings)

    def _apply_column_settings(self, selected_columns):
        self.visible_columns = selected_columns
        self._save_column_settings()  # Save settings
        self._rebuild_columns()
        self.search()

    def _load_column_settings(self):
        """Load column settings from config file"""
        config_dir = os.path.join(os.path.expanduser("~"), ".duruduru")
        config_file = os.path.join(config_dir, "operation_columns.json")
        try:
            if os.path.exists(config_file):
                with open(config_file, "r") as f:
                    data = json.load(f)
                    if "columns" in data and isinstance(data["columns"], list):
                        return data["columns"]
        except Exception:
            pass
        return self.DEFAULT_COLUMNS.copy()

    def _save_column_settings(self):
        """Save column settings to config file"""
        config_dir = os.path.join(os.path.expanduser("~"), ".duruduru")
        config_file = os.path.join(config_dir, "operation_columns.json")
        try:
            os.makedirs(config_dir, exist_ok=True)
            with open(config_file, "w") as f:
                json.dump({"columns": self.visible_columns}, f)
        except Exception:
            pass

    def _rebuild_columns(self):
        """Rebuild columns with fixed widths"""
        # Save current widths if they exist
        saved_widths = {}
        try:
            for col_id in self.tree["columns"]:
                saved_widths[col_id] = self.tree.column(col_id, "width")
        except:
            pass
        
        # Clear existing columns
        self.tree["columns"] = self.visible_columns
        
        col_map = {c[0]: (c[1], c[2]) for c in self.ALL_COLUMNS}
        for col_id in self.visible_columns:
            if col_id in col_map:
                title, default_width = col_map[col_id]
                # Use saved width if available, otherwise use default
                width = saved_widths.get(col_id, default_width)
                self.tree.heading(col_id, text=title)
                # Use stretch=False to prevent auto-resizing on Tab
                self.tree.column(col_id, width=width, minwidth=40, stretch=False, anchor="center")

    def _auto_resize_columns(self):
        """Auto resize columns based on content"""
        for col_id in self.visible_columns:
            max_width = 50  # Minimum width
            # Check header width
            col_map = {c[0]: c[1] for c in self.ALL_COLUMNS}
            header = col_map.get(col_id, col_id)
            max_width = max(max_width, len(header) * 10)
            
            # Check data width
            for item in self.tree.get_children():
                values = self.tree.item(item, "values")
                col_idx = self.visible_columns.index(col_id) if col_id in self.visible_columns else -1
                if col_idx >= 0 and col_idx < len(values):
                    cell_text = str(values[col_idx])
                    max_width = max(max_width, len(cell_text) * 8)
            
            # Cap max width
            max_width = min(max_width, 300)
            self.tree.column(col_id, width=max_width)

    def _toggle_expand(self):
        if self.expanded:
            self.detail_frame.pack_forget()
            self.expand_btn.configure(text="▼")
            self.expanded = False
        else:
            self.detail_frame.pack(fill="x", pady=(5, 0))
            self.expand_btn.configure(text="▲")
            self.expanded = True

    def _reset_filters(self):
        self.mode_var.set("ALL")
        self.op_var.set("ALL")
        self.status_var.set("ALL")
        self.job_var.set("")
        self.customer_var.set("")
        self.partner_var.set("")
        self.mbl_var.set("")
        self.hbl_var.set("")
        self.pol_var.set("")
        self.pod_var.set("")
        self.etd_from_var.set("")
        self.etd_to_var.set("")
        self.eta_from_var.set("")
        self.eta_to_var.set("")
        self.cntr_var.set("")
        self.carrier_var.set("")
        self.truck_var.set("")
        self.search()

    def _on_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        
        # Update status bar with selection count
        count = len(sel)
        self.status_bar.configure(text=f"{count} item(s) selected")
        
        if count == 1:
            values = self.tree.item(sel[0], "values")
            # Get job_no from values based on visible columns
            try:
                job_no_idx = self.visible_columns.index("job_no")
                job_no = values[job_no_idx]
                
                conn = get_connection()
                cur = conn.cursor()
                try:
                    cur.execute("SELECT status, atd, ata, remarks FROM jobs WHERE job_no = ?", (job_no,))
                    row = cur.fetchone()
                    if row:
                        self.edit_status_var.set(row[0] or "")
                        self.edit_atd_var.set(row[1] or "")
                        self.edit_ata_var.set(row[2] or "")
                        self.edit_location_var.set("")
                except:
                    pass
                finally:
                    conn.close()
            except ValueError:
                pass

    # ============================================================
    # INLINE EDITING
    # ============================================================
    def _on_double_click(self, event):
        """Handle double-click for inline cell editing"""
        region = self.tree.identify_region(event.x, event.y)
        
        if region == "cell":
            self._start_inline_edit(event)
        elif region == "heading":
            pass

    def _start_inline_edit(self, event):
        """Start inline editing of a cell"""
        col = self.tree.identify_column(event.x)
        item = self.tree.identify_row(event.y)
        
        if not item or not col:
            return
        
        col_idx = int(col.replace('#', '')) - 1
        if col_idx >= len(self.visible_columns):
            return
        
        col_name = self.visible_columns[col_idx]
        
        # Editable columns - including truck_line and carrier
        editable_cols = ["status", "atd", "ata", "location", "remarks", "cy_open", "cy_cut", "cy_out", "delivery", "truck_line", "carrier"]
        if col_name not in editable_cols:
            self._view_details()
            return
        
        bbox = self.tree.bbox(item, col)
        if not bbox:
            return
        
        if self._edit_entry:
            self._edit_entry.destroy()
        
        values = self.tree.item(item, "values")
        current_value = values[col_idx] if col_idx < len(values) else ""
        
        if col_name == "status":
            entry = ttk.Combobox(self.tree, values=["OPEN", "IN TRANSIT", "ARRIVED", "DELIVERED", "CLOSED"], state="readonly")
            entry.set(current_value)
        elif col_name == "truck_line":
            # Fetch trucker companies
            truckers = []
            try:
                conn = get_connection()
                cur = conn.cursor()
                cur.execute("""
                    SELECT name FROM companies 
                    WHERE company_type = 'TRUCKER' 
                       OR company_type LIKE '%TRUCK%'
                       OR type = 'Trucker'
                       OR type LIKE '%Truck%'
                    ORDER BY name
                """)
                truckers = [row[0] for row in cur.fetchall()]
                conn.close()
            except:
                pass
            entry = ttk.Combobox(self.tree, values=truckers, state="readonly")
            entry.set(current_value)
        else:
            entry = tk.Entry(self.tree, justify="center")
            entry.insert(0, str(current_value))
            entry.select_range(0, tk.END)
        
        entry.place(x=bbox[0], y=bbox[1], width=bbox[2], height=bbox[3])
        entry.focus_set()
        
        self._edit_entry = entry
        self._edit_item = item
        self._edit_col = col_idx
        self._edit_col_name = col_name
        
        entry.bind("<Return>", lambda e: self._save_inline_edit())
        entry.bind("<Escape>", lambda e: self._cancel_inline_edit())
        entry.bind("<FocusOut>", lambda e: self._save_inline_edit())

    def _save_inline_edit(self):
        """Save inline edit to database"""
        if not self._edit_entry:
            return
        
        new_value = self._edit_entry.get()
        item = self._edit_item
        col_name = self._edit_col_name
        
        self._edit_entry.destroy()
        self._edit_entry = None
        
        values = self.tree.item(item, "values")
        try:
            job_no_idx = self.visible_columns.index("job_no")
            job_no = values[job_no_idx]
        except (ValueError, IndexError):
            return
        
        db_col_map = {
            "status": "status",
            "atd": "atd",
            "ata": "ata",
            "location": "location",
            "remarks": "remarks",
            "truck_line": "truck_line",
            "carrier": "carrier",
            "cy_open": "cy_open",
            "cy_cut": "cy_cut",
            "cy_out": "cy_out",
            "delivery": "delivery_date",
        }
        
        if col_name not in db_col_map:
            return
        
        db_col = db_col_map[col_name]
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute(f"UPDATE jobs SET {db_col}=?, updated_at=? WHERE job_no=?",
                       (new_value, now_str(), job_no))
            conn.commit()
            self.search()
        except Exception as e:
            messagebox.showerror("Error", f"Update failed: {e}")
        finally:
            conn.close()

    def _cancel_inline_edit(self):
        """Cancel inline edit"""
        if self._edit_entry:
            self._edit_entry.destroy()
            self._edit_entry = None

    # ============================================================
    # COLUMN REORDERING
    # ============================================================
    def _on_header_press(self, event):
        """Handle mouse press on header"""
        region = self.tree.identify_region(event.x, event.y)
        if region == "heading":
            col = self.tree.identify_column(event.x)
            if col:
                self._drag_col = col
                self._drag_start_x = event.x

    def _on_header_drag(self, event):
        """Handle header dragging"""
        pass

    def _on_header_release(self, event):
        """Handle header release for column reordering"""
        if not self._drag_col or self._drag_start_x is None:
            self._drag_col = None
            self._drag_start_x = None
            return
        
        region = self.tree.identify_region(event.x, event.y)
        if region != "heading":
            self._drag_col = None
            self._drag_start_x = None
            return
        
        target_col = self.tree.identify_column(event.x)
        if not target_col or target_col == self._drag_col:
            self._drag_col = None
            self._drag_start_x = None
            return
        
        from_idx = int(self._drag_col.replace('#', '')) - 1
        to_idx = int(target_col.replace('#', '')) - 1
        
        if from_idx < len(self.visible_columns) and to_idx < len(self.visible_columns):
            col = self.visible_columns.pop(from_idx)
            self.visible_columns.insert(to_idx, col)
            self._save_column_settings()  # Persist order
            self._rebuild_columns()
            self.search()
        
        self._drag_col = None
        self._drag_start_x = None

    def _open_column_order_dialog(self):
        """Open dialog for column reordering"""
        dlg = ctk.CTkToplevel(self)
        dlg.title("Reorder Columns")
        dlg.geometry("350x500")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        
        ctk.CTkLabel(dlg, text="Reorder Columns", font=("SF Pro Display", 14, "bold")).pack(pady=15)
        ctk.CTkLabel(dlg, text="Select and use ↑↓ buttons", font=("SF Pro Display", 11), text_color="#666").pack()
        
        list_frame = ctk.CTkFrame(dlg, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        listbox = tk.Listbox(list_frame, font=("SF Pro Display", 12), height=15, selectmode=tk.SINGLE)
        listbox.pack(side="left", fill="both", expand=True)
        
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)
        
        col_labels = {c[0]: c[1] for c in self.ALL_COLUMNS}
        for col in self.visible_columns:
            label = col_labels.get(col, col)
            listbox.insert(tk.END, f"{col} - {label}")
        
        def move_up():
            sel = listbox.curselection()
            if not sel or sel[0] == 0:
                return
            idx = sel[0]
            text = listbox.get(idx)
            listbox.delete(idx)
            listbox.insert(idx - 1, text)
            listbox.selection_set(idx - 1)
        
        def move_down():
            sel = listbox.curselection()
            if not sel or sel[0] >= listbox.size() - 1:
                return
            idx = sel[0]
            text = listbox.get(idx)
            listbox.delete(idx)
            listbox.insert(idx + 1, text)
            listbox.selection_set(idx + 1)
        
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(pady=10)
        ctk.CTkButton(btn_frame, text="↑ Up", width=80, command=move_up).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="↓ Down", width=80, command=move_down).pack(side="left", padx=5)
        
        def apply():
            new_order = []
            for i in range(listbox.size()):
                item = listbox.get(i)
                col_key = item.split(" - ")[0]
                new_order.append(col_key)
            self.visible_columns = new_order
            self._save_column_settings()  # Persist order
            self._rebuild_columns()
            self.search()
            dlg.destroy()
        
        action_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        action_frame.pack(pady=15)
        ctk.CTkButton(action_frame, text="Apply", width=100, command=apply).pack(side="left", padx=10)
        ctk.CTkButton(action_frame, text="Cancel", width=100, fg_color="#6C757D", command=dlg.destroy).pack(side="left", padx=10)

    # ============================================================
    # COPY FUNCTIONS - Enhanced Cell Selection
    # ============================================================
    def _on_cell_click(self, event):
        """Track clicked cell for copy operations and show in status bar"""
        region = self.tree.identify_region(event.x, event.y)
        
        # Only process cell clicks, not heading clicks
        if region == "cell":
            item = self.tree.identify_row(event.y)
            col = self.tree.identify_column(event.x)
            if item and col:
                # Don't clear selection if Ctrl/Cmd is held (for multi-select)
                # Otherwise select just this row
                self.tree.selection_set(item)
                self.tree.focus(item)
                
                self._clicked_item = item
                col_idx = int(col.replace('#', '')) - 1
                self._clicked_col = col_idx
                
                # Show cell content in status bar with copy hint
                values = self.tree.item(item, "values")
                if col_idx < len(values) and col_idx < len(self.visible_columns):
                    cell_value = values[col_idx]
                    col_name = self.visible_columns[col_idx]
                    col_label = {c[0]: c[1] for c in self.ALL_COLUMNS}.get(col_name, col_name)
                    
                    display_val = str(cell_value)[:50] + "..." if len(str(cell_value)) > 50 else cell_value
                    self.status_bar.configure(
                        text=f"📋 [{col_label}]: {display_val}  |  ⌘C/Ctrl+C to copy  |  Right-click for menu",
                        text_color="#1565C0"
                    )
        elif region == "heading":
            # Let header click pass through for sorting
            pass
        elif region == "nothing":
            # Clear selection when clicking empty area
            self._clicked_item = None
            self._clicked_col = None
            self.status_bar.configure(text="Ready", text_color="#666666")

    def _copy_cell(self):
        """Copy clicked cell content to clipboard"""
        sel = self.tree.selection()
        if not sel:
            return
        
        item = self._clicked_item if self._clicked_item else sel[0]
        values = self.tree.item(item, "values")
        
        if values:
            # If we have a clicked column, copy just that cell
            if self._clicked_col is not None and 0 <= self._clicked_col < len(values):
                text = str(values[self._clicked_col])
                self.status_bar.configure(text=f"Cell copied: {text[:30]}...")
            else:
                # Otherwise copy whole row
                text = "\t".join(str(v) for v in values)
                self.status_bar.configure(text="Row copied to clipboard")
            
            self.clipboard_clear()
            self.clipboard_append(text)

    def _copy_row(self):
        """Copy selected row(s) to clipboard"""
        sel = self.tree.selection()
        if not sel:
            return
        
        lines = []
        for item in sel:
            values = self.tree.item(item, "values")
            lines.append("\t".join(str(v) for v in values))
        
        text = "\n".join(lines)
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_bar.configure(text=f"{len(sel)} row(s) copied to clipboard")

    def _mark_dirty(self, job_no=None, field=None, value=None):
        """Mark that there are unsaved changes"""
        self._is_dirty = True
        self._unsaved_label.configure(text="● Unsaved changes")
        
        # Track specific changes if provided
        if job_no and field:
            if job_no not in self._pending_changes:
                self._pending_changes[job_no] = {}
            self._pending_changes[job_no][field] = value
    
    def _clear_dirty(self):
        """Clear unsaved changes indicator"""
        self._is_dirty = False
        self._pending_changes = {}
        self._unsaved_label.configure(text="")
    
    def _save_all_changes(self):
        """Save all pending changes to database"""
        if not self._pending_changes:
            messagebox.showinfo("Save", "No changes to save.")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        saved = 0
        
        try:
            for job_no, changes in self._pending_changes.items():
                if changes:
                    updates = []
                    params = []
                    for field, value in changes.items():
                        updates.append(f"{field} = ?")
                        params.append(value)
                    
                    if updates:
                        updates.append("updated_at = ?")
                        params.append(now_str())
                        params.append(job_no)
                        
                        sql = f"UPDATE jobs SET {', '.join(updates)} WHERE job_no = ?"
                        cur.execute(sql, params)
                        saved += 1
            
            conn.commit()
            self._clear_dirty()
            messagebox.showinfo("Saved", f"{saved} job(s) saved successfully.")
            self.search()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Save failed: {e}")
        finally:
            conn.close()

    def _update_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select job(s) to update.")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        updated = 0
        
        try:
            job_no_idx = self.visible_columns.index("job_no")
        except ValueError:
            messagebox.showerror("Error", "Job No column not visible")
            return
        
        try:
            for item in sel:
                values = self.tree.item(item, "values")
                job_no = values[job_no_idx]
                
                updates = []
                params = []
                
                if self.edit_status_var.get():
                    updates.append("status = ?")
                    params.append(self.edit_status_var.get())
                if self.edit_atd_var.get():
                    updates.append("atd = ?")
                    params.append(self.edit_atd_var.get())
                if self.edit_ata_var.get():
                    updates.append("ata = ?")
                    params.append(self.edit_ata_var.get())
                
                if updates:
                    updates.append("updated_at = ?")
                    params.append(now_str())
                    params.append(job_no)
                    
                    cur.execute(f"UPDATE jobs SET {', '.join(updates)} WHERE job_no = ?", params)
                    updated += 1
            
            conn.commit()
            messagebox.showinfo("Updated", f"{updated} job(s) updated successfully.")
            self.search()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed to update: {e}")
        finally:
            conn.close()

    def _show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            if item not in self.tree.selection():
                self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)

    def search(self):
        mode = self.mode_var.get()
        op = self.op_var.get()
        status = self.status_var.get()
        customer = self.customer_var.get().strip()
        partner = self.partner_var.get().strip()
        job_no = self.job_var.get().strip()
        mbl = self.mbl_var.get().strip()
        hbl = self.hbl_var.get().strip()
        pol = self.pol_var.get().strip()
        pod = self.pod_var.get().strip()
        etd_from = self.etd_from_var.get().strip()
        etd_to = self.etd_to_var.get().strip()
        eta_from = self.eta_from_var.get().strip()
        eta_to = self.eta_to_var.get().strip()
        cntr = self.cntr_var.get().strip()
        carrier = self.carrier_var.get().strip()
        truck = self.truck_var.get().strip()

        conn = get_connection()
        cur = conn.cursor()

        # Build query based on container level checkbox
        if self.cntr_level_var.get() and (not mode or mode == "OCEAN"):
            # Container-level query for OCEAN
            q = """
                SELECT j.job_no, j.mode, 
                       CASE WHEN j.pol LIKE '%MX%' THEN 'EXPO' ELSE 'IMPO' END as op,
                       j.mbl, j.hbl, 
                       COALESCE(j.shipper, '') as shipper, COALESCE(j.consignee, '') as consignee,
                       j.customer, j.partner, j.carrier,
                       COALESCE(j.vessel || ' / ' || j.voyage, '') as vessel_flight,
                       j.pol, j.pod, j.etd, j.eta, j.atd, j.ata,
                       '' as cy_open, '' as cy_cut, '' as cy_out, '' as delivery,
                       COALESCE(c.location, '') as location,
                       COALESCE(c.cntr_no, '') as cntr_no,
                       COALESCE(c.cntr_type, '') as cntr_type,
                       COALESCE(c.seal_no, '') as seal_no,
                       COALESCE(c.pcs, '') as pcs,
                       COALESCE(c.weight, '') as weight,
                       COALESCE(c.cbm, '') as cbm,
                       COALESCE(j.truck_line, '') as truck_line, j.carrier as shipping_line,
                       COALESCE(c.status, j.status) as status,
                       j.remarks
                FROM jobs j
                LEFT JOIN containers c ON j.id = c.job_id
                WHERE 1=1
            """
        else:
            # Job-level query
            q = """
                SELECT j.job_no, j.mode,
                       CASE WHEN j.pol LIKE '%MX%' THEN 'EXPO' ELSE 'IMPO' END as op,
                       j.mbl, j.hbl, 
                       COALESCE(j.shipper, '') as shipper, COALESCE(j.consignee, '') as consignee,
                       j.customer, j.partner, j.carrier,
                       COALESCE(j.vessel || ' / ' || j.voyage, '') as vessel_flight,
                       j.pol, j.pod, j.etd, j.eta, j.atd, j.ata,
                       '' as cy_open, '' as cy_cut, '' as cy_out, '' as delivery,
                       '' as location, '' as cntr_no, '' as cntr_type, '' as seal_no,
                       '' as pcs, '' as weight, '' as cbm,
                       COALESCE(j.truck_line, '') as truck_line, j.carrier as shipping_line,
                       j.status, j.remarks
                FROM jobs j
                WHERE 1=1
            """
        
        params = []

        if mode and mode != "ALL":
            q += " AND j.mode = ?"; params.append(mode)
        if op and op != "ALL":
            if op == "EXPO":
                q += " AND j.pol LIKE '%MX%'"
            else:
                q += " AND j.pol NOT LIKE '%MX%'"
        if status and status != "ALL":
            if self.cntr_level_var.get():
                q += " AND (j.status = ? OR c.status = ?)"; params.extend([status, status])
            else:
                q += " AND j.status = ?"; params.append(status)
        if customer:
            q += " AND j.customer LIKE ?"; params.append(f"%{customer}%")
        if partner:
            q += " AND j.partner LIKE ?"; params.append(f"%{partner}%")
        if job_no:
            q += " AND j.job_no LIKE ?"; params.append(f"%{job_no}%")
        if mbl:
            q += " AND j.mbl LIKE ?"; params.append(f"%{mbl}%")
        if hbl:
            q += " AND j.hbl LIKE ?"; params.append(f"%{hbl}%")
        if pol:
            q += " AND j.pol LIKE ?"; params.append(f"%{pol}%")
        if pod:
            q += " AND j.pod LIKE ?"; params.append(f"%{pod}%")
        if etd_from:
            q += " AND j.etd >= ?"; params.append(etd_from)
        if etd_to:
            q += " AND j.etd <= ?"; params.append(etd_to)
        if eta_from:
            q += " AND j.eta >= ?"; params.append(eta_from)
        if eta_to:
            q += " AND j.eta <= ?"; params.append(eta_to)
        if cntr:
            q += " AND c.cntr_no LIKE ?"; params.append(f"%{cntr}%")
        if carrier:
            q += " AND j.carrier LIKE ?"; params.append(f"%{carrier}%")
        if truck:
            q += " AND j.truck_line LIKE ?"; params.append(f"%{truck}%")

        q += " ORDER BY j.created_at DESC, j.job_no DESC"
        
        # Get total count for pagination (wrap in subquery)
        count_q = "SELECT COUNT(*) FROM (" + q + ") AS subquery"

        try:
            # Get total count
            cur.execute(count_q, params)
            self._total_records = cur.fetchone()[0]
            self._total_pages = max(1, (self._total_records + self._page_size - 1) // self._page_size)
            
            # Ensure current page is valid
            if self._page > self._total_pages:
                self._page = self._total_pages
            if self._page < 1:
                self._page = 1
            
            # Add pagination to query
            offset = (self._page - 1) * self._page_size
            q += f" LIMIT {self._page_size} OFFSET {offset}"
            
            cur.execute(q, params)
            rows = cur.fetchall()
        except Exception as e:
            print(f"Query error: {e}")
            rows = []
            self._total_records = 0
            self._total_pages = 1
        finally:
            conn.close()

        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Column mapping for display - must match SQL query order
        all_col_ids = ["job_no", "mode", "op", "mbl_mawb", "hbl_hawb", "shipper", "consignee",
                       "customer", "partner", "carrier", "vessel_flight", "pol", "pod", 
                       "etd", "eta", "atd", "ata", "cy_open", "cy_cut", "cy_out", "delivery", 
                       "location", "cntr_no", "cntr_type", "seal_no", "pcs", "weight", "cbm",
                       "truck_line", "shipping_line", "status", "remarks"]
        
        for r in rows:
            # Map row data to visible columns
            row_dict = dict(zip(all_col_ids, r))
            display_values = [row_dict.get(col, "") for col in self.visible_columns]
            self.tree.insert("", "end", values=display_values)
        
        # Update pagination info
        start_record = (self._page - 1) * self._page_size + 1 if rows else 0
        end_record = start_record + len(rows) - 1 if rows else 0
        self.page_info_label.configure(text=f"Showing {start_record}-{end_record} of {self._total_records} records")
        self.page_entry_var.set(str(self._page))
        self.total_pages_label.configure(text=f"/ {self._total_pages}")
        
        self.status_bar.configure(text=f"Page {self._page}/{self._total_pages} | Total: {self._total_records} records")
    
    def _go_to_page(self, page):
        """Navigate to specific page"""
        try:
            page = int(page)
        except:
            return
        page = max(1, min(page, self._total_pages))
        if page != self._page:
            self._page = page
            self.search()
    
    def _on_page_size_change(self, event=None):
        """Handle page size change"""
        try:
            self._page_size = int(self.page_size_var.get())
        except:
            self._page_size = 100
        self._page = 1  # Reset to first page
        self.search()

    def _go_to_settlement(self):
        """Navigate to Settlement with selected job and auto-search"""
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Please select a job.")
            return
        
        values = self.tree.item(sel[0], "values")
        try:
            job_no_idx = self.visible_columns.index("job_no")
            job_no = values[job_no_idx]
        except:
            messagebox.showerror("Error", "Cannot find Job No.")
            return
        
        # Find main window
        root = self.winfo_toplevel()
        
        def search_in_settlement(frame, job):
            """Helper to search job in settlement frame"""
            if hasattr(frame, 'search_var'):
                frame.search_var.set(job)
                if hasattr(frame, '_search_job'):
                    frame._search_job()
        
        try:
            # Check if Settlement Mgmt frame exists
            if hasattr(root, 'frames') and 'Settlement Mgmt' in root.frames:
                frame = root.frames['Settlement Mgmt']
                frame.lift()
                root.active_frame = frame
                root.active_frame_name = 'Settlement Mgmt'
                # Auto search after small delay
                frame.after(200, lambda: search_in_settlement(frame, job_no))
                return
            
            # Try to open Settlement frame
            if hasattr(root, 'show_frame'):
                try:
                    from ui_settlement import SettlementMgmtFrame
                    root.show_frame('Settlement Mgmt', SettlementMgmtFrame)
                    # Search after frame is created
                    root.after(500, lambda: self._search_settlement_delayed(root, job_no))
                    return
                except ImportError:
                    pass
        except Exception as e:
            print(f"Settlement navigation error: {e}")
        
        messagebox.showinfo("Go to Settlement", f"Please open Settlement menu and search for:\n{job_no}")
    
    def _search_settlement_delayed(self, root, job_no):
        """Search in settlement after frame is created"""
        try:
            if hasattr(root, 'frames') and 'Settlement Mgmt' in root.frames:
                frame = root.frames['Settlement Mgmt']
                if hasattr(frame, 'search_var'):
                    frame.search_var.set(job_no)
                    if hasattr(frame, '_search_job'):
                        frame._search_job()
        except Exception as e:
            print(f"Settlement search error: {e}")

    def _view_details(self):
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], "values")
        
        try:
            job_no_idx = self.visible_columns.index("job_no")
            job_no = values[job_no_idx]
        except:
            return

        win = ctk.CTkToplevel(self)
        win.title(f"Job Details - {job_no}")
        win.geometry("950x750")
        win.transient(self.winfo_toplevel())
        
        # Main frame with scrollbar
        main_frame = ctk.CTkFrame(win, fg_color="#FFFFFF")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Canvas for scrolling
        canvas = tk.Canvas(main_frame, bg="#FFFFFF", highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ctk.CTkFrame(canvas, fg_color="#FFFFFF")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ctk.CTkLabel(scrollable_frame, text=f"📋 Job Details: {job_no}", font=("SF Pro Display", 18, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        conn = get_connection()
        cur = conn.cursor()
        job = None
        containers = []
        try:
            # Debug: print job_no being queried
            print(f"Querying job details for: '{job_no}'")
            
            cur.execute("""SELECT job_no, mode, mbl, hbl, shipper, consignee, notify, customer, partner, 
                          carrier, vessel, voyage, pol, pod, etd, eta, atd, ata, status, remarks 
                          FROM jobs WHERE job_no = ?""", (job_no,))
            job = cur.fetchone()
            
            print(f"Job data found: {job is not None}")
            
            if job:
                cur.execute("SELECT id FROM jobs WHERE job_no = ?", (job_no,))
                job_id_row = cur.fetchone()
                if job_id_row:
                    cur.execute("""SELECT cntr_no, cntr_type, COALESCE(seal_no, ''), weight, cbm, status, location 
                                  FROM containers WHERE job_id = ?""", (job_id_row[0],))
                    containers = cur.fetchall()
                    print(f"Containers found: {len(containers)}")
        except Exception as e:
            print(f"Detail query error: {e}")
            import traceback
            traceback.print_exc()
        finally:
            conn.close()

        if job:
            # Create a Text widget for selectable/copyable content
            info_frame = ctk.CTkFrame(scrollable_frame, fg_color="#F9FAFB", corner_radius=10)
            info_frame.pack(fill="x", padx=15, pady=(0, 15))
            
            ctk.CTkLabel(info_frame, text="📄 Job Information", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
            
            # Text widget for selectable content
            text_widget = tk.Text(info_frame, wrap="word", height=20, font=("SF Pro Display", 11), 
                                 bg="#F9FAFB", relief="flat", cursor="arrow")
            text_widget.pack(fill="x", padx=15, pady=(0, 10))
            
            labels = ["Job No", "Mode", "MBL/MAWB", "HBL/HAWB", "Shipper", "Consignee", "Notify", 
                     "Customer", "Partner", "S.Line/Airline", "Vessel", "Voyage", "POL/AOL", "POD/AOD", 
                     "ETD", "ETA", "ATD", "ATA", "Status", "Remarks"]
            
            for lbl, val in zip(labels, job):
                text_widget.insert("end", f"{lbl}: ", "label")
                text_widget.insert("end", f"{val or ''}\n", "value")
            
            text_widget.tag_configure("label", foreground="#666666", font=("SF Pro Display", 11, "bold"))
            text_widget.tag_configure("value", foreground="#000000")
            text_widget.configure(state="disabled")  # Read-only but selectable
        else:
            # No job found - show message
            no_data_frame = ctk.CTkFrame(scrollable_frame, fg_color="#FFF3E0", corner_radius=10)
            no_data_frame.pack(fill="x", padx=15, pady=15)
            ctk.CTkLabel(no_data_frame, text=f"⚠️ No job data found for: {job_no}", 
                        font=("SF Pro Display", 14), text_color="#E65100").pack(pady=20)

        # Container section
        if containers:
            cntr_frame = ctk.CTkFrame(scrollable_frame, fg_color="#E3F2FD", corner_radius=10)
            cntr_frame.pack(fill="x", padx=15, pady=(0, 15))
            
            ctk.CTkLabel(cntr_frame, text="📦 Containers", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
            
            cntr_tree = ttk.Treeview(cntr_frame, columns=["cntr_no", "type", "seal", "weight", "cbm", "status", "location"], 
                                    show="headings", height=min(len(containers), 5))
            for col, title in [("cntr_no", "CNTR NO"), ("type", "TYPE"), ("seal", "SEAL NO"), 
                              ("weight", "WEIGHT"), ("cbm", "CBM"), ("status", "STATUS"), ("location", "LOCATION")]:
                cntr_tree.heading(col, text=title)
                cntr_tree.column(col, width=100, anchor="center")
            
            for c in containers:
                cntr_tree.insert("", "end", values=c)
            
            cntr_tree.pack(fill="x", padx=15, pady=(0, 15))

        # Buttons
        btn_frame = ctk.CTkFrame(scrollable_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=15)
        ctk.CTkButton(btn_frame, text="📋 Copy All", width=100, fg_color="#6C757D", 
                     command=lambda: self._copy_job_details(job, labels)).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Close", width=100, command=win.destroy).pack(side="right", padx=5)

    def _copy_job_details(self, job, labels):
        """Copy job details to clipboard"""
        if not job:
            return
        lines = []
        for lbl, val in zip(labels, job):
            lines.append(f"{lbl}: {val or ''}")
        text = "\n".join(lines)
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_bar.configure(text="Job details copied to clipboard")

    def _update_status_dialog(self):
        from db import validate_status_transition, get_next_valid_statuses, ALL_STATUSES
        
        sel = self.tree.selection()
        if not sel:
            return
        
        try:
            job_no_idx = self.visible_columns.index("job_no")
            status_idx = self.visible_columns.index("status") if "status" in self.visible_columns else -1
        except ValueError:
            return
        
        values = self.tree.item(sel[0], "values")
        job_no = values[job_no_idx]
        current_status = values[status_idx] if status_idx >= 0 else ""

        win = ctk.CTkToplevel(self)
        win.title(f"Update Status - {job_no}")
        win.geometry("400x300")
        win.transient(self.winfo_toplevel())
        win.grab_set()

        ctk.CTkLabel(win, text=f"Job: {job_no}", font=("SF Pro Display", 14, "bold")).pack(pady=15)
        ctk.CTkLabel(win, text=f"Current Status: {current_status}", font=("SF Pro Display", 11)).pack(pady=5)

        # 유효한 다음 상태만 표시
        valid_statuses = get_next_valid_statuses(current_status)
        if not valid_statuses:
            valid_statuses = ALL_STATUSES  # Fallback
        
        # 현재 상태도 포함
        if current_status and current_status.upper() not in [s.upper() for s in valid_statuses]:
            valid_statuses = [current_status.upper()] + valid_statuses
        
        ctk.CTkLabel(win, text="Select New Status:", font=("SF Pro Display", 10)).pack(pady=(10, 0))
        
        status_var = tk.StringVar(value=current_status.upper() if current_status else "")
        status_combo = ttk.Combobox(win, textvariable=status_var, state="readonly", width=25, 
                    values=valid_statuses)
        status_combo.pack(pady=10)
        
        # 상태 설명 레이블
        desc_label = ctk.CTkLabel(win, text="", font=("SF Pro Display", 9), text_color="#6B7280")
        desc_label.pack(pady=5)
        
        STATUS_DESC = {
            'BOOKING': '예약 접수',
            'CONFIRMED': '예약 확정',
            'IN_TRANSIT': '운송 중',
            'ARRIVED': '도착 완료',
            'CUSTOMS_HOLD': '통관 보류',
            'DELIVERED': '배송 완료',
            'INVOICED': '인보이스 발행',
            'CLOSED': '종료',
            'CANCELLED': '취소'
        }
        
        def on_status_change(event=None):
            new_status = status_var.get()
            desc = STATUS_DESC.get(new_status, '')
            desc_label.configure(text=desc)
        
        status_combo.bind("<<ComboboxSelected>>", on_status_change)

        def save():
            new_status = status_var.get()
            
            # 상태 전이 검증
            is_valid, error_msg = validate_status_transition(current_status, new_status)
            if not is_valid:
                messagebox.showerror("Invalid Transition", error_msg, parent=win)
                return
            
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("UPDATE jobs SET status = ?, updated_at = ? WHERE job_no = ?", 
                           (new_status, now_str(), job_no))
                conn.commit()
                
                # Send email notification (if enabled)
                try:
                    from automation import notify_status_change
                    notify_status_change(job_no, current_status, new_status)
                except ImportError:
                    pass
                
                messagebox.showinfo("Updated", f"Status updated to '{new_status}'", parent=win)
                win.destroy()
                self.search()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}", parent=win)
            finally:
                conn.close()

        btn_frame = ctk.CTkFrame(win, fg_color="transparent")
        btn_frame.pack(pady=15)
        ctk.CTkButton(btn_frame, text="Update", width=100, fg_color="#374151", command=save).pack(side="left", padx=10)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#9CA3AF", command=win.destroy).pack(side="left", padx=10)

    def _delete_job(self):
        sel = self.tree.selection()
        if not sel:
            return
        
        try:
            job_no_idx = self.visible_columns.index("job_no")
        except ValueError:
            return
        
        job_nos = [self.tree.item(item, "values")[job_no_idx] for item in sel]
        
        if not messagebox.askyesno("Confirm Delete", f"Delete {len(job_nos)} job(s)?"):
            return

        conn = get_connection()
        cur = conn.cursor()
        deleted = 0
        blocked = []
        
        try:
            for job_no in job_nos:
                # Check if settlement data exists (revenue or cost)
                cur.execute("""
                    SELECT COUNT(*) FROM settlement_items 
                    WHERE job_id = (SELECT id FROM jobs WHERE job_no = ?)
                """, (job_no,))
                result = cur.fetchone()
                settlement_count = result[0] if result else 0
                
                if settlement_count > 0:
                    blocked.append(job_no)
                    continue
                
                # Safe to delete
                cur.execute("SELECT id FROM jobs WHERE job_no = ?", (job_no,))
                row = cur.fetchone()
                if row:
                    job_id = row[0]
                    
                    # Delete all related records first (ignore if table doesn't exist)
                    for table in ["containers", "job_containers", "air_jobs", "land_jobs", 
                                  "settlement_items", "job_tracking", "file_attachments"]:
                        try:
                            cur.execute(f"DELETE FROM {table} WHERE job_id = ?", (job_id,))
                        except:
                            pass  # Table might not exist
                    
                    # Now delete the job
                    cur.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
                    deleted += 1
            
            conn.commit()
            
            if blocked:
                messagebox.showerror("Delete Failed", 
                    f"Delete failed: Settlement data exists\n\n"
                    f"The following jobs have settlement records and cannot be deleted:\n"
                    f"{', '.join(blocked)}\n\n"
                    f"Please remove settlement items first.")
            
            if deleted > 0:
                messagebox.showinfo("Deleted", f"{deleted} job(s) deleted.")
            
            self.search()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed: {e}")
        finally:
            conn.close()

    def _export_excel(self):
        """Export current view to Excel"""
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill
        except ImportError:
            messagebox.showwarning("Warning", "openpyxl not installed. Run: pip install openpyxl")
            return
        
        items = self.tree.get_children()
        if not items:
            messagebox.showwarning("Warning", "No data to export.")
            return
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Operation"
        
        # Headers
        col_map = {c[0]: c[1] for c in self.ALL_COLUMNS}
        headers = [col_map.get(col, col) for col in self.visible_columns]
        
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            cell.font = Font(bold=True, color="FFFFFF")
            cell.alignment = Alignment(horizontal="center")
        
        # Data
        for row_idx, item in enumerate(items, 2):
            values = self.tree.item(item, "values")
            for col_idx, val in enumerate(values, 1):
                ws.cell(row=row_idx, column=col_idx, value=val)
        
        # Auto-width
        for col_idx in range(1, len(headers) + 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = 15
        
        # Save
        filename = f"operation_export_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = f"/mnt/user-data/outputs/{filename}"
        wb.save(filepath)
        messagebox.showinfo("Exported", f"Exported to {filename}")

    def _export_pdf(self, doc_type):
        """Export selected job to PDF"""
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a job to export.")
            return
        
        try:
            job_no_idx = self.visible_columns.index("job_no")
        except ValueError:
            messagebox.showerror("Error", "Job No column not visible")
            return
        
        job_no = self.tree.item(sel[0], "values")[job_no_idx]
        
        try:
            from pdf_export import export_job_documents
            
            if doc_type == 'all':
                files = export_job_documents(job_no)
            else:
                files = export_job_documents(job_no, [doc_type])
            
            if files:
                file_list = "\n".join([f"• {os.path.basename(f)}" for f in files])
                messagebox.showinfo("PDF Exported", f"Generated files:\n{file_list}")
            else:
                messagebox.showwarning("Warning", "No PDF files were generated.")
        except ImportError:
            messagebox.showerror("Error", "PDF export module not found. Please ensure pdf_export.py is available.")
        except Exception as e:
            messagebox.showerror("Error", f"PDF export failed: {e}")


class PerformanceFrame(ctk.CTkFrame):
    """Performance Dashboard with date range, revenue/cost/margin"""
    
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")

        # Title
        ctk.CTkLabel(self, text="PERFORMANCE DASHBOARD", font=("SF Pro Display", 22, "bold")).pack(anchor="w", padx=20, pady=(10, 5))

        # Filter section
        filter_frame = ctk.CTkFrame(self, fg_color="#F9FAFB", corner_radius=10)
        filter_frame.pack(fill="x", padx=20, pady=10)
        
        filter_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        filter_row.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(filter_row, text="Mode:").pack(side="left", padx=(0, 5))
        self.mode_var = tk.StringVar(value="")
        ttk.Combobox(filter_row, textvariable=self.mode_var, state="readonly", width=8, 
                    values=["", "OCEAN", "AIR", "LAND"]).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row, text="OP:").pack(side="left", padx=(15, 5))
        self.op_var = tk.StringVar(value="")
        ttk.Combobox(filter_row, textvariable=self.op_var, state="readonly", width=8, 
                    values=["", "EXPO", "IMPO"]).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row, text="Date:").pack(side="left", padx=(20, 5))
        self.date_from_var = tk.StringVar()
        ctk.CTkEntry(filter_row, textvariable=self.date_from_var, width=100, 
                    placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        ctk.CTkLabel(filter_row, text="~").pack(side="left", padx=5)
        self.date_to_var = tk.StringVar()
        ctk.CTkEntry(filter_row, textvariable=self.date_to_var, width=100, 
                    placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row, text="By:").pack(side="left", padx=(10, 5))
        self.date_type_var = tk.StringVar(value="Performance")
        ttk.Combobox(filter_row, textvariable=self.date_type_var, state="readonly", width=12, 
                    values=["Performance", "Invoice", "Slip"]).pack(side="left", padx=5)
        
        ctk.CTkButton(filter_row, text="🔍", width=40, command=self.load_data).pack(side="left", padx=(15, 5))
        ctk.CTkButton(filter_row, text="📊 Excel", width=80, fg_color="#217346", 
                     command=self._export_excel).pack(side="left", padx=5)

        # Summary cards
        summary = ctk.CTkFrame(self, fg_color="#FFFFFF")
        summary.pack(fill="x", padx=20, pady=15)

        self.ocean_lbl = self._card(summary, "🚢 OCEAN", "0", 0)
        self.air_lbl = self._card(summary, "✈️ AIR", "0", 1)
        self.land_lbl = self._card(summary, "🚚 LAND", "0", 2)
        self.total_lbl = self._card(summary, "📊 TOTAL", "0", 3)

        # Status breakdown with revenue/cost/margin
        status_frame = ctk.CTkFrame(self, fg_color="#F9FAFB", corner_radius=10)
        status_frame.pack(fill="both", expand=True, padx=20, pady=10)
        ctk.CTkLabel(status_frame, text="Status Breakdown", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        self.status_tree = ttk.Treeview(status_frame, 
                                        columns=["status", "ocean", "air", "land", "total", "revenue", "cost", "margin"], 
                                        show="headings", height=8)
        for c, w in [("STATUS", 100), ("OCEAN", 70), ("AIR", 70), ("LAND", 70), ("TOTAL", 70), 
                    ("REVENUE", 100), ("COST", 100), ("MARGIN", 100)]:
            self.status_tree.heading(c.lower(), text=c)
            self.status_tree.column(c.lower(), width=w, anchor="center")
        self.status_tree.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        ctk.CTkButton(self, text="🔄 Refresh", width=150, command=self.load_data).pack(pady=10)
        self.load_data()

    def _card(self, parent, title, value, col):
        card = ctk.CTkFrame(parent, fg_color="#F0F8FF", corner_radius=10, width=180, height=90)
        card.grid(row=0, column=col, padx=10, pady=10)
        card.grid_propagate(False)
        ctk.CTkLabel(card, text=title, font=("SF Pro Display", 11)).place(relx=0.5, rely=0.3, anchor="center")
        lbl = ctk.CTkLabel(card, text=value, font=("SF Pro Display", 26, "bold"))
        lbl.place(relx=0.5, rely=0.65, anchor="center")
        return lbl

    def load_data(self):
        mode = self.mode_var.get()
        op = self.op_var.get()
        date_from = self.date_from_var.get().strip()
        date_to = self.date_to_var.get().strip()
        date_type = self.date_type_var.get()  # Performance, Invoice, Slip
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Map date type to database column
            date_col_map = {
                "Performance": "created_at",  # Job creation date
                "Invoice": "etd",  # Use ETD as proxy for invoice date
                "Slip": "ata"  # Use ATA as proxy for slip/payment date
            }
            date_col = date_col_map.get(date_type, "created_at")
            
            # Build filter conditions
            conditions = []
            params = []
            
            if mode:
                conditions.append("mode = ?")
                params.append(mode)
            if op:
                if op == "EXPO":
                    conditions.append("pol LIKE '%MX%'")
                else:
                    conditions.append("pol NOT LIKE '%MX%'")
            if date_from:
                conditions.append(f"DATE({date_col}) >= ?")
                params.append(date_from)
            if date_to:
                conditions.append(f"DATE({date_col}) <= ?")
                params.append(date_to)
            
            where_clause = " AND ".join(conditions) if conditions else "1=1"
            
            # Count by mode
            cur.execute(f"SELECT mode, COUNT(*) FROM jobs WHERE {where_clause} GROUP BY mode", params)
            counts = dict(cur.fetchall())
            ocean = counts.get("OCEAN", 0)
            air = counts.get("AIR", 0)
            land = counts.get("LAND", 0)
            total = ocean + air + land
            
            self.ocean_lbl.configure(text=str(ocean))
            self.air_lbl.configure(text=str(air))
            self.land_lbl.configure(text=str(land))
            self.total_lbl.configure(text=str(total))

            # Status breakdown with revenue/cost/margin
            cur.execute(f"""
                SELECT status, 
                       SUM(CASE WHEN mode='OCEAN' THEN 1 ELSE 0 END) as ocean,
                       SUM(CASE WHEN mode='AIR' THEN 1 ELSE 0 END) as air,
                       SUM(CASE WHEN mode='LAND' THEN 1 ELSE 0 END) as land,
                       COUNT(*) as total,
                       0 as revenue,
                       0 as cost,
                       0 as margin
                FROM jobs 
                WHERE {where_clause}
                GROUP BY status
            """, params)
            
            for item in self.status_tree.get_children():
                self.status_tree.delete(item)
            
            for row in cur.fetchall():
                # Try to get revenue/cost from settlements
                status = row[0]
                try:
                    cur.execute(f"""
                        SELECT COALESCE(SUM(CASE WHEN t.type='REVENUE' THEN t.amount ELSE 0 END), 0),
                               COALESCE(SUM(CASE WHEN t.type='COST' THEN t.amount ELSE 0 END), 0)
                        FROM transactions t
                        JOIN jobs j ON t.job_id = j.id
                        WHERE j.status = ? AND {where_clause}
                    """, [status] + params)
                    fin = cur.fetchone()
                    revenue = fin[0] if fin else 0
                    cost = fin[1] if fin else 0
                    margin = revenue - cost
                except:
                    revenue, cost, margin = 0, 0, 0
                
                display_row = list(row[:5]) + [f"${revenue:,.2f}", f"${cost:,.2f}", f"${margin:,.2f}"]
                self.status_tree.insert("", "end", values=display_row)
                
        except Exception as e:
            print(f"Load error: {e}")
        finally:
            conn.close()

    def _export_excel(self):
        """Export performance data to Excel"""
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill
        except ImportError:
            messagebox.showwarning("Warning", "openpyxl not installed.")
            return
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Performance"
        
        # Summary
        ws["A1"] = "Performance Summary"
        ws["A1"].font = Font(bold=True, size=14)
        ws["A3"] = "OCEAN"
        ws["B3"] = self.ocean_lbl.cget("text")
        ws["A4"] = "AIR"
        ws["B4"] = self.air_lbl.cget("text")
        ws["A5"] = "LAND"
        ws["B5"] = self.land_lbl.cget("text")
        ws["A6"] = "TOTAL"
        ws["B6"] = self.total_lbl.cget("text")
        
        # Status breakdown
        ws["A8"] = "Status Breakdown"
        ws["A8"].font = Font(bold=True)
        headers = ["STATUS", "OCEAN", "AIR", "LAND", "TOTAL", "REVENUE", "COST", "MARGIN"]
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=9, column=col_idx, value=header)
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            cell.font = Font(bold=True, color="FFFFFF")
        
        for row_idx, item in enumerate(self.status_tree.get_children(), 10):
            values = self.status_tree.item(item, "values")
            for col_idx, val in enumerate(values, 1):
                ws.cell(row=row_idx, column=col_idx, value=val)
        
        filename = f"performance_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        filepath = f"/mnt/user-data/outputs/{filename}"
        wb.save(filepath)
        messagebox.showinfo("Exported", f"Exported to {filename}")
