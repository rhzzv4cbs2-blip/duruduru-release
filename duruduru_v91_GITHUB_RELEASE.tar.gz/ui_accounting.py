# ui_accounting.py
# Enhanced Accounting module with advanced filters, bank transfer, exchange rate
# v12: Integrated error handling and design system

import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog
import tkinter as tk
from datetime import datetime, timedelta
import calendar

# =============================================================================
# I18N IMPORT
# =============================================================================
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"

# =============================================================================
# IMPORTS WITH FALLBACKS
# =============================================================================

# Error handling
try:
    from error_handler import (
        logger, handle_errors, ErrorContext, 
        show_error_dialog, show_success_dialog,
        ErrorSeverity
    )
    HAS_ERROR_HANDLER = True
except ImportError:
    HAS_ERROR_HANDLER = False
    import logging
    logger = logging.getLogger(__name__)
    
    def show_error_dialog(msg, *args):
        messagebox.showerror("Error", msg)
    
    def show_success_dialog(msg, *args):
        messagebox.showinfo("Success", msg)

# Design system
try:
    from ui_design import COLORS, TYPOGRAPHY, SPACING
    HAS_DESIGN_SYSTEM = True
except ImportError:
    HAS_DESIGN_SYSTEM = False
    COLORS = None

# Database
from db import get_connection, now_str


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_date_range(period):
    """Get date range for period"""
    today = datetime.now()
    if period == "This Month":
        start = today.replace(day=1)
        end = today
    elif period == "Last Month":
        first = today.replace(day=1)
        last_month = first - timedelta(days=1)
        start = last_month.replace(day=1)
        end = last_month
    elif period == "This Year":
        start = today.replace(month=1, day=1)
        end = today
    elif period == "Last Year":
        start = today.replace(year=today.year-1, month=1, day=1)
        end = today.replace(year=today.year-1, month=12, day=31)
    else:  # All
        start = datetime(2020, 1, 1)
        end = today
    return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")


def create_bank_accounts_table():
    """Create bank accounts table if not exists"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS bank_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_name TEXT NOT NULL,
                bank_name TEXT,
                account_number TEXT,
                currency TEXT DEFAULT 'USD',
                balance REAL DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS bank_transfers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_account_id INTEGER,
                to_account_id INTEGER,
                amount REAL,
                currency TEXT,
                exchange_rate REAL DEFAULT 1.0,
                converted_amount REAL,
                category TEXT DEFAULT 'Internal Transfer',
                reference TEXT,
                description TEXT,
                fx_gain_loss REAL DEFAULT 0,
                transfer_date TEXT,
                created_at TEXT,
                FOREIGN KEY (from_account_id) REFERENCES bank_accounts(id),
                FOREIGN KEY (to_account_id) REFERENCES bank_accounts(id)
            )
        """)
        # New transactions table (실무용 입출금)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS bank_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trans_date TEXT,
                trans_type TEXT,
                account_id INTEGER,
                counterpart TEXT,
                category TEXT,
                amount REAL,
                currency TEXT,
                reference TEXT,
                description TEXT,
                balance_after REAL,
                created_at TEXT,
                FOREIGN KEY (account_id) REFERENCES bank_accounts(id)
            )
        """)
        # Add category column if not exists
        try:
            cur.execute("ALTER TABLE bank_transfers ADD COLUMN category TEXT DEFAULT 'Internal Transfer'")
        except:
            pass
        try:
            cur.execute("ALTER TABLE bank_transfers ADD COLUMN reference TEXT")
        except:
            pass
        try:
            cur.execute("ALTER TABLE bank_transfers ADD COLUMN fx_gain_loss REAL DEFAULT 0")
        except:
            pass
        # Note: exchange_rates table is created by db.py - do not create here
        conn.commit()
    except Exception as e:
        print(f"Bank table error: {e}")
    finally:
        conn.close()


# ============================================================
# INDEX SEARCH DIALOG
# ============================================================
class IndexSearchDialog(ctk.CTkToplevel):
    """Quick search by index (Invoice No, Job No, Customer)"""
    
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.title("🔍 Index Search")
        self.geometry("500x400")
        self.transient(parent)
        self.grab_set()
        self.callback = callback
        
        ctk.CTkLabel(self, text="Quick Search", font=("SF Pro Display", 16, "bold")).pack(pady=(15, 10))
        
        # Search type
        type_frame = ctk.CTkFrame(self, fg_color="transparent")
        type_frame.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(type_frame, text="Search By:").pack(side="left", padx=5)
        self.search_type = tk.StringVar(value="invoice_no")
        for val, txt in [("invoice_no", "Invoice No"), ("job_no", "Job No"), ("customer", "Customer")]:
            ctk.CTkRadioButton(type_frame, text=txt, variable=self.search_type, value=val).pack(side="left", padx=10)
        
        # Search input
        search_frame = ctk.CTkFrame(self, fg_color="transparent")
        search_frame.pack(fill="x", padx=20, pady=10)
        
        self.search_var = tk.StringVar()
        self.search_entry = ctk.CTkEntry(search_frame, textvariable=self.search_var, width=350, placeholder_text="Enter search term...")
        self.search_entry.pack(side="left", padx=5)
        ctk.CTkButton(search_frame, text="🔍", width=40, command=self._search).pack(side="left", padx=5)
        
        self.search_entry.bind("<Return>", lambda e: self._search())
        self.search_var.trace("w", lambda *args: self._search())
        
        # Results
        result_frame = ctk.CTkFrame(self, fg_color="#F9FAFB")
        result_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        cols = ["invoice_no", "job_no", "customer", "amount", "type", "status"]
        self.tree = ttk.Treeview(result_frame, columns=cols, show="headings", height=10)
        for c, h, w in zip(cols, ["INVOICE", "JOB NO", "CUSTOMER", "AMOUNT", "TYPE", "STATUS"], [100, 100, 150, 80, 70, 70]):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor="center")
        
        scrollbar = ttk.Scrollbar(result_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        self.tree.bind("<Double-1>", self._on_select)
        
        # Buttons
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(btn_frame, text="Select", width=80, command=self._on_select).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Close", width=80, fg_color="#E5E5EA", text_color="#333", command=self.destroy).pack(side="right", padx=5)
        
        self.search_entry.focus()
    
    def _search(self):
        search_term = self.search_var.get().strip()
        search_type = self.search_type.get()
        
        self.tree.delete(*self.tree.get_children())
        
        if not search_term:
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            if search_type == "invoice_no":
                cur.execute("""
                    SELECT s.invoice_no, j.job_no, s.customer, s.total, s.item_type, s.status
                    FROM settlement_items s
                    LEFT JOIN jobs j ON s.job_id = j.id
                    WHERE s.invoice_no LIKE ?
                    ORDER BY s.created_at DESC LIMIT 50
                """, (f"%{search_term}%",))
            elif search_type == "job_no":
                cur.execute("""
                    SELECT s.invoice_no, j.job_no, s.customer, s.total, s.item_type, s.status
                    FROM settlement_items s
                    LEFT JOIN jobs j ON s.job_id = j.id
                    WHERE j.job_no LIKE ?
                    ORDER BY s.created_at DESC LIMIT 50
                """, (f"%{search_term}%",))
            else:  # customer
                cur.execute("""
                    SELECT s.invoice_no, j.job_no, s.customer, s.total, s.item_type, s.status
                    FROM settlement_items s
                    LEFT JOIN jobs j ON s.job_id = j.id
                    WHERE s.customer LIKE ?
                    ORDER BY s.created_at DESC LIMIT 50
                """, (f"%{search_term}%",))
            
            for row in cur.fetchall():
                self.tree.insert("", "end", values=(
                    row[0] or "", row[1] or "", row[2] or "", 
                    f"${row[3]:,.2f}" if row[3] else "$0.00",
                    row[4] or "", row[5] or ""
                ))
        except Exception as e:
            print(f"Search error: {e}")
        finally:
            conn.close()
    
    def _on_select(self, event=None):
        sel = self.tree.selection()
        if sel:
            values = self.tree.item(sel[0], "values")
            self.callback(values)
            self.destroy()


# ============================================================
# EXCHANGE RATE DIALOG
# ============================================================
class ExchangeRateDialog(ctk.CTkToplevel):
    """Manage exchange rates - API only, no manual input"""
    
    def __init__(self, parent):
        super().__init__(parent)
        self.title("💱 Exchange Rates")
        self.geometry("650x600")
        self.transient(parent)
        self.grab_set()
        
        # Header
        header = ctk.CTkFrame(self, fg_color="#1565C0", corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(header, text="💱 Exchange Rate Management", font=("SF Pro Display", 18, "bold"),
                    text_color="white").pack(pady=15)
        
        # Current rate display (read-only)
        rate_frame = ctk.CTkFrame(self, fg_color="#E3F2FD", corner_radius=10)
        rate_frame.pack(fill="x", padx=20, pady=(15, 10))
        
        rate_inner = ctk.CTkFrame(rate_frame, fg_color="transparent")
        rate_inner.pack(pady=12)
        ctk.CTkLabel(rate_inner, text="Current Rate:", font=("SF Pro Display", 12)).pack(side="left", padx=10)
        self.rate_label = ctk.CTkLabel(rate_inner, text="Loading...", font=("SF Pro Display", 22, "bold"), text_color="#1565C0")
        self.rate_label.pack(side="left", padx=10)
        ctk.CTkLabel(rate_inner, text="MXN per 1 USD", font=("SF Pro Display", 11), text_color="#666").pack(side="left", padx=5)
        
        # Date Range Auto-Update (날짜 범위 자동 업데이트)
        range_frame = ctk.CTkFrame(self, fg_color="#E8F5E9", corner_radius=10)
        range_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(range_frame, text="📅 Date Range Update (날짜 범위 자동 업데이트)", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        range_row = ctk.CTkFrame(range_frame, fg_color="transparent")
        range_row.pack(fill="x", padx=15, pady=(0, 10))
        
        ctk.CTkLabel(range_row, text="From:", width=45).pack(side="left")
        self.from_date_var = tk.StringVar(value=(datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"))
        from_entry = ctk.CTkEntry(range_row, textvariable=self.from_date_var, width=110, height=30,
                                  placeholder_text="YYYY-MM-DD")
        from_entry.pack(side="left", padx=3)
        ctk.CTkButton(range_row, text="📅", width=28, height=28, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._pick_date(self.from_date_var)).pack(side="left", padx=2)
        
        ctk.CTkLabel(range_row, text="To:", width=30).pack(side="left", padx=(10, 0))
        self.to_date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        to_entry = ctk.CTkEntry(range_row, textvariable=self.to_date_var, width=110, height=30,
                               placeholder_text="YYYY-MM-DD")
        to_entry.pack(side="left", padx=3)
        ctk.CTkButton(range_row, text="📅", width=28, height=28, fg_color="#E5E5EA", text_color="#333",
                     command=lambda: self._pick_date(self.to_date_var)).pack(side="left", padx=2)
        
        ctk.CTkButton(range_row, text="🔄 Update Range", width=120, height=32, fg_color="#4CAF50",
                     hover_color="#388E3C", command=self._update_date_range).pack(side="left", padx=15)
        
        # Progress indicator
        self.range_status = ctk.CTkLabel(range_frame, text="", font=("SF Pro Display", 10), text_color="#666")
        self.range_status.pack(anchor="w", padx=15, pady=(0, 8))
        
        # API buttons
        api_frame = ctk.CTkFrame(self, fg_color="#FFF8E1", corner_radius=10)
        api_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(api_frame, text="🌐 Rate Management", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        api_btn_row = ctk.CTkFrame(api_frame, fg_color="transparent")
        api_btn_row.pack(fill="x", padx=15, pady=(0, 5))
        
        ctk.CTkButton(api_btn_row, text="📥 Fetch Today", width=120, height=32, fg_color="#FF9800",
                     hover_color="#F57C00", command=self._fetch_today_rate).pack(side="left", padx=3)
        ctk.CTkButton(api_btn_row, text="📅 Update Missing", width=130, height=32, fg_color="#2196F3",
                     hover_color="#1976D2", command=self._fetch_missing_rates).pack(side="left", padx=3)
        ctk.CTkButton(api_btn_row, text="🗑 Remove Duplicates", width=140, height=32, fg_color="#F44336",
                     hover_color="#D32F2F", command=self._remove_duplicates).pack(side="left", padx=3)
        
        self.api_status = ctk.CTkLabel(api_frame, text="", font=("SF Pro Display", 10), text_color="#666")
        self.api_status.pack(anchor="w", padx=15, pady=(0, 10))
        
        # Conversion calculator
        calc_frame = ctk.CTkFrame(self, fg_color="#F5F5F5", corner_radius=10)
        calc_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(calc_frame, text="💵 Quick Conversion", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        conv_row = ctk.CTkFrame(calc_frame, fg_color="transparent")
        conv_row.pack(fill="x", padx=15, pady=(5, 12))
        
        self.usd_var = tk.StringVar()
        ctk.CTkLabel(conv_row, text="USD:", width=40).pack(side="left")
        usd_entry = ctk.CTkEntry(conv_row, textvariable=self.usd_var, width=100, height=32)
        usd_entry.pack(side="left", padx=5)
        usd_entry.bind("<KeyRelease>", self._calc_usd_to_mxn)
        
        ctk.CTkLabel(conv_row, text="=", font=("SF Pro Display", 14, "bold")).pack(side="left", padx=8)
        self.mxn_result = ctk.CTkLabel(conv_row, text="$0.00 MXN", font=("SF Pro Display", 13, "bold"), text_color="#2E7D32")
        self.mxn_result.pack(side="left", padx=5)
        
        ctk.CTkLabel(conv_row, text="   |   MXN:", width=60).pack(side="left", padx=(20, 0))
        self.mxn_var = tk.StringVar()
        mxn_entry = ctk.CTkEntry(conv_row, textvariable=self.mxn_var, width=100, height=32)
        mxn_entry.pack(side="left", padx=5)
        mxn_entry.bind("<KeyRelease>", self._calc_mxn_to_usd)
        
        ctk.CTkLabel(conv_row, text="=", font=("SF Pro Display", 14, "bold")).pack(side="left", padx=8)
        self.usd_result = ctk.CTkLabel(conv_row, text="$0.00 USD", font=("SF Pro Display", 13, "bold"), text_color="#1565C0")
        self.usd_result.pack(side="left", padx=5)
        
        # History
        hist_frame = ctk.CTkFrame(self, fg_color="transparent")
        hist_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        hist_header = ctk.CTkFrame(hist_frame, fg_color="transparent")
        hist_header.pack(fill="x")
        ctk.CTkLabel(hist_header, text="📋 Rate History", font=("SF Pro Display", 12, "bold")).pack(side="left")
        self.count_label = ctk.CTkLabel(hist_header, text="", font=("SF Pro Display", 10), text_color="#666")
        self.count_label.pack(side="left", padx=10)
        ctk.CTkButton(hist_header, text="🔄", width=30, height=25, fg_color="#E5E5EA", text_color="#333",
                     command=self._load_history).pack(side="right")
        
        # Treeview with scrollbar
        tree_frame = ctk.CTkFrame(hist_frame, fg_color="transparent")
        tree_frame.pack(fill="both", expand=True, pady=5)
        
        cols = ["date", "rate", "source"]
        self.hist_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=10)
        self.hist_tree.heading("date", text="DATE")
        self.hist_tree.heading("rate", text="RATE")
        self.hist_tree.heading("source", text="SOURCE")
        self.hist_tree.column("date", width=120)
        self.hist_tree.column("rate", width=100)
        self.hist_tree.column("source", width=100)
        
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.hist_tree.yview)
        self.hist_tree.configure(yscrollcommand=vsb.set)
        
        self.hist_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        # Context menu for delete
        self.rate_context_menu = tk.Menu(self, tearoff=0)
        self.rate_context_menu.add_command(label="🗑 Delete Selected", command=self._delete_selected_rate)
        self.rate_context_menu.add_command(label="🗑 Delete All Rates", command=self._delete_all_rates)
        self.hist_tree.bind("<Button-2>", self._show_rate_context_menu)
        self.hist_tree.bind("<Button-3>", self._show_rate_context_menu)
        
        # Load initial data
        self._load_current_rate()
        self._load_history()
        
        self.current_rate = 20.50  # Default
    
    def _show_rate_context_menu(self, event):
        """Show context menu on right-click"""
        # Select item under cursor
        item = self.hist_tree.identify_row(event.y)
        if item:
            self.hist_tree.selection_set(item)
        self.rate_context_menu.tk_popup(event.x_root, event.y_root)
    
    def _delete_selected_rate(self):
        """Delete selected exchange rate"""
        selected = self.hist_tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a rate to delete.")
            return
        
        if not messagebox.askyesno("Confirm", "Delete selected exchange rate(s)?"):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            for item in selected:
                values = self.hist_tree.item(item, "values")
                rate_date = values[0]
                cur.execute("DELETE FROM exchange_rates WHERE rate_date = ? AND from_currency='USD' AND to_currency='MXN'", (rate_date,))
            conn.commit()
            self._load_history()
            self._load_current_rate()
            self.api_status.configure(text=f"✓ Deleted {len(selected)} rate(s)")
        except Exception as e:
            messagebox.showerror("Error", f"Delete failed: {e}")
        finally:
            conn.close()
    
    def _delete_all_rates(self):
        """Delete all exchange rates"""
        if not messagebox.askyesno("Confirm", "Delete ALL exchange rates?\n\nThis action cannot be undone."):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM exchange_rates WHERE from_currency='USD' AND to_currency='MXN'")
            deleted = cur.rowcount
            conn.commit()
            self._load_history()
            self._load_current_rate()
            self.api_status.configure(text=f"✓ Deleted all {deleted} rates")
            messagebox.showinfo("Success", f"Deleted {deleted} exchange rates.")
        except Exception as e:
            messagebox.showerror("Error", f"Delete failed: {e}")
        finally:
            conn.close()
    
    def _pick_date(self, var):
        """Simple date picker dialog"""
        top = ctk.CTkToplevel(self)
        top.title("📅 Select Date")
        top.geometry("280x150")
        top.transient(self)
        top.grab_set()
        
        # Position near pointer
        x = self.winfo_pointerx()
        y = self.winfo_pointery()
        top.geometry(f"280x150+{x+10}+{y+10}")
        
        ctk.CTkLabel(top, text="Enter Date (YYYY-MM-DD):", font=("SF Pro Display", 12)).pack(pady=(20, 10))
        entry = ctk.CTkEntry(top, width=180, height=32)
        entry.insert(0, var.get())
        entry.pack(pady=5)
        entry.focus_set()
        entry.select_range(0, tk.END)
        
        def apply():
            var.set(entry.get())
            top.destroy()
        
        entry.bind("<Return>", lambda e: apply())
        ctk.CTkButton(top, text="OK", width=100, height=35, command=apply).pack(pady=15)
    
    def _update_date_range(self):
        """Update exchange rates for date range using API"""
        from_date = self.from_date_var.get().strip()
        to_date = self.to_date_var.get().strip()
        
        # Validate dates
        try:
            from_dt = datetime.strptime(from_date, "%Y-%m-%d")
            to_dt = datetime.strptime(to_date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Use YYYY-MM-DD")
            return
        
        if from_dt > to_dt:
            messagebox.showwarning("Warning", "From date must be before To date.")
            return
        
        # Calculate number of days
        num_days = (to_dt - from_dt).days + 1
        
        if num_days > 365:
            messagebox.showwarning("Warning", "Date range too large. Maximum 365 days.")
            return
        
        # Confirm if many days
        if num_days > 30:
            if not messagebox.askyesno("Confirm", f"Update {num_days} days of exchange rates?\n\nThis may take a while."):
                return
        
        # Start update process
        self.range_status.configure(text=f"Updating {num_days} days...")
        self.update()
        
        try:
            from db import fetch_exchange_rate_for_date, save_exchange_rate
            
            success_count = 0
            skip_count = 0
            fail_count = 0
            saved_dates = []
            
            current_dt = from_dt
            while current_dt <= to_dt:
                date_str = current_dt.strftime("%Y-%m-%d")
                
                # Update status every 3 days
                if (current_dt - from_dt).days % 3 == 0:
                    self.range_status.configure(text=f"Processing {date_str}... ({success_count} saved)")
                    self.update()
                
                try:
                    # Fetch rate for this date
                    rate = fetch_exchange_rate_for_date(date_str)
                    
                    if rate and 15.0 <= rate <= 25.0:
                        # Save to database with source
                        save_exchange_rate(date_str, rate, "USD", "MXN", "API")
                        success_count += 1
                        saved_dates.append(f"{date_str}: {rate:.4f}")
                        print(f"✓ Saved: {date_str} = {rate:.4f}")  # Debug log
                    else:
                        skip_count += 1
                        print(f"⏭ Skip: {date_str} (rate={rate})")  # Debug log
                        
                except Exception as e:
                    fail_count += 1
                    print(f"✗ Fail: {date_str} - {e}")  # Debug log
                
                current_dt += timedelta(days=1)
            
            # Show results
            self.range_status.configure(text=f"✓ Done: {success_count} saved, {skip_count} skipped, {fail_count} failed")
            
            # Force reload history
            self.after(100, self._load_history)
            self.after(200, self._load_current_rate)
            
            # Show summary
            detail = "\n".join(saved_dates[:10])  # Show first 10
            if len(saved_dates) > 10:
                detail += f"\n... and {len(saved_dates) - 10} more"
            
            messagebox.showinfo("Update Complete", 
                f"Exchange rate update finished:\n\n"
                f"📥 Saved: {success_count} days\n"
                f"⏭ Skipped: {skip_count}\n"
                f"❌ Failed: {fail_count}\n\n"
                f"Recent saves:\n{detail if detail else '(none)'}")
            
        except Exception as e:
            self.range_status.configure(text=f"⚠ Error: {str(e)[:30]}...")
            messagebox.showerror("Error", f"Update failed: {e}")
    
    def _fetch_today_rate(self):
        """Fetch today's rate from API"""
        try:
            from db import fetch_exchange_rate_dof, save_exchange_rate, today_str
            self.api_status.configure(text="Fetching today's rate...")
            self.update()
            
            rate = fetch_exchange_rate_dof()
            if rate:
                today = today_str()
                save_exchange_rate(today, rate, "USD", "MXN", "API")
                self.current_rate = rate
                self.rate_label.configure(text=f"{rate:.4f}")
                self.api_status.configure(text=f"✓ Updated: {today} = {rate:.4f}")
                self._load_history()
            else:
                self.api_status.configure(text="⚠ API unavailable")
                messagebox.showwarning("Warning", "Could not fetch rate from API. Please try again later.")
        except Exception as e:
            self.api_status.configure(text="⚠ Error")
            messagebox.showerror("Error", f"Failed to fetch rate: {e}")
    
    def _fetch_missing_rates(self):
        """Fetch only missing dates from API"""
        try:
            from db import fetch_and_save_missing_rates, today_str
            self.api_status.configure(text="Checking missing dates...")
            self.update()
            
            result = fetch_and_save_missing_rates("2026-01-01", today_str())
            
            fetched = len(result.get("fetched", []))
            skipped = len(result.get("skipped", []))
            failed = len(result.get("failed", []))
            
            if fetched > 0:
                self.api_status.configure(text=f"✓ {fetched} dates added, {skipped} already existed")
                self._load_history()
                messagebox.showinfo("Success", 
                    f"Exchange rate update complete:\n\n"
                    f"• New dates added: {fetched}\n"
                    f"• Already existed (skipped): {skipped}\n"
                    f"• Failed: {failed}")
            else:
                self.api_status.configure(text=f"✓ All dates up to date ({skipped} exist)")
                messagebox.showinfo("Info", f"All dates from 2026-01-01 to today already have rates.\n\n{skipped} dates in database.")
                
        except Exception as e:
            self.api_status.configure(text="⚠ Error")
            messagebox.showerror("Error", f"Failed to update rates: {e}")
    
    def _load_current_rate(self):
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT rate FROM exchange_rates 
                WHERE from_currency='USD' AND to_currency='MXN' 
                ORDER BY rate_date DESC LIMIT 1
            """)
            row = cur.fetchone()
            if row:
                self.current_rate = row[0]
                self.rate_label.configure(text=f"{row[0]:.4f}")
            else:
                self.rate_label.configure(text="20.5000 (default)")
        except Exception as e:
            self.rate_label.configure(text="20.5000 (default)")
        finally:
            conn.close()
    
    def _load_history(self):
        self.hist_tree.delete(*self.hist_tree.get_children())
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Show all records, no limit
            cur.execute("""
                SELECT rate_date, rate, COALESCE(source, 'MANUAL') FROM exchange_rates 
                WHERE from_currency='USD' AND to_currency='MXN' 
                ORDER BY rate_date DESC
            """)
            rows = cur.fetchall()
            for row in rows:
                self.hist_tree.insert("", "end", values=row)
            
            # Update count label
            self.count_label.configure(text=f"({len(rows)} records)")
        except Exception as e:
            print(f"Load history error: {e}")
        finally:
            conn.close()
    
    def _remove_duplicates(self):
        """Remove duplicate exchange rate entries"""
        if not messagebox.askyesno("Confirm", "Remove duplicate exchange rate entries?\n\nThis will keep only the latest entry for each date."):
            return
        
        try:
            from db import delete_duplicate_exchange_rates
            self.api_status.configure(text="Removing duplicates...")
            self.update()
            
            deleted = delete_duplicate_exchange_rates()
            
            if deleted > 0:
                self.api_status.configure(text=f"✓ Removed {deleted} duplicates")
                self._load_history()
                messagebox.showinfo("Success", f"Removed {deleted} duplicate entries.")
            else:
                self.api_status.configure(text="✓ No duplicates found")
                messagebox.showinfo("Info", "No duplicate entries found.")
        except Exception as e:
            self.api_status.configure(text="⚠ Error")
            messagebox.showerror("Error", f"Failed to remove duplicates: {e}")
    
    def _calc_usd_to_mxn(self, event=None):
        try:
            usd = float(self.usd_var.get() or 0)
            mxn = usd * self.current_rate
            self.mxn_result.configure(text=f"${mxn:,.2f} MXN")
        except:
            self.mxn_result.configure(text="$0.00 MXN")
    
    def _calc_mxn_to_usd(self, event=None):
        try:
            mxn = float(self.mxn_var.get() or 0)
            usd = mxn / self.current_rate if self.current_rate else 0
            self.usd_result.configure(text=f"${usd:,.2f} USD")
        except:
            self.usd_result.configure(text="$0.00 USD")


# ============================================================
# TRANSACTION DIALOG (실무용 입출금)
# ============================================================
class TransactionDialog(ctk.CTkToplevel):
    """Bank transaction dialog - 입금/출금 기록"""
    
    CATEGORIES = ["Revenue", "Cost", "Admin Expense", "Tax Payment", "Loan", "Salary", "Utility", "Rent", "Other"]
    
    def __init__(self, parent, accounts, callback, edit_data=None):
        super().__init__(parent)
        self.title("💸 New Transaction" if not edit_data else "✏️ Edit Transaction")
        self.transient(parent)
        self.grab_set()
        self.all_accounts = accounts
        self.callback = callback
        self.edit_data = edit_data
        
        # Position near parent window
        self.update_idletasks()
        x = parent.winfo_rootx() + 50
        y = parent.winfo_rooty() + 50
        self.geometry(f"520x580+{x}+{y}")
        
        ctk.CTkLabel(self, text="💸 Transaction" if not edit_data else "✏️ Edit Transaction", 
                    font=("SF Pro Display", 20, "bold")).pack(pady=(20, 15))
        
        form = ctk.CTkFrame(self, fg_color="#F5F5F5", corner_radius=10)
        form.pack(fill="x", padx=25, pady=10)
        
        # Date
        row1 = ctk.CTkFrame(form, fg_color="transparent")
        row1.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row1, text="Date:", width=100, font=("SF Pro Display", 11, "bold")).pack(side="left")
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        date_entry = ctk.CTkEntry(row1, textvariable=self.date_var, width=120)
        date_entry.pack(side="left", padx=5)
        ctk.CTkButton(row1, text="📅", width=32, height=28, fg_color="#E5E5EA", text_color="#333",
                     command=self._show_date_picker).pack(side="left", padx=4)
        
        # Category
        row2 = ctk.CTkFrame(form, fg_color="transparent")
        row2.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row2, text="Category:", width=100, font=("SF Pro Display", 11, "bold")).pack(side="left")
        self.category_var = tk.StringVar(value="Cost")
        cat_combo = ttk.Combobox(row2, textvariable=self.category_var, width=20, state="readonly")
        cat_combo["values"] = self.CATEGORIES
        cat_combo.pack(side="left", padx=5)
        
        # Currency Toggle
        curr_frame = ctk.CTkFrame(form, fg_color="#E3F2FD", corner_radius=8)
        curr_frame.pack(fill="x", padx=15, pady=10)
        
        curr_row = ctk.CTkFrame(curr_frame, fg_color="transparent")
        curr_row.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(curr_row, text="💱 Currency:", font=("SF Pro Display", 11, "bold")).pack(side="left")
        
        self.currency_var = tk.StringVar(value="USD")
        self.usd_btn = ctk.CTkButton(curr_row, text="USD", width=70, height=30, 
                                     fg_color="#1565C0", font=("SF Pro Display", 12, "bold"),
                                     command=lambda: self._set_currency("USD"))
        self.usd_btn.pack(side="left", padx=(15, 0))
        
        self.mxn_btn = ctk.CTkButton(curr_row, text="MXN", width=70, height=30,
                                     fg_color="#E0E0E0", text_color="#333",
                                     font=("SF Pro Display", 12, "bold"),
                                     command=lambda: self._set_currency("MXN"))
        self.mxn_btn.pack(side="left", padx=(5, 0))
        
        # Transaction Type (입금/출금)
        type_frame = ctk.CTkFrame(form, fg_color="#FFF8E1", corner_radius=8)
        type_frame.pack(fill="x", padx=15, pady=10)
        
        type_row = ctk.CTkFrame(type_frame, fg_color="transparent")
        type_row.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(type_row, text="Type:", width=80, font=("SF Pro Display", 11, "bold")).pack(side="left")
        
        self.type_var = tk.StringVar(value="OUT")
        self.out_btn = ctk.CTkButton(type_row, text="🔴 출금 Withdrawal", width=140, height=32,
                                     fg_color="#DC2626", font=("SF Pro Display", 11, "bold"),
                                     command=lambda: self._set_type("OUT"))
        self.out_btn.pack(side="left", padx=(10, 5))
        
        self.in_btn = ctk.CTkButton(type_row, text="🟢 입금 Deposit", width=140, height=32,
                                    fg_color="#E0E0E0", text_color="#333",
                                    font=("SF Pro Display", 11, "bold"),
                                    command=lambda: self._set_type("IN"))
        self.in_btn.pack(side="left", padx=5)
        
        # Account (우리 계좌)
        row3 = ctk.CTkFrame(form, fg_color="transparent")
        row3.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row3, text="Account:", width=100).pack(side="left")
        self.account_var = tk.StringVar()
        self.account_combo = ttk.Combobox(row3, textvariable=self.account_var, width=28, state="readonly")
        self.account_combo.pack(side="left", padx=5)
        self.account_combo.bind("<<ComboboxSelected>>", self._on_account_select)
        ctk.CTkButton(row3, text="🔍", width=32, height=28, fg_color="#E5E5EA", text_color="#333",
                     command=self._search_account).pack(side="left", padx=3)
        
        # Counterpart (상대방) - 자동 채움
        row4 = ctk.CTkFrame(form, fg_color="transparent")
        row4.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row4, text="Counterpart:", width=100).pack(side="left")
        self.counterpart_var = tk.StringVar()
        self.counterpart_entry = ctk.CTkEntry(row4, textvariable=self.counterpart_var, width=250, 
                    placeholder_text="Auto-filled from account")
        self.counterpart_entry.pack(side="left", padx=5)
        ctk.CTkLabel(row4, text="(자동입력)", text_color="#059669", font=("SF Pro Display", 9)).pack(side="left", padx=3)
        
        # Amount
        row5 = ctk.CTkFrame(form, fg_color="transparent")
        row5.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row5, text="Amount:", width=100).pack(side="left")
        self.amount_var = tk.StringVar()
        ctk.CTkEntry(row5, textvariable=self.amount_var, width=150, placeholder_text="0.00").pack(side="left", padx=5)
        self.curr_label = ctk.CTkLabel(row5, text="USD", font=("SF Pro Display", 12, "bold"), text_color="#1565C0")
        self.curr_label.pack(side="left", padx=5)
        
        # Reference
        row6 = ctk.CTkFrame(form, fg_color="transparent")
        row6.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row6, text="Reference:", width=100).pack(side="left")
        self.ref_var = tk.StringVar()
        ctk.CTkEntry(row6, textvariable=self.ref_var, width=200, placeholder_text="Invoice/Job No").pack(side="left", padx=5)
        
        # Description
        row7 = ctk.CTkFrame(form, fg_color="transparent")
        row7.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(row7, text="Description:", width=100).pack(side="left")
        self.desc_var = tk.StringVar()
        ctk.CTkEntry(row7, textvariable=self.desc_var, width=280, placeholder_text="Transaction memo").pack(side="left", padx=5)
        
        # Buttons
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=25, pady=20)
        ctk.CTkButton(btn_frame, text="💾 Save", width=100, height=40, fg_color="#059669", 
                     font=("SF Pro Display", 13, "bold"), command=self._save).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, height=40, fg_color="#9E9E9E",
                     command=self.destroy).pack(side="right", padx=5)
        
        # Initialize
        self._update_account_list()
        
        # Load edit data if editing
        if edit_data:
            self._load_edit_data()
    
    def _set_currency(self, currency):
        self.currency_var.set(currency)
        if currency == "USD":
            self.usd_btn.configure(fg_color="#1565C0", text_color="white")
            self.mxn_btn.configure(fg_color="#E0E0E0", text_color="#333")
            self.curr_label.configure(text="USD", text_color="#1565C0")
        else:
            self.usd_btn.configure(fg_color="#E0E0E0", text_color="#333")
            self.mxn_btn.configure(fg_color="#2E7D32", text_color="white")
            self.curr_label.configure(text="MXN", text_color="#2E7D32")
        self._update_account_list()
    
    def _set_type(self, trans_type):
        self.type_var.set(trans_type)
        if trans_type == "OUT":
            self.out_btn.configure(fg_color="#DC2626", text_color="white")
            self.in_btn.configure(fg_color="#E0E0E0", text_color="#333")
        else:
            self.out_btn.configure(fg_color="#E0E0E0", text_color="#333")
            self.in_btn.configure(fg_color="#059669", text_color="white")
    
    def _update_account_list(self):
        currency = self.currency_var.get()
        filtered = [a for a in self.all_accounts if a[4] == currency]
        account_list = [f"{a[0]} - {a[1]} [{a[5]:,.0f}]" for a in filtered]
        self.account_combo["values"] = account_list
        self.account_var.set("")
    
    def _on_account_select(self, event=None):
        """Auto-fill counterpart with bank name when account is selected"""
        account_sel = self.account_var.get()
        if not account_sel:
            return
        
        try:
            account_id = int(account_sel.split(" - ")[0])
            # Find account and get bank name
            for a in self.all_accounts:
                if a[0] == account_id:
                    bank_name = a[2] or ""  # bank_name is at index 2
                    if bank_name and not self.counterpart_var.get():
                        self.counterpart_var.set(bank_name)
                    break
        except:
            pass
    
    def _search_account(self):
        currency = self.currency_var.get()
        filtered = [a for a in self.all_accounts if a[4] == currency]
        
        dlg = ctk.CTkToplevel(self)
        dlg.title(f"🔍 Search Account ({currency})")
        dlg.transient(self)
        dlg.grab_set()
        
        x = self.winfo_pointerx()
        y = self.winfo_pointery()
        dlg.geometry(f"400x350+{x+10}+{y-150}")
        
        search_var = tk.StringVar()
        ctk.CTkEntry(dlg, textvariable=search_var, width=350, placeholder_text="Search...").pack(padx=15, pady=15)
        
        listbox = tk.Listbox(dlg, font=("SF Pro Display", 11), height=10)
        listbox.pack(fill="both", expand=True, padx=15, pady=(0, 10))
        
        def load_list(filter_text=""):
            listbox.delete(0, tk.END)
            for a in filtered:
                if filter_text.lower() in (a[1] or "").lower():
                    listbox.insert(tk.END, f"{a[0]} - {a[1]} [{a[5]:,.0f}]")
        
        search_var.trace("w", lambda *args: load_list(search_var.get()))
        load_list()
        
        def select():
            sel = listbox.curselection()
            if sel:
                selected_text = listbox.get(sel[0])
                self.account_var.set(selected_text)
                # Auto-fill counterpart
                try:
                    account_id = int(selected_text.split(" - ")[0])
                    for a in filtered:
                        if a[0] == account_id:
                            bank_name = a[2] or ""
                            if bank_name and not self.counterpart_var.get():
                                self.counterpart_var.set(bank_name)
                            break
                except:
                    pass
                dlg.destroy()
        
        listbox.bind("<Double-1>", lambda e: select())
        ctk.CTkButton(dlg, text="Select", width=80, command=select).pack(pady=10)
    
    def _show_date_picker(self):
        top = ctk.CTkToplevel(self)
        top.title("📅 Select Date")
        top.transient(self)
        top.grab_set()
        
        x = self.winfo_pointerx()
        y = self.winfo_pointery()
        top.geometry(f"280x150+{x+10}+{y+10}")
        
        ctk.CTkLabel(top, text="Enter Date (YYYY-MM-DD):", font=("SF Pro Display", 12)).pack(pady=(20, 10))
        date_entry = ctk.CTkEntry(top, width=180)
        date_entry.insert(0, self.date_var.get())
        date_entry.pack(pady=5)
        date_entry.focus_set()
        
        def apply():
            self.date_var.set(date_entry.get())
            top.destroy()
        
        date_entry.bind("<Return>", lambda e: apply())
        ctk.CTkButton(top, text="OK", width=100, height=35, command=apply).pack(pady=15)
    
    def _load_edit_data(self):
        if self.edit_data:
            ed = self.edit_data
            self.date_var.set(ed.get('date', ''))
            self.category_var.set(ed.get('category', 'Cost'))
            self._set_currency(ed.get('currency', 'USD'))
            self._set_type(ed.get('type', 'OUT'))
            self.counterpart_var.set(ed.get('counterpart', ''))
            self.amount_var.set(str(ed.get('amount', '')))
            self.ref_var.set(ed.get('reference', ''))
            self.desc_var.set(ed.get('description', ''))
            
            # Set account
            for a in self.all_accounts:
                if a[0] == ed.get('account_id'):
                    self.account_var.set(f"{a[0]} - {a[1]} [{a[5]:,.0f}]")
                    break
    
    def _save(self):
        try:
            account_sel = self.account_var.get()
            if not account_sel:
                messagebox.showwarning("Warning", "Please select an account.")
                return
            
            amount = float(self.amount_var.get() or 0)
            if amount <= 0:
                messagebox.showwarning("Warning", "Please enter a valid amount.")
                return
            
            account_id = int(account_sel.split(" - ")[0])
            
            data = {
                'id': self.edit_data.get('id') if self.edit_data else None,
                'date': self.date_var.get().strip(),
                'type': self.type_var.get(),
                'account_id': account_id,
                'counterpart': self.counterpart_var.get().strip(),
                'category': self.category_var.get(),
                'amount': amount,
                'currency': self.currency_var.get(),
                'reference': self.ref_var.get().strip(),
                'description': self.desc_var.get().strip()
            }
            
            self.callback(data)
            self.destroy()
            
        except ValueError:
            messagebox.showerror("Error", "Invalid amount.")
        except Exception as e:
            messagebox.showerror("Error", f"Save failed: {e}")


# ============================================================
# MAIN ACCOUNTING FRAME
# ============================================================
class AccountingFrame(ctk.CTkFrame):
    """Main Accounting Dashboard with enhanced filters and features"""

    def __init__(self, master, width=1200, height=800):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)
        
        create_bank_accounts_table()
        
        # Get font for current language
        font_family = get_font_family()

        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")

        # Title bar
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(10, 5))
        ctk.CTkLabel(title_frame, text=_t("acct.title").upper(), font=(font_family, 22, "bold")).pack(side="left")

        # Quick actions
        actions = ctk.CTkFrame(title_frame, fg_color="transparent")
        actions.pack(side="right")
        ctk.CTkButton(actions, text=f"🔍 {_t('btn.search')}", width=80, fg_color="#E5E5EA", text_color="#333",
                     command=self._open_index_search).pack(side="left", padx=3)
        ctk.CTkButton(actions, text=f"💱 {_t('rate.current').replace(':', '')}", width=70, fg_color="#E5E5EA", text_color="#333",
                     command=self._open_exchange_rate).pack(side="left", padx=3)
        ctk.CTkButton(actions, text="🔄", width=40, command=self._refresh_data).pack(side="left", padx=3)

        # Advanced Filter Section
        filter_frame = ctk.CTkFrame(self, fg_color="#F9FAFB", corner_radius=10)
        filter_frame.pack(fill="x", padx=20, pady=10)
        
        # Filter row 1: Date type, Date range
        filter_row1 = ctk.CTkFrame(filter_frame, fg_color="transparent")
        filter_row1.pack(fill="x", padx=15, pady=8)
        
        ctk.CTkLabel(filter_row1, text=_t("acct.date_type"), font=(font_family, 12)).pack(side="left", padx=(0, 5))
        self.date_type_var = tk.StringVar(value="invoice")
        ttk.Combobox(filter_row1, textvariable=self.date_type_var, values=["invoice", "operation"], 
                    state="readonly", width=10).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row1, text=_t("ui.from"), font=(font_family, 12)).pack(side="left", padx=(20, 5))
        self.date_from_var = tk.StringVar()
        ctk.CTkEntry(filter_row1, textvariable=self.date_from_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row1, text=_t("ui.to"), font=(font_family, 12)).pack(side="left", padx=(10, 5))
        self.date_to_var = tk.StringVar()
        ctk.CTkEntry(filter_row1, textvariable=self.date_to_var, width=100, placeholder_text="YYYY-MM-DD").pack(side="left", padx=5)
        
        # Filter row 2: Company, MODE, OP
        filter_row2 = ctk.CTkFrame(filter_frame, fg_color="transparent")
        filter_row2.pack(fill="x", padx=15, pady=8)
        
        ctk.CTkLabel(filter_row2, text=_t("ui.company"), font=(font_family, 12)).pack(side="left", padx=(0, 5))
        self.company_var = tk.StringVar()
        ctk.CTkEntry(filter_row2, textvariable=self.company_var, width=150, placeholder_text=_t("ui.customer") + "/" + _t("ui.vendor")).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row2, text=_t("ui.mode") + ":", font=(font_family, 12)).pack(side="left", padx=(20, 5))
        self.mode_var = tk.StringVar(value="")
        ttk.Combobox(filter_row2, textvariable=self.mode_var, values=["", "OCEAN", "AIR", "LAND"], 
                    state="readonly", width=8).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row2, text="OP:", font=(font_family, 12)).pack(side="left", padx=(10, 5))
        self.op_var = tk.StringVar(value="")
        ttk.Combobox(filter_row2, textvariable=self.op_var, values=["", "EXPO", "IMPO"], 
                    state="readonly", width=8).pack(side="left", padx=5)
        
        ctk.CTkLabel(filter_row2, text=_t("ui.type") + ":", font=(font_family, 12)).pack(side="left", padx=(10, 5))
        self.type_var = tk.StringVar(value="")
        ttk.Combobox(filter_row2, textvariable=self.type_var, values=["", "REVENUE", "COST"], 
                    state="readonly", width=10).pack(side="left", padx=5)
        
        ctk.CTkButton(filter_row2, text=f"🔍 {_t('btn.search')}", width=80, command=self._refresh_data).pack(side="left", padx=15)
        ctk.CTkButton(filter_row2, text=_t("btn.clear"), width=60, fg_color="#E5E5EA", text_color="#333",
                     command=self._clear_filters).pack(side="left", padx=5)

        # Summary cards
        cards_frame = ctk.CTkFrame(self, fg_color="transparent")
        cards_frame.pack(fill="x", padx=20, pady=10)

        self.revenue_card = self._create_card(cards_frame, f"💰 {_t('acct.revenue')}", "$0.00", "#4CAF50")
        self.revenue_card.pack(side="left", padx=8, expand=True, fill="x")

        self.cost_card = self._create_card(cards_frame, f"📦 {_t('acct.expense')}", "$0.00", "#FF9800")
        self.cost_card.pack(side="left", padx=8, expand=True, fill="x")

        self.profit_card = self._create_card(cards_frame, f"📈 {_t('acct.profit')}", "$0.00", "#2196F3")
        self.profit_card.pack(side="left", padx=8, expand=True, fill="x")

        self.receivable_card = self._create_card(cards_frame, f"📥 {_t('acct.ar')}", "$0.00", "#9C27B0")
        self.receivable_card.pack(side="left", padx=8, expand=True, fill="x")

        self.payable_card = self._create_card(cards_frame, f"📤 {_t('acct.ap')}", "$0.00", "#F44336")
        self.payable_card.pack(side="left", padx=8, expand=True, fill="x")

        # Tab view
        self.tabview = ctk.CTkTabview(self, fg_color="#F5F5F5")
        self.tabview.pack(fill="both", expand=True, padx=20, pady=10)

        # Tab names - store for reference
        self.TAB_JOURNAL = "Journal"
        self.TAB_CASHFLOW = "Cash Flow"
        self.TAB_SLIP = "Slip Processing"
        self.TAB_AGING = "Aging Report"
        self.TAB_PL = "📊 Monthly Closing"

        # Tabs
        self.tabview.add(self.TAB_JOURNAL)
        self.tabview.add(self.TAB_CASHFLOW)
        self.tabview.add(self.TAB_SLIP)
        self.tabview.add(self.TAB_AGING)
        self.tabview.add(self.TAB_PL)

        self._setup_journal_tab()
        self._setup_cashflow_tab()
        self._setup_slip_tab()
        self._setup_aging_tab()
        self._setup_monthly_closing_tab()

        # Initialize with current month
        today = datetime.now()
        self.date_from_var.set(today.replace(day=1).strftime("%Y-%m-%d"))
        self.date_to_var.set(today.strftime("%Y-%m-%d"))
        self._refresh_data()

    def _create_card(self, parent, title, amount, color):
        font_family = get_font_family()
        card = ctk.CTkFrame(parent, fg_color=color, corner_radius=12)
        ctk.CTkLabel(card, text=title, text_color="#FFFFFF", font=(font_family, 10)).pack(pady=(10, 2))
        lbl = ctk.CTkLabel(card, text=amount, text_color="#FFFFFF", font=(font_family, 14, "bold"))
        lbl.pack(pady=(2, 10))
        card._amount_label = lbl
        return card

    def _clear_filters(self):
        self.company_var.set("")
        self.mode_var.set("")
        self.op_var.set("")
        self.type_var.set("")
        self._refresh_data()

    def _open_index_search(self):
        def on_select(values):
            # Could navigate to the selected item
            messagebox.showinfo("Selected", f"Invoice: {values[0]}\nJob: {values[1]}\nCustomer: {values[2]}")
        IndexSearchDialog(self, on_select)

    def _open_exchange_rate(self):
        ExchangeRateDialog(self)

    def _setup_journal_tab(self):
        """Journal entries tab"""
        tab = self.tabview.tab(self.TAB_JOURNAL)

        # Toolbar
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", pady=10)
        
        ctk.CTkButton(toolbar, text="+ New Entry", width=100, command=self._add_journal_entry).pack(side="left", padx=5)
        ctk.CTkButton(toolbar, text="📥 Export", width=80, fg_color="#6C757D", command=lambda: self._export("journal")).pack(side="right", padx=5)

        # Table
        cols = ["id", "date", "job_no", "account", "description", "debit", "credit", "currency"]
        self.journal_tree = ttk.Treeview(tab, columns=cols, show="headings", height=15)
        
        headers = ["#", "DATE", "JOB NO", "ACCOUNT", "DESCRIPTION", "DEBIT", "CREDIT", "CUR"]
        widths = [40, 90, 100, 120, 180, 90, 90, 50]
        
        for c, h, w in zip(cols, headers, widths):
            self.journal_tree.heading(c, text=h)
            self.journal_tree.column(c, width=w, anchor="center" if c != "description" else "w")

        vsb = ttk.Scrollbar(tab, orient="vertical", command=self.journal_tree.yview)
        self.journal_tree.configure(yscrollcommand=vsb.set)
        self.journal_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    def _setup_ar_tab(self):
        """Accounts Receivable tab"""
        tab = self.tabview.tab("A/R (Receivable)")

        # Summary
        summary = ctk.CTkFrame(tab, fg_color="#E8F5E9", corner_radius=10)
        summary.pack(fill="x", pady=10)
        
        ctk.CTkLabel(summary, text="Total Outstanding:", font=("SF Pro Display", 12)).pack(side="left", padx=20, pady=10)
        self.ar_total_label = ctk.CTkLabel(summary, text="$0.00", font=("SF Pro Display", 16, "bold"), text_color="#2E7D32")
        self.ar_total_label.pack(side="left", padx=10, pady=10)
        
        ctk.CTkButton(summary, text="📥 Export", width=80, fg_color="#6C757D", command=lambda: self._export("ar")).pack(side="right", padx=10, pady=10)

        # Table
        cols = ["job_no", "customer", "invoice_no", "amount", "paid", "balance", "due_date", "status", "days"]
        self.ar_tree = ttk.Treeview(tab, columns=cols, show="headings", height=12)
        
        headers = ["JOB NO", "CUSTOMER", "INVOICE", "AMOUNT", "PAID", "BALANCE", "DUE DATE", "STATUS", "DAYS"]
        widths = [90, 150, 100, 90, 80, 90, 90, 80, 50]
        
        for c, h, w in zip(cols, headers, widths):
            self.ar_tree.heading(c, text=h)
            self.ar_tree.column(c, width=w, anchor="center")

        self.ar_tree.pack(fill="both", expand=True, pady=10)

    def _setup_ap_tab(self):
        """Accounts Payable tab"""
        tab = self.tabview.tab("A/P (Payable)")

        # Summary
        summary = ctk.CTkFrame(tab, fg_color="#FFEBEE", corner_radius=10)
        summary.pack(fill="x", pady=10)
        
        ctk.CTkLabel(summary, text="Total Outstanding:", font=("SF Pro Display", 12)).pack(side="left", padx=20, pady=10)
        self.ap_total_label = ctk.CTkLabel(summary, text="$0.00", font=("SF Pro Display", 16, "bold"), text_color="#C62828")
        self.ap_total_label.pack(side="left", padx=10, pady=10)
        
        ctk.CTkButton(summary, text="📥 Export", width=80, fg_color="#6C757D", command=lambda: self._export("ap")).pack(side="right", padx=10, pady=10)

        # Table
        cols = ["job_no", "vendor", "invoice_no", "amount", "paid", "balance", "due_date", "status", "days"]
        self.ap_tree = ttk.Treeview(tab, columns=cols, show="headings", height=12)
        
        headers = ["JOB NO", "VENDOR", "INVOICE", "AMOUNT", "PAID", "BALANCE", "DUE DATE", "STATUS", "DAYS"]
        widths = [90, 150, 100, 90, 80, 90, 90, 80, 50]
        
        for c, h, w in zip(cols, headers, widths):
            self.ap_tree.heading(c, text=h)
            self.ap_tree.column(c, width=w, anchor="center")

        self.ap_tree.pack(fill="both", expand=True, pady=10)

    def _setup_cashflow_tab(self):
        """Cash Flow tab - Transfer History as main view"""
        tab = self.tabview.tab(self.TAB_CASHFLOW)
        
        # Top toolbar
        toolbar = ctk.CTkFrame(tab, fg_color="#FAFAFA", corner_radius=8, height=50)
        toolbar.pack(fill="x", pady=(10, 5), padx=10)
        toolbar.pack_propagate(False)
        
        ctk.CTkLabel(toolbar, text="💱 Transfer History", font=("SF Pro Display", 16, "bold")).pack(side="left", padx=15)
        
        # Buttons - right side
        ctk.CTkButton(toolbar, text="🏦 Manage Accounts", width=130, height=32, fg_color="#374151", 
                     hover_color="#1F2937", command=self._open_account_manager).pack(side="right", padx=10, pady=9)
        ctk.CTkButton(toolbar, text="💸 New Transaction", width=130, height=32, fg_color="#059669", 
                     hover_color="#047857", command=self._open_transaction).pack(side="right", padx=5, pady=9)
        ctk.CTkButton(toolbar, text="✏️ Edit", width=70, height=32, fg_color="#2563EB", 
                     hover_color="#1D4ED8", command=self._edit_transaction).pack(side="right", padx=5, pady=9)
        ctk.CTkButton(toolbar, text="🗑️ Delete", width=70, height=32, fg_color="#DC2626", 
                     hover_color="#B91C1C", command=self._delete_transaction).pack(side="right", padx=5, pady=9)
        
        # Category filter
        filter_frame = ctk.CTkFrame(tab, fg_color="transparent")
        filter_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(filter_frame, text="Filter:").pack(side="left", padx=(5, 10))
        self.trans_cat_var = tk.StringVar(value="All")
        cat_combo = ttk.Combobox(filter_frame, textvariable=self.trans_cat_var, 
                    values=["All", "Revenue", "Cost", "Admin Expense", "Tax Payment", "Salary", "Utility", "Rent", "Loan", "Other"],
                    state="readonly", width=15)
        cat_combo.pack(side="left", padx=5)
        cat_combo.bind("<<ComboboxSelected>>", lambda e: self._load_transactions())
        
        ctk.CTkLabel(filter_frame, text="Type:").pack(side="left", padx=(15, 5))
        self.trans_type_var = tk.StringVar(value="All")
        ttk.Combobox(filter_frame, textvariable=self.trans_type_var, 
                    values=["All", "입금 IN", "출금 OUT"],
                    state="readonly", width=10).pack(side="left", padx=5)
        
        ctk.CTkButton(filter_frame, text="🔍 Search", width=80, height=28, 
                     fg_color="#374151", command=self._load_transactions).pack(side="left", padx=15)
        ctk.CTkButton(filter_frame, text="📥 Export", width=70, height=28, 
                     fg_color="#D97706", hover_color="#B45309", command=lambda: self._export("transaction")).pack(side="right", padx=10)
        
        # Transaction history table
        table_frame = ctk.CTkFrame(tab, fg_color="#FFFFFF", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        cols = ["id", "date", "type", "account", "counterpart", "category", "amount", "balance", "description"]
        self.trans_tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=12)
        for c, h, w in zip(cols, ["#", "DATE", "TYPE", "ACCOUNT", "COUNTERPART", "CATEGORY", "AMOUNT", "BALANCE", "DESCRIPTION"],
                         [0, 85, 60, 120, 130, 100, 100, 100, 180]):
            self.trans_tree.heading(c, text=h)
            self.trans_tree.column(c, width=w, anchor="center" if c in ["type", "amount", "balance"] else "w")
        
        # Hide ID column
        self.trans_tree.column("id", width=0, stretch=False)
        
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.trans_tree.yview)
        self.trans_tree.configure(yscrollcommand=vsb.set)
        self.trans_tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y", pady=10, padx=(0, 5))
        
        # Double-click to edit
        self.trans_tree.bind("<Double-1>", lambda e: self._edit_transaction())
        
        # Summary footer
        summary_frame = ctk.CTkFrame(tab, fg_color="#F8F5F2", corner_radius=8, height=60)
        summary_frame.pack(fill="x", padx=10, pady=(5, 10))
        summary_frame.pack_propagate(False)
        
        # Currency balance display
        cards_inner = ctk.CTkFrame(summary_frame, fg_color="transparent")
        cards_inner.pack(expand=True)
        
        ctk.CTkLabel(cards_inner, text="💰 Account Balances:", 
                    font=("SF Pro Display", 12, "bold")).pack(side="left", padx=(20, 30))
        
        # USD Balance
        usd_frame = ctk.CTkFrame(cards_inner, fg_color="#E3F2FD", corner_radius=8)
        usd_frame.pack(side="left", padx=15)
        ctk.CTkLabel(usd_frame, text="USD", font=("SF Pro Display", 11, "bold"), 
                    text_color="#1565C0").pack(side="left", padx=(15, 5), pady=8)
        self.usd_balance_label = ctk.CTkLabel(usd_frame, text="$0.00", 
                                              font=("SF Pro Display", 14, "bold"), text_color="#1565C0")
        self.usd_balance_label.pack(side="left", padx=(5, 15), pady=8)
        
        # MXN Balance
        mxn_frame = ctk.CTkFrame(cards_inner, fg_color="#E8F5E9", corner_radius=8)
        mxn_frame.pack(side="left", padx=15)
        ctk.CTkLabel(mxn_frame, text="MXN", font=("SF Pro Display", 11, "bold"), 
                    text_color="#2E7D32").pack(side="left", padx=(15, 5), pady=8)
        self.mxn_balance_label = ctk.CTkLabel(mxn_frame, text="$0.00", 
                                              font=("SF Pro Display", 14, "bold"), text_color="#2E7D32")
        self.mxn_balance_label.pack(side="left", padx=(5, 15), pady=8)
        
        # Hidden bank_tree for compatibility (used by _load_cashflow)
        self.bank_tree = None  # Will be created in account manager
    
    def _open_account_manager(self):
        """Open bank account management window"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("🏦 Bank Account Management")
        dialog.geometry("700x500")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        # Header
        header = ctk.CTkFrame(dialog, fg_color="#374151", height=50, corner_radius=0)
        header.pack(fill="x")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="Bank Accounts", font=("SF Pro Display", 18, "bold"), 
                    text_color="white").pack(side="left", padx=20, pady=10)
        
        # Toolbar
        toolbar = ctk.CTkFrame(dialog, fg_color="#F8F5F2", height=45)
        toolbar.pack(fill="x", padx=15, pady=10)
        toolbar.pack_propagate(False)
        
        ctk.CTkButton(toolbar, text="➕ Add Account", width=110, height=30, fg_color="#059669",
                     command=lambda: self._add_bank_account_dialog(dialog, tree)).pack(side="left", padx=10, pady=7)
        ctk.CTkButton(toolbar, text="✏️ Edit", width=70, height=30, fg_color="#374151",
                     command=lambda: self._edit_selected_account(dialog, tree)).pack(side="left", padx=5, pady=7)
        ctk.CTkButton(toolbar, text="🗑️ Delete", width=70, height=30, fg_color="#DC2626",
                     command=lambda: self._delete_selected_account(tree)).pack(side="left", padx=5, pady=7)
        
        # Account list
        list_frame = ctk.CTkFrame(dialog, fg_color="#FFFFFF", corner_radius=8)
        list_frame.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        
        cols = ["id", "name", "bank", "account_no", "currency", "balance", "status"]
        tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=12)
        for c, h, w in zip(cols, ["ID", "ACCOUNT NAME", "BANK", "ACCOUNT NO", "CURRENCY", "BALANCE", "STATUS"],
                         [40, 150, 120, 140, 70, 100, 70]):
            tree.heading(c, text=h)
            tree.column(c, width=w, anchor="center")
        
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y", pady=10, padx=(0, 5))
        
        # Double-click to edit
        tree.bind("<Double-1>", lambda e: self._edit_selected_account(dialog, tree))
        
        # Load accounts
        self._load_accounts_to_tree(tree)
        
        # Footer with total balance
        footer = ctk.CTkFrame(dialog, fg_color="#F8F5F2", height=40, corner_radius=0)
        footer.pack(fill="x", side="bottom")
        footer.pack_propagate(False)
        
        total_label = ctk.CTkLabel(footer, text="", font=("SF Pro Display", 12, "bold"))
        total_label.pack(pady=10)
        
        # Calculate totals
        self._update_account_totals(tree, total_label)
    
    def _load_accounts_to_tree(self, tree):
        """Load bank accounts to treeview"""
        tree.delete(*tree.get_children())
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT id, account_name, bank_name, account_number, currency, balance, is_active FROM bank_accounts ORDER BY id")
            for row in cur.fetchall():
                status = "Active" if row[6] else "Inactive"
                tree.insert("", "end", values=(row[0], row[1], row[2], row[3], row[4], f"{row[5]:,.2f}", status))
        except Exception as e:
            print(f"Load accounts error: {e}")
        finally:
            conn.close()
    
    def _update_account_totals(self, tree, label):
        """Update total balance label"""
        totals = {"USD": 0, "MXN": 0}
        for item in tree.get_children():
            values = tree.item(item, "values")
            curr = values[4]
            try:
                bal = float(str(values[5]).replace(",", ""))
                if curr in totals:
                    totals[curr] += bal
            except:
                pass
        
        label.configure(text=f"Total: USD ${totals['USD']:,.2f}  |  MXN ${totals['MXN']:,.2f}")
    
    def _add_bank_account_dialog(self, parent, tree):
        """Show add account dialog"""
        self._show_account_form(parent, tree, None)
    
    def _edit_selected_account(self, parent, tree):
        """Edit selected account"""
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Please select an account to edit.")
            return
        
        account_id = tree.item(sel[0], "values")[0]
        self._show_account_form(parent, tree, account_id)
    
    def _show_account_form(self, parent, tree, account_id):
        """Show account add/edit form"""
        is_edit = account_id is not None
        
        form = ctk.CTkToplevel(parent)
        form.title("Edit Account" if is_edit else "Add Account")
        form.geometry("400x350")
        form.transient(parent)
        form.grab_set()
        
        ctk.CTkLabel(form, text="Edit Account" if is_edit else "New Account", 
                    font=("SF Pro Display", 16, "bold")).pack(pady=15)
        
        fields_frame = ctk.CTkFrame(form, fg_color="#F8F5F2", corner_radius=8)
        fields_frame.pack(fill="x", padx=20, pady=10)
        
        # Account Name
        ctk.CTkLabel(fields_frame, text="Account Name:").pack(anchor="w", padx=15, pady=(10, 0))
        name_var = tk.StringVar()
        ctk.CTkEntry(fields_frame, textvariable=name_var, width=300).pack(padx=15, pady=5)
        
        # Bank Name
        ctk.CTkLabel(fields_frame, text="Bank Name:").pack(anchor="w", padx=15, pady=(5, 0))
        bank_var = tk.StringVar()
        ctk.CTkEntry(fields_frame, textvariable=bank_var, width=300).pack(padx=15, pady=5)
        
        # Account Number
        ctk.CTkLabel(fields_frame, text="Account Number:").pack(anchor="w", padx=15, pady=(5, 0))
        acct_var = tk.StringVar()
        ctk.CTkEntry(fields_frame, textvariable=acct_var, width=300).pack(padx=15, pady=5)
        
        # Currency & Balance row
        row = ctk.CTkFrame(fields_frame, fg_color="transparent")
        row.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(row, text="Currency:").pack(side="left")
        curr_var = tk.StringVar(value="USD")
        ttk.Combobox(row, textvariable=curr_var, values=["USD", "MXN"], 
                    width=8, state="readonly").pack(side="left", padx=10)
        
        ctk.CTkLabel(row, text="Opening Bal:").pack(side="left", padx=(20, 0))
        bal_var = tk.StringVar(value="0.00")
        ctk.CTkEntry(row, textvariable=bal_var, width=100).pack(side="left", padx=5)
        ctk.CTkLabel(row, text="(개시잔액)", text_color="#888", font=("SF Pro Display", 9)).pack(side="left")
        
        # Load existing data if editing
        if is_edit:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT account_name, bank_name, account_number, currency, balance FROM bank_accounts WHERE id=?", (account_id,))
            row_data = cur.fetchone()
            conn.close()
            if row_data:
                name_var.set(row_data[0] or "")
                bank_var.set(row_data[1] or "")
                acct_var.set(row_data[2] or "")
                curr_var.set(row_data[3] or "USD")
                bal_var.set(f"{row_data[4]:.2f}" if row_data[4] else "0.00")
        
        def save():
            name = name_var.get().strip()
            if not name:
                messagebox.showwarning("Warning", "Account name is required.")
                return
            
            try:
                balance = float(bal_var.get() or 0)
            except:
                balance = 0
            
            conn = get_connection()
            cur = conn.cursor()
            try:
                if is_edit:
                    cur.execute("""UPDATE bank_accounts SET 
                        account_name=?, bank_name=?, account_number=?, currency=?, balance=?, updated_at=?
                        WHERE id=?""", (name, bank_var.get(), acct_var.get(), curr_var.get(), balance, now_str(), account_id))
                else:
                    cur.execute("""INSERT INTO bank_accounts (account_name, bank_name, account_number, currency, balance, is_active, created_at)
                        VALUES (?, ?, ?, ?, ?, 1, ?)""", (name, bank_var.get(), acct_var.get(), curr_var.get(), balance, now_str()))
                conn.commit()
                form.destroy()
                self._load_accounts_to_tree(tree)
                # Update totals
                for child in parent.winfo_children():
                    if isinstance(child, ctk.CTkFrame):
                        for subchild in child.winfo_children():
                            if isinstance(subchild, ctk.CTkLabel) and "Total:" in subchild.cget("text"):
                                self._update_account_totals(tree, subchild)
                                break
            except Exception as e:
                conn.rollback()
                messagebox.showerror("Error", f"Save failed: {e}")
            finally:
                conn.close()
        
        # Buttons
        btn_frame = ctk.CTkFrame(form, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Save", width=100, fg_color="#059669", command=save).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#A0A8AB", command=form.destroy).pack(side="right", padx=5)
    
    def _delete_selected_account(self, tree):
        """Delete selected account"""
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Warning", "Please select an account to delete.")
            return
        
        account_id = tree.item(sel[0], "values")[0]
        account_name = tree.item(sel[0], "values")[1]
        
        # Check for transfers
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM bank_transfers WHERE from_account_id=? OR to_account_id=?", (account_id, account_id))
        count = cur.fetchone()[0]
        conn.close()
        
        if count > 0:
            messagebox.showwarning("Cannot Delete", f"Account '{account_name}' has {count} transfer record(s).\nDelete transfers first.")
            return
        
        if not messagebox.askyesno("Confirm", f"Delete account '{account_name}'?"):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM bank_accounts WHERE id=?", (account_id,))
            conn.commit()
            tree.delete(sel[0])
            messagebox.showinfo("Deleted", "Account deleted.")
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Delete failed: {e}")
        finally:
            conn.close()

    def _setup_slip_tab(self):
        """Slip Processing tab - Receipt/Payment vouchers with Invoice/MBL/HBL linkage"""
        tab = self.tabview.tab(self.TAB_SLIP)

        # Toolbar Row 1
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", pady=(10, 5))
        
        ctk.CTkLabel(toolbar, text="Slip Type:").pack(side="left", padx=(10, 5))
        self.slip_type_var = tk.StringVar(value="All")
        ttk.Combobox(toolbar, textvariable=self.slip_type_var, values=["All", "Receipt", "Payment"], 
                    state="readonly", width=10).pack(side="left", padx=5)
        
        ctk.CTkLabel(toolbar, text="Status:").pack(side="left", padx=(15, 5))
        self.slip_status_var = tk.StringVar(value="All")
        ttk.Combobox(toolbar, textvariable=self.slip_status_var, values=["All", "PENDING", "COMPLETE", "CANCELLED"], 
                    state="readonly", width=10).pack(side="left", padx=5)
        
        ctk.CTkButton(toolbar, text="🔍 Search", width=80, command=self._load_slips).pack(side="left", padx=10)
        ctk.CTkButton(toolbar, text="➕ New Slip", width=100, fg_color="#4CAF50", command=self._new_slip).pack(side="left", padx=5)
        ctk.CTkButton(toolbar, text="📥 Export", width=80, fg_color="#6C757D", command=lambda: self._export("slip")).pack(side="right", padx=10)

        # Toolbar Row 2 - Invoice filter
        toolbar2 = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar2.pack(fill="x", pady=5)
        
        ctk.CTkLabel(toolbar2, text="Invoice Filter:").pack(side="left", padx=(10, 5))
        self.invoice_slip_filter_var = tk.StringVar(value="All")
        ttk.Combobox(toolbar2, textvariable=self.invoice_slip_filter_var, 
                    values=["All", "Slipped", "Not Slipped"], state="readonly", width=12).pack(side="left", padx=5)
        
        ctk.CTkLabel(toolbar2, text="Job No:").pack(side="left", padx=(15, 5))
        self.slip_job_filter_var = tk.StringVar()
        ctk.CTkEntry(toolbar2, textvariable=self.slip_job_filter_var, width=100, placeholder_text="Job No").pack(side="left", padx=5)
        
        ctk.CTkLabel(toolbar2, text="MBL/HBL:").pack(side="left", padx=(15, 5))
        self.slip_bl_filter_var = tk.StringVar()
        ctk.CTkEntry(toolbar2, textvariable=self.slip_bl_filter_var, width=120, placeholder_text="MBL or HBL").pack(side="left", padx=5)

        # Slip summary cards
        summary_frame = ctk.CTkFrame(tab, fg_color="#F5F5F5", corner_radius=10)
        summary_frame.pack(fill="x", padx=10, pady=10)
        
        self.slip_receipt_label = self._create_slip_card(summary_frame, "📥 Receipts", "$0.00", "#4CAF50")
        self.slip_receipt_label.pack(side="left", padx=10, pady=10, expand=True, fill="x")
        
        self.slip_payment_label = self._create_slip_card(summary_frame, "📤 Payments", "$0.00", "#F44336")
        self.slip_payment_label.pack(side="left", padx=10, pady=10, expand=True, fill="x")
        
        self.slip_balance_label = self._create_slip_card(summary_frame, "💰 Balance", "$0.00", "#2196F3")
        self.slip_balance_label.pack(side="left", padx=10, pady=10, expand=True, fill="x")

        # Slips table - with Invoice/MBL/HBL columns
        table_frame = ctk.CTkFrame(tab, fg_color="#FFFFFF")
        table_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        cols = ["id", "slip_no", "date", "type", "customer_code", "customer_name", "job_no", "mbl", "hbl", "invoice_no", "amount", "curr", "rate", "amount_mxn", "status"]
        self.slip_tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=12)
        
        headers = ["#", "SLIP NO", "DATE", "TYPE", "CODE", "CUSTOMER", "JOB NO", "MBL", "HBL", "INVOICE", "AMOUNT", "CURR", "RATE", "MXN", "STATUS"]
        widths = [35, 100, 80, 60, 60, 120, 90, 100, 100, 100, 80, 40, 50, 80, 70]
        
        for c, h, w in zip(cols, headers, widths):
            self.slip_tree.heading(c, text=h)
            self.slip_tree.column(c, width=w, anchor="center" if c not in ["customer_name"] else "w")
        
        slip_scroll_y = ttk.Scrollbar(table_frame, orient="vertical", command=self.slip_tree.yview)
        slip_scroll_x = ttk.Scrollbar(table_frame, orient="horizontal", command=self.slip_tree.xview)
        self.slip_tree.configure(yscrollcommand=slip_scroll_y.set, xscrollcommand=slip_scroll_x.set)
        
        self.slip_tree.grid(row=0, column=0, sticky="nsew")
        slip_scroll_y.grid(row=0, column=1, sticky="ns")
        slip_scroll_x.grid(row=1, column=0, sticky="ew")
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # Context menu
        self.slip_menu = tk.Menu(self, tearoff=0)
        self.slip_menu.add_command(label="✏️ Edit", command=self._edit_slip)
        self.slip_menu.add_command(label="📄 Print", command=self._print_slip)
        self.slip_menu.add_separator()
        self.slip_menu.add_command(label="🔗 Link Invoice", command=self._link_invoice_to_slip)
        self.slip_menu.add_separator()
        self.slip_menu.add_command(label="✓ Mark Complete", command=lambda: self._mark_slip("COMPLETE"))
        self.slip_menu.add_command(label="✗ Mark Cancelled", command=lambda: self._mark_slip("CANCELLED"))
        self.slip_menu.add_separator()
        self.slip_menu.add_command(label="🗑 Delete", command=self._delete_slip)
        
        self.slip_tree.bind("<Button-3>", self._show_slip_menu)
        self.slip_tree.bind("<Double-1>", lambda e: self._edit_slip())

    def _create_slip_card(self, parent, title, amount, color):
        """Create a slip summary card"""
        card = ctk.CTkFrame(parent, fg_color=color, corner_radius=10)
        ctk.CTkLabel(card, text=title, text_color="#FFFFFF", font=("SF Pro Display", 11)).pack(pady=(8, 2))
        lbl = ctk.CTkLabel(card, text=amount, text_color="#FFFFFF", font=("SF Pro Display", 16, "bold"))
        lbl.pack(pady=(2, 8))
        card._amount_label = lbl
        return card

    def _show_slip_menu(self, event):
        """Show slip context menu"""
        item = self.slip_tree.identify_row(event.y)
        if item:
            self.slip_tree.selection_set(item)
            self.slip_menu.post(event.x_root, event.y_root)

    def _load_slips(self):
        """Load slips from database with Invoice/MBL/HBL linkage"""
        slip_type = self.slip_type_var.get()
        slip_status = self.slip_status_var.get()
        invoice_filter = self.invoice_slip_filter_var.get()
        job_filter = self.slip_job_filter_var.get().strip()
        bl_filter = self.slip_bl_filter_var.get().strip()
        start_date = self.date_from_var.get()
        end_date = self.date_to_var.get()
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Ensure slips table has all columns
            cur.execute("PRAGMA table_info(slips)")
            existing_cols = [c[1] for c in cur.fetchall()]
            
            new_cols = [
                ("customer_code", "TEXT DEFAULT ''"),
                ("customer_name", "TEXT DEFAULT ''"),
                ("mbl", "TEXT DEFAULT ''"),
                ("hbl", "TEXT DEFAULT ''"),
                ("invoice_no", "TEXT DEFAULT ''"),
                ("job_id", "INTEGER"),
                ("exchange_rate", "REAL DEFAULT 1"),
                ("amount_mxn", "REAL DEFAULT 0"),
            ]
            for col, col_type in new_cols:
                if col not in existing_cols:
                    cur.execute(f"ALTER TABLE slips ADD COLUMN {col} {col_type}")
            conn.commit()
            
            # Build query
            q = """SELECT s.id, s.slip_no, s.date, s.type, 
                          COALESCE(s.customer_code, ''), COALESCE(s.customer_name, s.customer, ''),
                          s.job_no, COALESCE(s.mbl, ''), COALESCE(s.hbl, ''), COALESCE(s.invoice_no, ''),
                          s.amount, s.currency, COALESCE(s.exchange_rate, 1), COALESCE(s.amount_mxn, 0), s.status
                   FROM slips s WHERE 1=1"""
            params = []
            
            if slip_type != "All":
                q += " AND s.type = ?"
                params.append(slip_type)
            if slip_status != "All":
                q += " AND s.status = ?"
                params.append(slip_status)
            if start_date:
                q += " AND s.date >= ?"
                params.append(start_date)
            if end_date:
                q += " AND s.date <= ?"
                params.append(end_date)
            if job_filter:
                q += " AND s.job_no LIKE ?"
                params.append(f"%{job_filter}%")
            if bl_filter:
                q += " AND (s.mbl LIKE ? OR s.hbl LIKE ?)"
                params.append(f"%{bl_filter}%")
                params.append(f"%{bl_filter}%")
            
            # Invoice filter
            if invoice_filter == "Slipped":
                q += " AND s.invoice_no IS NOT NULL AND s.invoice_no != ''"
            elif invoice_filter == "Not Slipped":
                q += " AND (s.invoice_no IS NULL OR s.invoice_no = '')"
            
            q += " ORDER BY s.date DESC, s.id DESC"
            
            cur.execute(q, params)
            rows = cur.fetchall()
            
            # Clear and populate tree
            for item in self.slip_tree.get_children():
                self.slip_tree.delete(item)
            
            total_receipt = 0
            total_payment = 0
            
            for row in rows:
                self.slip_tree.insert("", "end", values=row)
                if row[3] == "Receipt":
                    total_receipt += row[10] or 0
                else:
                    total_payment += row[10] or 0
            
            # Update summary cards
            self.slip_receipt_label._amount_label.configure(text=f"${total_receipt:,.2f}")
            self.slip_payment_label._amount_label.configure(text=f"${total_payment:,.2f}")
            self.slip_balance_label._amount_label.configure(text=f"${total_receipt - total_payment:,.2f}")
            
        except Exception as e:
            print(f"Slip load error: {e}")
        finally:
            conn.close()

    def _link_invoice_to_slip(self):
        """Link an invoice to the selected slip"""
        sel = self.slip_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a slip")
            return
        
        slip_values = self.slip_tree.item(sel[0], "values")
        slip_id = slip_values[0]
        
        # Dialog to select invoice
        dlg = ctk.CTkToplevel(self)
        dlg.title("Link Invoice to Slip")
        dlg.geometry("500x400")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        
        ctk.CTkLabel(dlg, text="Select Invoice to Link", font=("SF Pro Display", 14, "bold")).pack(pady=15)
        
        # Invoice list
        inv_frame = ctk.CTkFrame(dlg, fg_color="#FFFFFF")
        inv_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        inv_tree = ttk.Treeview(inv_frame, columns=["invoice_no", "date", "customer", "amount"], show="headings", height=10)
        for c, h, w in [("invoice_no", "INVOICE NO", 120), ("date", "DATE", 80), ("customer", "CUSTOMER", 150), ("amount", "AMOUNT", 100)]:
            inv_tree.heading(c, text=h)
            inv_tree.column(c, width=w, anchor="center" if c != "customer" else "w")
        inv_tree.pack(fill="both", expand=True)
        
        # Load unlinked invoices from settlement_items
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT DISTINCT si.invoice_no, si.invoice_date, si.customer_name, SUM(si.total)
                FROM settlement_items si
                WHERE si.invoice_no IS NOT NULL AND si.invoice_no != ''
                AND si.invoice_no NOT IN (SELECT DISTINCT invoice_no FROM slips WHERE invoice_no IS NOT NULL AND invoice_no != '')
                GROUP BY si.invoice_no
                ORDER BY si.invoice_date DESC
            """)
            for row in cur.fetchall():
                inv_tree.insert("", "end", values=row)
        except Exception as e:
            print(f"Invoice load error: {e}")
        finally:
            conn.close()
        
        def link():
            inv_sel = inv_tree.selection()
            if not inv_sel:
                return
            invoice_no = inv_tree.item(inv_sel[0], "values")[0]
            
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("UPDATE slips SET invoice_no=?, updated_at=? WHERE id=?", 
                           (invoice_no, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), slip_id))
                conn.commit()
                dlg.destroy()
                self._load_slips()
                messagebox.showinfo("Linked", f"Invoice {invoice_no} linked to slip")
            except Exception as e:
                messagebox.showerror("Error", str(e))
            finally:
                conn.close()
        
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Link", width=100, command=link).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=100, fg_color="#6C757D", command=dlg.destroy).pack(side="right", padx=5)

    def _new_slip(self):
        """Open dialog to create new slip with Job/MBL/HBL/Invoice linkage"""
        dlg = ctk.CTkToplevel(self)
        dlg.title("New Slip")
        dlg.geometry("550x550")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        
        # Form
        form = ctk.CTkFrame(dlg, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=20, pady=20)
        
        row = 0
        ctk.CTkLabel(form, text="Slip Type:").grid(row=row, column=0, sticky="w", pady=5)
        type_var = tk.StringVar(value="Receipt")
        ttk.Combobox(form, textvariable=type_var, values=["Receipt", "Payment"], state="readonly", width=15).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Date:").grid(row=row, column=0, sticky="w", pady=5)
        date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        ctk.CTkEntry(form, textvariable=date_var, width=150).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Customer Code:").grid(row=row, column=0, sticky="w", pady=5)
        cust_code_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=cust_code_var, width=100).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Customer Name:").grid(row=row, column=0, sticky="w", pady=5)
        cust_name_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=cust_name_var, width=250).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Job No:").grid(row=row, column=0, sticky="w", pady=5)
        job_var = tk.StringVar()
        job_entry = ctk.CTkEntry(form, textvariable=job_var, width=150)
        job_entry.grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="MBL:").grid(row=row, column=0, sticky="w", pady=5)
        mbl_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=mbl_var, width=200).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="HBL:").grid(row=row, column=0, sticky="w", pady=5)
        hbl_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=hbl_var, width=200).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Invoice No:").grid(row=row, column=0, sticky="w", pady=5)
        invoice_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=invoice_var, width=150).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Description:").grid(row=row, column=0, sticky="w", pady=5)
        desc_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=desc_var, width=300).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Amount:").grid(row=row, column=0, sticky="w", pady=5)
        amount_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=amount_var, width=150).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Currency:").grid(row=row, column=0, sticky="w", pady=5)
        curr_var = tk.StringVar(value="USD")
        ttk.Combobox(form, textvariable=curr_var, values=["USD", "MXN"], state="readonly", width=10).grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Exchange Rate:").grid(row=row, column=0, sticky="w", pady=5)
        rate_var = tk.StringVar(value="20.0")
        rate_entry = ctk.CTkEntry(form, textvariable=rate_var, width=100)
        rate_entry.grid(row=row, column=1, sticky="w", pady=5)
        
        row += 1
        ctk.CTkLabel(form, text="Amount (MXN):").grid(row=row, column=0, sticky="w", pady=5)
        mxn_label = ctk.CTkLabel(form, text="$0.00")
        mxn_label.grid(row=row, column=1, sticky="w", pady=5)
        
        def calc_mxn(*args):
            try:
                amt = float(amount_var.get() or 0)
                rate = float(rate_var.get() or 20)
                if curr_var.get() == "USD":
                    mxn = amt * rate
                else:
                    mxn = amt
                mxn_label.configure(text=f"${mxn:,.2f}")
            except:
                pass
        
        amount_var.trace_add("write", calc_mxn)
        rate_var.trace_add("write", calc_mxn)
        curr_var.trace_add("write", calc_mxn)
        
        # Auto-fill from job
        def load_job_info(*args):
            job_no = job_var.get().strip()
            if not job_no:
                return
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("SELECT mbl, hbl, customer FROM jobs WHERE job_no = ?", (job_no,))
                row = cur.fetchone()
                if row:
                    mbl_var.set(row[0] or "")
                    hbl_var.set(row[1] or "")
                    if not cust_name_var.get():
                        cust_name_var.set(row[2] or "")
            except:
                pass
            finally:
                conn.close()
        
        job_entry.bind("<FocusOut>", load_job_info)
        
        def save():
            conn = get_connection()
            cur = conn.cursor()
            try:
                # Generate slip number
                prefix = "RCP" if type_var.get() == "Receipt" else "PMT"
                cur.execute("SELECT MAX(id) FROM slips")
                max_id = cur.fetchone()[0] or 0
                slip_no = f"{prefix}{datetime.now().strftime('%Y%m%d')}{max_id + 1:04d}"
                
                amt = float(amount_var.get() or 0)
                rate = float(rate_var.get() or 20)
                if curr_var.get() == "USD":
                    amt_mxn = amt * rate
                else:
                    amt_mxn = amt
                
                # Get job_id
                job_id = None
                if job_var.get():
                    cur.execute("SELECT id FROM jobs WHERE job_no = ?", (job_var.get(),))
                    r = cur.fetchone()
                    if r:
                        job_id = r[0]
                
                cur.execute("""
                    INSERT INTO slips (slip_no, date, type, customer_code, customer_name, job_id, job_no, 
                                      mbl, hbl, invoice_no, description, amount, currency, exchange_rate, 
                                      amount_mxn, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
                """, (slip_no, date_var.get(), type_var.get(), cust_code_var.get(), cust_name_var.get(),
                      job_id, job_var.get(), mbl_var.get(), hbl_var.get(), invoice_var.get(),
                      desc_var.get(), amt, curr_var.get(), rate, amt_mxn,
                      datetime.now().strftime("%Y-%m-%d %H:%M:%S"), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                conn.commit()
                dlg.destroy()
                self._load_slips()
                messagebox.showinfo("Success", f"Slip {slip_no} created")
            except Exception as e:
                messagebox.showerror("Error", f"Save failed: {e}")
            finally:
                conn.close()
        
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Save", width=100, command=save).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=100, fg_color="#6C757D", command=dlg.destroy).pack(side="right", padx=5)

    def _edit_slip(self):
        """Edit selected slip"""
        sel = self.slip_tree.selection()
        if not sel:
            return
        values = self.slip_tree.item(sel[0], "values")
        slip_id = values[0]
        
        # Similar dialog as _new_slip but pre-filled
        messagebox.showinfo("Edit", f"Edit slip #{slip_id} - Feature coming soon")

    def _print_slip(self):
        """Print slip"""
        sel = self.slip_tree.selection()
        if not sel:
            return
        messagebox.showinfo("Print", "Print feature - Coming soon")

    def _mark_slip(self, status):
        """Mark slip status"""
        sel = self.slip_tree.selection()
        if not sel:
            return
        
        slip_id = self.slip_tree.item(sel[0], "values")[0]
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("UPDATE slips SET status=?, updated_at=? WHERE id=?",
                       (status, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), slip_id))
            conn.commit()
            self._load_slips()
        except Exception as e:
            messagebox.showerror("Error", f"Update failed: {e}")
        finally:
            conn.close()

    def _delete_slip(self):
        """Delete slip"""
        sel = self.slip_tree.selection()
        if not sel:
            return
        
        if not messagebox.askyesno("Delete", "Delete this slip?"):
            return
        
        slip_id = self.slip_tree.item(sel[0], "values")[0]
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM slips WHERE id=?", (slip_id,))
            conn.commit()
            self._load_slips()
        except Exception as e:
            messagebox.showerror("Error", f"Delete failed: {e}")
        finally:
            conn.close()

    def _setup_pl_tab(self):
        """Profit & Loss Statement tab - Standard Format"""
        tab = self.tabview.tab("P&L Statement")

        # Export button
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", pady=10)
        ctk.CTkButton(toolbar, text="📥 Export P&L", width=100, fg_color="#6C757D", command=lambda: self._export("pl")).pack(side="right", padx=5)
        ctk.CTkButton(toolbar, text="🔄 Refresh", width=80, command=self._load_pl_data).pack(side="right", padx=5)

        # P&L Display - Standard Format
        self.pl_frame = ctk.CTkScrollableFrame(tab, fg_color="#FFFFFF")
        self.pl_frame.pack(fill="both", expand=True, pady=10)

        # Title
        ctk.CTkLabel(self.pl_frame, text="PROFIT & LOSS STATEMENT", 
                    font=("SF Pro Display", 16, "bold")).pack(pady=(10, 5))
        self.pl_period_label = ctk.CTkLabel(self.pl_frame, text="Period: ", 
                                           font=("SF Pro Display", 11), text_color="#666")
        self.pl_period_label.pack(pady=(0, 15))

        # Revenue Section
        self._create_pl_section("REVENUE", "#4CAF50")
        self.pl_revenue_items = ctk.CTkFrame(self.pl_frame, fg_color="#F8FFF8")
        self.pl_revenue_items.pack(fill="x", padx=20, pady=5)
        
        self.pl_gross_revenue_label = self._create_pl_line(self.pl_revenue_items, "Gross Revenue (매출)", "$0.00", bold=True)
        self.pl_freight_income_label = self._create_pl_line(self.pl_revenue_items, "  Freight Income", "$0.00")
        self.pl_service_income_label = self._create_pl_line(self.pl_revenue_items, "  Service Income", "$0.00")
        self.pl_other_income_label = self._create_pl_line(self.pl_revenue_items, "  Other Income", "$0.00")

        # COGS Section
        self._create_pl_section("COST OF GOODS SOLD", "#FF9800")
        self.pl_cogs_items = ctk.CTkFrame(self.pl_frame, fg_color="#FFF8F0")
        self.pl_cogs_items.pack(fill="x", padx=20, pady=5)
        
        self.pl_total_cogs_label = self._create_pl_line(self.pl_cogs_items, "Total Cost (매입)", "$0.00", bold=True)
        self.pl_freight_cost_label = self._create_pl_line(self.pl_cogs_items, "  Freight Cost", "$0.00")
        self.pl_trucking_cost_label = self._create_pl_line(self.pl_cogs_items, "  Trucking Cost", "$0.00")
        self.pl_customs_cost_label = self._create_pl_line(self.pl_cogs_items, "  Customs & Handling", "$0.00")
        self.pl_other_cost_label = self._create_pl_line(self.pl_cogs_items, "  Other Cost", "$0.00")

        # Gross Profit
        self._create_pl_divider()
        self.pl_gross_profit_frame = ctk.CTkFrame(self.pl_frame, fg_color="#E3F2FD")
        self.pl_gross_profit_frame.pack(fill="x", padx=20, pady=10)
        self.pl_gross_profit_label = self._create_pl_line(self.pl_gross_profit_frame, "GROSS PROFIT", "$0.00", bold=True, size=13)

        # Operating Expenses
        self._create_pl_section("OPERATING EXPENSES", "#9C27B0")
        self.pl_opex_items = ctk.CTkFrame(self.pl_frame, fg_color="#F8F0FF")
        self.pl_opex_items.pack(fill="x", padx=20, pady=5)
        
        self.pl_total_opex_label = self._create_pl_line(self.pl_opex_items, "Total Operating Expenses", "$0.00", bold=True)
        self.pl_salary_label = self._create_pl_line(self.pl_opex_items, "  Salaries & Wages", "$0.00")
        self.pl_rent_label = self._create_pl_line(self.pl_opex_items, "  Rent & Utilities", "$0.00")
        self.pl_admin_label = self._create_pl_line(self.pl_opex_items, "  Administrative", "$0.00")

        # Net Profit
        self._create_pl_divider()
        self.pl_net_profit_frame = ctk.CTkFrame(self.pl_frame, fg_color="#E8F5E9")
        self.pl_net_profit_frame.pack(fill="x", padx=20, pady=10)
        self.pl_net_profit_label = self._create_pl_line(self.pl_net_profit_frame, "NET PROFIT / (LOSS)", "$0.00", bold=True, size=14)
        
        # Margin
        self.pl_margin_label = ctk.CTkLabel(self.pl_frame, text="Profit Margin: 0.0%", 
                                           font=("SF Pro Display", 11), text_color="#666")
        self.pl_margin_label.pack(pady=(5, 15))

    def _create_pl_section(self, title, color):
        """Create a P&L section header"""
        frame = ctk.CTkFrame(self.pl_frame, fg_color=color, corner_radius=5)
        frame.pack(fill="x", padx=20, pady=(15, 5))
        ctk.CTkLabel(frame, text=title, text_color="#FFFFFF", font=("SF Pro Display", 12, "bold")).pack(pady=8, padx=15, anchor="w")

    def _create_pl_line(self, parent, label, amount, bold=False, size=11):
        """Create a P&L line item"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", pady=3)
        font = ("SF Pro Display", size, "bold") if bold else ("SF Pro Display", size)
        ctk.CTkLabel(frame, text=label, font=font, width=300, anchor="w").pack(side="left", padx=15)
        amount_label = ctk.CTkLabel(frame, text=amount, font=font, width=120, anchor="e")
        amount_label.pack(side="right", padx=15)
        return amount_label

    def _create_pl_divider(self):
        """Create a divider line"""
        ctk.CTkFrame(self.pl_frame, height=2, fg_color="#BDBDBD").pack(fill="x", padx=20, pady=5)

    def _setup_bs_tab(self):
        """Balance Sheet tab"""
        tab = self.tabview.tab("Balance Sheet")

        # Export button
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", pady=10)
        ctk.CTkButton(toolbar, text="📥 Export B/S", width=100, fg_color="#6C757D", command=lambda: self._export("bs")).pack(side="right", padx=5)
        ctk.CTkButton(toolbar, text="🔄 Refresh", width=80, command=self._load_bs_data).pack(side="right", padx=5)

        # B/S Display
        self.bs_frame = ctk.CTkScrollableFrame(tab, fg_color="#FFFFFF")
        self.bs_frame.pack(fill="both", expand=True, pady=10)

        # Title
        ctk.CTkLabel(self.bs_frame, text="BALANCE SHEET", 
                    font=("SF Pro Display", 16, "bold")).pack(pady=(10, 5))
        self.bs_date_label = ctk.CTkLabel(self.bs_frame, text="As of: ", 
                                         font=("SF Pro Display", 11), text_color="#666")
        self.bs_date_label.pack(pady=(0, 15))

        # Two columns: Assets | Liabilities & Equity
        main_frame = ctk.CTkFrame(self.bs_frame, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=20)

        # Assets Column
        assets_col = ctk.CTkFrame(main_frame, fg_color="#F0F8FF")
        assets_col.pack(side="left", fill="both", expand=True, padx=5)
        
        ctk.CTkLabel(assets_col, text="ASSETS", font=("SF Pro Display", 14, "bold"), 
                    fg_color="#2196F3", text_color="#FFFFFF", corner_radius=5).pack(fill="x", padx=10, pady=10)
        
        # Current Assets
        ctk.CTkLabel(assets_col, text="Current Assets", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        self.bs_cash_label = self._create_bs_line(assets_col, "Cash & Bank", "$0.00")
        self.bs_ar_label = self._create_bs_line(assets_col, "Accounts Receivable", "$0.00")
        self.bs_prepaid_label = self._create_bs_line(assets_col, "Prepaid Expenses", "$0.00")
        self.bs_current_total_label = self._create_bs_line(assets_col, "Total Current Assets", "$0.00", bold=True)
        
        # Fixed Assets
        ctk.CTkLabel(assets_col, text="Fixed Assets", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(15, 5))
        self.bs_equipment_label = self._create_bs_line(assets_col, "Equipment", "$0.00")
        self.bs_fixed_total_label = self._create_bs_line(assets_col, "Total Fixed Assets", "$0.00", bold=True)
        
        ctk.CTkFrame(assets_col, height=2, fg_color="#2196F3").pack(fill="x", padx=15, pady=10)
        self.bs_total_assets_label = self._create_bs_line(assets_col, "TOTAL ASSETS", "$0.00", bold=True, size=13)

        # Liabilities & Equity Column
        liab_col = ctk.CTkFrame(main_frame, fg_color="#FFF8F0")
        liab_col.pack(side="right", fill="both", expand=True, padx=5)
        
        ctk.CTkLabel(liab_col, text="LIABILITIES & EQUITY", font=("SF Pro Display", 14, "bold"), 
                    fg_color="#FF9800", text_color="#FFFFFF", corner_radius=5).pack(fill="x", padx=10, pady=10)
        
        # Current Liabilities
        ctk.CTkLabel(liab_col, text="Current Liabilities", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        self.bs_ap_label = self._create_bs_line(liab_col, "Accounts Payable", "$0.00")
        self.bs_accrued_label = self._create_bs_line(liab_col, "Accrued Expenses", "$0.00")
        self.bs_liab_total_label = self._create_bs_line(liab_col, "Total Liabilities", "$0.00", bold=True)
        
        # Equity
        ctk.CTkLabel(liab_col, text="Equity", font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=15, pady=(15, 5))
        self.bs_capital_label = self._create_bs_line(liab_col, "Capital", "$0.00")
        self.bs_retained_label = self._create_bs_line(liab_col, "Retained Earnings", "$0.00")
        self.bs_equity_total_label = self._create_bs_line(liab_col, "Total Equity", "$0.00", bold=True)
        
        ctk.CTkFrame(liab_col, height=2, fg_color="#FF9800").pack(fill="x", padx=15, pady=10)
        self.bs_total_liab_equity_label = self._create_bs_line(liab_col, "TOTAL L & E", "$0.00", bold=True, size=13)

    def _create_bs_line(self, parent, label, amount, bold=False, size=11):
        """Create a Balance Sheet line item"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", pady=2)
        font = ("SF Pro Display", size, "bold") if bold else ("SF Pro Display", size)
        ctk.CTkLabel(frame, text=label, font=font, anchor="w").pack(side="left", padx=15)
        amount_label = ctk.CTkLabel(frame, text=amount, font=font, anchor="e")
        amount_label.pack(side="right", padx=15)
        return amount_label

    def _load_bs_data(self):
        """Load Balance Sheet data"""
        end_date = self.date_to_var.get() or datetime.now().strftime("%Y-%m-%d")
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Get A/R total
            cur.execute("""SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                          WHERE item_type = 'REVENUE' AND status = 'PENDING'""")
            ar_total = cur.fetchone()[0] or 0
            
            # Get A/P total
            cur.execute("""SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                          WHERE item_type = 'COST' AND status = 'PENDING'""")
            ap_total = cur.fetchone()[0] or 0
            
            # Get cash (from bank accounts if available)
            try:
                cur.execute("SELECT COALESCE(SUM(balance), 0) FROM bank_accounts")
                cash_total = cur.fetchone()[0] or 0
            except:
                cash_total = 0
            
            # Calculate retained earnings (cumulative profit)
            cur.execute("""SELECT 
                          COALESCE(SUM(CASE WHEN item_type='REVENUE' THEN total ELSE 0 END), 0) -
                          COALESCE(SUM(CASE WHEN item_type='COST' THEN total ELSE 0 END), 0)
                          FROM settlement_items""")
            retained = cur.fetchone()[0] or 0
            
            # Update B/S labels
            self.bs_date_label.configure(text=f"As of: {end_date}")
            self.bs_cash_label.configure(text=f"${cash_total:,.2f}")
            self.bs_ar_label.configure(text=f"${ar_total:,.2f}")
            self.bs_prepaid_label.configure(text="$0.00")
            
            current_assets = cash_total + ar_total
            self.bs_current_total_label.configure(text=f"${current_assets:,.2f}")
            
            self.bs_equipment_label.configure(text="$0.00")
            self.bs_fixed_total_label.configure(text="$0.00")
            
            total_assets = current_assets
            self.bs_total_assets_label.configure(text=f"${total_assets:,.2f}")
            
            self.bs_ap_label.configure(text=f"${ap_total:,.2f}")
            self.bs_accrued_label.configure(text="$0.00")
            self.bs_liab_total_label.configure(text=f"${ap_total:,.2f}")
            
            equity = total_assets - ap_total
            self.bs_capital_label.configure(text="$0.00")
            self.bs_retained_label.configure(text=f"${equity:,.2f}")
            self.bs_equity_total_label.configure(text=f"${equity:,.2f}")
            
            self.bs_total_liab_equity_label.configure(text=f"${total_assets:,.2f}")
            
        except Exception as e:
            print(f"B/S load error: {e}")
        finally:
            conn.close()

    def _setup_aging_tab(self):
        """Aging Report tab"""
        tab = self.tabview.tab(self.TAB_AGING)

        # Type selector
        type_frame = ctk.CTkFrame(tab, fg_color="transparent")
        type_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(type_frame, text="Type:").pack(side="left", padx=10)
        self.aging_type = tk.StringVar(value="Receivable")
        ttk.Combobox(type_frame, textvariable=self.aging_type, values=["Receivable", "Payable"], state="readonly", width=12).pack(side="left", padx=5)
        ctk.CTkButton(type_frame, text="Generate", width=80, command=self._generate_aging).pack(side="left", padx=10)
        ctk.CTkButton(type_frame, text="📥 Export", width=80, fg_color="#6C757D", command=lambda: self._export("aging")).pack(side="right", padx=5)

        # Aging summary
        self.aging_summary = ctk.CTkFrame(tab, fg_color="#F5F5F5", corner_radius=10)
        self.aging_summary.pack(fill="x", pady=10)

        aging_cols = ["Current", "1-30 Days", "31-60 Days", "61-90 Days", "90+ Days", "Total"]
        self.aging_labels = {}
        
        for i, col in enumerate(aging_cols):
            frame = ctk.CTkFrame(self.aging_summary, fg_color="transparent")
            frame.pack(side="left", expand=True, fill="x", padx=5, pady=10)
            ctk.CTkLabel(frame, text=col, font=("SF Pro Display", 10)).pack()
            lbl = ctk.CTkLabel(frame, text="$0.00", font=("SF Pro Display", 12, "bold"))
            lbl.pack()
            self.aging_labels[col] = lbl

        # Aging table
        cols = ["customer", "current", "d30", "d60", "d90", "d90plus", "total"]
        self.aging_tree = ttk.Treeview(tab, columns=cols, show="headings", height=10)
        
        headers = ["CUSTOMER/VENDOR", "CURRENT", "1-30", "31-60", "61-90", "90+", "TOTAL"]
        widths = [180, 100, 100, 100, 100, 100, 100]
        
        for c, h, w in zip(cols, headers, widths):
            self.aging_tree.heading(c, text=h)
            self.aging_tree.column(c, width=w, anchor="center" if c != "customer" else "w")

        self.aging_tree.pack(fill="both", expand=True, pady=10)

    def _setup_monthly_closing_tab(self):
        """
        Monthly/Yearly Closing - 초천재 회계사의 월마감/연마감 도구
        
        최소 입력으로 최대 결과를 도출하는 회계 마감 시스템
        - Bank Statement Import & Auto-matching
        - Auto FX Calculation
        - Invoice Auto-numbering
        - Monthly Lock
        - Audit Trail
        """
        tab = self.tabview.tab(self.TAB_PL)
        
        # Header
        header = ctk.CTkFrame(tab, fg_color="#374151", corner_radius=8, height=50)
        header.pack(fill="x", pady=(10, 5), padx=10)
        header.pack_propagate(False)
        
        ctk.CTkLabel(header, text="📊 Monthly Closing / 월마감 관리", 
                    font=("SF Pro Display", 18, "bold"), text_color="white").pack(side="left", padx=20, pady=10)
        
        # Period selector
        period_frame = ctk.CTkFrame(header, fg_color="transparent")
        period_frame.pack(side="right", padx=20)
        
        self.closing_year_var = tk.StringVar(value=str(datetime.now().year))
        ttk.Combobox(period_frame, textvariable=self.closing_year_var, 
                    values=[str(y) for y in range(2024, 2030)], width=6, state="readonly").pack(side="left", padx=5)
        
        self.closing_month_var = tk.StringVar(value=str(datetime.now().month))
        ttk.Combobox(period_frame, textvariable=self.closing_month_var, 
                    values=[str(m) for m in range(1, 13)], width=4, state="readonly").pack(side="left", padx=5)
        
        ctk.CTkButton(period_frame, text="🔍 Load", width=70, height=28, fg_color="white", 
                     text_color="#374151", command=self._load_closing_data).pack(side="left", padx=10)
        
        # Month status indicator
        self.month_status_label = ctk.CTkLabel(header, text="", font=("SF Pro Display", 12, "bold"))
        self.month_status_label.pack(side="right", padx=10)
        
        # Main content - scrollable
        main_scroll = ctk.CTkScrollableFrame(tab, fg_color="#FAFAFA")
        main_scroll.pack(fill="both", expand=True, padx=10, pady=5)
        
        # === Section 1: 마감 체크리스트 ===
        checklist_frame = ctk.CTkFrame(main_scroll, fg_color="#FFFFFF", corner_radius=8)
        checklist_frame.pack(fill="x", pady=5)
        
        ctk.CTkLabel(checklist_frame, text="✅ 마감 체크리스트", 
                    font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        self.checklist_items = {}
        checklist_data = [
            ("all_invoiced", "모든 매출 인보이스 발행 완료", "Revenue invoices"),
            ("all_costs_entered", "모든 비용 입력 완료", "Cost entries"),
            ("bank_reconciled", "은행 잔액 대사 완료", "Bank reconciliation"),
            ("ar_confirmed", "미수금 확인 완료", "A/R confirmation"),
            ("ap_confirmed", "미지급금 확인 완료", "A/P confirmation"),
            ("fx_settled", "환차손익 정리 완료", "FX settlement"),
        ]
        
        for key, label_kr, label_en in checklist_data:
            row = ctk.CTkFrame(checklist_frame, fg_color="transparent")
            row.pack(fill="x", padx=15, pady=3)
            
            var = tk.BooleanVar(value=False)
            self.checklist_items[key] = var
            
            ctk.CTkCheckBox(row, text=f"{label_kr} ({label_en})", variable=var,
                           font=("SF Pro Display", 11), command=self._update_closing_status).pack(side="left")
        
        # Progress bar
        self.closing_progress = ctk.CTkProgressBar(checklist_frame, width=400, height=12)
        self.closing_progress.pack(pady=10)
        self.closing_progress.set(0)
        
        # === Section 2: 요약 카드 ===
        summary_frame = ctk.CTkFrame(main_scroll, fg_color="#FFFFFF", corner_radius=8)
        summary_frame.pack(fill="x", pady=5)
        
        ctk.CTkLabel(summary_frame, text="📈 월간 요약 (Monthly Summary)", 
                    font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        cards_inner = ctk.CTkFrame(summary_frame, fg_color="transparent")
        cards_inner.pack(fill="x", padx=15, pady=10)
        
        # Revenue card
        rev_card = ctk.CTkFrame(cards_inner, fg_color="#E8F5E9", corner_radius=8, width=150)
        rev_card.pack(side="left", padx=5, expand=True, fill="x")
        ctk.CTkLabel(rev_card, text="매출 (Revenue)", font=("SF Pro Display", 10)).pack(pady=(10, 2))
        self.closing_revenue_label = ctk.CTkLabel(rev_card, text="$0.00", 
                                                  font=("SF Pro Display", 16, "bold"), text_color="#2E7D32")
        self.closing_revenue_label.pack(pady=(2, 10))
        
        # Cost card
        cost_card = ctk.CTkFrame(cards_inner, fg_color="#FFF3E0", corner_radius=8, width=150)
        cost_card.pack(side="left", padx=5, expand=True, fill="x")
        ctk.CTkLabel(cost_card, text="비용 (Cost)", font=("SF Pro Display", 10)).pack(pady=(10, 2))
        self.closing_cost_label = ctk.CTkLabel(cost_card, text="$0.00", 
                                               font=("SF Pro Display", 16, "bold"), text_color="#E65100")
        self.closing_cost_label.pack(pady=(2, 10))
        
        # Profit card
        profit_card = ctk.CTkFrame(cards_inner, fg_color="#E3F2FD", corner_radius=8, width=150)
        profit_card.pack(side="left", padx=5, expand=True, fill="x")
        ctk.CTkLabel(profit_card, text="손익 (Profit)", font=("SF Pro Display", 10)).pack(pady=(10, 2))
        self.closing_profit_label = ctk.CTkLabel(profit_card, text="$0.00", 
                                                 font=("SF Pro Display", 16, "bold"), text_color="#1565C0")
        self.closing_profit_label.pack(pady=(2, 10))
        
        # Margin card
        margin_card = ctk.CTkFrame(cards_inner, fg_color="#F3E5F5", corner_radius=8, width=150)
        margin_card.pack(side="left", padx=5, expand=True, fill="x")
        ctk.CTkLabel(margin_card, text="이익률 (Margin)", font=("SF Pro Display", 10)).pack(pady=(10, 2))
        self.closing_margin_label = ctk.CTkLabel(margin_card, text="0.0%", 
                                                 font=("SF Pro Display", 16, "bold"), text_color="#7B1FA2")
        self.closing_margin_label.pack(pady=(2, 10))
        
        # === Section 3: 미처리 항목 ===
        pending_frame = ctk.CTkFrame(main_scroll, fg_color="#FFFFFF", corner_radius=8)
        pending_frame.pack(fill="x", pady=5)
        
        ctk.CTkLabel(pending_frame, text="⚠️ 미처리 항목 (Pending Items)", 
                    font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        # Jobs without settlement
        pending_inner = ctk.CTkFrame(pending_frame, fg_color="#FFF8E1", corner_radius=6)
        pending_inner.pack(fill="x", padx=15, pady=5)
        
        self.pending_jobs_label = ctk.CTkLabel(pending_inner, text="Settlement 미등록 Job: 0건", 
                                               font=("SF Pro Display", 11))
        self.pending_jobs_label.pack(side="left", padx=15, pady=8)
        
        ctk.CTkButton(pending_inner, text="View", width=60, height=25, fg_color="#D97706",
                     command=self._show_pending_jobs).pack(side="right", padx=15, pady=8)
        
        # Uninvoiced items
        uninvoiced_inner = ctk.CTkFrame(pending_frame, fg_color="#FFEBEE", corner_radius=6)
        uninvoiced_inner.pack(fill="x", padx=15, pady=5)
        
        self.uninvoiced_label = ctk.CTkLabel(uninvoiced_inner, text="미발행 인보이스: 0건 ($0.00)", 
                                             font=("SF Pro Display", 11))
        self.uninvoiced_label.pack(side="left", padx=15, pady=8)
        
        uninvoiced_btn_frame = ctk.CTkFrame(uninvoiced_inner, fg_color="transparent")
        uninvoiced_btn_frame.pack(side="right", padx=15, pady=8)
        ctk.CTkButton(uninvoiced_btn_frame, text="🔢 Auto-Generate", width=100, height=25, fg_color="#374151",
                     command=self._auto_generate_invoices).pack(side="left", padx=5)
        ctk.CTkButton(uninvoiced_btn_frame, text="View", width=50, height=25, fg_color="#DC2626",
                     command=self._show_uninvoiced_items).pack(side="left", padx=5)
        
        # Bank unmatched
        bank_inner = ctk.CTkFrame(pending_frame, fg_color="#E3F2FD", corner_radius=6)
        bank_inner.pack(fill="x", padx=15, pady=5)
        
        self.unmatched_bank_label = ctk.CTkLabel(bank_inner, text="미대사 은행거래: 0건", 
                                                  font=("SF Pro Display", 11))
        self.unmatched_bank_label.pack(side="left", padx=15, pady=8)
        
        bank_btn_frame = ctk.CTkFrame(bank_inner, fg_color="transparent")
        bank_btn_frame.pack(side="right", padx=15, pady=8)
        ctk.CTkButton(bank_btn_frame, text="📥 Import CSV", width=90, height=25, fg_color="#374151",
                     command=self._import_bank_statement).pack(side="left", padx=5)
        ctk.CTkButton(bank_btn_frame, text="🔗 Auto-Match", width=90, height=25, fg_color="#059669",
                     command=self._auto_match_bank).pack(side="left", padx=5)
        
        # === Section 4: FX Summary ===
        fx_frame = ctk.CTkFrame(main_scroll, fg_color="#FFFFFF", corner_radius=8)
        fx_frame.pack(fill="x", pady=5)
        
        fx_header = ctk.CTkFrame(fx_frame, fg_color="transparent")
        fx_header.pack(fill="x", padx=15, pady=(10, 5))
        
        ctk.CTkLabel(fx_header, text="💱 환율 및 환차손익 (FX Summary)", 
                    font=("SF Pro Display", 14, "bold")).pack(side="left")
        ctk.CTkButton(fx_header, text="🔄 Calculate FX", width=100, height=25, fg_color="#D97706",
                     command=self._calculate_fx_gains).pack(side="right")
        
        fx_inner = ctk.CTkFrame(fx_frame, fg_color="#F8F5F2", corner_radius=6)
        fx_inner.pack(fill="x", padx=15, pady=10)
        
        fx_row1 = ctk.CTkFrame(fx_inner, fg_color="transparent")
        fx_row1.pack(fill="x", padx=15, pady=8)
        
        self.avg_rate_label = ctk.CTkLabel(fx_row1, text="평균 환율: 17.50", font=("SF Pro Display", 12))
        self.avg_rate_label.pack(side="left", padx=10)
        
        self.fx_gain_label = ctk.CTkLabel(fx_row1, text="환차익: $0.00", 
                                          font=("SF Pro Display", 12), text_color="#2E7D32")
        self.fx_gain_label.pack(side="left", padx=20)
        
        self.fx_loss_label = ctk.CTkLabel(fx_row1, text="환차손: $0.00", 
                                          font=("SF Pro Display", 12), text_color="#C62828")
        self.fx_loss_label.pack(side="left", padx=20)
        
        self.fx_net_label = ctk.CTkLabel(fx_row1, text="순 환차손익: $0.00", 
                                         font=("SF Pro Display", 14, "bold"))
        self.fx_net_label.pack(side="right", padx=10)
        
        # === Section 5: Audit Trail ===
        audit_frame = ctk.CTkFrame(main_scroll, fg_color="#FFFFFF", corner_radius=8)
        audit_frame.pack(fill="x", pady=5)
        
        audit_header = ctk.CTkFrame(audit_frame, fg_color="transparent")
        audit_header.pack(fill="x", padx=15, pady=(10, 5))
        
        ctk.CTkLabel(audit_header, text="📝 감사 추적 (Audit Trail)", 
                    font=("SF Pro Display", 14, "bold")).pack(side="left")
        ctk.CTkButton(audit_header, text="View Full Log", width=90, height=25, fg_color="#6B7280",
                     command=self._show_audit_trail).pack(side="right")
        
        self.audit_summary_label = ctk.CTkLabel(audit_frame, 
                                                text="이번 달 변경사항: 0건 (INSERT: 0, UPDATE: 0, DELETE: 0)", 
                                                font=("SF Pro Display", 11))
        self.audit_summary_label.pack(anchor="w", padx=15, pady=(0, 10))
        
        # === Section 6: Export / Close ===
        action_frame = ctk.CTkFrame(main_scroll, fg_color="#F5F5F5", corner_radius=8)
        action_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(action_frame, text="📤 마감 및 출력", 
                    font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        btn_frame = ctk.CTkFrame(action_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkButton(btn_frame, text="📊 P&L Report", width=95, height=35, fg_color="#374151",
                     command=lambda: self._export_closing_report("pl")).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📋 Balance Sheet", width=105, height=35, fg_color="#374151",
                     command=lambda: self._export_closing_report("bs")).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📑 Trial Balance", width=100, height=35, fg_color="#374151",
                     command=lambda: self._export_closing_report("trial")).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📈 Excel Export", width=100, height=35, fg_color="#6B7280",
                     command=lambda: self._export_closing_report("excel")).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📜 History", width=80, height=35, fg_color="#6B7280",
                     command=self._show_closing_history).pack(side="left", padx=3)
        
        # Right side - Close/Reopen buttons
        self.close_btn = ctk.CTkButton(btn_frame, text="🔒 월마감 확정", width=110, height=35, fg_color="#DC2626",
                                       command=self._confirm_monthly_closing)
        self.close_btn.pack(side="right", padx=5)
        
        self.reopen_btn = ctk.CTkButton(btn_frame, text="🔓 월마감 해제", width=110, height=35, 
                                        fg_color="#9CA3AF", command=self._reopen_month)
        self.reopen_btn.pack(side="right", padx=5)
        self.reopen_btn.pack_forget()  # Initially hidden
    
    def _load_closing_data(self):
        """Load closing data for selected month"""
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        # Calculate date range
        start_date = f"{year}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1}-01-01"
        else:
            end_date = f"{year}-{month+1:02d}-01"
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Get revenue
            cur.execute("""
                SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                WHERE item_type = 'REVENUE' AND invoice_date >= ? AND invoice_date < ?
            """, (start_date, end_date))
            revenue = cur.fetchone()[0] or 0
            
            # Get cost
            cur.execute("""
                SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                WHERE item_type = 'COST' AND invoice_date >= ? AND invoice_date < ?
            """, (start_date, end_date))
            cost = cur.fetchone()[0] or 0
            
            profit = revenue - cost
            margin = (profit / revenue * 100) if revenue > 0 else 0
            
            # Update labels
            self.closing_revenue_label.configure(text=f"${revenue:,.2f}")
            self.closing_cost_label.configure(text=f"${cost:,.2f}")
            self.closing_profit_label.configure(text=f"${profit:,.2f}")
            self.closing_profit_label.configure(text_color="#2E7D32" if profit >= 0 else "#C62828")
            self.closing_margin_label.configure(text=f"{margin:.1f}%")
            
            # Get pending jobs (jobs without settlement)
            cur.execute("""
                SELECT COUNT(*) FROM jobs j
                WHERE j.created_at >= ? AND j.created_at < ?
                AND NOT EXISTS (SELECT 1 FROM settlement_items s WHERE s.job_id = j.id)
            """, (start_date, end_date))
            pending_jobs = cur.fetchone()[0] or 0
            self.pending_jobs_label.configure(text=f"Settlement 미등록 Job: {pending_jobs}건")
            
            # Get uninvoiced items
            cur.execute("""
                SELECT COUNT(*), COALESCE(SUM(total), 0) FROM settlement_items 
                WHERE invoice_date >= ? AND invoice_date < ?
                AND (invoice_no IS NULL OR invoice_no = '')
            """, (start_date, end_date))
            uninv_row = cur.fetchone()
            uninv_count = uninv_row[0] or 0
            uninv_amount = uninv_row[1] or 0
            self.uninvoiced_label.configure(text=f"미발행 인보이스: {uninv_count}건 (${uninv_amount:,.2f})")
            
            # Get average exchange rate
            cur.execute("""
                SELECT AVG(rate) FROM exchange_rates 
                WHERE rate_date >= ? AND rate_date < ? AND currency_pair = 'USD/MXN'
            """, (start_date, end_date))
            avg_rate = cur.fetchone()[0] or 17.50
            self.avg_rate_label.configure(text=f"평균 환율: {avg_rate:.4f}")
            
            # Get FX gain/loss from transfers
            cur.execute("""
                SELECT COALESCE(SUM(fx_gain_loss), 0) FROM bank_transfers 
                WHERE transfer_date >= ? AND transfer_date < ?
            """, (start_date, end_date))
            fx_total = cur.fetchone()[0] or 0
            self.fx_gain_loss_label.configure(text=f"환차손익: ${fx_total:,.2f}")
            self.fx_gain_loss_label.configure(text_color="#2E7D32" if fx_total >= 0 else "#C62828")
            
        except Exception as e:
            print(f"Load closing data error: {e}")
        finally:
            conn.close()
    
    def _update_closing_status(self):
        """Update closing progress bar"""
        checked = sum(1 for var in self.checklist_items.values() if var.get())
        total = len(self.checklist_items)
        self.closing_progress.set(checked / total if total > 0 else 0)
    
    def _show_pending_jobs(self):
        """Show jobs without settlement"""
        messagebox.showinfo("미처리 Job", "Settlement 미등록 Job 목록을 표시합니다.\n\n"
                          "Status → Operation에서 해당 Job을 선택하고\nSettlement를 등록해주세요.")
    
    def _show_uninvoiced_items(self):
        """Show uninvoiced items"""
        messagebox.showinfo("미발행 인보이스", "인보이스 미발행 항목 목록을 표시합니다.\n\n"
                          "Settlement에서 해당 항목의 Invoice No를 입력해주세요.")
    
    def _export_closing_report(self, report_type):
        """Export closing report - 실제 Excel 파일 생성"""
        from db import get_pl_data, get_balance_sheet_data, get_trial_balance_data
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
            from openpyxl.utils import get_column_letter
        except ImportError:
            messagebox.showerror("Error", "openpyxl 라이브러리가 필요합니다.\npip install openpyxl")
            return
        
        # 스타일 정의
        header_font = Font(bold=True, size=14)
        section_font = Font(bold=True, size=11)
        number_font = Font(name='Consolas', size=10)
        
        header_fill = PatternFill(start_color="374151", end_color="374151", fill_type="solid")
        header_font_white = Font(bold=True, size=12, color="FFFFFF")
        
        section_fill = PatternFill(start_color="F3F4F6", end_color="F3F4F6", fill_type="solid")
        
        thin_border = Border(
            left=Side(style='thin', color='E5E7EB'),
            right=Side(style='thin', color='E5E7EB'),
            top=Side(style='thin', color='E5E7EB'),
            bottom=Side(style='thin', color='E5E7EB')
        )
        
        if report_type == "pl":
            # P&L Report
            data = get_pl_data(year, month)
            
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = f"P&L {year}-{month:02d}"
            
            # Title
            ws.merge_cells('A1:D1')
            ws['A1'] = f"PROFIT & LOSS STATEMENT - {year}/{month:02d}"
            ws['A1'].font = header_font
            ws['A1'].alignment = Alignment(horizontal='center')
            
            row = 3
            
            # Revenue Section
            ws[f'A{row}'] = "REVENUE"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = section_fill
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            for cat, amount in data['revenue']['by_category'].items():
                ws[f'B{row}'] = cat
                ws[f'D{row}'] = amount
                ws[f'D{row}'].number_format = '#,##0.00'
                row += 1
            
            ws[f'B{row}'] = "Total Revenue"
            ws[f'B{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['revenue']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 2
            
            # Cost Section
            ws[f'A{row}'] = "COST OF SERVICES"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = section_fill
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            for cat, amount in data['cost']['by_category'].items():
                ws[f'B{row}'] = cat
                ws[f'D{row}'] = amount
                ws[f'D{row}'].number_format = '#,##0.00'
                row += 1
            
            ws[f'B{row}'] = "Total Cost"
            ws[f'B{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['cost']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 2
            
            # Gross Profit
            ws[f'A{row}'] = "GROSS PROFIT"
            ws[f'A{row}'].font = section_font
            ws[f'D{row}'] = data['gross_profit']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True, color="059669" if data['gross_profit'] >= 0 else "DC2626")
            row += 2
            
            # Operating Expenses
            ws[f'A{row}'] = "OPERATING EXPENSES"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = section_fill
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            ws[f'B{row}'] = "Admin Expenses"
            ws[f'D{row}'] = data['admin_expense']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 2
            
            # FX Gain/Loss
            ws[f'A{row}'] = "FX GAIN/LOSS"
            ws[f'A{row}'].font = section_font
            ws[f'D{row}'] = data['fx_gain_loss']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 2
            
            # Net Profit
            ws[f'A{row}'] = "NET PROFIT"
            ws[f'A{row}'].font = Font(bold=True, size=12)
            ws[f'A{row}'].fill = header_fill
            ws[f'A{row}'].font = header_font_white
            ws.merge_cells(f'A{row}:C{row}')
            ws[f'D{row}'] = data['net_profit']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True, size=12)
            ws[f'D{row}'].fill = header_fill
            row += 1
            
            ws[f'A{row}'] = f"Margin: {data['margin']:.1f}%"
            
            # Column widths
            ws.column_dimensions['A'].width = 20
            ws.column_dimensions['B'].width = 30
            ws.column_dimensions['C'].width = 15
            ws.column_dimensions['D'].width = 15
            
            filename = f"PL_{year}{month:02d}.xlsx"
            
        elif report_type == "bs":
            # Balance Sheet
            data = get_balance_sheet_data(year, month)
            
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = f"BS {year}-{month:02d}"
            
            ws.merge_cells('A1:D1')
            ws['A1'] = f"BALANCE SHEET - As of {data['as_of_date']}"
            ws['A1'].font = header_font
            ws['A1'].alignment = Alignment(horizontal='center')
            
            row = 3
            
            # Assets
            ws[f'A{row}'] = "ASSETS"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = header_fill
            ws[f'A{row}'].font = header_font_white
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            ws[f'A{row}'] = "Current Assets"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = section_fill
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            # Cash
            for account, balance in data['assets']['cash'].items():
                ws[f'B{row}'] = account
                ws[f'D{row}'] = balance
                ws[f'D{row}'].number_format = '#,##0.00'
                row += 1
            
            ws[f'B{row}'] = "Accounts Receivable"
            ws[f'D{row}'] = data['assets']['accounts_receivable']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 1
            
            ws[f'B{row}'] = "Total Current Assets"
            ws[f'B{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['assets']['total_current']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 1
            
            ws[f'A{row}'] = "TOTAL ASSETS"
            ws[f'A{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['assets']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 2
            
            # Liabilities
            ws[f'A{row}'] = "LIABILITIES"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = header_fill
            ws[f'A{row}'].font = header_font_white
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            ws[f'B{row}'] = "Accounts Payable"
            ws[f'D{row}'] = data['liabilities']['accounts_payable']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 1
            
            ws[f'A{row}'] = "TOTAL LIABILITIES"
            ws[f'A{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['liabilities']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 2
            
            # Equity
            ws[f'A{row}'] = "EQUITY"
            ws[f'A{row}'].font = section_font
            ws[f'A{row}'].fill = header_fill
            ws[f'A{row}'].font = header_font_white
            ws.merge_cells(f'A{row}:D{row}')
            row += 1
            
            ws[f'B{row}'] = "Retained Earnings"
            ws[f'D{row}'] = data['equity']['retained_earnings']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 1
            
            ws[f'B{row}'] = "Current Period Profit"
            ws[f'D{row}'] = data['equity']['current_period_profit']
            ws[f'D{row}'].number_format = '#,##0.00'
            row += 1
            
            ws[f'A{row}'] = "TOTAL EQUITY"
            ws[f'A{row}'].font = Font(bold=True)
            ws[f'D{row}'] = data['equity']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            row += 2
            
            # Total L+E
            ws[f'A{row}'] = "TOTAL LIABILITIES + EQUITY"
            ws[f'A{row}'].font = Font(bold=True, size=11)
            ws[f'A{row}'].fill = section_fill
            ws.merge_cells(f'A{row}:C{row}')
            ws[f'D{row}'] = data['liabilities']['total'] + data['equity']['total']
            ws[f'D{row}'].number_format = '#,##0.00'
            ws[f'D{row}'].font = Font(bold=True)
            
            ws.column_dimensions['A'].width = 25
            ws.column_dimensions['B'].width = 25
            ws.column_dimensions['C'].width = 15
            ws.column_dimensions['D'].width = 15
            
            filename = f"BS_{year}{month:02d}.xlsx"
            
        elif report_type == "trial":
            # Trial Balance
            data = get_trial_balance_data(year, month)
            
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = f"TB {year}-{month:02d}"
            
            ws.merge_cells('A1:D1')
            ws['A1'] = f"TRIAL BALANCE - {data['period']}"
            ws['A1'].font = header_font
            ws['A1'].alignment = Alignment(horizontal='center')
            
            # Headers
            row = 3
            for col, header in enumerate(['Account Code', 'Account Name', 'Debit', 'Credit'], 1):
                cell = ws.cell(row=row, column=col, value=header)
                cell.font = header_font_white
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center')
            row += 1
            
            # Data
            for acc in data['accounts']:
                ws.cell(row=row, column=1, value=acc['code'])
                ws.cell(row=row, column=2, value=acc['name'])
                ws.cell(row=row, column=3, value=acc['debit']).number_format = '#,##0.00'
                ws.cell(row=row, column=4, value=acc['credit']).number_format = '#,##0.00'
                row += 1
            
            # Totals
            row += 1
            ws.cell(row=row, column=2, value="TOTAL").font = Font(bold=True)
            ws.cell(row=row, column=3, value=data['total_debit']).number_format = '#,##0.00'
            ws.cell(row=row, column=3).font = Font(bold=True)
            ws.cell(row=row, column=4, value=data['total_credit']).number_format = '#,##0.00'
            ws.cell(row=row, column=4).font = Font(bold=True)
            
            row += 1
            balance_status = "✓ BALANCED" if data['is_balanced'] else "✗ UNBALANCED"
            ws.cell(row=row, column=2, value=balance_status)
            ws.cell(row=row, column=2).font = Font(bold=True, color="059669" if data['is_balanced'] else "DC2626")
            
            ws.column_dimensions['A'].width = 15
            ws.column_dimensions['B'].width = 25
            ws.column_dimensions['C'].width = 15
            ws.column_dimensions['D'].width = 15
            
            filename = f"TB_{year}{month:02d}.xlsx"
            
        elif report_type == "excel":
            # Summary Excel (all in one)
            pl_data = get_pl_data(year, month)
            bs_data = get_balance_sheet_data(year, month)
            tb_data = get_trial_balance_data(year, month)
            
            wb = openpyxl.Workbook()
            
            # P&L Sheet
            ws_pl = wb.active
            ws_pl.title = "P&L"
            ws_pl['A1'] = f"P&L Summary {year}/{month:02d}"
            ws_pl['A3'] = "Revenue"
            ws_pl['B3'] = pl_data['revenue']['total']
            ws_pl['A4'] = "Cost"
            ws_pl['B4'] = pl_data['cost']['total']
            ws_pl['A5'] = "Gross Profit"
            ws_pl['B5'] = pl_data['gross_profit']
            ws_pl['A6'] = "Net Profit"
            ws_pl['B6'] = pl_data['net_profit']
            ws_pl['A7'] = "Margin"
            ws_pl['B7'] = f"{pl_data['margin']:.1f}%"
            
            # BS Sheet
            ws_bs = wb.create_sheet("Balance Sheet")
            ws_bs['A1'] = f"Balance Sheet {bs_data['as_of_date']}"
            ws_bs['A3'] = "Total Assets"
            ws_bs['B3'] = bs_data['assets']['total']
            ws_bs['A4'] = "Total Liabilities"
            ws_bs['B4'] = bs_data['liabilities']['total']
            ws_bs['A5'] = "Total Equity"
            ws_bs['B5'] = bs_data['equity']['total']
            
            # TB Sheet
            ws_tb = wb.create_sheet("Trial Balance")
            ws_tb['A1'] = f"Trial Balance {tb_data['period']}"
            ws_tb['A3'] = "Total Debit"
            ws_tb['B3'] = tb_data['total_debit']
            ws_tb['A4'] = "Total Credit"
            ws_tb['B4'] = tb_data['total_credit']
            ws_tb['A5'] = "Balanced"
            ws_tb['B5'] = "Yes" if tb_data['is_balanced'] else "No"
            
            filename = f"Summary_{year}{month:02d}.xlsx"
        
        else:
            return
        
        # Save file
        filepath = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfile=filename
        )
        
        if filepath:
            wb.save(filepath)
            messagebox.showinfo("Export Complete", f"파일이 저장되었습니다:\n{filepath}")
    
    def _confirm_monthly_closing(self):
        """Confirm monthly closing with all validations"""
        from db import close_month, is_month_closed, record_audit
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        # Check if already closed
        if is_month_closed(year, month):
            messagebox.showwarning("Already Closed", f"{year}년 {month}월은 이미 마감되었습니다.")
            return
        
        # Check if all items are checked
        all_checked = all(var.get() for var in self.checklist_items.values())
        
        if not all_checked:
            if not messagebox.askyesno("체크리스트 미완료", 
                                       "체크리스트가 완료되지 않았습니다.\n그래도 마감을 진행하시겠습니까?"):
                return
        
        # Get closing data
        revenue = float(self.closing_revenue_label.cget("text").replace("$", "").replace(",", ""))
        cost = float(self.closing_cost_label.cget("text").replace("$", "").replace(",", ""))
        fx_text = self.fx_net_label.cget("text").replace("순 환차손익: ", "").replace("$", "").replace(",", "")
        fx_gain_loss = float(fx_text) if fx_text else 0
        
        if messagebox.askyesno("월마감 확정", 
                               f"{year}년 {month}월 마감을 확정하시겠습니까?\n\n"
                               f"매출: ${revenue:,.2f}\n"
                               f"비용: ${cost:,.2f}\n"
                               f"손익: ${revenue - cost:,.2f}\n"
                               f"환차손익: ${fx_gain_loss:,.2f}\n\n"
                               "확정 후에는 해당 월의 데이터 수정이 제한됩니다."):
            
            if close_month(year, month, "admin", revenue, cost, fx_gain_loss):
                messagebox.showinfo("마감 완료", f"{year}년 {month}월 마감이 완료되었습니다.")
                self._load_closing_data()
            else:
                messagebox.showerror("Error", "마감 처리 중 오류가 발생했습니다.")
    
    def _reopen_month(self):
        """Reopen a closed month (admin only)"""
        from db import reopen_month, is_month_closed
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        if not is_month_closed(year, month):
            messagebox.showinfo("Info", f"{year}년 {month}월은 마감되지 않았습니다.")
            return
        
        reason = simpledialog.askstring("마감 해제 사유", "마감 해제 사유를 입력하세요:")
        if not reason:
            return
        
        if messagebox.askyesno("마감 해제 확인", 
                               f"{year}년 {month}월 마감을 해제하시겠습니까?\n\n"
                               f"사유: {reason}"):
            if reopen_month(year, month, "admin", reason):
                messagebox.showinfo("해제 완료", f"{year}년 {month}월 마감이 해제되었습니다.")
                self._load_closing_data()
            else:
                messagebox.showerror("Error", "마감 해제 중 오류가 발생했습니다.")
    
    def _auto_generate_invoices(self):
        """Auto-generate invoice numbers for uninvoiced items"""
        from db import generate_invoice_number, get_next_invoice_preview, record_audit
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        start_date = f"{year}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1}-01-01"
        else:
            end_date = f"{year}-{month+1:02d}-01"
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Get uninvoiced items
            cur.execute("""
                SELECT id, item_type, customer_name, total FROM settlement_items 
                WHERE invoice_date >= ? AND invoice_date < ?
                AND (invoice_no IS NULL OR invoice_no = '')
            """, (start_date, end_date))
            items = cur.fetchall()
            
            if not items:
                messagebox.showinfo("Info", "미발행 인보이스가 없습니다.")
                return
            
            # Preview
            next_inv = get_next_invoice_preview("INV", year)
            
            if not messagebox.askyesno("인보이스 자동 생성", 
                                       f"{len(items)}건의 인보이스를 자동 생성합니다.\n\n"
                                       f"시작 번호: {next_inv}\n"
                                       f"계속하시겠습니까?"):
                return
            
            # Generate invoices
            generated = 0
            for item in items:
                item_id, item_type, customer, total = item
                
                # Use different prefix for revenue vs cost
                prefix = "INV" if item_type == "REVENUE" else "BILL"
                invoice_no = generate_invoice_number(prefix, year)
                
                cur.execute("UPDATE settlement_items SET invoice_no = ? WHERE id = ?", (invoice_no, item_id))
                
                # Record audit
                record_audit("settlement_items", item_id, "UPDATE",
                            old_values={"invoice_no": None},
                            new_values={"invoice_no": invoice_no},
                            changed_by="system")
                
                generated += 1
            
            conn.commit()
            messagebox.showinfo("완료", f"{generated}건의 인보이스가 생성되었습니다.")
            self._load_closing_data()
            
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"인보이스 생성 오류: {e}")
        finally:
            conn.close()
    
    def _import_bank_statement(self):
        """Import bank statement CSV"""
        from db import import_bank_statement_csv
        
        # Select account
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, account_name, currency FROM bank_accounts WHERE is_active=1")
        accounts = cur.fetchall()
        conn.close()
        
        if not accounts:
            messagebox.showwarning("Warning", "등록된 은행계좌가 없습니다.")
            return
        
        # Account selection dialog
        dialog = ctk.CTkToplevel(self)
        dialog.title("Bank Statement Import")
        dialog.geometry("500x400")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        ctk.CTkLabel(dialog, text="📥 Bank Statement Import", font=("SF Pro Display", 16, "bold")).pack(pady=15)
        
        form = ctk.CTkFrame(dialog, fg_color="#F8F5F2", corner_radius=8)
        form.pack(fill="x", padx=20, pady=10)
        
        # Account selection
        ctk.CTkLabel(form, text="Select Account:").pack(anchor="w", padx=15, pady=(10, 0))
        account_var = tk.StringVar()
        account_combo = ttk.Combobox(form, textvariable=account_var, 
                                     values=[f"{a[0]} - {a[1]} ({a[2]})" for a in accounts], width=40)
        account_combo.pack(padx=15, pady=5)
        if accounts:
            account_combo.current(0)
        
        # CSV format settings
        ctk.CTkLabel(form, text="CSV Column Settings:", font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=15, pady=(10, 0))
        
        col_frame = ctk.CTkFrame(form, fg_color="transparent")
        col_frame.pack(fill="x", padx=15, pady=5)
        
        ctk.CTkLabel(col_frame, text="Date:").grid(row=0, column=0, padx=5, pady=3)
        date_col_var = tk.StringVar(value="0")
        ctk.CTkEntry(col_frame, textvariable=date_col_var, width=40).grid(row=0, column=1, padx=5, pady=3)
        
        ctk.CTkLabel(col_frame, text="Desc:").grid(row=0, column=2, padx=5, pady=3)
        desc_col_var = tk.StringVar(value="1")
        ctk.CTkEntry(col_frame, textvariable=desc_col_var, width=40).grid(row=0, column=3, padx=5, pady=3)
        
        ctk.CTkLabel(col_frame, text="Debit:").grid(row=1, column=0, padx=5, pady=3)
        debit_col_var = tk.StringVar(value="2")
        ctk.CTkEntry(col_frame, textvariable=debit_col_var, width=40).grid(row=1, column=1, padx=5, pady=3)
        
        ctk.CTkLabel(col_frame, text="Credit:").grid(row=1, column=2, padx=5, pady=3)
        credit_col_var = tk.StringVar(value="3")
        ctk.CTkEntry(col_frame, textvariable=credit_col_var, width=40).grid(row=1, column=3, padx=5, pady=3)
        
        # Date format
        ctk.CTkLabel(form, text="Date Format:").pack(anchor="w", padx=15, pady=(10, 0))
        date_fmt_var = tk.StringVar(value="%Y-%m-%d")
        ttk.Combobox(form, textvariable=date_fmt_var, 
                    values=["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y"], width=20).pack(anchor="w", padx=15, pady=5)
        
        # Skip header checkbox
        skip_header_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(form, text="Skip header row", variable=skip_header_var).pack(anchor="w", padx=15, pady=5)
        
        # Result label
        result_label = ctk.CTkLabel(dialog, text="", font=("SF Pro Display", 11))
        result_label.pack(pady=10)
        
        def do_import():
            # Select file
            filepath = filedialog.askopenfilename(
                title="Select Bank Statement CSV",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
            )
            if not filepath:
                return
            
            try:
                account_id = int(account_var.get().split(" - ")[0])
                
                with open(filepath, 'r', encoding='utf-8-sig') as f:
                    csv_content = f.read()
                
                result = import_bank_statement_csv(
                    account_id=account_id,
                    csv_content=csv_content,
                    date_col=int(date_col_var.get()),
                    desc_col=int(desc_col_var.get()),
                    debit_col=int(debit_col_var.get()),
                    credit_col=int(credit_col_var.get()),
                    skip_header=skip_header_var.get(),
                    date_format=date_fmt_var.get()
                )
                
                result_text = f"Import complete:\n• Imported: {result['imported']}\n• Duplicates: {result['duplicates']}"
                if result['errors']:
                    result_text += f"\n• Errors: {len(result['errors'])}"
                
                result_label.configure(text=result_text)
                messagebox.showinfo("Import Complete", result_text)
                self._load_closing_data()
                
            except Exception as e:
                messagebox.showerror("Import Error", str(e))
        
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="📂 Select File & Import", width=150, fg_color="#374151",
                     command=do_import).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Close", width=80, fg_color="#9E9E9E",
                     command=dialog.destroy).pack(side="right", padx=5)
    
    def _auto_match_bank(self):
        """Auto-match bank statements with transfers"""
        from db import auto_match_bank_statements, get_unmatched_statements
        
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, account_name FROM bank_accounts WHERE is_active=1")
        accounts = cur.fetchall()
        conn.close()
        
        total_matched = 0
        total_unmatched = 0
        
        for acc_id, acc_name in accounts:
            result = auto_match_bank_statements(acc_id)
            total_matched += result['matched']
            total_unmatched += result['unmatched']
        
        messagebox.showinfo("Auto-Match Complete", 
                           f"자동 대사 완료\n\n"
                           f"• 매칭됨: {total_matched}건\n"
                           f"• 미매칭: {total_unmatched}건")
        
        self._load_closing_data()
    
    def _calculate_fx_gains(self):
        """Calculate FX gains/losses for the month"""
        from db import get_fx_summary, record_fx_transaction
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        # Get FX summary
        fx_summary = get_fx_summary(year, month)
        
        # Update UI
        self.fx_gain_label.configure(text=f"환차익: ${fx_summary['gain']:,.2f}")
        self.fx_loss_label.configure(text=f"환차손: ${abs(fx_summary['loss']):,.2f}")
        
        net = fx_summary['net']
        self.fx_net_label.configure(text=f"순 환차손익: ${net:,.2f}")
        self.fx_net_label.configure(text_color="#2E7D32" if net >= 0 else "#C62828")
        
        messagebox.showinfo("FX Calculation", 
                           f"환차손익 계산 완료\n\n"
                           f"• 거래 건수: {fx_summary['count']}건\n"
                           f"• 환차익: ${fx_summary['gain']:,.2f}\n"
                           f"• 환차손: ${abs(fx_summary['loss']):,.2f}\n"
                           f"• 순 환차손익: ${net:,.2f}")
    
    def _show_audit_trail(self):
        """Show audit trail for the month"""
        from db import get_audit_history
        
        year = int(self.closing_year_var.get())
        month = int(self.closing_month_var.get())
        
        start_date = f"{year}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1}-01-01"
        else:
            end_date = f"{year}-{month+1:02d}-01"
        
        history = get_audit_history(start_date=start_date, end_date=end_date, limit=200)
        
        # Show in dialog
        dialog = ctk.CTkToplevel(self)
        dialog.title(f"Audit Trail - {year}/{month}")
        dialog.geometry("800x500")
        dialog.transient(self.winfo_toplevel())
        
        cols = ["datetime", "table", "action", "record_id", "user", "details"]
        tree = ttk.Treeview(dialog, columns=cols, show="headings", height=20)
        
        for c, h, w in zip(cols, ["Date/Time", "Table", "Action", "ID", "User", "Details"],
                         [130, 100, 70, 60, 80, 300]):
            tree.heading(c, text=h)
            tree.column(c, width=w)
        
        vsb = ttk.Scrollbar(dialog, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True, padx=(10,0), pady=10)
        vsb.pack(side="right", fill="y", pady=10, padx=(0,10))
        
        for item in history:
            details = ""
            if item.g_t('new_values'):
                import json
                try:
                    details = json.loads(item['new_values'])
                    details = str(details)[:100]
                except:
                    details = str(item['new_values'])[:100]
            
            tree.insert("", "end", values=(
                item.g_t('changed_at', ''),
                item.g_t('table_name', ''),
                item.g_t('action', ''),
                item.g_t('record_id', ''),
                item.g_t('changed_by', ''),
                details
            ))
    
    def _show_closing_history(self):
        """Show monthly closing history"""
        from db import get_closing_history
        
        history = get_closing_history()
        
        dialog = ctk.CTkToplevel(self)
        dialog.title("Monthly Closing History")
        dialog.geometry("700x400")
        dialog.transient(self.winfo_toplevel())
        
        cols = ["period", "status", "revenue", "cost", "profit", "fx", "closed_by", "closed_at"]
        tree = ttk.Treeview(dialog, columns=cols, show="headings", height=15)
        
        for c, h, w in zip(cols, ["Period", "Status", "Revenue", "Cost", "Profit", "FX G/L", "Closed By", "Closed At"],
                         [80, 70, 90, 90, 90, 80, 80, 120]):
            tree.heading(c, text=h)
            tree.column(c, width=w, anchor="center")
        
        tree.pack(fill="both", expand=True, padx=10, pady=10)
        
        for item in history:
            tree.insert("", "end", values=(
                f"{item['year']}-{item['month']:02d}",
                item['status'],
                f"${item['revenue']:,.2f}" if item['revenue'] else "$0.00",
                f"${item['cost']:,.2f}" if item['cost'] else "$0.00",
                f"${item['profit']:,.2f}" if item['profit'] else "$0.00",
                f"${item['fx_gain_loss']:,.2f}" if item['fx_gain_loss'] else "$0.00",
                item['closed_by'] or "",
                item['closed_at'] or ""
            ))

    def _refresh_data(self):
        """Refresh all data with filters"""
        start_date = self.date_from_var.get() or "2020-01-01"
        end_date = self.date_to_var.get() or datetime.now().strftime("%Y-%m-%d")
        company = self.company_var.get().strip()
        mode = self.mode_var.get()
        op = self.op_var.get()
        item_type = self.type_var.get()
        date_type = self.date_type_var.get()  # invoice or operation
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Build filter conditions
            conditions = []
            params = []
            
            if date_type == "invoice":
                conditions.append("s.invoice_date BETWEEN ? AND ?")
            else:
                conditions.append("j.etd BETWEEN ? AND ?")
            params.extend([start_date, end_date])
            
            if company:
                conditions.append("s.customer LIKE ?")
                params.append(f"%{company}%")
            if mode:
                conditions.append("j.mode = ?")
                params.append(mode)
            if op:
                if op == "EXPO":
                    conditions.append("j.pol LIKE '%MX%'")
                else:
                    conditions.append("j.pol NOT LIKE '%MX%'")
            
            where_clause = " AND ".join(conditions) if conditions else "1=1"
            
            # Get revenue
            rev_cond = where_clause + (" AND s.item_type='REVENUE'" if not item_type else f" AND s.item_type='{item_type}'")
            if item_type != "COST":
                cur.execute(f"""
                    SELECT COALESCE(SUM(s.total), 0) FROM settlement_items s
                    LEFT JOIN jobs j ON s.job_id = j.id
                    WHERE s.item_type='REVENUE' AND {where_clause}
                """, params)
                revenue = cur.fetchone()[0] or 0
            else:
                revenue = 0

            # Get cost
            if item_type != "REVENUE":
                cur.execute(f"""
                    SELECT COALESCE(SUM(s.total), 0) FROM settlement_items s
                    LEFT JOIN jobs j ON s.job_id = j.id
                    WHERE s.item_type='COST' AND {where_clause}
                """, params)
                cost = cur.fetchone()[0] or 0
            else:
                cost = 0

            # Get receivable (unpaid revenue)
            cur.execute("""
                SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                WHERE item_type='REVENUE' AND status != 'PAID'
            """)
            receivable = cur.fetchone()[0] or 0

            # Get payable (unpaid cost)
            cur.execute("""
                SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                WHERE item_type='COST' AND status != 'PAID'
            """)
            payable = cur.fetchone()[0] or 0

            profit = revenue - cost

            # Update cards
            self.revenue_card._amount_label.configure(text=f"${revenue:,.2f}")
            self.cost_card._amount_label.configure(text=f"${cost:,.2f}")
            self.profit_card._amount_label.configure(text=f"${profit:,.2f}")
            self.receivable_card._amount_label.configure(text=f"${receivable:,.2f}")
            self.payable_card._amount_label.configure(text=f"${payable:,.2f}")

            # Profit color
            if profit >= 0:
                self.profit_card.configure(fg_color="#4CAF50")
            else:
                self.profit_card.configure(fg_color="#F44336")

            # Load tables
            self._load_journal(start_date, end_date, company, mode, op, item_type)
            if hasattr(self, 'ar_tree'):
                self._load_ar()
            if hasattr(self, 'ap_tree'):
                self._load_ap()
            self._load_cashflow()
            self._load_pl(start_date, end_date)

        except Exception as e:
            print(f"Refresh error: {e}")
        finally:
            conn.close()

    def _load_journal(self, start_date, end_date, company, mode, op, item_type):
        """Load journal entries with filters"""
        for item in self.journal_tree.get_children():
            self.journal_tree.delete(item)

        conn = get_connection()
        cur = conn.cursor()
        try:
            # Build query with filters
            conditions = ["s.invoice_date BETWEEN ? AND ?"]
            params = [start_date, end_date]
            
            if company:
                conditions.append("s.customer LIKE ?")
                params.append(f"%{company}%")
            if item_type:
                conditions.append("s.item_type = ?")
                params.append(item_type)
            
            where_clause = " AND ".join(conditions)
            
            cur.execute(f"""
                SELECT s.id, s.invoice_date, j.job_no, s.item_type, s.freight_desc, 
                       CASE WHEN s.item_type='REVENUE' THEN s.total ELSE 0 END,
                       CASE WHEN s.item_type='COST' THEN s.total ELSE 0 END,
                       s.currency
                FROM settlement_items s
                LEFT JOIN jobs j ON s.job_id = j.id
                WHERE {where_clause}
                ORDER BY s.invoice_date DESC
            """, params)
            
            for row in cur.fetchall():
                debit = row[5] or 0
                credit = row[6] or 0
                self.journal_tree.insert("", "end", values=(
                    row[0], row[1], row[2] or "", row[3], row[4] or "",
                    f"${debit:,.2f}" if debit > 0 else "-",
                    f"${credit:,.2f}" if credit > 0 else "-",
                    row[7] or "USD"
                ))

        except Exception as e:
            print(f"Journal load error: {e}")
        finally:
            conn.close()

    def _load_ar(self):
        """Load Accounts Receivable"""
        for item in self.ar_tree.get_children():
            self.ar_tree.delete(item)

        conn = get_connection()
        cur = conn.cursor()
        total = 0
        try:
            cur.execute("""
                SELECT j.job_no, s.customer, s.invoice_no, s.total, 0, s.total, s.invoice_date, s.status
                FROM settlement_items s
                LEFT JOIN jobs j ON s.job_id = j.id
                WHERE s.item_type = 'REVENUE' AND s.status != 'PAID'
                ORDER BY s.invoice_date
            """)
            
            today = datetime.now()
            for row in cur.fetchall():
                amount = row[3] or 0
                due_date = row[6] or ""
                days = 0
                if due_date:
                    try:
                        due = datetime.strptime(due_date, "%Y-%m-%d")
                        days = (today - due).days
                    except:
                        pass
                
                status = "OVERDUE" if days > 30 else row[7]
                total += amount
                self.ar_tree.insert("", "end", values=(row[0], row[1], row[2], f"${amount:,.2f}", "$0.00", f"${amount:,.2f}", due_date, status, days))

            self.ar_total_label.configure(text=f"${total:,.2f}")

        except Exception as e:
            print(f"AR load error: {e}")
        finally:
            conn.close()

    def _load_ap(self):
        """Load Accounts Payable"""
        for item in self.ap_tree.get_children():
            self.ap_tree.delete(item)

        conn = get_connection()
        cur = conn.cursor()
        total = 0
        try:
            cur.execute("""
                SELECT j.job_no, s.customer, s.invoice_no, s.total, 0, s.total, s.invoice_date, s.status
                FROM settlement_items s
                LEFT JOIN jobs j ON s.job_id = j.id
                WHERE s.item_type = 'COST' AND s.status != 'PAID'
                ORDER BY s.invoice_date
            """)
            
            today = datetime.now()
            for row in cur.fetchall():
                amount = row[3] or 0
                due_date = row[6] or ""
                days = 0
                if due_date:
                    try:
                        due = datetime.strptime(due_date, "%Y-%m-%d")
                        days = (today - due).days
                    except:
                        pass
                
                status = "OVERDUE" if days > 30 else row[7]
                total += amount
                self.ap_tree.insert("", "end", values=(row[0], row[1], row[2], f"${amount:,.2f}", "$0.00", f"${amount:,.2f}", due_date, status, days))

            self.ap_total_label.configure(text=f"${total:,.2f}")

        except Exception as e:
            print(f"AP load error: {e}")
        finally:
            conn.close()

    def _load_transactions(self):
        """Load transactions from bank_transactions table"""
        for item in self.trans_tree.get_children():
            self.trans_tree.delete(item)
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Check if bank_transactions table exists with correct schema
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='bank_transactions'")
            table_exists = cur.fetchone()
            
            needs_recreate = False
            if table_exists:
                # Check if counterpart column exists
                cur.execute("PRAGMA table_info(bank_transactions)")
                columns = [row[1] for row in cur.fetchall()]
                if 'counterpart' not in columns:
                    needs_recreate = True
                    print("⚠ bank_transactions table missing 'counterpart' column, recreating...")
            
            if not table_exists or needs_recreate:
                # Drop old table if exists
                cur.execute("DROP TABLE IF EXISTS bank_transactions")
                
                # Create table with correct schema
                cur.execute("""
                    CREATE TABLE bank_transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        trans_date TEXT,
                        trans_type TEXT,
                        account_id INTEGER,
                        counterpart TEXT,
                        category TEXT,
                        amount REAL,
                        currency TEXT,
                        reference TEXT,
                        description TEXT,
                        balance_after REAL,
                        created_at TEXT,
                        FOREIGN KEY (account_id) REFERENCES bank_accounts(id)
                    )
                """)
                conn.commit()
                print("✓ bank_transactions table created/recreated")
            
            # Build query based on filters
            cat_filter = self.trans_cat_var.get() if hasattr(self, 'trans_cat_var') else "All"
            type_filter = self.trans_type_var.get() if hasattr(self, 'trans_type_var') else "All"
            
            query = """
                SELECT t.id, t.trans_date, t.trans_type, a.account_name, t.counterpart,
                       t.category, t.amount, t.balance_after, t.description, t.currency
                FROM bank_transactions t
                LEFT JOIN bank_accounts a ON t.account_id = a.id
                WHERE 1=1
            """
            params = []
            
            if cat_filter and cat_filter != "All":
                query += " AND t.category = ?"
                params.append(cat_filter)
            
            if type_filter and type_filter != "All":
                if "IN" in type_filter:
                    query += " AND t.trans_type = 'IN'"
                elif "OUT" in type_filter:
                    query += " AND t.trans_type = 'OUT'"
            
            query += " ORDER BY t.trans_date DESC, t.id DESC LIMIT 100"
            
            cur.execute(query, params)
            for row in cur.fetchall():
                trans_type = row[2]
                amount = row[6] or 0
                currency = row[9] or "USD"
                
                # Format type and amount
                if trans_type == "IN":
                    type_display = "🟢 입금"
                    amount_display = f"+{amount:,.0f}"
                else:
                    type_display = "🔴 출금"
                    amount_display = f"-{amount:,.0f}"
                
                balance = row[7] or 0
                
                self.trans_tree.insert("", "end", iid=str(row[0]), values=(
                    row[0],  # id (hidden)
                    row[1] or "",  # date
                    type_display,  # type
                    row[3] or "",  # account
                    row[4] or "",  # counterpart
                    row[5] or "",  # category
                    amount_display,  # amount
                    f"{balance:,.0f}",  # balance
                    row[8] or ""  # description
                ))
            
            # Load currency balances
            cur.execute("SELECT currency, COALESCE(SUM(balance), 0) FROM bank_accounts WHERE is_active=1 GROUP BY currency")
            balances = {row[0]: row[1] for row in cur.fetchall()}
            
            usd_bal = balances.get("USD", 0)
            mxn_bal = balances.get("MXN", 0)
            
            if hasattr(self, 'usd_balance_label'):
                self.usd_balance_label.configure(text=f"${usd_bal:,.2f}")
            if hasattr(self, 'mxn_balance_label'):
                self.mxn_balance_label.configure(text=f"${mxn_bal:,.2f}")
                
        except Exception as e:
            print(f"Load transactions error: {e}")
        finally:
            conn.close()
    
    # Keep old method for compatibility
    def _load_cashflow(self):
        self._load_transactions()

    def _load_pl_data(self):
        """Wrapper to load P&L data with current date filters"""
        start_date = self.date_from_var.get() or "2020-01-01"
        end_date = self.date_to_var.get() or datetime.now().strftime("%Y-%m-%d")
        self._load_pl(start_date, end_date)

    def _load_pl(self, start_date, end_date):
        """Load P&L Report - Update labels with data"""
        # Check if P&L tab is set up
        if not hasattr(self, 'pl_period_label'):
            return
            
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Revenue by category
            cur.execute("""
                SELECT freight_code, SUM(total) as total
                FROM settlement_items
                WHERE item_type = 'REVENUE' AND invoice_date BETWEEN ? AND ?
                GROUP BY freight_code
            """, (start_date, end_date))
            
            revenue_items = cur.fetchall()
            total_revenue = sum(r[1] or 0 for r in revenue_items)
            
            # Categorize revenue
            freight_income = 0
            service_income = 0
            other_income = 0
            for code, amount in revenue_items:
                code = (code or "").upper()
                if code in ["OFR", "AFR", "LFR", "THC"]:
                    freight_income += amount or 0
                elif code in ["DOC", "CFS", "CUS", "HAZ", "INS"]:
                    service_income += amount or 0
                else:
                    other_income += amount or 0

            # Cost by category
            cur.execute("""
                SELECT freight_code, SUM(total) as total
                FROM settlement_items
                WHERE item_type = 'COST' AND invoice_date BETWEEN ? AND ?
                GROUP BY freight_code
            """, (start_date, end_date))
            
            cost_items = cur.fetchall()
            total_cost = sum(c[1] or 0 for c in cost_items)
            
            # Categorize cost
            freight_cost = 0
            trucking_cost = 0
            customs_cost = 0
            other_cost = 0
            for code, amount in cost_items:
                code = (code or "").upper()
                if code in ["OFR", "AFR", "LFR", "THC"]:
                    freight_cost += amount or 0
                elif code in ["DEL", "PKP", "TRK"]:
                    trucking_cost += amount or 0
                elif code in ["CUS", "CFS", "DOC"]:
                    customs_cost += amount or 0
                else:
                    other_cost += amount or 0

            # Update labels
            self.pl_period_label.configure(text=f"Period: {start_date} to {end_date}")
            
            # Revenue
            self.pl_gross_revenue_label.configure(text=f"${total_revenue:,.2f}")
            self.pl_freight_income_label.configure(text=f"${freight_income:,.2f}")
            self.pl_service_income_label.configure(text=f"${service_income:,.2f}")
            self.pl_other_income_label.configure(text=f"${other_income:,.2f}")
            
            # Cost
            self.pl_total_cogs_label.configure(text=f"${total_cost:,.2f}")
            self.pl_freight_cost_label.configure(text=f"${freight_cost:,.2f}")
            self.pl_trucking_cost_label.configure(text=f"${trucking_cost:,.2f}")
            self.pl_customs_cost_label.configure(text=f"${customs_cost:,.2f}")
            self.pl_other_cost_label.configure(text=f"${other_cost:,.2f}")
            
            # Gross Profit
            gross_profit = total_revenue - total_cost
            color = "#4CAF50" if gross_profit >= 0 else "#F44336"
            self.pl_gross_profit_label.configure(text=f"${gross_profit:,.2f}", text_color=color)
            
            # Operating expenses (placeholder - would need separate tracking)
            opex = 0
            self.pl_total_opex_label.configure(text=f"${opex:,.2f}")
            self.pl_salary_label.configure(text="$0.00")
            self.pl_rent_label.configure(text="$0.00")
            self.pl_admin_label.configure(text="$0.00")
            
            # Net Profit
            net_profit = gross_profit - opex
            color = "#4CAF50" if net_profit >= 0 else "#F44336"
            self.pl_net_profit_label.configure(text=f"${net_profit:,.2f}", text_color=color)
            
            # Margin
            margin = (net_profit / total_revenue * 100) if total_revenue > 0 else 0
            self.pl_margin_label.configure(text=f"Profit Margin: {margin:.1f}%")

        except Exception as e:
            print(f"P&L load error: {e}")
        finally:
            conn.close()

    def _generate_aging(self):
        """Generate aging report"""
        for item in self.aging_tree.get_children():
            self.aging_tree.delete(item)

        item_type = "REVENUE" if self.aging_type.get() == "Receivable" else "COST"
        
        conn = get_connection()
        cur = conn.cursor()
        
        totals = {"Current": 0, "1-30 Days": 0, "31-60 Days": 0, "61-90 Days": 0, "90+ Days": 0, "Total": 0}
        
        try:
            cur.execute("""
                SELECT customer, total, invoice_date
                FROM settlement_items
                WHERE item_type = ? AND status != 'PAID'
            """, (item_type,))
            
            today = datetime.now()
            customer_data = {}
            
            for row in cur.fetchall():
                customer = row[0] or "Unknown"
                amount = row[1] or 0
                inv_date = row[2] or ""
                
                days = 0
                if inv_date:
                    try:
                        inv = datetime.strptime(inv_date, "%Y-%m-%d")
                        days = (today - inv).days
                    except:
                        pass
                
                if customer not in customer_data:
                    customer_data[customer] = {"current": 0, "d30": 0, "d60": 0, "d90": 0, "d90plus": 0, "total": 0}
                
                if days <= 0:
                    customer_data[customer]["current"] += amount
                    totals["Current"] += amount
                elif days <= 30:
                    customer_data[customer]["d30"] += amount
                    totals["1-30 Days"] += amount
                elif days <= 60:
                    customer_data[customer]["d60"] += amount
                    totals["31-60 Days"] += amount
                elif days <= 90:
                    customer_data[customer]["d90"] += amount
                    totals["61-90 Days"] += amount
                else:
                    customer_data[customer]["d90plus"] += amount
                    totals["90+ Days"] += amount
                
                customer_data[customer]["total"] += amount
                totals["Total"] += amount

            # Update summary labels
            for key, lbl in self.aging_labels.items():
                lbl.configure(text=f"${totals[key]:,.2f}")

            # Add to tree
            for cust, data in customer_data.items():
                self.aging_tree.insert("", "end", values=(
                    cust,
                    f"${data['current']:,.2f}",
                    f"${data['d30']:,.2f}",
                    f"${data['d60']:,.2f}",
                    f"${data['d90']:,.2f}",
                    f"${data['d90plus']:,.2f}",
                    f"${data['total']:,.2f}"
                ))

        except Exception as e:
            print(f"Aging error: {e}")
        finally:
            conn.close()

    def _add_bank_account(self):
        """Add new bank account"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Add Bank Account")
        dialog.geometry("400x300")
        dialog.transient(self)
        dialog.grab_set()
        
        ctk.CTkLabel(dialog, text="Add Bank Account", font=("SF Pro Display", 14, "bold")).pack(pady=15)
        
        form = ctk.CTkFrame(dialog, fg_color="#F9FAFB")
        form.pack(fill="x", padx=20, pady=10)
        
        entries = {}
        for lbl, key in [("Account Name:", "name"), ("Bank Name:", "bank"), ("Account No:", "acc_no"), ("Currency:", "currency")]:
            row = ctk.CTkFrame(form, fg_color="transparent")
            row.pack(fill="x", padx=15, pady=5)
            ctk.CTkLabel(row, text=lbl, width=100).pack(side="left")
            if key == "currency":
                var = tk.StringVar(value="USD")
                ttk.Combobox(row, textvariable=var, values=["USD", "MXN"], width=10, state="readonly").pack(side="left", padx=5)
            else:
                var = tk.StringVar()
                ctk.CTkEntry(row, textvariable=var, width=180).pack(side="left", padx=5)
            entries[key] = var
        
        def save():
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT INTO bank_accounts (account_name, bank_name, account_number, currency, balance, is_active, created_at)
                    VALUES (?, ?, ?, ?, 0, 1, ?)
                """, (entries["name"].get(), entries["bank"].get(), entries["acc_no"].get(), entries["currency"].get(), now_str()))
                conn.commit()
                dialog.destroy()
                self._load_cashflow()
            except Exception as e:
                messagebox.showerror("Error", f"Failed: {e}")
            finally:
                conn.close()
        
        ctk.CTkButton(dialog, text="Save", width=100, command=save).pack(pady=15)

    def _open_transaction(self):
        """Open new transaction dialog"""
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, account_name, bank_name, account_number, currency, balance FROM bank_accounts WHERE is_active=1")
        accounts = cur.fetchall()
        conn.close()
        
        if not accounts:
            messagebox.showwarning("Warning", "No bank accounts found. Please add an account first.")
            return
        
        def save_transaction(data):
            conn = get_connection()
            cur = conn.cursor()
            try:
                # Get current balance
                cur.execute("SELECT balance FROM bank_accounts WHERE id = ?", (data['account_id'],))
                current_bal = cur.fetchone()[0] or 0
                
                # Calculate new balance
                if data['type'] == 'IN':
                    new_bal = current_bal + data['amount']
                else:
                    new_bal = current_bal - data['amount']
                
                # Insert transaction
                cur.execute("""
                    INSERT INTO bank_transactions (trans_date, trans_type, account_id, counterpart,
                        category, amount, currency, reference, description, balance_after, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (data['date'], data['type'], data['account_id'], data['counterpart'],
                      data['category'], data['amount'], data['currency'], data['reference'],
                      data['description'], new_bal, now_str()))
                
                # Update account balance
                cur.execute("UPDATE bank_accounts SET balance = ? WHERE id = ?", (new_bal, data['account_id']))
                
                conn.commit()
                
                type_text = "입금" if data['type'] == 'IN' else "출금"
                messagebox.showinfo("Success", f"{type_text} 완료\n금액: {data['amount']:,.0f} {data['currency']}")
                self._load_transactions()
            except Exception as e:
                conn.rollback()
                messagebox.showerror("Error", f"Save failed: {e}")
            finally:
                conn.close()
        
        TransactionDialog(self, accounts, save_transaction)
    
    def _edit_transaction(self):
        """Edit selected transaction"""
        sel = self.trans_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a transaction to edit.")
            return
        
        trans_id = int(sel[0])
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT t.id, t.trans_date, t.trans_type, t.account_id, t.counterpart,
                       t.category, t.amount, t.currency, t.reference, t.description
                FROM bank_transactions t
                WHERE t.id = ?
            """, (trans_id,))
            trans = cur.fetchone()
            
            if not trans:
                messagebox.showerror("Error", "Transaction not found.")
                return
            
            cur.execute("SELECT id, account_name, bank_name, account_number, currency, balance FROM bank_accounts WHERE is_active=1")
            accounts = cur.fetchall()
        finally:
            conn.close()
        
        edit_data = {
            'id': trans[0],
            'date': trans[1],
            'type': trans[2],
            'account_id': trans[3],
            'counterpart': trans[4],
            'category': trans[5],
            'amount': trans[6],
            'currency': trans[7],
            'reference': trans[8],
            'description': trans[9]
        }
        
        def save_edit(data):
            conn = get_connection()
            cur = conn.cursor()
            try:
                old_amount = edit_data['amount']
                old_type = edit_data['type']
                new_amount = data['amount']
                new_type = data['type']
                account_id = data['account_id']
                
                # Calculate balance adjustment
                # First reverse old transaction
                if old_type == 'IN':
                    adjustment = -old_amount
                else:
                    adjustment = old_amount
                
                # Then apply new transaction
                if new_type == 'IN':
                    adjustment += new_amount
                else:
                    adjustment -= new_amount
                
                # Get current balance and calculate new
                cur.execute("SELECT balance FROM bank_accounts WHERE id = ?", (account_id,))
                current_bal = cur.fetchone()[0] or 0
                new_bal = current_bal + adjustment
                
                # Update transaction
                cur.execute("""
                    UPDATE bank_transactions SET
                        trans_date = ?, trans_type = ?, counterpart = ?,
                        category = ?, amount = ?, reference = ?, description = ?, balance_after = ?
                    WHERE id = ?
                """, (data['date'], new_type, data['counterpart'], data['category'],
                      new_amount, data['reference'], data['description'], new_bal, trans_id))
                
                # Update account balance
                cur.execute("UPDATE bank_accounts SET balance = ? WHERE id = ?", (new_bal, account_id))
                
                conn.commit()
                messagebox.showinfo("Success", "Transaction updated.")
                self._load_transactions()
            except Exception as e:
                conn.rollback()
                messagebox.showerror("Error", f"Update failed: {e}")
            finally:
                conn.close()
        
        TransactionDialog(self, accounts, save_edit, edit_data)
    
    def _delete_transaction(self):
        """Delete selected transaction"""
        sel = self.trans_tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a transaction to delete.")
            return
        
        trans_id = int(sel[0])
        values = self.trans_tree.item(sel[0], "values")
        
        if not messagebox.askyesno("Confirm Delete", 
                                   f"Delete this transaction?\n\nDate: {values[1]}\nType: {values[2]}\nAmount: {values[6]}"):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Get transaction details
            cur.execute("SELECT account_id, trans_type, amount FROM bank_transactions WHERE id = ?", (trans_id,))
            trans = cur.fetchone()
            
            if trans:
                account_id, trans_type, amount = trans
                
                # Reverse balance
                cur.execute("SELECT balance FROM bank_accounts WHERE id = ?", (account_id,))
                current_bal = cur.fetchone()[0] or 0
                
                if trans_type == 'IN':
                    new_bal = current_bal - amount
                else:
                    new_bal = current_bal + amount
                
                cur.execute("UPDATE bank_accounts SET balance = ? WHERE id = ?", (new_bal, account_id))
                cur.execute("DELETE FROM bank_transactions WHERE id = ?", (trans_id,))
                
                conn.commit()
                messagebox.showinfo("Deleted", "Transaction deleted and balance reversed.")
                self._load_transactions()
            else:
                messagebox.showerror("Error", "Transaction not found.")
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Delete failed: {e}")
        finally:
            conn.close()
    
    # Keep old methods for compatibility
    def _open_transfer(self):
        self._open_transaction()
    
    def _edit_transfer(self):
        self._edit_transaction()
    
    def _delete_transfer(self):
        self._delete_transaction()

    def _add_journal_entry(self):
        """Add manual journal entry"""
        messagebox.showinfo("Info", "Journal entries are automatically created from Settlement.\n\nGo to Settlement → Add Revenue/Cost items.")

    def _export(self, report_type):
        """Export report to CSV"""
        filename = f"{report_type}_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        filepath = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=filename)
        
        if not filepath:
            return

        try:
            lines = []
            
            if report_type == "journal":
                lines.append("ID,Date,Job No,Account,Description,Debit,Credit,Currency")
                for item in self.journal_tree.get_children():
                    vals = self.journal_tree.item(item, "values")
                    lines.append(",".join(str(v) for v in vals))
            
            elif report_type == "ar":
                lines.append("Job No,Customer,Invoice,Amount,Paid,Balance,Due Date,Status,Days")
                for item in self.ar_tree.get_children():
                    vals = self.ar_tree.item(item, "values")
                    lines.append(",".join(str(v) for v in vals))
            
            elif report_type == "ap":
                lines.append("Job No,Vendor,Invoice,Amount,Paid,Balance,Due Date,Status,Days")
                for item in self.ap_tree.get_children():
                    vals = self.ap_tree.item(item, "values")
                    lines.append(",".join(str(v) for v in vals))
            
            elif report_type == "aging":
                lines.append("Customer/Vendor,Current,1-30 Days,31-60 Days,61-90 Days,90+ Days,Total")
                for item in self.aging_tree.get_children():
                    vals = self.aging_tree.item(item, "values")
                    lines.append(",".join(str(v) for v in vals))
            
            elif report_type == "pl":
                lines.append(f"Profit & Loss Report")
                lines.append("")
                lines.append("See on-screen report for details")

            with open(filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            
            messagebox.showinfo("Exported", f"Report saved to:\n{filepath}")

        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {e}")
