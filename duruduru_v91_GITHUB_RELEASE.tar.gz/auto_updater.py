# auto_updater.py
# Automatic Update System for DURUDURU
# Uses GitHub Releases for version management

import os
import sys
import json
import shutil
import tempfile
import threading
import subprocess
from datetime import datetime

# Version info
APP_VERSION = "1.0.91"
APP_NAME = "DURUDURU"

# GitHub repository settings
# ⚠️ 아래 값을 실제 GitHub 사용자명으로 변경하세요!
GITHUB_OWNER = "yjhong-staticweb"  # ← GitHub 사용자명
GITHUB_REPO = "duruduru-releases"  # ← 저장소 이름
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/latest"

# Local config
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".duruduru")
UPDATE_CONFIG_FILE = os.path.join(CONFIG_DIR, "update_config.json")


def get_current_version():
    """Get current app version"""
    return APP_VERSION


def parse_version(version_str):
    """Parse version string to tuple for comparison"""
    try:
        # Remove 'v' prefix if present
        v = version_str.lower().replace('v', '').strip()
        parts = v.split('.')
        return tuple(int(p) for p in parts)
    except:
        return (0, 0, 0)


def is_newer_version(remote_version, local_version):
    """Check if remote version is newer than local"""
    remote = parse_version(remote_version)
    local = parse_version(local_version)
    return remote > local


def check_for_updates(callback=None):
    """
    Check GitHub for latest release
    callback(has_update, version, download_url, release_notes)
    """
    def _check():
        try:
            import urllib.request
            import ssl
            import certifi
            
            # Use certifi for SSL certificates (fixes macOS SSL issue)
            try:
                ctx = ssl.create_default_context(cafile=certifi.where())
            except:
                # Fallback: disable SSL verification (not recommended for production)
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            
            req = urllib.request.Request(
                GITHUB_API_URL,
                headers={'User-Agent': 'DURUDURU-Updater/1.0'}
            )
            
            with urllib.request.urlopen(req, context=ctx, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                remote_version = data.get('tag_name', '0.0.0')
                release_notes = data.get('body', '')
                
                # Find the right asset for current platform
                download_url = None
                assets = data.get('assets', [])
                
                if sys.platform == 'win32':
                    # Look for Windows installer
                    for asset in assets:
                        name = asset.get('name', '').lower()
                        if name.endswith('.exe') or name.endswith('.msi'):
                            download_url = asset.get('browser_download_url')
                            break
                elif sys.platform == 'darwin':
                    # Look for macOS installer or tar.gz
                    for asset in assets:
                        name = asset.get('name', '').lower()
                        if name.endswith('.dmg') or name.endswith('.pkg') or name.endswith('.tar.gz'):
                            download_url = asset.get('browser_download_url')
                            break
                else:
                    # Linux - look for tar.gz or AppImage
                    for asset in assets:
                        name = asset.get('name', '').lower()
                        if name.endswith('.tar.gz') or name.endswith('.appimage'):
                            download_url = asset.get('browser_download_url')
                            break
                
                # Fallback to source
                if not download_url:
                    download_url = data.get('zipball_url')
                
                has_update = is_newer_version(remote_version, APP_VERSION)
                
                if callback:
                    callback(has_update, remote_version, download_url, release_notes)
                
                return has_update, remote_version, download_url, release_notes
                
        except Exception as e:
            print(f"Update check failed: {e}")
            if callback:
                callback(False, None, None, str(e))
            return False, None, None, str(e)
    
    # Run in background thread
    thread = threading.Thread(target=_check, daemon=True)
    thread.start()
    return thread


def download_update(url, progress_callback=None):
    """
    Download update file
    progress_callback(downloaded_bytes, total_bytes, percent)
    Returns: path to downloaded file or None
    """
    try:
        import urllib.request
        import ssl
        
        ctx = ssl.create_default_context()
        
        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'DURUDURU-Updater/1.0'}
        )
        
        # Get filename from URL
        filename = url.split('/')[-1]
        if '?' in filename:
            filename = filename.split('?')[0]
        
        # Create temp directory for download
        download_dir = os.path.join(tempfile.gettempdir(), 'duruduru_update')
        os.makedirs(download_dir, exist_ok=True)
        download_path = os.path.join(download_dir, filename)
        
        with urllib.request.urlopen(req, context=ctx, timeout=60) as response:
            total_size = int(response.headers.get('Content-Length', 0))
            downloaded = 0
            block_size = 8192
            
            with open(download_path, 'wb') as f:
                while True:
                    chunk = response.read(block_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    if progress_callback and total_size > 0:
                        percent = (downloaded / total_size) * 100
                        progress_callback(downloaded, total_size, percent)
        
        return download_path
        
    except Exception as e:
        print(f"Download failed: {e}")
        return None


def install_update_windows(installer_path):
    """Install update on Windows"""
    try:
        if installer_path.endswith('.exe'):
            # Run installer silently
            subprocess.Popen([installer_path, '/SILENT'], shell=True)
        elif installer_path.endswith('.msi'):
            subprocess.Popen(['msiexec', '/i', installer_path, '/quiet'], shell=True)
        
        # Exit current app
        sys.exit(0)
        
    except Exception as e:
        print(f"Install failed: {e}")
        return False


def install_update_macos(installer_path):
    """Install update on macOS"""
    try:
        if installer_path.endswith('.dmg'):
            # Mount DMG and copy app
            subprocess.run(['hdiutil', 'attach', installer_path], check=True)
            # User needs to manually drag app
            subprocess.run(['open', '/Volumes/'])
        elif installer_path.endswith('.pkg'):
            subprocess.run(['open', installer_path], check=True)
        
        return True
        
    except Exception as e:
        print(f"Install failed: {e}")
        return False


def get_update_settings():
    """Get update settings"""
    try:
        if os.path.exists(UPDATE_CONFIG_FILE):
            with open(UPDATE_CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    
    return {
        'auto_check': True,
        'auto_download': False,
        'last_check': None,
        'skip_version': None
    }


def save_update_settings(settings):
    """Save update settings"""
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(UPDATE_CONFIG_FILE, 'w') as f:
            json.dump(settings, f, indent=2)
    except:
        pass


# ============================================================
# UPDATE DIALOG (Tkinter/CustomTkinter)
# ============================================================
def show_update_dialog(parent, version, download_url, release_notes):
    """Show update available dialog"""
    try:
        import customtkinter as ctk
        from tkinter import messagebox
        
        dialog = ctk.CTkToplevel(parent)
        dialog.title("🔄 Update Available")
        dialog.geometry("450x350")
        dialog.transient(parent)
        dialog.grab_set()
        
        # Center on screen
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() - 450) // 2
        y = (dialog.winfo_screenheight() - 350) // 2
        dialog.geometry(f"450x350+{x}+{y}")
        
        # Content
        ctk.CTkLabel(dialog, text="🎉 New Version Available!", 
                    font=("SF Pro Display", 18, "bold")).pack(pady=(20, 10))
        
        ctk.CTkLabel(dialog, text=f"Version {version}", 
                    font=("SF Pro Display", 14), text_color="#059669").pack(pady=5)
        
        ctk.CTkLabel(dialog, text=f"Current: {APP_VERSION}", 
                    font=("SF Pro Display", 11), text_color="#888").pack()
        
        # Release notes
        notes_frame = ctk.CTkFrame(dialog, fg_color="#F5F5F5", corner_radius=8)
        notes_frame.pack(fill="both", expand=True, padx=20, pady=15)
        
        ctk.CTkLabel(notes_frame, text="What's New:", 
                    font=("SF Pro Display", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        
        notes_text = ctk.CTkTextbox(notes_frame, height=100, font=("SF Pro Display", 10))
        notes_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        notes_text.insert("1.0", release_notes[:500] if release_notes else "Bug fixes and improvements")
        notes_text.configure(state="disabled")
        
        # Progress bar (hidden initially)
        progress_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        progress_var = ctk.DoubleVar(value=0)
        progress_bar = ctk.CTkProgressBar(progress_frame, variable=progress_var, width=300)
        progress_label = ctk.CTkLabel(progress_frame, text="", font=("SF Pro Display", 10))
        
        def start_download():
            progress_frame.pack(fill="x", padx=20, pady=5)
            progress_bar.pack(pady=5)
            progress_label.pack()
            update_btn.configure(state="disabled", text="Downloading...")
            
            def on_progress(downloaded, total, percent):
                progress_var.set(percent / 100)
                progress_label.configure(text=f"{downloaded // 1024} KB / {total // 1024} KB ({percent:.1f}%)")
                dialog.update()
            
            def do_download():
                path = download_update(download_url, on_progress)
                if path:
                    dialog.after(0, lambda: on_download_complete(path))
                else:
                    dialog.after(0, lambda: messagebox.showerror("Error", "Download failed"))
            
            thread = threading.Thread(target=do_download, daemon=True)
            thread.start()
        
        def on_download_complete(path):
            progress_label.configure(text="Download complete! Installing...")
            dialog.update()
            
            if sys.platform == 'win32':
                install_update_windows(path)
            elif sys.platform == 'darwin':
                install_update_macos(path)
                messagebox.showinfo("Update", "Please drag the app to Applications folder.")
            
            dialog.destroy()
        
        # Buttons
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(btn_frame, text="Later", width=100, fg_color="#9E9E9E",
                     command=dialog.destroy).pack(side="left")
        
        update_btn = ctk.CTkButton(btn_frame, text="⬇️ Update Now", width=120, 
                                   fg_color="#059669", command=start_download)
        update_btn.pack(side="right")
        
    except Exception as e:
        print(f"Update dialog error: {e}")


def check_updates_on_startup(parent):
    """Check for updates when app starts"""
    settings = get_update_settings()
    
    if not settings.get('auto_check', True):
        return
    
    def on_check_complete(has_update, version, url, notes):
        if has_update and version != settings.get('skip_version'):
            parent.after(2000, lambda: show_update_dialog(parent, version, url, notes))
    
    check_for_updates(on_check_complete)


# ============================================================
# CLI for manual update check
# ============================================================
if __name__ == "__main__":
    print(f"DURUDURU Auto-Updater")
    print(f"Current Version: {APP_VERSION}")
    print(f"Checking for updates...")
    
    import time
    result = [None]
    
    def on_result(has_update, version, url, notes):
        result[0] = (has_update, version, url, notes)
    
    check_for_updates(on_result)
    
    # Wait for result
    for _ in range(50):
        if result[0]:
            break
        time.sleep(0.1)
    
    if result[0]:
        has_update, version, url, notes = result[0]
        if has_update:
            print(f"\n✓ Update available: {version}")
            print(f"Download: {url}")
        else:
            print(f"\n✓ You're up to date!")
    else:
        print("\n✗ Could not check for updates")
