#!/usr/bin/env python3
"""
Windows EXE 빌드 스크립트
PyInstaller를 사용하여 Windows용 실행파일 생성

사용법:
    1. Windows에서 실행:
       pip install pyinstaller
       python build_windows.py
    
    2. Mac에서 Windows용 빌드 (Wine 필요):
       brew install wine-stable
       wine pip install pyinstaller
       wine python build_windows.py
"""

import os
import sys
import shutil
import subprocess

APP_NAME = "DURUDURU"
VERSION = "1.0.0"
ICON = "app_icon.ico"

# PyInstaller 스펙 파일 생성
SPEC_CONTENT = f'''
# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('app_icon.ico', '.'),
        ('app_icon.iconset', 'app_icon.iconset'),
    ],
    hiddenimports=[
        'customtkinter',
        'tkinter',
        'sqlite3',
        'PIL',
        'PIL._tkinter_finder',
    ],
    hookspath=[],
    hooksconfig={{}},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='{APP_NAME}',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='{ICON}',
    version='version_info.txt',
)
'''

# Windows 버전 정보 파일
VERSION_INFO = f'''
VSVersionInfo(
  ffi=FixedFileInfo(
    filevers=({VERSION.replace(".", ", ")}, 0),
    prodvers=({VERSION.replace(".", ", ")}, 0),
    mask=0x3f,
    flags=0x0,
    OS=0x40004,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo(
      [
      StringTable(
        u'040904B0',
        [StringStruct(u'CompanyName', u'DURUDURU'),
        StringStruct(u'FileDescription', u'Freight Forwarding System'),
        StringStruct(u'FileVersion', u'{VERSION}'),
        StringStruct(u'InternalName', u'{APP_NAME}'),
        StringStruct(u'LegalCopyright', u'© 2024 DURUDURU'),
        StringStruct(u'OriginalFilename', u'{APP_NAME}.exe'),
        StringStruct(u'ProductName', u'{APP_NAME}'),
        StringStruct(u'ProductVersion', u'{VERSION}')])
      ]),
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)
'''

def build():
    print(f"Building {APP_NAME} v{VERSION} for Windows...")
    
    # Write spec file
    with open(f"{APP_NAME}.spec", "w") as f:
        f.write(SPEC_CONTENT)
    
    # Write version info
    with open("version_info.txt", "w") as f:
        f.write(VERSION_INFO)
    
    # Run PyInstaller
    cmd = ["pyinstaller", "--clean", f"{APP_NAME}.spec"]
    subprocess.run(cmd, check=True)
    
    print(f"\\n✅ Build complete! EXE located at: dist/{APP_NAME}.exe")
    print(f"   Size: {os.path.getsize(f'dist/{APP_NAME}.exe') / 1024 / 1024:.1f} MB")

if __name__ == "__main__":
    build()