# pdf_invoice.py
# PDF Invoice Generation Module
# Created: 2026-01-09

import os
from datetime import datetime
from typing import Dict, List, Optional
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT

from db import get_connection


class InvoicePDFExporter:
    """Export invoices (Debit Note / Credit Note) to PDF"""
    
    def __init__(self, company_info: Dict = None):
        self.company_info = company_info or {
            "name": "DURUDURU LOGISTICS",
            "address": "Mexico City, Mexico",
            "phone": "+52 55 1234 5678",
            "email": "info@duruduru.com",
            "tax_id": "RFC: DUR123456ABC"
        }
        self.styles = getSampleStyleSheet()
        self._setup_styles()
    
    def _setup_styles(self):
        """Setup custom styles"""
        self.styles.add(ParagraphStyle(
            name='InvoiceTitle',
            parent=self.styles['Heading1'],
            fontSize=22,
            textColor=colors.HexColor('#1E40AF'),
            spaceAfter=15,
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='CompanyName',
            parent=self.styles['Normal'],
            fontSize=14,
            textColor=colors.HexColor('#1E40AF'),
            spaceAfter=3,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        self.styles.add(ParagraphStyle(
            name='CompanyInfo',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#666666'),
            alignment=TA_CENTER
        ))
        
        self.styles.add(ParagraphStyle(
            name='SectionHead',
            parent=self.styles['Normal'],
            fontSize=11,
            textColor=colors.white,
            backColor=colors.HexColor('#374151'),
            fontName='Helvetica-Bold',
            spaceBefore=10,
            spaceAfter=5
        ))
        
        self.styles.add(ParagraphStyle(
            name='TableCell',
            parent=self.styles['Normal'],
            fontSize=9,
            leading=12
        ))
        
        self.styles.add(ParagraphStyle(
            name='TotalLabel',
            parent=self.styles['Normal'],
            fontSize=12,
            fontName='Helvetica-Bold',
            alignment=TA_RIGHT
        ))
    
    def generate_debit_note(self, job_id: int, invoice_no: str, output_path: str) -> str:
        """Generate Debit Note (매출 청구서) PDF"""
        return self._generate_invoice(job_id, invoice_no, "DEBIT", output_path)
    
    def generate_credit_note(self, job_id: int, invoice_no: str, output_path: str) -> str:
        """Generate Credit Note (매입 청구서) PDF"""
        return self._generate_invoice(job_id, invoice_no, "CREDIT", output_path)
    
    def _generate_invoice(self, job_id: int, invoice_no: str, inv_type: str, output_path: str) -> str:
        """Generate invoice PDF"""
        # Fetch data
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Job info
            cur.execute("""
                SELECT j.job_no, j.shipper, j.consignee, j.pol, j.pod, j.etd, j.eta,
                       j.vessel, j.voyage, j.mbl_no, j.hbl_no, j.container_info,
                       c.name as customer_name, c.address, c.phone, c.email
                FROM jobs j
                LEFT JOIN companies c ON j.customer_id = c.id
                WHERE j.id = ?
            """, (job_id,))
            job = cur.fetchone()
            
            if not job:
                raise ValueError(f"Job {job_id} not found")
            
            # Settlement items
            item_type = "REVENUE" if inv_type == "DEBIT" else "COST"
            cur.execute("""
                SELECT freight_code, description, unit, qty, currency, rate, amount,
                       vendor_name, customer_name
                FROM settlement_items
                WHERE job_id = ? AND item_type = ? AND invoice_no = ?
                ORDER BY id
            """, (job_id, item_type, invoice_no))
            items = cur.fetchall()
            
        finally:
            conn.close()
        
        # Create PDF
        doc = SimpleDocTemplate(output_path, pagesize=letter,
                               topMargin=0.5*inch, bottomMargin=0.5*inch,
                               leftMargin=0.75*inch, rightMargin=0.75*inch)
        
        story = []
        
        # Header
        story.append(Paragraph(self.company_info["name"], self.styles['CompanyName']))
        story.append(Paragraph(self.company_info["address"], self.styles['CompanyInfo']))
        story.append(Paragraph(f"Tel: {self.company_info['phone']} | Email: {self.company_info['email']}", self.styles['CompanyInfo']))
        story.append(Paragraph(self.company_info.get("tax_id", ""), self.styles['CompanyInfo']))
        story.append(Spacer(1, 20))
        
        # Invoice title
        title = "DEBIT NOTE" if inv_type == "DEBIT" else "CREDIT NOTE"
        title_color = "#059669" if inv_type == "DEBIT" else "#DC2626"
        self.styles['InvoiceTitle'].textColor = colors.HexColor(title_color)
        story.append(Paragraph(title, self.styles['InvoiceTitle']))
        
        # Invoice info table
        inv_data = [
            ["Invoice No:", invoice_no, "Date:", datetime.now().strftime("%Y-%m-%d")],
            ["Job No:", job[0] or "", "B/L No:", job[10] or job[9] or ""],
        ]
        inv_table = Table(inv_data, colWidths=[1.2*inch, 2*inch, 1*inch, 2*inch])
        inv_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#374151')),
            ('TEXTCOLOR', (2, 0), (2, -1), colors.HexColor('#374151')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(inv_table)
        story.append(Spacer(1, 15))
        
        # Bill To / Ship To
        bill_to = job[12] or job[1] or "N/A"  # customer_name or shipper
        bill_addr = job[13] or ""
        
        bill_data = [
            ["BILL TO:", "SHIPMENT INFO:"],
            [bill_to, f"From: {job[3] or 'N/A'}"],
            [bill_addr, f"To: {job[4] or 'N/A'}"],
            [f"Tel: {job[14] or ''}", f"Vessel: {job[7] or ''} / {job[8] or ''}"],
            [f"Email: {job[15] or ''}", f"Container: {job[11] or ''}"],
        ]
        bill_table = Table(bill_data, colWidths=[3.5*inch, 3.5*inch])
        bill_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F3F4F6')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#374151')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(bill_table)
        story.append(Spacer(1, 20))
        
        # Items table
        item_header = ["No", "Code", "Description", "Unit", "Qty", "Rate", "Currency", "Amount"]
        item_data = [item_header]
        
        total_usd = 0
        total_mxn = 0
        
        for idx, item in enumerate(items, 1):
            code, desc, unit, qty, curr, rate, amount, vendor, customer = item
            item_data.append([
                str(idx),
                code or "",
                desc or "",
                unit or "",
                f"{qty:.0f}" if qty else "1",
                f"{rate:,.2f}" if rate else "0.00",
                curr or "USD",
                f"{amount:,.2f}" if amount else "0.00"
            ])
            if curr == "MXN":
                total_mxn += amount or 0
            else:
                total_usd += amount or 0
        
        # Add empty rows if less than 5 items
        while len(item_data) < 6:
            item_data.append(["", "", "", "", "", "", "", ""])
        
        items_table = Table(item_data, colWidths=[0.4*inch, 0.7*inch, 2.5*inch, 0.6*inch, 0.5*inch, 0.9*inch, 0.6*inch, 1*inch])
        items_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#374151')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('ALIGN', (0, 1), (0, -1), 'CENTER'),
            ('ALIGN', (3, 1), (-1, -1), 'CENTER'),
            ('ALIGN', (-1, 1), (-1, -1), 'RIGHT'),
            ('ALIGN', (-2, 1), (-2, -1), 'RIGHT'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(items_table)
        story.append(Spacer(1, 15))
        
        # Totals
        total_data = []
        if total_usd > 0:
            total_data.append(["", "", "", "", "", "", "Total USD:", f"${total_usd:,.2f}"])
        if total_mxn > 0:
            total_data.append(["", "", "", "", "", "", "Total MXN:", f"${total_mxn:,.2f}"])
        
        if total_data:
            totals_table = Table(total_data, colWidths=[0.4*inch, 0.7*inch, 2.5*inch, 0.6*inch, 0.5*inch, 0.9*inch, 0.6*inch, 1*inch])
            totals_table.setStyle(TableStyle([
                ('FONTNAME', (-2, 0), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('ALIGN', (-2, 0), (-2, -1), 'RIGHT'),
                ('ALIGN', (-1, 0), (-1, -1), 'RIGHT'),
                ('TEXTCOLOR', (-1, 0), (-1, -1), colors.HexColor(title_color)),
            ]))
            story.append(totals_table)
        
        story.append(Spacer(1, 30))
        
        # Payment info
        payment_info = """
        <b>Payment Information:</b><br/>
        Bank: BBVA Mexico<br/>
        Account: 0123456789<br/>
        CLABE: 012345678901234567<br/>
        SWIFT: BCMRMXMM
        """
        story.append(Paragraph(payment_info, self.styles['TableCell']))
        
        story.append(Spacer(1, 20))
        
        # Footer
        footer_text = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')} | DURUDURU Logistics System"
        story.append(Paragraph(footer_text, self.styles['CompanyInfo']))
        
        # Build PDF
        doc.build(story)
        return output_path
    
    def generate_settlement_report(self, job_id: int, output_path: str) -> str:
        """Generate complete settlement report with revenue and cost"""
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # Job info
            cur.execute("""
                SELECT j.job_no, j.shipper, j.consignee, j.pol, j.pod, j.etd, j.eta,
                       j.vessel, j.voyage, j.mbl_no, j.hbl_no, j.container_info,
                       c.name as customer_name
                FROM jobs j
                LEFT JOIN companies c ON j.customer_id = c.id
                WHERE j.id = ?
            """, (job_id,))
            job = cur.fetchone()
            
            if not job:
                raise ValueError(f"Job {job_id} not found")
            
            # Revenue items
            cur.execute("""
                SELECT freight_code, description, unit, qty, currency, rate, amount, customer_name, status
                FROM settlement_items WHERE job_id = ? AND item_type = 'REVENUE' ORDER BY id
            """, (job_id,))
            revenues = cur.fetchall()
            
            # Cost items
            cur.execute("""
                SELECT freight_code, description, unit, qty, currency, rate, amount, vendor_name, status
                FROM settlement_items WHERE job_id = ? AND item_type = 'COST' ORDER BY id
            """, (job_id,))
            costs = cur.fetchall()
            
        finally:
            conn.close()
        
        # Create PDF
        doc = SimpleDocTemplate(output_path, pagesize=letter,
                               topMargin=0.5*inch, bottomMargin=0.5*inch,
                               leftMargin=0.75*inch, rightMargin=0.75*inch)
        
        story = []
        
        # Header
        story.append(Paragraph(self.company_info["name"], self.styles['CompanyName']))
        story.append(Spacer(1, 10))
        story.append(Paragraph("SETTLEMENT REPORT", self.styles['InvoiceTitle']))
        
        # Job info
        job_data = [
            ["Job No:", job[0] or "", "Customer:", job[12] or ""],
            ["Route:", f"{job[3] or ''} → {job[4] or ''}", "B/L:", job[10] or job[9] or ""],
            ["Vessel:", f"{job[7] or ''} / {job[8] or ''}", "Container:", job[11] or ""],
        ]
        job_table = Table(job_data, colWidths=[1*inch, 2.5*inch, 1*inch, 2.5*inch])
        job_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(job_table)
        story.append(Spacer(1, 20))
        
        # Revenue section
        story.append(Paragraph("📈 REVENUE (매출)", self.styles['SectionHead']))
        
        rev_header = ["Code", "Description", "Unit", "Qty", "Rate", "Amount", "Status"]
        rev_data = [rev_header]
        rev_total = 0
        
        for item in revenues:
            rev_data.append([
                item[0] or "", item[1] or "", item[2] or "",
                f"{item[3]:.0f}" if item[3] else "1",
                f"{item[5]:,.2f}" if item[5] else "0",
                f"{item[6]:,.2f}" if item[6] else "0",
                item[8] or ""
            ])
            rev_total += item[6] or 0
        
        rev_data.append(["", "", "", "", "TOTAL:", f"${rev_total:,.2f}", ""])
        
        rev_table = Table(rev_data, colWidths=[0.7*inch, 2.2*inch, 0.6*inch, 0.5*inch, 0.9*inch, 1*inch, 0.8*inch])
        rev_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (4, -1), (5, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#059669')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (4, -1), (5, -1), colors.HexColor('#D1FAE5')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
            ('ALIGN', (3, 0), (-1, -1), 'CENTER'),
            ('ALIGN', (4, 1), (5, -1), 'RIGHT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(rev_table)
        story.append(Spacer(1, 15))
        
        # Cost section
        story.append(Paragraph("📉 COST (매입)", self.styles['SectionHead']))
        
        cost_header = ["Code", "Description", "Vendor", "Qty", "Rate", "Amount", "Status"]
        cost_data = [cost_header]
        cost_total = 0
        
        for item in costs:
            cost_data.append([
                item[0] or "", item[1] or "", item[7] or "",
                f"{item[3]:.0f}" if item[3] else "1",
                f"{item[5]:,.2f}" if item[5] else "0",
                f"{item[6]:,.2f}" if item[6] else "0",
                item[8] or ""
            ])
            cost_total += item[6] or 0
        
        cost_data.append(["", "", "", "", "TOTAL:", f"${cost_total:,.2f}", ""])
        
        cost_table = Table(cost_data, colWidths=[0.7*inch, 1.5*inch, 1.3*inch, 0.5*inch, 0.9*inch, 1*inch, 0.8*inch])
        cost_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (4, -1), (5, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#DC2626')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BACKGROUND', (4, -1), (5, -1), colors.HexColor('#FEE2E2')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
            ('ALIGN', (3, 0), (-1, -1), 'CENTER'),
            ('ALIGN', (4, 1), (5, -1), 'RIGHT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
        ]))
        story.append(cost_table)
        story.append(Spacer(1, 20))
        
        # Profit summary
        profit = rev_total - cost_total
        margin = (profit / rev_total * 100) if rev_total > 0 else 0
        profit_color = "#059669" if profit >= 0 else "#DC2626"
        
        summary_data = [
            ["PROFIT SUMMARY"],
            [f"Revenue: ${rev_total:,.2f}"],
            [f"Cost: ${cost_total:,.2f}"],
            [f"Profit: ${profit:,.2f} ({margin:.1f}%)"],
        ]
        summary_table = Table(summary_data, colWidths=[3*inch])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (0, 0), 12),
            ('FONTSIZE', (0, 1), (-1, -1), 11),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#374151')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('TEXTCOLOR', (0, -1), (-1, -1), colors.HexColor(profit_color)),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#374151')),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(summary_table)
        
        story.append(Spacer(1, 30))
        footer_text = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')} | DURUDURU Logistics System"
        story.append(Paragraph(footer_text, self.styles['CompanyInfo']))
        
        doc.build(story)
        return output_path


# Convenience functions
def export_debit_note(job_id: int, invoice_no: str, output_dir: str = None) -> str:
    """Export debit note PDF"""
    output_dir = output_dir or os.path.expanduser("~/Documents")
    filename = f"DN_{invoice_no.replace('/', '-')}_{datetime.now().strftime('%Y%m%d')}.pdf"
    output_path = os.path.join(output_dir, filename)
    
    exporter = InvoicePDFExporter()
    return exporter.generate_debit_note(job_id, invoice_no, output_path)


def export_credit_note(job_id: int, invoice_no: str, output_dir: str = None) -> str:
    """Export credit note PDF"""
    output_dir = output_dir or os.path.expanduser("~/Documents")
    filename = f"CN_{invoice_no.replace('/', '-')}_{datetime.now().strftime('%Y%m%d')}.pdf"
    output_path = os.path.join(output_dir, filename)
    
    exporter = InvoicePDFExporter()
    return exporter.generate_credit_note(job_id, invoice_no, output_path)


def export_settlement_report(job_id: int, output_dir: str = None) -> str:
    """Export settlement report PDF"""
    output_dir = output_dir or os.path.expanduser("~/Documents")
    filename = f"Settlement_{job_id}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    output_path = os.path.join(output_dir, filename)
    
    exporter = InvoicePDFExporter()
    return exporter.generate_settlement_report(job_id, output_path)
