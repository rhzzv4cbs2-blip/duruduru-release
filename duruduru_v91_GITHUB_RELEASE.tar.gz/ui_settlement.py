# ui_settlement.py
# Settlement Management - Revenue/Cost with Right-Click Actions
# v12: Integrated error handling and design system

import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog
import tkinter as tk
import json
from datetime import datetime
import os

# =============================================================================
# I18N IMPORT
# =============================================================================
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"

# =============================================================================
# IMPORTS WITH FALLBACKS
# =============================================================================

# Error handling
try:
    from error_handler import (
        logger, handle_errors, ErrorContext, 
        show_error_dialog, show_success_dialog, confirm_dialog,
        validate_required, validate_positive, ErrorSeverity
    )
    HAS_ERROR_HANDLER = True
except ImportError:
    HAS_ERROR_HANDLER = False
    import logging
    logger = logging.getLogger(__name__)
    
    def handle_errors(*args, **kwargs):
        def decorator(func):
            return func
        return decorator
    
    def show_error_dialog(msg, *args):
        messagebox.showerror("Error", msg)
    
    def show_success_dialog(msg, *args):
        messagebox.showinfo("Success", msg)
    
    def confirm_dialog(msg, *args):
        return messagebox.askyesno("Confirm", msg)

# Design system
try:
    from ui_design import COLORS, TYPOGRAPHY, SPACING, Icons, ComponentStyles
    HAS_DESIGN_SYSTEM = True
except ImportError:
    HAS_DESIGN_SYSTEM = False
    COLORS = None

# Database and utilities - with fallbacks
try:
    from utils import (
        get_connection, now_str, today_str,
        fetch_freight_codes, fetch_customers_for_combo, fetch_vendors_for_combo,
        get_exchange_rate, format_currency, parse_number, execute_query
    )
except ImportError:
    from db import get_connection, now_str
    
    def today_str():
        return datetime.now().strftime("%Y-%m-%d")
    
    def fetch_freight_codes():
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT code, description, default_currency FROM freight_codes ORDER BY code")
            return cur.fetchall()
        except:
            return []
        finally:
            conn.close()
    
    def fetch_customers_for_combo():
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT code, name FROM companies WHERE company_type IN ('CUSTOMER', 'BOTH') ORDER BY code")
            return cur.fetchall()
        except:
            cur.execute("SELECT code, name FROM companies ORDER BY code")
            return cur.fetchall()
        finally:
            conn.close()
    
    def fetch_vendors_for_combo():
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT code, name FROM companies WHERE company_type IN ('VENDOR', 'BOTH') ORDER BY code")
            return cur.fetchall()
        except:
            return []
        finally:
            conn.close()
    
    def get_exchange_rate():
        return 20.0
    
    def format_currency(amount, currency="USD"):
        return f"${amount:,.2f}"
    
    def parse_number(value, default=0):
        try:
            return float(str(value).replace(",", "").replace("$", ""))
        except:
            return default
    
    def execute_query(query, params=(), fetch=None):
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute(query, params)
            if fetch == "one":
                return cur.fetchone()
            elif fetch == "all":
                return cur.fetchall()
            conn.commit()
            return cur
        finally:
            conn.close()

# Theme (fallback if not available)
try:
    from theme import get_theme, Icons as ThemeIcons
    Icons = ThemeIcons
except ImportError:
    class Icons:
        SUCCESS = "✓"
        ERROR = "✗"
        WARNING = "⚠️"
        ADD = "+"
        DELETE = "🗑️"
        SAVE = "💾"
        REFRESH = "🔄"
        SEARCH = "🔍"
        INVOICE = "📄"
        REVENUE = "📈"
        COST = "📉"

# Service Layer integration
try:
    from services import (
        SettlementService, 
        JobService, 
        CompanyService, 
        ExchangeRateService,
        get_services
    )
    from repositories.settlement_repo import SettlementRepository, SettlementItem
    HAS_SERVICE_LAYER = True
except ImportError:
    HAS_SERVICE_LAYER = False
    SettlementService = None
    JobService = None
    CompanyService = None
    ExchangeRateService = None
    get_services = None


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def is_mexico_customer(customer_code):
    """Check if customer is from Mexico"""
    try:
        row = execute_query("""
            SELECT address FROM companies WHERE code = ?
        """, (customer_code,), fetch="one")
        if row and row[0]:
            addr = str(row[0]).upper()
            return "MEXICO" in addr or "MX" in addr or "CDMX" in addr
    except Exception as e:
        logger.warning(f"Error checking Mexico customer: {e}")
    return False


# ============================================================
# FREIGHT CODE SEARCH DIALOG
# ============================================================
class FreightCodeSearchDialog(ctk.CTkToplevel):
    """Dialog for searching and selecting freight codes"""
    
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.title("🔍 Freight Code Search")
        self.geometry("550x450")
        self.transient(parent)
        self.grab_set()
        
        self.callback = callback
        self.selected_code = None
        
        # Search frame
        search_frame = ctk.CTkFrame(self, fg_color="transparent")
        search_frame.pack(fill="x", padx=15, pady=15)
        
        ctk.CTkLabel(search_frame, text="Search:").pack(side="left", padx=5)
        self.search_var = tk.StringVar()
        search_entry = ctk.CTkEntry(search_frame, textvariable=self.search_var, width=300)
        search_entry.pack(side="left", padx=5, fill="x", expand=True)
        search_entry.bind("<KeyRelease>", self._on_search)
        
        ctk.CTkButton(search_frame, text="🔍", width=40, command=self._search).pack(side="left", padx=5)
        
        # Results frame
        result_frame = ctk.CTkFrame(self, fg_color="#F9FAFB", corner_radius=10)
        result_frame.pack(fill="both", expand=True, padx=15, pady=10)
        
        cols = ["code", "description", "currency"]
        self.tree = ttk.Treeview(result_frame, columns=cols, show="headings", height=12)
        self.tree.heading("code", text="CODE")
        self.tree.heading("description", text="DESCRIPTION")
        self.tree.heading("currency", text="CURRENCY")
        self.tree.column("code", width=80, anchor="center")
        self.tree.column("description", width=300, anchor="w")
        self.tree.column("currency", width=80, anchor="center")
        
        scroll = ttk.Scrollbar(result_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        scroll.pack(side="right", fill="y", pady=5)
        
        self.tree.bind("<Double-1>", self._on_select)
        
        # Buttons
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=15)
        
        ctk.CTkButton(btn_frame, text="Select", width=100, fg_color="#059669", command=self._select).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#E5E5EA", text_color="#333", command=self.destroy).pack(side="right", padx=5)
        
        # Load initial data
        self._load_data()
        search_entry.focus_set()
    
    def _load_data(self, search_term=""):
        """Load freight codes"""
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            if search_term:
                cur.execute("""
                    SELECT code, description, default_currency 
                    FROM freight_codes 
                    WHERE code LIKE ? OR description LIKE ?
                    ORDER BY code
                """, (f"%{search_term}%", f"%{search_term}%"))
            else:
                cur.execute("SELECT code, description, default_currency FROM freight_codes ORDER BY code")
            
            for row in cur.fetchall():
                self.tree.insert("", "end", values=row)
        except:
            pass
        finally:
            conn.close()
    
    def _on_search(self, event=None):
        """Handle search input"""
        self._load_data(self.search_var.get())
    
    def _search(self):
        """Search button click"""
        self._load_data(self.search_var.get())
    
    def _on_select(self, event):
        """Handle double-click selection"""
        self._select()
    
    def _select(self):
        """Select current item"""
        sel = self.tree.selection()
        if sel:
            values = self.tree.item(sel[0], "values")
            self.callback(values[0], values[1], values[2])
            self.destroy()


# ============================================================
# QUICK ADD DIALOG
# ============================================================
class QuickAddDialog(ctk.CTkToplevel):
    """Quick dialog for adding rows with minimal input"""
    
    def __init__(self, parent, item_type, job_id, freight_codes, companies, callback):
        super().__init__(parent)
        self.title(f"Quick Add {item_type.title()}")
        self.geometry("450x380")
        self.transient(parent)
        self.grab_set()
        
        self.item_type = item_type
        self.job_id = job_id
        self.freight_codes = freight_codes
        self.companies = companies
        self.callback = callback
        
        # Header
        header_color = "#059669" if item_type == "REVENUE" else "#DC2626"
        header = ctk.CTkFrame(self, fg_color=header_color, corner_radius=0)
        header.pack(fill="x")
        icon = "📈" if item_type == "REVENUE" else "📉"
        ctk.CTkLabel(header, text=f"{icon} Quick Add {item_type.title()}", 
                    font=("SF Pro Display", 14, "bold"), text_color="#FFFFFF").pack(pady=12)
        
        # Form
        form = ctk.CTkFrame(self, fg_color="#F9FAFB")
        form.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Company
        row1 = ctk.CTkFrame(form, fg_color="transparent")
        row1.pack(fill="x", pady=8)
        ctk.CTkLabel(row1, text="Company:", width=80).pack(side="left")
        self.company_var = tk.StringVar()
        company_cb = ttk.Combobox(row1, textvariable=self.company_var, width=30)
        company_cb["values"] = [f"{c[0]} - {c[1]}" for c in companies]
        company_cb.pack(side="left", padx=5)
        
        # Freight Code
        row2 = ctk.CTkFrame(form, fg_color="transparent")
        row2.pack(fill="x", pady=8)
        ctk.CTkLabel(row2, text="F.Code:", width=80).pack(side="left")
        self.fcode_var = tk.StringVar()
        fcode_cb = ttk.Combobox(row2, textvariable=self.fcode_var, width=15)
        fcode_cb["values"] = [f[0] for f in freight_codes]
        fcode_cb.pack(side="left", padx=5)
        
        # Freight Description (auto-filled)
        self.freight_var = tk.StringVar()
        ctk.CTkEntry(row2, textvariable=self.freight_var, width=150, placeholder_text="Description").pack(side="left", padx=5)
        
        def on_fcode_select(e):
            code = self.fcode_var.get()
            for f in freight_codes:
                if f[0] == code:
                    self.freight_var.set(f[1] or "")
                    self.curr_var.set(f[2] or "USD")
                    break
        fcode_cb.bind("<<ComboboxSelected>>", on_fcode_select)
        
        # Currency & Rate
        row3 = ctk.CTkFrame(form, fg_color="transparent")
        row3.pack(fill="x", pady=8)
        ctk.CTkLabel(row3, text="Currency:", width=80).pack(side="left")
        self.curr_var = tk.StringVar(value="USD")
        ttk.Combobox(row3, textvariable=self.curr_var, values=["USD", "MXN", "EUR"], width=8, state="readonly").pack(side="left", padx=5)
        ctk.CTkLabel(row3, text="Rate:").pack(side="left", padx=(20, 5))
        self.rate_var = tk.StringVar(value="0")
        ctk.CTkEntry(row3, textvariable=self.rate_var, width=100).pack(side="left", padx=5)
        
        # Qty
        row4 = ctk.CTkFrame(form, fg_color="transparent")
        row4.pack(fill="x", pady=8)
        ctk.CTkLabel(row4, text="Qty:", width=80).pack(side="left")
        self.qty_var = tk.StringVar(value="1")
        ctk.CTkEntry(row4, textvariable=self.qty_var, width=80).pack(side="left", padx=5)
        
        # Amount preview
        row5 = ctk.CTkFrame(form, fg_color="transparent")
        row5.pack(fill="x", pady=8)
        ctk.CTkLabel(row5, text="Amount:", width=80).pack(side="left")
        self.amount_label = ctk.CTkLabel(row5, text="$0.00", font=("SF Pro Display", 14, "bold"))
        self.amount_label.pack(side="left", padx=5)
        
        # Auto-calculate amount
        def calc_amount(*args):
            try:
                rate = float(self.rate_var.get() or 0)
                qty = float(self.qty_var.get() or 1)
                amount = rate * qty
                vat = amount * 0.16 if self.curr_var.get() == "MXN" else 0
                total = amount + vat
                self.amount_label.configure(text=f"${total:,.2f}")
            except:
                self.amount_label.configure(text="$0.00")
        
        self.rate_var.trace("w", calc_amount)
        self.qty_var.trace("w", calc_amount)
        self.curr_var.trace("w", calc_amount)
        
        # Invoice/Date row
        row6 = ctk.CTkFrame(form, fg_color="transparent")
        row6.pack(fill="x", pady=8)
        ctk.CTkLabel(row6, text="Invoice:", width=80).pack(side="left")
        self.inv_var = tk.StringVar()
        ctk.CTkEntry(row6, textvariable=self.inv_var, width=120).pack(side="left", padx=5)
        ctk.CTkLabel(row6, text="Date:").pack(side="left", padx=(10, 5))
        self.date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        ctk.CTkEntry(row6, textvariable=self.date_var, width=100).pack(side="left", padx=5)
        
        # Buttons
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15, pady=15)
        
        ctk.CTkButton(btn_frame, text="➕ Add & Close", width=120, fg_color=header_color, 
                     command=self._save_and_close).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="➕ Add More", width=100, fg_color="#6C757D",
                     command=self._save_and_continue).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#E5E5EA", text_color="#333",
                     command=self.destroy).pack(side="right", padx=5)
    
    def _save(self):
        """Save the item to database"""
        try:
            rate = float(self.rate_var.get() or 0)
            qty = float(self.qty_var.get() or 1)
            amount = rate * qty
            vat = amount * 0.16 if self.curr_var.get() == "MXN" else 0
            total = amount + vat
            
            cust = self.company_var.get()
            cust_code = cust.split(" - ")[0] if " - " in cust else cust
            
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO settlement_items 
                (job_id, item_type, customer, freight_code, freight_desc, currency, rate, qty, amount, vat, total, 
                 invoice_no, folio, invoice_date, status, created_at, updated_at) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (self.job_id, self.item_type, cust_code, self.fcode_var.get(), self.freight_var.get(),
                  self.curr_var.get(), rate, qty, amount, vat, total, self.inv_var.get(), "", 
                  self.date_var.get(), "PENDING", now_str(), now_str()))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return False
    
    def _save_and_close(self):
        if self._save():
            self.callback()
            self.destroy()
    
    def _save_and_continue(self):
        if self._save():
            self.callback()
            # Clear form for next entry
            self.rate_var.set("0")
            self.inv_var.set("")
            self.fcode_var.set("")
            self.freight_var.set("")


# ============================================================
# SETTLEMENT MANAGEMENT FRAME
# ============================================================
class SettlementMgmtFrame(ctk.CTkFrame):
    """Settlement Management - Revenue/Cost with Right-Click Actions"""

    def __init__(self, master, width=1200, height=800):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        self.current_job_id = None
        self.current_job_no = None
        self.current_job_customer = ""
        self.current_job_customer_code = ""
        self.exchange_rate = 17.5
        
        # Initialize services (v10 Final)
        if HAS_SERVICE_LAYER:
            self._services = get_services()
            self.settlement_service = self._services.settlement
            self.job_service = self._services.job
            self.company_service = self._services.company
            self.exchange_rate_service = self._services.exchange_rate
        else:
            self._services = None
            self.settlement_service = None
            self.job_service = None
            self.company_service = None
            self.exchange_rate_service = None
        
        # Load reference data via services or fallback
        self.freight_codes = self._load_freight_codes()
        self.customers = self._load_customers()
        self.vendors = self._load_vendors()
        
        # Inline edit variables
        self._edit_entry = None
        self._edit_item = None
        self._edit_col = None
        self._edit_frame = None
        self._tab_pressed = False  # Flag to prevent double-save on Tab
        
        # ID mappings (row_num -> db_id) for each item type
        self._rev_id_map = {}
        self._cost_id_map = {}
        
        # Build UI
        self._build_ui()
        
        # Keyboard shortcuts
        self._setup_keyboard_shortcuts()

    def _setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts for common actions"""
        # Get root window for global bindings
        root = self.winfo_toplevel()
        
        # Ctrl/Cmd + S = Save
        root.bind("<Control-s>", lambda e: self._save_items())
        root.bind("<Command-s>", lambda e: self._save_items())
        
        # Ctrl/Cmd + I = Generate Invoice
        root.bind("<Control-i>", lambda e: self._generate_invoice_only())
        root.bind("<Command-i>", lambda e: self._generate_invoice_only())
        
        # Ctrl/Cmd + R = Refresh
        root.bind("<Control-r>", lambda e: self._load_data())
        root.bind("<Command-r>", lambda e: self._load_data())
        
        # F5 = Refresh
        root.bind("<F5>", lambda e: self._load_data())
        
        # Ctrl/Cmd + F = Focus search
        root.bind("<Control-f>", lambda e: self._focus_search())
        root.bind("<Command-f>", lambda e: self._focus_search())
        
        # Escape = Cancel edit
        root.bind("<Escape>", lambda e: self._cancel_edit())
    
    def _focus_search(self):
        """Focus the search entry"""
        try:
            self.search_entry.focus_set()
        except:
            pass
    
    def _delete_selected(self):
        """Delete currently selected row"""
        # Check which tree has selection
        if self.rev_tree.selection():
            self._delete_row("REVENUE")
        elif self.cost_tree.selection():
            self._delete_row("COST")
    
    def _cancel_edit(self):
        """Cancel current inline edit"""
        if self._edit_entry:
            try:
                self._edit_entry.destroy()
            except:
                pass
            self._edit_entry = None
            self._edit_item = None
    
    def _edit_selected(self, tree):
        """Edit selected cell on Enter key"""
        sel = tree.selection()
        if sel:
            item_type = "REVENUE" if tree == self.rev_tree else "COST"
            # Start editing first editable column (rate)
            self._start_cell_edit(tree, sel[0], "#9", item_type)  # Rate column
    
    def _move_to_next_cell(self, tree, event):
        """Move to next cell on Tab"""
        # Prevent default tab behavior
        return "break"

    # ============================================================
    # Service Layer Helper Methods (v10 Final)
    # ============================================================
    
    def _load_freight_codes(self):
        """Load freight codes via service or fallback"""
        try:
            from db import get_connection
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT code, description, default_currency FROM freight_codes ORDER BY code")
            results = cur.fetchall()
            conn.close()
            return results
        except Exception as e:
            print(f"Load freight codes error: {e}")
        return fetch_freight_codes()
    
    def _load_customers(self):
        """Load customers via service or fallback"""
        try:
            if self.company_service:
                return self.company_service.get_customers_for_combo()
        except Exception as e:
            print(f"Load customers error: {e}")
        return fetch_customers_for_combo()
    
    def _load_vendors(self):
        """Load vendors via service or fallback"""
        try:
            if self.company_service:
                return self.company_service.get_vendors_for_combo()
        except Exception as e:
            print(f"Load vendors error: {e}")
        return fetch_vendors_for_combo()
    
    def _build_ui(self):
        """Build the UI components"""
        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")

        # Title
        font_family = get_font_family()
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(10, 5))
        ctk.CTkLabel(title_frame, text=_t("settle.title").upper(), font=(font_family, 20, "bold")).pack(side="left")
        
        self.rate_label = ctk.CTkLabel(title_frame, text=f"USD/MXN: {self.exchange_rate:.4f}", font=(font_family, 12))
        self.rate_label.pack(side="right", padx=10)
        ctk.CTkButton(title_frame, text="🔄", width=30, fg_color="#E5E5EA", text_color="#333", command=self._refresh_rate).pack(side="right")

        # Search
        search_frame = ctk.CTkFrame(self, fg_color="#F9FAFB", corner_radius=10)
        search_frame.pack(fill="x", padx=20, pady=10)

        ctk.CTkLabel(search_frame, text=f"{_t('settle.job_no')} / MBL / HBL:", font=(font_family, 12)).pack(side="left", padx=10, pady=10)
        self.search_var = tk.StringVar()
        search_entry = ctk.CTkEntry(search_frame, textvariable=self.search_var, width=250)
        search_entry.pack(side="left", padx=5, pady=10)
        search_entry.bind("<Return>", lambda e: self._search_job())
        ctk.CTkButton(search_frame, text=f"🔍 {_t('btn.search')}", width=100, command=self._search_job).pack(side="left", padx=10)
        
        # Recent jobs dropdown
        ctk.CTkLabel(search_frame, text=_t("dash.recent") + ":", font=(font_family, 12)).pack(side="left", padx=(20, 5))
        self.recent_var = tk.StringVar()
        self.recent_combo = ttk.Combobox(search_frame, textvariable=self.recent_var, width=25, state="readonly")
        self.recent_combo.pack(side="left", padx=5)
        self.recent_combo.bind("<<ComboboxSelected>>", self._on_recent_select)
        self._load_recent_jobs()

        # Job info
        self.job_info_frame = ctk.CTkFrame(self, fg_color="#E8F4FD", corner_radius=10)
        self.job_info_frame.pack(fill="x", padx=20, pady=5)
        self.job_info_label = ctk.CTkLabel(self.job_info_frame, text=_t("ui.no_data"), font=(font_family, 12))
        self.job_info_label.pack(pady=10)

        # Main content
        content_scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        content_scroll.pack(fill="both", expand=True, padx=20, pady=5)

        # === REVENUE ===
        rev_header = ctk.CTkFrame(content_scroll, fg_color="#059669", corner_radius=8)
        rev_header.pack(fill="x", pady=(10, 5))
        ctk.CTkLabel(rev_header, text=f"📈 {_t('settle.revenue').upper()}", font=(font_family, 13, "bold"), text_color="#FFFFFF").pack(side="left", padx=15, pady=8)
        
        rev_btns = ctk.CTkFrame(rev_header, fg_color="transparent")
        rev_btns.pack(side="right", padx=10, pady=5)
        ctk.CTkButton(rev_btns, text=f"➕ {_t('btn.add')}", width=90, fg_color="#388E3C", 
                     command=lambda: self._add_inline_row("REVENUE")).pack(side="left", padx=3)
        ctk.CTkButton(rev_btns, text="📋 Detail", width=70, fg_color="#2E7D32", 
                     command=lambda: self._add_row("REVENUE")).pack(side="left", padx=3)

        rev_table = ctk.CTkFrame(content_scroll, fg_color="#FFFFFF")
        rev_table.pack(fill="x", pady=5)

        cols = ["id", "cust_code", "cust_name", "fcode", "freight", "unit", "qty", "curr", "rate", "amount", "vat", "total", "invoice", "folio", "date"]
        widths = [35, 70, 100, 60, 130, 50, 40, 45, 65, 75, 55, 75, 80, 55, 80]
        titles = ["#", "CODE", "CUSTOMER", "F.CODE", "FREIGHT", "UNIT", "QTY", "CURR", "RATE", "AMOUNT", "VAT", "TOTAL", "INV#", "FOLIO", "DATE"]

        self.rev_tree = ttk.Treeview(rev_table, columns=cols, show="headings", height=6)
        for c, w, t in zip(cols, widths, titles):
            self.rev_tree.heading(c, text=t)
            self.rev_tree.column(c, width=w, anchor="center")
        
        rev_scroll = ttk.Scrollbar(rev_table, orient="vertical", command=self.rev_tree.yview)
        self.rev_tree.configure(yscrollcommand=rev_scroll.set)
        self.rev_tree.pack(side="left", fill="both", expand=True)
        rev_scroll.pack(side="right", fill="y")
        
        self.rev_tree.bind("<Double-1>", lambda e: self._inline_edit(e, "REVENUE"))
        self.rev_tree.bind("<Delete>", lambda e: self._delete_row("REVENUE"))
        self.rev_tree.bind("<Button-3>", lambda e: self._show_context_menu(e, "REVENUE"))
        
        # Revenue context menu
        self.rev_menu = tk.Menu(self, tearoff=0)
        self.rev_menu.add_command(label="➕ Add Row", command=lambda: self._add_inline_row("REVENUE"))
        self.rev_menu.add_command(label="📋 Copy Row", command=lambda: self._copy_row("REVENUE"))
        self.rev_menu.add_command(label="✏️ Edit (Dialog)", command=lambda: self._edit_row("REVENUE"))
        self.rev_menu.add_separator()
        self.rev_menu.add_command(label="➖ Delete Row", command=lambda: self._delete_row("REVENUE"))
        self.rev_menu.add_separator()
        self.rev_menu.add_command(label="✓ Mark as PAID", command=lambda: self._mark_status("REVENUE", "PAID"))
        self.rev_menu.add_command(label="⏳ Mark as PENDING", command=lambda: self._mark_status("REVENUE", "PENDING"))
        self.rev_menu.add_separator()
        self.rev_menu.add_command(label="📄 Create Slip (Receipt)", command=lambda: self._create_slip_from_item("REVENUE"))

        rev_total_frame = ctk.CTkFrame(content_scroll, fg_color="#C8E6C9", corner_radius=8)
        rev_total_frame.pack(fill="x", pady=5)
        self.rev_total = ctk.CTkLabel(rev_total_frame, text="Total: $0.00", font=("SF Pro Display", 12, "bold"))
        self.rev_total.pack(side="left", padx=20, pady=8)
        self.rev_count = ctk.CTkLabel(rev_total_frame, text="(0 items)", font=("SF Pro Display", 10), text_color="#666")
        self.rev_count.pack(side="left", padx=5, pady=8)
        ctk.CTkButton(rev_total_frame, text="📄 Debit Note", width=100, fg_color="#1565C0", command=lambda: self._gen_doc("debit_note")).pack(side="right", padx=5, pady=5)
        ctk.CTkButton(rev_total_frame, text="📋 Proforma", width=100, fg_color="#2E7D32", command=lambda: self._gen_doc("proforma")).pack(side="right", padx=5, pady=5)
        ctk.CTkButton(rev_total_frame, text="📄 Slip", width=70, fg_color="#FF9800", command=lambda: self._create_slip_from_item("REVENUE")).pack(side="right", padx=5, pady=5)
        ctk.CTkButton(rev_total_frame, text="➖ Delete", width=70, fg_color="#C62828", command=lambda: self._delete_row("REVENUE")).pack(side="right", padx=5, pady=5)

        # Separator
        ctk.CTkFrame(content_scroll, height=2, fg_color="#BDBDBD").pack(fill="x", pady=15)

        # === COST ===
        cost_header = ctk.CTkFrame(content_scroll, fg_color="#DC2626", corner_radius=8)
        cost_header.pack(fill="x", pady=(10, 5))
        ctk.CTkLabel(cost_header, text="📉 COST (매입)", font=("SF Pro Display", 14, "bold"), text_color="#FFFFFF").pack(side="left", padx=15, pady=8)
        
        cost_btns = ctk.CTkFrame(cost_header, fg_color="transparent")
        cost_btns.pack(side="right", padx=10, pady=5)
        ctk.CTkButton(cost_btns, text="📥 Load Vendor Quote", width=130, fg_color="#1E40AF", 
                     command=self._load_vendor_quote).pack(side="left", padx=3)
        ctk.CTkButton(cost_btns, text="➕ Add Row", width=90, fg_color="#D32F2F", 
                     command=lambda: self._add_inline_row("COST")).pack(side="left", padx=3)
        ctk.CTkButton(cost_btns, text="📋 Detail", width=70, fg_color="#C62828", 
                     command=lambda: self._add_row("COST")).pack(side="left", padx=3)

        cost_table = ctk.CTkFrame(content_scroll, fg_color="#FFFFFF")
        cost_table.pack(fill="x", pady=5)

        # Use same columns as revenue (cols, widths, titles already defined above)
        self.cost_tree = ttk.Treeview(cost_table, columns=cols, show="headings", height=6)
        for c, w, t in zip(cols, widths, titles):
            self.cost_tree.heading(c, text=t)
            self.cost_tree.column(c, width=w, anchor="center")
        
        cost_scroll = ttk.Scrollbar(cost_table, orient="vertical", command=self.cost_tree.yview)
        self.cost_tree.configure(yscrollcommand=cost_scroll.set)
        self.cost_tree.pack(side="left", fill="both", expand=True)
        cost_scroll.pack(side="right", fill="y")
        
        self.cost_tree.bind("<Double-1>", lambda e: self._inline_edit(e, "COST"))
        self.cost_tree.bind("<Delete>", lambda e: self._delete_row("COST"))
        self.cost_tree.bind("<Button-3>", lambda e: self._show_context_menu(e, "COST"))
        
        # Cost context menu
        self.cost_menu = tk.Menu(self, tearoff=0)
        self.cost_menu.add_command(label="➕ Add Row", command=lambda: self._add_inline_row("COST"))
        self.cost_menu.add_command(label="📋 Copy Row", command=lambda: self._copy_row("COST"))
        self.cost_menu.add_command(label="✏️ Edit (Dialog)", command=lambda: self._edit_row("COST"))
        self.cost_menu.add_separator()
        self.cost_menu.add_command(label="➖ Delete Row", command=lambda: self._delete_row("COST"))
        self.cost_menu.add_separator()
        self.cost_menu.add_command(label="✓ Mark as PAID", command=lambda: self._mark_status("COST", "PAID"))
        self.cost_menu.add_command(label="⏳ Mark as PENDING", command=lambda: self._mark_status("COST", "PENDING"))
        self.cost_menu.add_separator()
        self.cost_menu.add_command(label="📄 Create Slip (Payment)", command=lambda: self._create_slip_from_item("COST"))

        cost_total_frame = ctk.CTkFrame(content_scroll, fg_color="#FFCDD2", corner_radius=8)
        cost_total_frame.pack(fill="x", pady=5)
        self.cost_total = ctk.CTkLabel(cost_total_frame, text="Total: $0.00", font=("SF Pro Display", 12, "bold"))
        self.cost_total.pack(side="left", padx=20, pady=8)
        self.cost_count = ctk.CTkLabel(cost_total_frame, text="(0 items)", font=("SF Pro Display", 10), text_color="#666")
        self.cost_count.pack(side="left", padx=5, pady=8)
        ctk.CTkButton(cost_total_frame, text="📄 Credit Note", width=100, fg_color="#7B1FA2", command=lambda: self._gen_doc("credit_note")).pack(side="right", padx=5, pady=5)
        ctk.CTkButton(cost_total_frame, text="📄 Slip", width=70, fg_color="#FF9800", command=lambda: self._create_slip_from_item("COST")).pack(side="right", padx=5, pady=5)
        ctk.CTkButton(cost_total_frame, text="➖ Delete", width=70, fg_color="#C62828", command=lambda: self._delete_row("COST")).pack(side="right", padx=5, pady=5)

        # === PROFIT ===
        profit_frame = ctk.CTkFrame(content_scroll, fg_color="#374151", corner_radius=10)
        profit_frame.pack(fill="x", pady=(20, 10))

        ctk.CTkLabel(profit_frame, text="💰 PROFIT SUMMARY", font=("SF Pro Display", 16, "bold"), text_color="#FFFFFF").pack(pady=(15, 10))

        profit_grid = ctk.CTkFrame(profit_frame, fg_color="transparent")
        profit_grid.pack(padx=20, pady=10)

        ctk.CTkLabel(profit_grid, text="Revenue:", text_color="#BBDEFB").grid(row=0, column=0, sticky="w", padx=10)
        self.sum_rev = ctk.CTkLabel(profit_grid, text="$0.00", text_color="#FFFFFF", font=("SF Pro Display", 12, "bold"))
        self.sum_rev.grid(row=0, column=1, padx=10)

        ctk.CTkLabel(profit_grid, text="Cost:", text_color="#BBDEFB").grid(row=1, column=0, sticky="w", padx=10)
        self.sum_cost = ctk.CTkLabel(profit_grid, text="$0.00", text_color="#FFFFFF", font=("SF Pro Display", 12, "bold"))
        self.sum_cost.grid(row=1, column=1, padx=10)

        ctk.CTkLabel(profit_grid, text="PROFIT:", text_color="#FFEB3B", font=("SF Pro Display", 14, "bold")).grid(row=2, column=0, sticky="w", padx=10, pady=10)
        self.sum_profit = ctk.CTkLabel(profit_grid, text="$0.00", text_color="#FFEB3B", font=("SF Pro Display", 16, "bold"))
        self.sum_profit.grid(row=2, column=1, padx=10, pady=10)

        self.sum_margin = ctk.CTkLabel(profit_frame, text="Margin: 0%", text_color="#81D4FA")
        self.sum_margin.pack(pady=(0, 15))

        # === ACTION BUTTONS ===
        action_frame = ctk.CTkFrame(content_scroll, fg_color="#F5F5F7", corner_radius=10)
        action_frame.pack(fill="x", pady=15, padx=5)
        
        # Row 1: Invoice Actions
        inv_row = ctk.CTkFrame(action_frame, fg_color="transparent")
        inv_row.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(inv_row, text="📄 Invoice:", font=("SF Pro Display", 12, "bold")).pack(side="left", padx=(0, 10))
        
        ctk.CTkButton(inv_row, text="🧾 Generate Invoice", width=150, height=35, 
                     fg_color="#28A745", hover_color="#218838", font=("SF Pro Display", 12),
                     command=self._generate_invoice_only).pack(side="left", padx=5)
        
        ctk.CTkButton(inv_row, text="❌ Cancel Invoice", width=130, height=35, 
                     fg_color="#DC3545", hover_color="#C82333", font=("SF Pro Display", 12),
                     command=self._cancel_invoice).pack(side="left", padx=5)
        
        # Separator
        ctk.CTkFrame(inv_row, width=2, height=30, fg_color="#CCCCCC").pack(side="left", padx=15)
        
        ctk.CTkLabel(inv_row, text="📋 Slip:", font=("SF Pro Display", 12, "bold")).pack(side="left", padx=(0, 10))
        
        ctk.CTkButton(inv_row, text="📝 Create Slip", width=120, height=35, 
                     fg_color="#FF9800", hover_color="#F57C00", font=("SF Pro Display", 12),
                     command=lambda: self._create_slip_from_item("REVENUE")).pack(side="left", padx=5)
        
        ctk.CTkButton(inv_row, text="🗑️ Cancel Slip", width=120, height=35, 
                     fg_color="#6C757D", hover_color="#5A6268", font=("SF Pro Display", 12),
                     command=self._cancel_slip).pack(side="left", padx=5)
        
        # Row 2: Save and Refresh
        save_row = ctk.CTkFrame(action_frame, fg_color="transparent")
        save_row.pack(fill="x", padx=10, pady=(0, 10))
        
        ctk.CTkButton(save_row, text="💾 Save All", width=120, height=35, 
                     fg_color="#007AFF", hover_color="#0056B3", font=("SF Pro Display", 12),
                     command=self._save_items).pack(side="left", padx=5)
        
        ctk.CTkButton(save_row, text="🔄 Refresh", width=100, height=35, fg_color="#6C757D",
                     command=self._load_data).pack(side="left", padx=5)
        
        # Separator
        ctk.CTkFrame(save_row, width=2, height=30, fg_color="#CCCCCC").pack(side="left", padx=15)
        
        ctk.CTkLabel(save_row, text="📊 Export:", font=("SF Pro Display", 12, "bold")).pack(side="left", padx=(0, 10))
        
        ctk.CTkButton(save_row, text="📄 PDF", width=80, height=35, 
                     fg_color="#5856D6", hover_color="#4745B0",
                     command=self._show_pdf_menu).pack(side="left", padx=5)
        
        ctk.CTkButton(save_row, text="📊 Excel", width=80, height=35, 
                     fg_color="#217346", hover_color="#1A5C38",
                     command=self._export_settlement_excel).pack(side="left", padx=5)

        self._refresh_rate()

    def _show_pdf_menu(self):
        """Show PDF export menu"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="📄 Proforma Invoice", command=lambda: self._gen_doc("proforma"))
        menu.add_command(label="📈 Debit Note (매출)", command=lambda: self._gen_doc("debit_note"))
        menu.add_command(label="📉 Credit Note (매입)", command=lambda: self._gen_doc("credit_note"))
        menu.add_separator()
        menu.add_command(label="📊 Settlement Report", command=self._export_settlement_pdf)
        
        # Show menu at button location
        try:
            menu.tk_popup(self.winfo_pointerx(), self.winfo_pointery())
        finally:
            menu.grab_release()
    
    def _export_settlement_pdf(self):
        """Export settlement report PDF"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        try:
            from pdf_invoice import export_settlement_report
            from tkinter import filedialog
            
            # Ask save location
            fp = filedialog.asksaveasfilename(
                defaultextension=".pdf",
                filetypes=[("PDF files", "*.pdf")],
                initialfile=f"Settlement_{self.current_job_no}_{datetime.now().strftime('%Y%m%d')}.pdf"
            )
            if not fp:
                return
            
            # Generate PDF
            from pdf_invoice import InvoicePDFExporter
            exporter = InvoicePDFExporter()
            exporter.generate_settlement_report(self.current_job_id, fp)
            
            messagebox.showinfo("Success", f"Settlement Report saved:\n{fp}")
            
            # Open file
            if messagebox.askyesno("Open", "Open the PDF file?"):
                import subprocess
                import platform
                if platform.system() == "Darwin":
                    subprocess.run(["open", fp])
                elif platform.system() == "Windows":
                    os.startfile(fp)
                else:
                    subprocess.run(["xdg-open", fp])
                    
        except ImportError as e:
            messagebox.showerror("Error", f"PDF module not available: {e}\nInstall: pip install reportlab")
        except Exception as e:
            messagebox.showerror("Error", f"PDF export failed: {e}")

    def _refresh_rate(self):
        """Refresh exchange rate - try to fetch from DB"""
        try:
            # Get rate from db module
            from db import get_exchange_rate_for_date, today_str
            today = today_str()
            rate = get_exchange_rate_for_date(today)
            self.exchange_rate = rate if rate else 20.50
            self.rate_label.configure(text=f"USD/MXN: {self.exchange_rate:.4f}")
        except Exception as e:
            print(f"Rate refresh error: {e}")
            self.exchange_rate = 20.50
            self.rate_label.configure(text=f"USD/MXN: {self.exchange_rate:.4f}")

    def _load_recent_jobs(self):
        """Load recent jobs for quick access using service layer"""
        if self.job_service:
            try:
                jobs = self.job_service.get_recent_jobs(20)
                self.recent_combo["values"] = [f"{j.job_no} - {j.customer or ''} ({j.mode})" for j in jobs]
                return
            except Exception as e:
                print(f"Service failed, falling back: {e}")
        
        # Fallback to direct DB
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT job_no, customer, mode FROM jobs ORDER BY created_at DESC LIMIT 20")
            jobs = cur.fetchall()
            self.recent_combo["values"] = [f"{j[0]} - {j[1] or ''} ({j[2]})" for j in jobs]
        except:
            pass
        finally:
            conn.close()

    def _on_recent_select(self, event):
        """Handle recent job selection"""
        sel = self.recent_var.get()
        if sel:
            job_no = sel.split(" - ")[0]
            self.search_var.set(job_no)
            self._search_job()

    def _search_job(self):
        """Search job using service layer"""
        s = self.search_var.get().strip()
        if not s:
            return
        
        # Use service layer if available
        if self.job_service:
            try:
                result = self.job_service.search_job(s)
                if result:
                    self.current_job_id = result.id
                    self.current_job_no = result.job_no
                    self.current_job_customer = result.customer
                    self.current_job_customer_code = result.customer_code
                    
                    info_text = f"Job: {result.job_no} | Mode: {result.mode} | MBL: {result.mbl or '-'} | HBL: {result.hbl or '-'} | Customer: {result.customer or '-'} | {result.pol or ''} → {result.pod or ''}"
                    self.job_info_label.configure(text=info_text)
                    self._load_data()
                else:
                    messagebox.showinfo("Not Found", "No job found")
                return
            except Exception as e:
                print(f"Service search failed, falling back: {e}")
        
        # Fallback to direct DB
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT id, job_no, mode, mbl, hbl, customer, pol, pod 
                FROM jobs 
                WHERE job_no LIKE ? OR mbl LIKE ? OR hbl LIKE ? 
                LIMIT 1
            """, (f"%{s}%", f"%{s}%", f"%{s}%"))
            row = cur.fetchone()
            if row:
                self.current_job_id = row[0]
                self.current_job_no = row[1]
                self.current_job_customer = row[5] or ""
                
                self.current_job_customer_code = ""
                if self.current_job_customer:
                    cur.execute("SELECT code FROM companies WHERE name LIKE ? OR code = ? LIMIT 1", 
                               (f"%{self.current_job_customer}%", self.current_job_customer))
                    cust_row = cur.fetchone()
                    if cust_row:
                        self.current_job_customer_code = cust_row[0]
                
                info_text = f"Job: {row[1]} | Mode: {row[2]} | MBL: {row[3] or '-'} | HBL: {row[4] or '-'} | Customer: {row[5] or '-'} | {row[6] or ''} → {row[7] or ''}"
                self.job_info_label.configure(text=info_text)
                self._load_data()
            else:
                messagebox.showinfo("Not Found", "No job found")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

    def _load_data(self):
        """Load settlement data using service layer"""
        if not self.current_job_id:
            return
        
        # Clear trees
        for tree in [self.rev_tree, self.cost_tree]:
            for i in tree.get_children():
                tree.delete(i)
        
        # Initialize id mappings (row_num -> db_id)
        self._rev_id_map = {}
        self._cost_id_map = {}
        
        # Use service layer if available
        if self.settlement_service:
            try:
                # Load revenue items - now returns (row_num, ..., db_id)
                rev_items = self.settlement_service.get_items_for_display(self.current_job_id, "REVENUE")
                for r in rev_items:
                    row_num = r[0]
                    db_id = r[-1]  # Last element is the actual DB id
                    display_values = r[:-1]  # All except last (db_id)
                    self.rev_tree.insert("", "end", iid=str(db_id), values=display_values)
                    self._rev_id_map[row_num] = db_id
                
                # Load cost items
                cost_items = self.settlement_service.get_items_for_display(self.current_job_id, "COST")
                for r in cost_items:
                    row_num = r[0]
                    db_id = r[-1]
                    display_values = r[:-1]
                    self.cost_tree.insert("", "end", iid=str(db_id), values=display_values)
                    self._cost_id_map[row_num] = db_id
                
                self._recalc()
                return
            except Exception as e:
                print(f"Service load failed, falling back: {e}")
        
        # Fallback to direct DB
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Ensure columns exist
            cur.execute("PRAGMA table_info(settlement_items)")
            existing_cols = [c[1] for c in cur.fetchall()]
            
            if "customer_code" not in existing_cols:
                cur.execute("ALTER TABLE settlement_items ADD COLUMN customer_code TEXT DEFAULT ''")
            if "customer_name" not in existing_cols:
                cur.execute("ALTER TABLE settlement_items ADD COLUMN customer_name TEXT DEFAULT ''")
            if "unit" not in existing_cols:
                cur.execute("ALTER TABLE settlement_items ADD COLUMN unit TEXT DEFAULT 'B/L'")
            conn.commit()
            
            # Load revenue items with row_num
            cur.execute("""
                SELECT id, COALESCE(customer_code, ''), COALESCE(customer_name, customer, ''), 
                       freight_code, freight_desc, COALESCE(unit, 'B/L'), qty, currency, rate, 
                       amount, vat, total, invoice_no, folio, invoice_date 
                FROM settlement_items 
                WHERE job_id=? AND item_type='REVENUE' 
                ORDER BY id
            """, (self.current_job_id,))
            for row_num, r in enumerate(cur.fetchall(), start=1):
                db_id = r[0]
                display_values = (row_num,) + r[1:]  # Replace db_id with row_num
                self.rev_tree.insert("", "end", iid=str(db_id), values=display_values)
                self._rev_id_map[row_num] = db_id
            
            # Load cost items with row_num
            cur.execute("""
                SELECT id, COALESCE(customer_code, ''), COALESCE(customer_name, customer, ''), 
                       freight_code, freight_desc, COALESCE(unit, 'B/L'), qty, currency, rate, 
                       amount, vat, total, invoice_no, folio, invoice_date 
                FROM settlement_items 
                WHERE job_id=? AND item_type='COST' 
                ORDER BY id
            """, (self.current_job_id,))
            for row_num, r in enumerate(cur.fetchall(), start=1):
                db_id = r[0]
                display_values = (row_num,) + r[1:]
                self.cost_tree.insert("", "end", iid=str(db_id), values=display_values)
                self._cost_id_map[row_num] = db_id
            
            self._recalc()
        except Exception as e:
            print(f"Load error: {e}")
        finally:
            conn.close()

    def _save_and_generate_invoice(self):
        """
        Save all items and generate invoice numbers.
        All REVENUE items without invoice_no get the SAME DN number.
        All COST items without invoice_no get the SAME CN number.
        """
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Get job info for invoice prefix
            cur.execute("SELECT job_no FROM jobs WHERE id=?", (self.current_job_id,))
            job_row = cur.fetchone()
            job_no = job_row[0] if job_row else "UNKNOWN"
            
            today = datetime.now().strftime("%Y-%m-%d")
            year_month = datetime.now().strftime("%Y%m")
            
            # ============================================================
            # REVENUE - All items without invoice get SAME DN number
            # ============================================================
            rev_items_to_update = []
            for item in self.rev_tree.get_children():
                values = self.rev_tree.item(item, "values")
                item_id = item  # iid is the actual DB id
                invoice_no = values[12] if len(values) > 12 else ""
                
                # Handle None as string or empty
                if str(invoice_no).strip() in ('', 'None', 'null'):
                    invoice_no = None
                
                # Check amount (values[9])
                try:
                    amount = float(str(values[9]).replace(',', '') or 0)
                except:
                    amount = 0
                
                # Collect items that need invoice number
                if not invoice_no and amount > 0:
                    rev_items_to_update.append(item_id)
            
            # Generate ONE invoice number for all revenue items
            rev_count = 0
            if rev_items_to_update:
                # Get max invoice number for this month
                cur.execute("""
                    SELECT invoice_no FROM settlement_items 
                    WHERE item_type='REVENUE' AND invoice_no LIKE ? 
                    ORDER BY invoice_no DESC LIMIT 1
                """, (f"DN-{year_month}-%",))
                last_row = cur.fetchone()
                
                if last_row and last_row[0]:
                    try:
                        last_num = int(last_row[0].spl_t('-')[-1])
                        next_num = last_num + 1
                    except:
                        next_num = 1
                else:
                    next_num = 1
                
                new_invoice_no = f"DN-{year_month}-{next_num:04d}"
                
                # Update ALL collected items with SAME invoice number
                for item_id in rev_items_to_update:
                    cur.execute("UPDATE settlement_items SET invoice_no=?, invoice_date=?, updated_at=? WHERE id=?",
                               (new_invoice_no, today, now_str(), item_id))
                    rev_count += 1
            
            # ============================================================
            # COST - All items without invoice get SAME CN number
            # ============================================================
            cost_items_to_update = []
            for item in self.cost_tree.get_children():
                values = self.cost_tree.item(item, "values")
                item_id = item  # iid is the actual DB id
                invoice_no = values[12] if len(values) > 12 else ""
                
                # Handle None as string or empty
                if str(invoice_no).strip() in ('', 'None', 'null'):
                    invoice_no = None
                
                # Check amount (values[9])
                try:
                    amount = float(str(values[9]).replace(',', '') or 0)
                except:
                    amount = 0
                
                if not invoice_no and amount > 0:
                    cost_items_to_update.append(item_id)
            
            # Generate ONE invoice number for all cost items
            cost_count = 0
            if cost_items_to_update:
                cur.execute("""
                    SELECT invoice_no FROM settlement_items 
                    WHERE item_type='COST' AND invoice_no LIKE ? 
                    ORDER BY invoice_no DESC LIMIT 1
                """, (f"CN-{year_month}-%",))
                last_row = cur.fetchone()
                
                if last_row and last_row[0]:
                    try:
                        last_num = int(last_row[0].spl_t('-')[-1])
                        next_num = last_num + 1
                    except:
                        next_num = 1
                else:
                    next_num = 1
                
                new_invoice_no = f"CN-{year_month}-{next_num:04d}"
                
                # Update ALL collected items with SAME invoice number
                for item_id in cost_items_to_update:
                    cur.execute("UPDATE settlement_items SET invoice_no=?, invoice_date=?, updated_at=? WHERE id=?",
                               (new_invoice_no, today, now_str(), item_id))
                    cost_count += 1
            
            conn.commit()
            self._load_data()
            
            msg = f"Saved successfully!\n"
            if rev_count > 0:
                msg += f"DN: {new_invoice_no if rev_items_to_update else ''} ({rev_count} items)\n"
            if cost_count > 0:
                msg += f"CN: {new_invoice_no if cost_items_to_update else ''} ({cost_count} items)"
            messagebox.showinfo("Saved", msg)
            
        except Exception as e:
            messagebox.showerror("Error", f"Save failed: {e}")
        finally:
            conn.close()

    def _generate_invoice_only(self):
        """Generate invoice numbers for selected items only"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        # Check if there are selected items, otherwise use all without invoice
        rev_sel = self.rev_tree.selection()
        cost_sel = self.cost_tree.selection()
        
        if not rev_sel and not cost_sel:
            # No selection, ask user
            if not messagebox.askyesno("Generate Invoice", 
                "No items selected. Generate invoice for ALL items without invoice number?"):
                return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            year_month = datetime.now().strftime("%Y%m")
            
            # Revenue items
            rev_items = []
            if rev_sel:
                rev_items = [item for item in rev_sel]
            else:
                # Get all items without invoice
                for item in self.rev_tree.get_children():
                    values = self.rev_tree.item(item, "values")
                    invoice_no = values[12] if len(values) > 12 else ""
                    if not invoice_no or str(invoice_no).strip() in ('', 'None', 'null'):
                        rev_items.append(item)
            
            # Generate revenue invoice
            rev_count = 0
            if rev_items:
                cur.execute("""
                    SELECT invoice_no FROM settlement_items 
                    WHERE item_type='REVENUE' AND invoice_no LIKE ? 
                    ORDER BY invoice_no DESC LIMIT 1
                """, (f"DN-{year_month}-%",))
                last_row = cur.fetchone()
                next_num = int(last_row[0].spl_t('-')[-1]) + 1 if last_row and last_row[0] else 1
                new_inv = f"DN-{year_month}-{next_num:04d}"
                
                for item_id in rev_items:
                    cur.execute("UPDATE settlement_items SET invoice_no=?, invoice_date=?, updated_at=? WHERE id=?",
                               (new_inv, today, now_str(), item_id))
                    rev_count += 1
            
            # Cost items
            cost_items = []
            if cost_sel:
                cost_items = [item for item in cost_sel]
            else:
                for item in self.cost_tree.get_children():
                    values = self.cost_tree.item(item, "values")
                    invoice_no = values[12] if len(values) > 12 else ""
                    if not invoice_no or str(invoice_no).strip() in ('', 'None', 'null'):
                        cost_items.append(item)
            
            # Generate cost invoice
            cost_count = 0
            if cost_items:
                cur.execute("""
                    SELECT invoice_no FROM settlement_items 
                    WHERE item_type='COST' AND invoice_no LIKE ? 
                    ORDER BY invoice_no DESC LIMIT 1
                """, (f"CN-{year_month}-%",))
                last_row = cur.fetchone()
                next_num = int(last_row[0].spl_t('-')[-1]) + 1 if last_row and last_row[0] else 1
                new_inv = f"CN-{year_month}-{next_num:04d}"
                
                for item_id in cost_items:
                    cur.execute("UPDATE settlement_items SET invoice_no=?, invoice_date=?, updated_at=? WHERE id=?",
                               (new_inv, today, now_str(), item_id))
                    cost_count += 1
            
            conn.commit()
            self._load_data()
            
            if rev_count > 0 or cost_count > 0:
                msg = "Invoice generated:\n"
                if rev_count > 0:
                    msg += f"Revenue: {rev_count} items\n"
                if cost_count > 0:
                    msg += f"Cost: {cost_count} items"
                messagebox.showinfo("Success", msg)
            else:
                messagebox.showinfo("Info", "No items to generate invoice for")
                
        except Exception as e:
            messagebox.showerror("Error", f"Invoice generation failed: {e}")
        finally:
            conn.close()

    def _cancel_invoice(self):
        """Cancel invoice numbers for selected items"""
        rev_sel = self.rev_tree.selection()
        cost_sel = self.cost_tree.selection()
        
        if not rev_sel and not cost_sel:
            messagebox.showwarning("Select", "Please select items to cancel invoice")
            return
        
        if not messagebox.askyesno("Cancel Invoice", 
            f"Cancel invoice for {len(rev_sel) + len(cost_sel)} selected item(s)?"):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            count = 0
            for item_id in list(rev_sel) + list(cost_sel):
                cur.execute("""
                    UPDATE settlement_items 
                    SET invoice_no = NULL, invoice_date = NULL, updated_at = ? 
                    WHERE id = ?
                """, (now_str(), item_id))
                count += 1
            
            conn.commit()
            self._load_data()
            messagebox.showinfo("Cancelled", f"Invoice cancelled for {count} item(s)")
            
        except Exception as e:
            messagebox.showerror("Error", f"Cancel failed: {e}")
        finally:
            conn.close()

    def _load_vendor_quote(self):
        """Load vendor quote into cost items"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Please select a job first")
            return
        
        # Get POL/POD from current job
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT pol, pod FROM jobs WHERE id=?", (self.current_job_id,))
            job_row = cur.fetchone()
            if not job_row:
                messagebox.showwarning("No Job", "Job not found")
                return
            pol, pod = job_row[0] or "", job_row[1] or ""
        except Exception as e:
            messagebox.showerror("Error", f"Failed to get job info: {e}")
            return
        finally:
            conn.close()
        
        # Create vendor quote selection dialog
        dlg = ctk.CTkToplevel(self)
        dlg.title("📥 Load Vendor Quote")
        dlg.geometry("700x500")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        
        # Header
        hdr = ctk.CTkFrame(dlg, fg_color="#1E40AF", corner_radius=0, height=50)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text=f"📥 Select Vendor Quote", font=("SF Pro Display", 16, "bold"), 
                    text_color="white").pack(side="left", padx=20)
        ctk.CTkLabel(hdr, text=f"Route: {pol} → {pod}", font=("SF Pro Display", 12), 
                    text_color="#93C5FD").pack(side="right", padx=20)
        
        # Quote list
        list_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        list_frame.pack(fill="both", expand=True, padx=20, pady=15)
        
        ctk.CTkLabel(list_frame, text="Available Vendor Quotes:", font=("SF Pro Display", 12, "bold")).pack(anchor="w", pady=(0, 10))
        
        tree_frame = ctk.CTkFrame(list_frame, fg_color="#FFFFFF", corner_radius=8)
        tree_frame.pack(fill="both", expand=True)
        
        cols = ["id", "ref", "vendor", "type", "valid", "status"]
        vq_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=10)
        for c, h, w in [("id", "#", 0), ("ref", "Quote Ref", 120), ("vendor", "Vendor", 150), 
                       ("type", "Type", 80), ("valid", "Valid Until", 100), ("status", "Status", 70)]:
            vq_tree.heading(c, text=h)
            vq_tree.column(c, width=w, anchor="center" if c in ["type", "valid", "status"] else "w")
        vq_tree.column("id", width=0, stretch=False)
        
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=vq_tree.yview)
        vq_tree.configure(yscrollcommand=vsb.set)
        vq_tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        vsb.pack(side="right", fill="y", pady=5)
        
        # Load vendor quotes
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT id, quote_ref, vendor_name, vendor_type, valid_until, status
                FROM vendor_quotes 
                WHERE status = 'ACTIVE' 
                  AND (origin_port LIKE ? OR ? = '')
                  AND (dest_port LIKE ? OR ? = '')
                ORDER BY vendor_name
            """, (f"%{pol}%", pol, f"%{pod}%", pod))
            
            for r in cur.fetchall():
                vq_tree.insert("", "end", iid=str(r[0]), values=(r[0], r[1], r[2], r[3], r[4], r[5]))
        except Exception as e:
            print(f"Load vendor quotes error: {e}")
        finally:
            conn.close()
        
        # Container type selection
        opt_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        opt_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(opt_frame, text="Container Type:").pack(side="left")
        cntr_var = tk.StringVar(value="40HQ")
        ttk.Combobox(opt_frame, textvariable=cntr_var, values=["20GP", "40GP", "40HQ", "CBM", "B/L"], width=10).pack(side="left", padx=10)
        
        ctk.CTkLabel(opt_frame, text="Qty:").pack(side="left", padx=(20, 0))
        qty_var = tk.StringVar(value="1")
        ctk.CTkEntry(opt_frame, textvariable=qty_var, width=60).pack(side="left", padx=5)
        
        def import_quote():
            sel = vq_tree.selection()
            if not sel:
                messagebox.showwarning("Select", "Please select a vendor quote")
                return
            
            vq_id = int(sel[0])
            cntr_type = cntr_var.get()
            qty = float(qty_var.get() or 1)
            
            # Get rate items from vendor quote
            conn = get_connection()
            cur = conn.cursor()
            try:
                # Get vendor info
                cur.execute("SELECT vendor_name, currency FROM vendor_quotes WHERE id=?", (vq_id,))
                vq_info = cur.fetchone()
                vendor_name = vq_info[0] if vq_info else "Unknown"
                currency = vq_info[1] if vq_info else "USD"
                
                # Get rate items
                rate_col = {"20GP": "rate_20gp", "40GP": "rate_40gp", "40HQ": "rate_40hq", 
                           "CBM": "rate_cbm", "B/L": "rate_bl"}.get(cntr_type, "rate_40hq")
                
                cur.execute(f"""
                    SELECT freight_code, description, unit, {rate_col}
                    FROM vendor_quote_items WHERE vq_id=? AND {rate_col} > 0
                """, (vq_id,))
                
                items = cur.fetchall()
                if not items:
                    messagebox.showinfo("No Items", f"No rate items found for {cntr_type}")
                    return
                
                # Insert cost items
                added = 0
                for item in items:
                    code, desc, unit, rate = item
                    # Adjust qty based on unit
                    item_qty = qty if unit == "CNTR" else 1
                    amount = rate * item_qty
                    
                    cur.execute("""
                        INSERT INTO settlement_items 
                        (job_id, item_type, freight_code, description, unit, qty, currency, rate, amount, 
                         vendor_code, vendor_name, status, created_at, updated_at)
                        VALUES (?, 'COST', ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
                    """, (self.current_job_id, code, desc or code, unit, item_qty, currency, rate, amount,
                          "", vendor_name, now_str(), now_str()))
                    added += 1
                
                conn.commit()
                dlg.destroy()
                self._load_data()
                messagebox.showinfo("Imported", f"Imported {added} cost items from {vendor_name}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Import failed: {e}")
            finally:
                conn.close()
        
        # Buttons
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkButton(btn_frame, text="📥 Import", width=100, fg_color="#059669", command=import_quote).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=80, fg_color="#6B7280", command=dlg.destroy).pack(side="right", padx=5)

    def _cancel_slip(self):
        """Cancel slip for selected items"""
        rev_sel = self.rev_tree.selection()
        cost_sel = self.cost_tree.selection()
        
        if not rev_sel and not cost_sel:
            messagebox.showwarning("Select", "Please select items to cancel slip")
            return
        
        # Get slips associated with selected items
        conn = get_connection()
        cur = conn.cursor()
        try:
            slip_count = 0
            for item_id in list(rev_sel) + list(cost_sel):
                # Get invoice_no for the item
                cur.execute("SELECT invoice_no FROM settlement_items WHERE id = ?", (item_id,))
                row = cur.fetchone()
                if row and row[0]:
                    invoice_no = row[0]
                    # Cancel associated slips
                    cur.execute("""
                        UPDATE slips SET status = 'CANCELLED', updated_at = ? 
                        WHERE invoice_no = ? AND status != 'CANCELLED'
                    """, (now_str(), invoice_no))
                    slip_count += cur.rowcount
            
            conn.commit()
            
            if slip_count > 0:
                messagebox.showinfo("Cancelled", f"Cancelled {slip_count} slip(s)")
            else:
                messagebox.showinfo("Info", "No active slips found for selected items")
                
        except Exception as e:
            messagebox.showerror("Error", f"Cancel slip failed: {e}")
        finally:
            conn.close()

    def _save_items(self):
        """Save items without generating invoices"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        # Items are saved as they are edited inline
        # This button is for explicit save confirmation
        self._load_data()
        messagebox.showinfo("Saved", "All changes have been saved")

    def _export_settlement_excel(self):
        """Export settlement data to Excel"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
        except ImportError:
            messagebox.showwarning("Warning", "openpyxl not installed. Run: pip install openpyxl")
            return
        
        from tkinter import filedialog
        filename = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            initialfilename=f"settlement_{self.current_job_no}_{datetime.now().strftime('%Y%m%d')}.xlsx"
        )
        if not filename:
            return
        
        wb = openpyxl.Workbook()
        
        # Styles
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        revenue_fill = PatternFill(start_color="C8E6C9", end_color="C8E6C9", fill_type="solid")
        cost_fill = PatternFill(start_color="FFCDD2", end_color="FFCDD2", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        border = Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')
        )
        
        # Revenue sheet
        ws_rev = wb.active
        ws_rev.title = "Revenue"
        
        headers = ["#", "CODE", "CUSTOMER", "F.CODE", "FREIGHT", "UNIT", "QTY", "CURR", "RATE", "AMOUNT", "VAT", "TOTAL", "INV#", "FOLIO", "DATE"]
        for col, header in enumerate(headers, 1):
            cell = ws_rev.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = border
        
        for row_idx, item in enumerate(self.rev_tree.get_children(), 2):
            values = self.rev_tree.item(item, "values")
            for col_idx, val in enumerate(values, 1):
                cell = ws_rev.cell(row=row_idx, column=col_idx, value=val)
                cell.border = border
        
        # Cost sheet
        ws_cost = wb.create_sheet("Cost")
        for col, header in enumerate(headers, 1):
            cell = ws_cost.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = PatternFill(start_color="D32F2F", end_color="D32F2F", fill_type="solid")
            cell.border = border
        
        for row_idx, item in enumerate(self.cost_tree.get_children(), 2):
            values = self.cost_tree.item(item, "values")
            for col_idx, val in enumerate(values, 1):
                cell = ws_cost.cell(row=row_idx, column=col_idx, value=val)
                cell.border = border
        
        # Summary sheet
        ws_sum = wb.create_sheet("Summary")
        ws_sum["A1"] = f"Job No: {self.current_job_no}"
        ws_sum["A1"].font = Font(bold=True, size=14)
        ws_sum["A3"] = "Total Revenue:"
        ws_sum["B3"] = self.rev_total.cget("text")
        ws_sum["A4"] = "Total Cost:"
        ws_sum["B4"] = self.cost_total.cget("text")
        ws_sum["A5"] = "Profit:"
        ws_sum["B5"] = self.sum_profit.cget("text")
        ws_sum["A5"].font = Font(bold=True)
        ws_sum["B5"].font = Font(bold=True)
        
        # Auto-width
        for ws in [ws_rev, ws_cost]:
            for col in range(1, len(headers) + 1):
                ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 12
        
        try:
            wb.save(filename)
            messagebox.showinfo("Exported", f"Settlement exported to:\n{filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {e}")

    # ============================================================
    # INLINE EDITING
    # ============================================================
    def _inline_edit(self, event, item_type):
        """Handle double-click for inline cell editing"""
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        
        # Identify clicked cell
        region = tree.identify_region(event.x, event.y)
        if region != "cell":
            return
        
        col = tree.identify_column(event.x)
        item = tree.identify_row(event.y)
        if not item or not col:
            return
        
        self._start_cell_edit(tree, item, col, item_type)

    def _start_cell_edit(self, tree, item, col, item_type, col_idx=None):
        """Start editing a cell"""
        if col_idx is None:
            col_idx = int(col.replace('#', '')) - 1
        
        cols = ["id", "cust_code", "cust_name", "fcode", "freight", "unit", "qty", "curr", "rate", "amount", "vat", "total", "invoice", "folio", "date"]
        
        # Don't edit id, amount, vat, total (calculated fields)
        if col_idx in [0, 9, 10, 11]:
            return
        
        col_name = cols[col_idx] if col_idx < len(cols) else ""
        
        # Get cell bounding box
        col_id = f"#{col_idx + 1}"
        bbox = tree.bbox(item, col_id)
        if not bbox:
            return
        
        # Destroy previous edit entry
        if self._edit_entry:
            self._edit_entry.destroy()
        
        # Get current value
        values = tree.item(item, "values")
        current_value = values[col_idx] if col_idx < len(values) else ""
        
        # Special handling for customer_code, freight_code, unit, currency
        if col_name == "cust_code":
            # Use Combobox with customer codes
            entry = ttk.Combobox(tree, justify="center", width=12)
            entry["values"] = self._get_customer_codes()
            entry.set(str(current_value))
            entry.bind("<<ComboboxSelected>>", lambda e: self._on_cust_code_selected(tree, item, entry))
        elif col_name == "fcode":
            # Use Frame with Combobox and search button
            frame = tk.Frame(tree)
            entry = ttk.Combobox(frame, justify="center", width=8)
            entry["values"] = self._get_freight_codes()
            entry.set(str(current_value))
            entry.bind("<<ComboboxSelected>>", lambda e: self._on_freight_code_selected(tree, item, entry))
            entry.pack(side="left", fill="both", expand=True)
            
            # Search button
            search_btn = tk.Button(frame, text="🔍", width=2, 
                                  command=lambda: self._open_freight_search(tree, item, entry))
            search_btn.pack(side="right")
            
            frame.place(x=bbox[0], y=bbox[1], width=bbox[2]+25, height=bbox[3])
            entry.focus_set()
            
            self._edit_entry = entry
            self._edit_frame = frame
            self._edit_item = item
            self._edit_col = col_idx
            self._edit_tree = tree
            self._edit_item_type = item_type
            
            entry.bind("<Return>", lambda e: self._save_inline_edit())
            entry.bind("<Escape>", lambda e: self._cancel_inline_edit())
            entry.bind("<Tab>", self._save_and_next_cell)
            entry.bind("<FocusOut>", lambda e: self.after(100, self._save_inline_edit))
            return
        elif col_name == "unit":
            entry = ttk.Combobox(tree, justify="center", width=8)
            entry["values"] = ["B/L", "R/TON", "CBM", "PCS", "SET", "EA"]
            entry.set(str(current_value))
        elif col_name == "curr":
            entry = ttk.Combobox(tree, justify="center", width=6)
            entry["values"] = ["USD", "MXN"]
            entry.set(str(current_value))
        else:
            entry = tk.Entry(tree, justify="center")
            entry.insert(0, str(current_value))
            entry.select_range(0, tk.END)
        
        # Place entry at cell location
        entry.place(x=bbox[0], y=bbox[1], width=bbox[2], height=bbox[3])
        entry.focus_set()
        
        self._edit_entry = entry
        self._edit_item = item
        self._edit_col = col_idx
        self._edit_tree = tree
        self._edit_item_type = item_type
        
        # Bind events - use self._save_and_next_cell directly for proper "break" return
        entry.bind("<Return>", lambda e: self._save_inline_edit())
        entry.bind("<Escape>", lambda e: self._cancel_inline_edit())
        entry.bind("<Tab>", self._save_and_next_cell)
        entry.bind("<FocusOut>", lambda e: self.after(100, self._save_inline_edit))

    def _get_customer_codes(self):
        """Get list of customer codes from cached customers"""
        # Use cached customers if available
        if hasattr(self, 'customers') and self.customers:
            return [c[0] for c in self.customers if c[0]]
        
        # Fallback to database query
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT DISTINCT code FROM companies WHERE code IS NOT NULL AND code != '' ORDER BY code")
            return [row[0] for row in cur.fetchall()]
        except:
            return []
        finally:
            conn.close()

    def _get_freight_codes(self):
        """Get list of freight codes from cached data"""
        # Use cached freight codes if available
        if hasattr(self, 'freight_codes') and self.freight_codes:
            return [f[0] for f in self.freight_codes if f[0]]
        
        # Fallback to database query
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT code FROM freight_codes ORDER BY code")
            return [row[0] for row in cur.fetchall()]
        except:
            return []
        finally:
            conn.close()

    def _on_cust_code_selected(self, tree, item, combobox):
        """When customer code is selected, auto-fill customer name"""
        code = combobox.get()
        if not code:
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT name FROM companies WHERE code = ?", (code,))
            row = cur.fetchone()
            if row:
                # Update customer_name in the current row
                item_id = item  # Use iid as the actual DB id
                cur2 = conn.cursor()
                cur2.execute("UPDATE settlement_items SET customer_code=?, customer_name=?, updated_at=? WHERE id=?",
                           (code, row[0], now_str(), item_id))
                conn.commit()
        except Exception as e:
            print(f"Customer code select error: {e}")
        finally:
            conn.close()

    def _on_freight_code_selected(self, tree, item, combobox):
        """When freight code is selected, auto-fill freight description"""
        code = combobox.get()
        if not code:
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT description, default_currency FROM freight_codes WHERE code = ?", (code,))
            row = cur.fetchone()
            if row:
                values = list(tree.item(item, "values"))
                item_id = item  # Use iid as the actual DB id
                cur2 = conn.cursor()
                cur2.execute("UPDATE settlement_items SET freight_code=?, freight_desc=?, currency=?, updated_at=? WHERE id=?",
                           (code, row[0], row[1], now_str(), item_id))
                conn.commit()
        except Exception as e:
            print(f"Freight code select error: {e}")
        finally:
            conn.close()

    def _open_freight_search(self, tree, item, combobox):
        """Open freight code search dialog"""
        def on_select(code, desc, currency):
            combobox.set(code)
            # Update database
            item_id = item  # Use iid as the actual DB id
            conn = get_connection()
            cur = conn.cursor()
            try:
                cur.execute("UPDATE settlement_items SET freight_code=?, freight_desc=?, currency=?, updated_at=? WHERE id=?",
                           (code, desc, currency, now_str(), item_id))
                conn.commit()
                self._load_data()
            except Exception as e:
                print(f"Freight search select error: {e}")
            finally:
                conn.close()
        
        FreightCodeSearchDialog(self, on_select)

    def _save_and_next_cell(self, event=None):
        """Save current cell and move to next editable cell"""
        if not self._edit_entry:
            return "break"
        
        # Set flag to prevent FocusOut from firing again
        self._tab_pressed = True
        
        try:
            # Save current edit
            new_value = self._edit_entry.get()
            item = self._edit_item
            col_idx = self._edit_col
            tree = self._edit_tree
            item_type = self._edit_item_type
            
            # Destroy entry first
            self._edit_entry.destroy()
            self._edit_entry = None
            
            # Save to database
            self._save_cell_value(tree, item, col_idx, new_value, item_type)
            
            # Editable column indices
            editable_cols = [1, 2, 3, 4, 5, 6, 7, 8, 12, 13, 14]
            
            # Find next editable column
            next_col_idx = None
            for ec in editable_cols:
                if ec > col_idx:
                    next_col_idx = ec
                    break
            
            if next_col_idx is None:
                # Move to first editable column of next row
                children = tree.get_children()
                try:
                    current_idx = children.index(item)
                    if current_idx < len(children) - 1:
                        next_item = children[current_idx + 1]
                        next_col_idx = editable_cols[0]
                        tree.selection_set(next_item)
                        tree.see(next_item)
                        # Schedule the edit to avoid event conflicts
                        self.after(50, lambda: self._start_cell_edit(tree, next_item, f"#{next_col_idx + 1}", item_type, next_col_idx))
                except ValueError:
                    pass
            else:
                # Stay on same row, move to next column
                self.after(50, lambda: self._start_cell_edit(tree, item, f"#{next_col_idx + 1}", item_type, next_col_idx))
        except Exception as e:
            print(f"Tab navigation error: {e}")
        
        return "break"

    def _save_cell_value(self, tree, item, col_idx, new_value, item_type):
        """Save cell value to database"""
        values = list(tree.item(item, "values"))
        if col_idx >= len(values):
            return
        
        # Column mapping for new structure
        db_cols = {
            1: "customer_code",
            2: "customer_name",
            3: "freight_code",
            4: "freight_desc",
            5: "unit",
            6: "qty",
            7: "currency",
            8: "rate",
            12: "invoice_no",
            13: "folio",
            14: "invoice_date"
        }
        
        if col_idx not in db_cols:
            return
        
        db_col = db_cols[col_idx]
        item_id = item  # Use iid as the actual DB id (not values[0] which is row_num)
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # 마감 체크
            from db import check_month_editable
            cur.execute("SELECT invoice_date FROM settlement_items WHERE id=?", (item_id,))
            row = cur.fetchone()
            if row and row[0]:
                is_editable, lock_msg = check_month_editable(row[0])
                if not is_editable:
                    messagebox.showerror("Month Closed", lock_msg)
                    self._load_data()
                    return
            
            # 금액 검증 (qty, rate 컬럼)
            if col_idx in [6, 8]:
                from db import validate_amount
                parsed, error = validate_amount(new_value, "금액" if col_idx == 8 else "수량")
                if error:
                    messagebox.showerror("Invalid Value", error)
                    self._load_data()
                    return
                new_value = parsed
            
            cur.execute(f"UPDATE settlement_items SET {db_col}=?, updated_at=? WHERE id=?",
                       (new_value, now_str(), item_id))
            
            # Recalculate if rate or qty changed
            if col_idx in [6, 8]:  # qty or rate
                cur.execute("SELECT rate, qty, currency FROM settlement_items WHERE id=?", (item_id,))
                row = cur.fetchone()
                if row:
                    rate = float(row[0] or 0)
                    qty = float(row[1] or 1)
                    curr = row[2]
                    amount = rate * qty
                    vat = amount * 0.16 if curr == "MXN" else 0
                    total = amount + vat
                    cur.execute("UPDATE settlement_items SET amount=?, vat=?, total=? WHERE id=?",
                               (amount, vat, total, item_id))
            
            conn.commit()
            self._load_data()
        except Exception as e:
            print(f"Save error: {e}")
        finally:
            conn.close()

    def _save_inline_edit(self):
        """Save the inline edit to database"""
        # If Tab was pressed, don't save here (Tab handler already saved)
        if getattr(self, '_tab_pressed', False):
            self._tab_pressed = False
            return
        
        if not self._edit_entry:
            return
        
        new_value = self._edit_entry.get()
        item = self._edit_item
        col_idx = self._edit_col
        tree = self._edit_tree
        item_type = self._edit_item_type
        
        # Destroy entry and frame if exists
        self._edit_entry.destroy()
        self._edit_entry = None
        if hasattr(self, '_edit_frame') and self._edit_frame:
            try:
                self._edit_frame.destroy()
            except:
                pass
            self._edit_frame = None
        
        # Get current values
        values = list(tree.item(item, "values"))
        if col_idx >= len(values):
            return
        
        # Column mapping for new structure
        # cols = ["row_num", "cust_code", "cust_name", "fcode", "freight", "unit", "qty", "curr", "rate", "amount", "vat", "total", "invoice", "folio", "date"]
        db_cols = {
            1: "customer_code",
            2: "customer_name",
            3: "freight_code",
            4: "freight_desc",
            5: "unit",
            6: "qty",
            7: "currency",
            8: "rate",
            12: "invoice_no",
            13: "folio",
            14: "invoice_date"
        }
        
        if col_idx not in db_cols:
            return
        
        db_col = db_cols[col_idx]
        item_id = item  # Use iid as the actual DB id (not values[0] which is row_num)
        
        # Update database
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Update value
            cur.execute(f"UPDATE settlement_items SET {db_col}=?, updated_at=? WHERE id=?",
                       (new_value, now_str(), item_id))
            
            # Recalculate if rate or qty changed
            if col_idx in [6, 8]:  # qty or rate
                cur.execute("SELECT rate, qty, currency FROM settlement_items WHERE id=?", (item_id,))
                row = cur.fetchone()
                if row:
                    rate = float(row[0] or 0)
                    qty = float(row[1] or 1)
                    curr = row[2]
                    amount = rate * qty
                    vat = amount * 0.16 if curr == "MXN" else 0
                    total = amount + vat
                    cur.execute("UPDATE settlement_items SET amount=?, vat=?, total=? WHERE id=?",
                               (amount, vat, total, item_id))
            
            conn.commit()
            self._load_data()
        except Exception as e:
            messagebox.showerror("Error", f"Update failed: {e}")
        finally:
            conn.close()

    def _cancel_inline_edit(self):
        """Cancel inline edit"""
        if self._edit_entry:
            self._edit_entry.destroy()
            self._edit_entry = None
        if hasattr(self, '_edit_frame') and self._edit_frame:
            try:
                self._edit_frame.destroy()
            except:
                pass
            self._edit_frame = None

    def _add_inline_row(self, item_type):
        """Add new row directly in table"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        # For REVENUE, auto-fill customer from job
        cust_code = ""
        cust_name = ""
        if item_type == "REVENUE":
            cust_code = self.current_job_customer_code or ""
            cust_name = self.current_job_customer or ""
        
        # Insert row with customer data
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                INSERT INTO settlement_items 
                (job_id, item_type, customer, customer_code, customer_name, freight_code, freight_desc, 
                 currency, rate, qty, amount, vat, total, invoice_no, folio, invoice_date, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, '', '', 'USD', 0, 1, 0, 0, 0, '', '', ?, 'PENDING', ?, ?)
            """, (self.current_job_id, item_type, cust_name, cust_code, cust_name, 
                  datetime.now().strftime("%Y-%m-%d"), now_str(), now_str()))
            conn.commit()
            self._load_data()
            
            # Select the new row and start editing first editable cell
            tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
            children = tree.get_children()
            if children:
                last_item = children[-1]
                tree.selection_set(last_item)
                tree.see(last_item)
        except Exception as e:
            messagebox.showerror("Error", f"Add failed: {e}")
        finally:
            conn.close()

    def _show_context_menu(self, event, item_type):
        """Show context menu on right-click"""
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        menu = self.rev_menu if item_type == "REVENUE" else self.cost_menu
        
        # Select row under cursor
        item = tree.identify_row(event.y)
        if item:
            tree.selection_set(item)
        
        menu.post(event.x_root, event.y_root)

    def _quick_add(self, item_type):
        """Open quick add dialog"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        companies = self.customers if item_type == "REVENUE" else self.vendors
        QuickAddDialog(self, item_type, self.current_job_id, self.freight_codes, companies, self._load_data)

    def _add_row(self, item_type):
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        self._open_dialog(item_type, None)

    def _edit_row(self, item_type):
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        sel = tree.selection()
        if sel:
            # Use iid (sel[0]) as the actual DB id, not vals[0] which is row_num
            self._open_dialog(item_type, sel[0])

    def _copy_row(self, item_type):
        """Copy selected row and create a new entry"""
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Select", "Please select a row to copy")
            return
        
        original_id = sel[0]  # Use iid as the actual DB id (not vals[0] which is row_num)
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Get original data
            cur.execute("SELECT * FROM settlement_items WHERE id=?", (original_id,))
            original = cur.fetchone()
            
            if original:
                # Insert copy
                cur.execute("""
                    INSERT INTO settlement_items 
                    (job_id, item_type, customer, freight_code, freight_desc, currency, rate, qty, amount, vat, total, 
                     invoice_no, folio, invoice_date, status, created_at, updated_at) 
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (original[1], original[2], original[3], original[4], original[5], original[6], 
                      original[7], original[8], original[9], original[10], original[11],
                      "", "", datetime.now().strftime("%Y-%m-%d"), "PENDING", now_str(), now_str()))
                conn.commit()
                self._load_data()
                messagebox.showinfo("Copied", "Row copied successfully")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

    def _delete_row(self, item_type):
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        sel = tree.selection()
        if not sel:
            return
        
        if not messagebox.askyesno("Delete", "Delete selected item(s)?"):
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            for item in sel:
                # Use iid as the actual DB id (not values[0] which is row_num)
                db_id = item  # iid is the db_id
                cur.execute("DELETE FROM settlement_items WHERE id=?", (db_id,))
            conn.commit()
            self._load_data()
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

    def _mark_status(self, item_type, status):
        """Mark selected items with status"""
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        sel = tree.selection()
        if not sel:
            return
        
        conn = get_connection()
        cur = conn.cursor()
        try:
            for item in sel:
                # Use iid as the actual DB id
                db_id = item
                cur.execute("UPDATE settlement_items SET status=?, updated_at=? WHERE id=?", 
                           (status, now_str(), db_id))
            conn.commit()
            messagebox.showinfo("Updated", f"Marked {len(sel)} item(s) as {status}")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()

    def _open_dialog(self, item_type, item_id):
        dlg = ctk.CTkToplevel(self)
        dlg.title(f"{'Edit' if item_id else 'Add'} {item_type.title()}")
        dlg.geometry("550x500")
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()

        existing = None
        if item_id:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM settlement_items WHERE id=?", (item_id,))
            existing = cur.fetchone()
            conn.close()

        # Header
        header_color = "#059669" if item_type == "REVENUE" else "#DC2626"
        header = ctk.CTkFrame(dlg, fg_color=header_color, corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(header, text=f"{'Edit' if item_id else 'Add'} {item_type.title()}", 
                    font=("SF Pro Display", 14, "bold"), text_color="#FFFFFF").pack(pady=12)

        form = ctk.CTkFrame(dlg, fg_color="#F9FAFB")
        form.pack(fill="both", expand=True, padx=20, pady=15)

        # Customer
        row0 = ctk.CTkFrame(form, fg_color="transparent")
        row0.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row0, text="Customer:", width=100).pack(side="left")
        cust_var = tk.StringVar(value=existing[3] if existing else "")
        cust_cb = ttk.Combobox(row0, textvariable=cust_var, width=35)
        companies = self.customers if item_type == "REVENUE" else self.vendors
        cust_cb["values"] = [f"{c[0]} - {c[1]}" for c in companies]
        cust_cb.pack(side="left", padx=5)

        # Freight Code
        row1 = ctk.CTkFrame(form, fg_color="transparent")
        row1.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row1, text="F.Code:", width=100).pack(side="left")
        fcode_var = tk.StringVar(value=existing[4] if existing else "")
        fcode_cb = ttk.Combobox(row1, textvariable=fcode_var, width=15)
        fcode_cb["values"] = [f[0] for f in self.freight_codes]
        fcode_cb.pack(side="left", padx=5)

        # Freight
        row2 = ctk.CTkFrame(form, fg_color="transparent")
        row2.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row2, text="Freight:", width=100).pack(side="left")
        freight_var = tk.StringVar(value=existing[5] if existing else "")
        freight_e = ctk.CTkEntry(row2, textvariable=freight_var, width=300)
        freight_e.pack(side="left", padx=5)

        def on_fcode(e):
            code = fcode_var.get()
            for f in self.freight_codes:
                if f[0] == code:
                    freight_var.set(f[1] or "")
                    curr_var.set(f[2] or "USD")
                    break
        fcode_cb.bind("<<ComboboxSelected>>", on_fcode)

        # Currency & Rate
        row3 = ctk.CTkFrame(form, fg_color="transparent")
        row3.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row3, text="Currency:", width=100).pack(side="left")
        curr_var = tk.StringVar(value=existing[6] if existing else "USD")
        ttk.Combobox(row3, textvariable=curr_var, values=["USD", "MXN", "EUR"], width=10, state="readonly").pack(side="left", padx=5)
        
        ctk.CTkLabel(row3, text="Rate:").pack(side="left", padx=(20, 5))
        rate_var = tk.StringVar(value=str(existing[7]) if existing else "0")
        ctk.CTkEntry(row3, textvariable=rate_var, width=100).pack(side="left", padx=5)

        # Qty
        row4 = ctk.CTkFrame(form, fg_color="transparent")
        row4.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row4, text="Qty:", width=100).pack(side="left")
        qty_var = tk.StringVar(value=str(existing[8]) if existing else "1")
        ctk.CTkEntry(row4, textvariable=qty_var, width=80).pack(side="left", padx=5)

        # Invoice
        row5 = ctk.CTkFrame(form, fg_color="transparent")
        row5.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row5, text="Invoice No:", width=100).pack(side="left")
        inv_var = tk.StringVar(value=existing[11] if existing else "")
        ctk.CTkEntry(row5, textvariable=inv_var, width=150).pack(side="left", padx=5)

        # Folio
        row6 = ctk.CTkFrame(form, fg_color="transparent")
        row6.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row6, text="Folio:", width=100).pack(side="left")
        folio_var = tk.StringVar(value=existing[12] if existing else "")
        ctk.CTkEntry(row6, textvariable=folio_var, width=100).pack(side="left", padx=5)

        # Date
        row7 = ctk.CTkFrame(form, fg_color="transparent")
        row7.pack(fill="x", pady=8, padx=10)
        ctk.CTkLabel(row7, text="Date:", width=100).pack(side="left")
        date_var = tk.StringVar(value=existing[13] if existing else datetime.now().strftime("%Y-%m-%d"))
        ctk.CTkEntry(row7, textvariable=date_var, width=100).pack(side="left", padx=5)

        def save():
            try:
                rate = float(rate_var.get() or 0)
                qty = float(qty_var.get() or 1)
                amount = rate * qty
                vat = amount * 0.16 if curr_var.get() == "MXN" else 0
                total = amount + vat
                cust_code = cust_var.get().split(" - ")[0] if " - " in cust_var.get() else cust_var.get()

                conn = get_connection()
                cur = conn.cursor()
                if item_id:
                    cur.execute("""
                        UPDATE settlement_items 
                        SET customer=?, freight_code=?, freight_desc=?, currency=?, rate=?, qty=?, 
                            amount=?, vat=?, total=?, invoice_no=?, folio=?, invoice_date=?, updated_at=? 
                        WHERE id=?
                    """, (cust_code, fcode_var.get(), freight_var.get(), curr_var.get(), rate, qty, 
                          amount, vat, total, inv_var.get(), folio_var.get(), date_var.get(), now_str(), item_id))
                else:
                    cur.execute("""
                        INSERT INTO settlement_items 
                        (job_id, item_type, customer, freight_code, freight_desc, currency, rate, qty, amount, vat, total, 
                         invoice_no, folio, invoice_date, status, created_at, updated_at) 
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (self.current_job_id, item_type, cust_code, fcode_var.get(), freight_var.get(), 
                          curr_var.get(), rate, qty, amount, vat, total, inv_var.get(), folio_var.get(), 
                          date_var.get(), "PENDING", now_str(), now_str()))
                conn.commit()
                conn.close()
                dlg.destroy()
                self._load_data()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=15)
        ctk.CTkButton(btn_frame, text="Save", width=100, fg_color=header_color, command=save).pack(side="right", padx=5)
        ctk.CTkButton(btn_frame, text="Cancel", width=100, fg_color="#E5E5EA", text_color="#333", command=dlg.destroy).pack(side="right", padx=5)

    def _recalc(self):
        rev_items = self.rev_tree.get_children()
        cost_items = self.cost_tree.get_children()
        
        rev_t = sum(float(self.rev_tree.item(i, "values")[9] or 0) for i in rev_items)
        cost_t = sum(float(self.cost_tree.item(i, "values")[9] or 0) for i in cost_items)
        profit = rev_t - cost_t
        margin = (profit / rev_t * 100) if rev_t > 0 else 0

        self.rev_total.configure(text=f"Total: ${rev_t:,.2f}")
        self.rev_count.configure(text=f"({len(rev_items)} items)")
        self.cost_total.configure(text=f"Total: ${cost_t:,.2f}")
        self.cost_count.configure(text=f"({len(cost_items)} items)")
        self.sum_rev.configure(text=f"${rev_t:,.2f}")
        self.sum_cost.configure(text=f"${cost_t:,.2f}")
        self.sum_profit.configure(text=f"${profit:,.2f}", text_color="#059669" if profit >= 0 else "#DC2626")
        self.sum_margin.configure(text=f"Margin: {margin:.1f}%")

    def _export_pdf(self, doc_type):
        """Export to PDF using pdf_export module"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return
        
        try:
            from pdf_export import export_job_documents
            files = export_job_documents(self.current_job_no, ['invoice'])
            if files:
                messagebox.showinfo("PDF Exported", f"Generated: {os.path.basename(files[0])}")
        except ImportError:
            messagebox.showerror("Error", "PDF export module not found")
        except Exception as e:
            messagebox.showerror("Error", f"PDF export failed: {e}")

    def _gen_doc(self, doc_type):
        """Generate PDF document matching KGL template"""
        if not self.current_job_id:
            messagebox.showwarning("No Job", "Select a job first")
            return

        # Check Mexico customer for revenue docs
        if doc_type == "debit_note":
            for i in self.rev_tree.get_children():
                cust = self.rev_tree.item(i, "values")[2]  # cust_name
                if is_mexico_customer(cust):
                    messagebox.showinfo("Info", "Mexican customer detected.\nUse Proforma → Factura instead of Debit Note.")
                    return
                break

        tree = self.rev_tree if doc_type in ["debit_note", "proforma"] else self.cost_tree
        titles = {"debit_note": "DEBIT NOTE", "proforma": "PROFORMA INVOICE", "credit_note": "CREDIT NOTE"}
        
        # Get job details
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""SELECT job_no, mbl, hbl, shipper, consignee, notify, customer, partner, 
                          carrier, vessel, voyage, pol, pod, etd, eta, mode, remarks
                          FROM jobs WHERE id=?""", (self.current_job_id,))
            job = cur.fetchone()
            if not job:
                messagebox.showwarning("Error", "Job not found")
                return
                
            job_no, mbl, hbl, shipper, consignee, notify, customer, partner, \
            carrier, vessel, voyage, pol, pod, etd, eta, mode, remarks = job
            pcs = ""  # pcs is not in jobs table, get from containers if needed
            
            # Try to get pcs from containers (with fallback for missing column)
            try:
                cur.execute("SELECT SUM(CAST(COALESCE(pcs, '0') AS INTEGER)) FROM containers WHERE job_id=?", (self.current_job_id,))
                pcs_row = cur.fetchone()
                if pcs_row and pcs_row[0]:
                    pcs = str(pcs_row[0])
            except Exception as pcs_err:
                print(f"PCS fetch error (may be missing column): {pcs_err}")
                pcs = ""
            
            # Generate D/C Note number
            prefix = "SEMP" if doc_type in ["debit_note", "proforma"] else "SEMC"
            cur.execute("SELECT COUNT(*) FROM settlement_items WHERE invoice_no LIKE ?", (f"{prefix}%",))
            count = cur.fetchone()[0] + 1
            dc_note_no = f"{prefix}{datetime.now().strftime('%y%m')}{count:04d}"
            
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return
        finally:
            conn.close()
        
        # Collect items - use new column structure
        items = []
        for i in tree.get_children():
            v = tree.item(i, "values")
            # cols: id, cust_code, cust_name, fcode, freight, unit, qty, curr, rate, amount, vat, total, invoice, folio, date
            items.append({
                "bl_no": hbl or job_no,
                "description": str(v[4])[:30] if len(v) > 4 else "",
                "unit": str(v[5]) if len(v) > 5 else "B/L",
                "qty": float(v[6] or 1) if len(v) > 6 else 1,
                "currency": str(v[7]) if len(v) > 7 else "USD",
                "rate": float(v[8] or 0) if len(v) > 8 else 0,
                "debit": float(v[9] or 0) if len(v) > 9 and doc_type != "credit_note" else 0,
                "credit": float(v[9] or 0) if len(v) > 9 and doc_type == "credit_note" else 0,
                "vat": float(v[10] or 0) if len(v) > 10 else 0
            })

        if not items:
            messagebox.showwarning("No Data", "No items to export")
            return

        try:
            from reportlab.lib.pagesizes import letter, A4
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch, mm
            from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
            
            fp = filedialog.asksaveasfilename(defaultextension=".pdf", 
                                              filetypes=[("PDF files", "*.pdf")],
                                              initialfile=f"{doc_type}_{job_no}.pdf")
            if not fp:
                return
            
            # Page width for A4: 210mm - 30mm margins = 180mm usable
            page_width = 180*mm
            
            doc = SimpleDocTemplate(fp, pagesize=A4, topMargin=12*mm, bottomMargin=12*mm, leftMargin=15*mm, rightMargin=15*mm)
            elements = []
            styles = getSampleStyleSheet()
            
            # === LOAD COMPANY INFO FROM SETTINGS ===
            try:
                from db import get_company_info
                company = get_company_info()
            except Exception as ce:
                print(f"Company info load error: {ce}")
                company = {}
            
            company_name = company.get("company_name", "COMPANY NAME")
            company_address = company.get("company_address", "")
            company_city = company.get("company_city", "")
            company_state = company.get("company_state", "")
            company_phone = company.get("company_phone", "")
            company_email = company.get("company_email", "")
            company_tax_id = company.get("company_tax_id", "")
            bank_name = company.get("bank_name", "")
            bank_account = company.get("bank_account", "")
            bank_clabe = company.get("bank_clabe", "")
            bank_usd_account = company.get("bank_usd_account", "")
            bank_swift = company.get("bank_swift", "")
            
            full_address = ", ".join(filter(None, [company_address, company_city, company_state]))
            
            # === COLOR THEME: Professional Dark Gray/Black ===
            DARK_BLACK = colors.HexColor('#1A1A1A')
            DARK_GRAY = colors.HexColor('#333333')
            MID_GRAY = colors.HexColor('#555555')
            LIGHT_GRAY = colors.HexColor('#F0F0F0')
            BORDER_GRAY = colors.HexColor('#888888')
            
            # Page width for calculations
            page_width = A4[0] - 30*mm
            
            # Custom styles - Smaller fonts to prevent overflow
            title_style = ParagraphStyle('Title', fontSize=14, alignment=TA_CENTER, spaceAfter=6, 
                                        fontName='Helvetica-Bold', textColor=DARK_BLACK)
            header_style = ParagraphStyle('Header', fontSize=7, alignment=TA_LEFT, fontName='Helvetica', textColor=MID_GRAY)
            small_style = ParagraphStyle('Small', fontSize=6, alignment=TA_LEFT, fontName='Helvetica', textColor=DARK_GRAY)
            label_style = ParagraphStyle('Label', fontSize=6, alignment=TA_LEFT, fontName='Helvetica-Bold', textColor=DARK_BLACK)
            
            # === HEADER BAR - Black ===
            header_bar = Table([[""]], colWidths=[page_width], rowHeights=[2*mm])
            header_bar.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), DARK_BLACK)]))
            elements.append(header_bar)
            elements.append(Spacer(1, 3*mm))
            
            # === COMPANY INFO & DOC NUMBER ===
            header_data = [
                [Paragraph(f"<b>{company_name[:40]}</b>", ParagraphStyle('H', fontSize=10, fontName='Helvetica-Bold', textColor=DARK_BLACK)),
                 Paragraph(f"<b>{titles[doc_type]}</b>", ParagraphStyle('H', fontSize=12, fontName='Helvetica-Bold', alignment=TA_RIGHT, textColor=DARK_BLACK))],
                [Paragraph(f"{full_address[:45]}", header_style),
                 Paragraph(f"No: {dc_note_no}", ParagraphStyle('H', fontSize=8, alignment=TA_RIGHT, textColor=MID_GRAY))],
                [Paragraph(f"Tel: {company_phone}  |  {company_email[:25]}", header_style),
                 Paragraph(f"Date: {datetime.now().strftime('%Y-%m-%d')}", ParagraphStyle('H', fontSize=7, alignment=TA_RIGHT, textColor=MID_GRAY))],
                [Paragraph(f"RFC: {company_tax_id}" if company_tax_id else "", header_style), ""],
            ]
            header_table = Table(header_data, colWidths=[page_width*0.55, page_width*0.45])
            header_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 1),
            ]))
            elements.append(header_table)
            elements.append(Spacer(1, 3*mm))
            
            # === DIVIDER LINE - Black ===
            divider = Table([[""]], colWidths=[page_width], rowHeights=[0.3*mm])
            divider.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), DARK_BLACK)]))
            elements.append(divider)
            elements.append(Spacer(1, 3*mm))
            
            # === BILL TO (Partner Info) ===
            elements.append(Paragraph("<b>BILL TO</b>", label_style))
            elements.append(Spacer(1, 1*mm))
            partner_box = Table([
                [Paragraph(f"{(partner or 'N/A')[:50]}", small_style)]
            ], colWidths=[page_width*0.5])
            partner_box.setStyle(TableStyle([
                ('BOX', (0,0), (-1,-1), 0.5, BORDER_GRAY),
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8F8F8')),
                ('TOPPADDING', (0,0), (-1,-1), 3),
                ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ('LEFTPADDING', (0,0), (-1,-1), 4),
            ]))
            elements.append(partner_box)
            elements.append(Spacer(1, 3*mm))
            
            # === SHIPMENT DETAILS (Compact 2-column) ===
            ship_data = [
                [Paragraph("<b>MBL</b>", label_style), Paragraph(f"{(mbl or '-')[:20]}", small_style),
                 Paragraph("<b>HBL</b>", label_style), Paragraph(f"{(hbl or '-')[:20]}", small_style)],
                [Paragraph("<b>POL</b>", label_style), Paragraph(f"{(pol or '-')[:15]}", small_style),
                 Paragraph("<b>POD</b>", label_style), Paragraph(f"{(pod or '-')[:15]}", small_style)],
                [Paragraph("<b>ETD</b>", label_style), Paragraph(f"{etd or '-'}", small_style),
                 Paragraph("<b>ETA</b>", label_style), Paragraph(f"{eta or '-'}", small_style)],
                [Paragraph("<b>Vessel</b>", label_style), Paragraph(f"{(vessel or '-')[:15]}/{(voyage or '-')[:8]}", small_style),
                 Paragraph("<b>Carrier</b>", label_style), Paragraph(f"{(carrier or '-')[:15]}", small_style)],
            ]
            ship_table = Table(ship_data, colWidths=[page_width*0.10, page_width*0.40, page_width*0.10, page_width*0.40])
            ship_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('GRID', (0, 0), (-1, -1), 0.3, BORDER_GRAY),
                ('BACKGROUND', (0, 0), (0, -1), LIGHT_GRAY),
                ('BACKGROUND', (2, 0), (2, -1), LIGHT_GRAY),
                ('TOPPADDING', (0,0), (-1,-1), 2),
                ('BOTTOMPADDING', (0,0), (-1,-1), 2),
                ('LEFTPADDING', (0,0), (-1,-1), 2),
                ('FONTSIZE', (0,0), (-1,-1), 6),
            ]))
            elements.append(ship_table)
            elements.append(Spacer(1, 3*mm))
            
            # === ITEMS TABLE ===
            item_header = ["No", "Description", "Unit", "Qty", "Curr", "Rate", "Amount"]
            item_data = [item_header]
            
            total_amount = 0
            total_vat = 0
            
            for idx, item in enumerate(items, 1):
                amount = item['debit'] if item['debit'] > 0 else item['credit']
                item_data.append([
                    str(idx),
                    item["description"][:22],  # Shorter to fit
                    item["unit"][:4],
                    f"{item['qty']:.1f}",
                    item["currency"][:3],
                    f"{item['rate']:,.2f}",
                    f"{amount:,.2f}"
                ])
                total_amount += amount
                total_vat += item['vat']
            
            # Subtotal, VAT, Total rows
            item_data.append(["", "", "", "", "", "Subtotal:", f"{total_amount:,.2f}"])
            if total_vat > 0:
                item_data.append(["", "", "", "", "", "VAT:", f"{total_vat:,.2f}"])
            item_data.append(["", "", "", "", "", "TOTAL:", f"{total_amount + total_vat:,.2f}"])
            
            col_widths = [page_width*0.05, page_width*0.32, page_width*0.07, page_width*0.08, page_width*0.07, page_width*0.18, page_width*0.20]
            item_table = Table(item_data, colWidths=col_widths)
            item_table.setStyle(TableStyle([
                # Header - Black
                ('BACKGROUND', (0, 0), (-1, 0), DARK_BLACK),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 6),
                ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                # Body - Smaller font
                ('FONTSIZE', (0, 1), (-1, -1), 6),
                ('ALIGN', (0, 1), (0, -1), 'CENTER'),  # No
                ('ALIGN', (2, 1), (2, -1), 'CENTER'),  # Unit
                ('ALIGN', (3, 1), (-1, -1), 'RIGHT'),  # Qty, Curr, Rate, Amount
                ('GRID', (0, 0), (-1, -4), 0.3, BORDER_GRAY),
                # Totals styling - Black accents
                ('FONTNAME', (5, -3), (-1, -1), 'Helvetica-Bold'),
                ('LINEABOVE', (5, -3), (-1, -3), 1, DARK_BLACK),
                ('BACKGROUND', (5, -1), (-1, -1), DARK_BLACK),
                ('TEXTCOLOR', (5, -1), (-1, -1), colors.white),
                ('TOPPADDING', (0,0), (-1,-1), 2),
                ('BOTTOMPADDING', (0,0), (-1,-1), 2),
            ]))
            elements.append(item_table)
            elements.append(Spacer(1, 5*mm))
            
            # === BANK INFORMATION (Compact box) ===
            bank_info_text = f"""<b>BANK INFORMATION</b><br/>
<font size=5>Bank: {(bank_name or 'N/A')[:25]}  |  Beneficiary: {company_name[:30]}<br/>
MXN: {(bank_account or 'N/A')[:20]}  |  CLABE: {(bank_clabe or 'N/A')[:20]}<br/>
USD: {(bank_usd_account or 'N/A')[:20]}  |  SWIFT: {(bank_swift or 'N/A')[:12]}</font>"""
            
            bank_para = Paragraph(bank_info_text, ParagraphStyle('Bank', fontSize=6, leading=8, textColor=MID_GRAY))
            bank_table = Table([[bank_para]], colWidths=[page_width])
            bank_table.setStyle(TableStyle([
                ('BOX', (0,0), (-1,-1), 0.5, DARK_GRAY),
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F5F5F5')),
                ('TOPPADDING', (0,0), (-1,-1), 3),
                ('BOTTOMPADDING', (0,0), (-1,-1), 3),
                ('LEFTPADDING', (0,0), (-1,-1), 4),
            ]))
            elements.append(bank_table)
            elements.append(Spacer(1, 5*mm))
            
            # === REMARK ===
            if remarks:
                elements.append(Paragraph(f"<b>Remark:</b> {remarks[:80]}", small_style))
                elements.append(Spacer(1, 3*mm))
            
            # === SIGNATURE ===
            sig_data = [["", "Authorized Signature", ""],
                       ["", "_______________________", ""],
                       ["", company_name, ""]]
            sig_table = Table(sig_data, colWidths=[page_width*0.35, page_width*0.3, page_width*0.35])
            sig_table.setStyle(TableStyle([
                ('ALIGN', (1, 0), (1, -1), 'CENTER'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('FONTSIZE', (1, 2), (1, 2), 6),
                ('TEXTCOLOR', (1, 2), (1, 2), MID_GRAY),
            ]))
            elements.append(sig_table)
            elements.append(Spacer(1, 4*mm))
            
            # === FOOTER BAR ===
            footer_bar = Table([[""]], colWidths=[page_width], rowHeights=[2*mm])
            footer_bar.setStyle(TableStyle([('BACKGROUND', (0,0), (-1,-1), DARK_GRAY)]))
            elements.append(footer_bar)
            
            # === PRINT INFO ===
            elements.append(Spacer(1, 2*mm))
            elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", 
                                     ParagraphStyle('Footer', fontSize=6, alignment=TA_CENTER, textColor=BORDER_GRAY)))
            
            doc.build(elements)
            messagebox.showinfo("Success", f"PDF saved to:\n{fp}")
            
        except ImportError:
            # Fallback to simple text
            self._gen_doc_text_fallback(doc_type, titles, job_no, items)
        except Exception as e:
            messagebox.showerror("Error", f"PDF generation failed: {e}")

    def _gen_doc_text_fallback(self, doc_type, titles, job_no, items):
        """Fallback to text file if reportlab not available"""
        lines = []
        lines.append("=" * 70)
        lines.append(f"                {titles[doc_type]}")
        lines.append("=" * 70)
        lines.append(f"\nJob No: {job_no}")
        lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d')}\n")
        lines.append("-" * 70)
        lines.append(f"{'DESCRIPTION':<30} {'UNIT':<6} {'QTY':>8} {'CURR':<5} {'RATE':>10} {'AMOUNT':>12}")
        lines.append("-" * 70)

        total = 0
        for item in items:
            amount = item.g_t('debit', 0) or item.g_t('credit', 0)
            lines.append(f"{item['description']:<30} {item['unit']:<6} {item['qty']:>8.2f} {item['currency']:<5} {item['rate']:>10,.2f} {amount:>12,.2f}")
            total += amount

        lines.append("-" * 70)
        lines.append(f"{'TOTAL':<60} {total:>12,.2f}")
        lines.append("=" * 70)

        fp = filedialog.asksaveasfilename(defaultextension=".txt", initialfile=f"{doc_type}_{job_no}.txt")
        if fp:
            with open(fp, "w") as f:
                f.write("\n".join(lines))
            messagebox.showinfo("Saved", f"Saved to {fp}\n\nNote: Install reportlab for PDF:\npip install reportlab")

    def _create_slip_from_item(self, item_type):
        """Create a slip directly from selected settlement item"""
        tree = self.rev_tree if item_type == "REVENUE" else self.cost_tree
        sel = tree.selection()
        
        if not sel:
            messagebox.showwarning("Select Item", "Please select an item to create slip from")
            return
        
        if not self.current_job_id:
            messagebox.showwarning("No Job", "No job selected")
            return
        
        values = tree.item(sel[0], "values")
        # cols: row_num, cust_code, cust_name, fcode, freight, unit, qty, curr, rate, amount, vat, total, invoice, folio, date
        
        item_id = sel[0]  # Use iid as the actual DB id (not values[0] which is row_num)
        cust_code = values[1] if len(values) > 1 else ""
        cust_name = values[2] if len(values) > 2 else ""
        freight_desc = values[4] if len(values) > 4 else ""
        currency = values[7] if len(values) > 7 else "USD"
        amount = float(values[9] or 0) if len(values) > 9 else 0
        invoice_no = values[12] if len(values) > 12 else ""
        
        if amount <= 0:
            messagebox.showwarning("No Amount", "Item has no amount to create slip")
            return
        
        # Get job info
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT job_no, mbl, hbl FROM jobs WHERE id=?", (self.current_job_id,))
            job_row = cur.fetchone()
            job_no = job_row[0] if job_row else ""
            mbl = job_row[1] if job_row else ""
            hbl = job_row[2] if job_row else ""
            
            # Determine slip type
            slip_type = "Receipt" if item_type == "REVENUE" else "Payment"
            
            # Generate slip number
            prefix = "RCP" if slip_type == "Receipt" else "PMT"
            cur.execute("SELECT MAX(id) FROM slips")
            max_id = cur.fetchone()[0] or 0
            slip_no = f"{prefix}{datetime.now().strftime('%Y%m%d')}{max_id + 1:04d}"
            
            # Get exchange rate
            from db import get_or_fetch_exchange_rate
            today = datetime.now().strftime("%Y-%m-%d")
            exchange_rate = get_or_fetch_exchange_rate(today)
            
            # Calculate MXN amount
            if currency == "USD":
                amount_mxn = amount * exchange_rate
            else:
                amount_mxn = amount
            
            # Insert slip
            cur.execute("""
                INSERT INTO slips (slip_no, date, type, customer_code, customer_name, 
                                  job_id, job_no, mbl, hbl, invoice_no, description,
                                  amount, currency, exchange_rate, amount_mxn, status, 
                                  created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
            """, (slip_no, today, slip_type, cust_code, cust_name,
                  self.current_job_id, job_no, mbl, hbl, invoice_no, freight_desc,
                  amount, currency, exchange_rate, amount_mxn,
                  now_str(), now_str()))
            
            conn.commit()
            messagebox.showinfo("Slip Created", f"Slip {slip_no} created successfully!\n\nType: {slip_type}\nAmount: {currency} {amount:,.2f}\nExchange Rate: {exchange_rate:.4f}\nMXN: ${amount_mxn:,.2f}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to create slip: {e}")
        finally:
            conn.close()


# ============================================================
# OUTSTANDING FRAME
# ============================================================
class OutstandingFrame(ctk.CTkFrame):
    """Outstanding tracking with enhanced features"""

    def __init__(self, master, width=1100, height=650):
        super().__init__(master, fg_color="#FFFFFF", width=width, height=height)

        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")

        # Title
        title_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        title_frame.pack(fill="x", padx=20, pady=(10, 10))
        ctk.CTkLabel(title_frame, text="OUTSTANDING SETTLEMENTS", font=("SF Pro Display", 22, "bold")).pack(side="left")
        ctk.CTkButton(title_frame, text="🔄 Refresh", width=100, command=self._filter).pack(side="right")
        ctk.CTkButton(title_frame, text="📥 Export", width=80, fg_color="#6C757D", command=self._export).pack(side="right", padx=10)

        # Summary cards
        summary = ctk.CTkFrame(self, fg_color="transparent")
        summary.pack(fill="x", padx=20, pady=10)

        self.recv_card = self._card(summary, "📥 Receivable", "$0.00", "#059669")
        self.recv_card.pack(side="left", padx=10, expand=True, fill="x")
        self.pay_card = self._card(summary, "📤 Payable", "$0.00", "#DC2626")
        self.pay_card.pack(side="left", padx=10, expand=True, fill="x")
        self.net_card = self._card(summary, "💰 Net", "$0.00", "#374151")
        self.net_card.pack(side="left", padx=10, expand=True, fill="x")

        # Filter section
        filt = ctk.CTkFrame(self, fg_color="#F5F5F5", corner_radius=10)
        filt.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(filt, text="Type:").pack(side="left", padx=10, pady=10)
        self.type_v = tk.StringVar(value="ALL")
        ttk.Combobox(filt, textvariable=self.type_v, values=["ALL", "RECEIVABLE", "PAYABLE"], state="readonly", width=12).pack(side="left", padx=5)
        
        ctk.CTkLabel(filt, text="Status:").pack(side="left", padx=(20, 5))
        self.status_v = tk.StringVar(value="PENDING")
        ttk.Combobox(filt, textvariable=self.status_v, values=["ALL", "PENDING", "OVERDUE"], state="readonly", width=12).pack(side="left", padx=5)
        
        ctk.CTkLabel(filt, text="Customer:").pack(side="left", padx=(20, 5))
        self.cust_var = tk.StringVar()
        ctk.CTkEntry(filt, textvariable=self.cust_var, width=150, placeholder_text="Filter by customer").pack(side="left", padx=5)
        
        ctk.CTkButton(filt, text="🔍 Search", width=80, command=self._filter).pack(side="left", padx=15)

        # Table
        tf = ctk.CTkFrame(self, fg_color="#FFFFFF")
        tf.pack(fill="both", expand=True, padx=20, pady=10)

        cols = ["job_no", "type", "customer", "freight", "amount", "invoice", "date", "days", "status"]
        widths = [100, 60, 150, 150, 100, 100, 90, 50, 80]
        self.tree = ttk.Treeview(tf, columns=cols, show="headings", height=15, selectmode="extended")
        for c, w in zip(cols, widths):
            self.tree.heading(c, text=c.upper())
            self.tree.column(c, width=w, anchor="center")
        
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        # Context menu
        self.tree.bind("<Button-3>", self._show_menu)
        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="✓ Mark as PAID", command=lambda: self._mark("PAID"))
        self.menu.add_command(label="⏳ Mark as PENDING", command=lambda: self._mark("PENDING"))

        self._filter()

    def _card(self, parent, title, amount, color):
        c = ctk.CTkFrame(parent, fg_color=color, corner_radius=10)
        ctk.CTkLabel(c, text=title, text_color="#FFF", font=("SF Pro Display", 11)).pack(pady=(12, 3))
        lbl = ctk.CTkLabel(c, text=amount, text_color="#FFF", font=("SF Pro Display", 18, "bold"))
        lbl.pack(pady=(3, 12))
        c._lbl = lbl
        return c

    def _show_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
        self.menu.post(event.x_root, event.y_root)

    def _mark(self, status):
        sel = self.tree.selection()
        if not sel:
            return
        # This would need the item ID stored - simplified for now
        messagebox.showinfo("Info", f"Marked {len(sel)} item(s) as {status}\n(Go to Settlement Management for full update)")
        self._filter()

    def _filter(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        conn = get_connection()
        cur = conn.cursor()
        recv, pay = 0, 0
        cust_filter = self.cust_var.get().strip()
        
        try:
            t = self.type_v.get()
            today = datetime.now()
            
            if t in ["ALL", "RECEIVABLE"]:
                query = """
                    SELECT j.job_no, 'RECV', s.customer, s.freight_desc, s.total, s.invoice_no, s.invoice_date, s.status
                    FROM settlement_items s 
                    JOIN jobs j ON s.job_id=j.id 
                    WHERE s.item_type='REVENUE' AND s.status != 'PAID'
                """
                if cust_filter:
                    query += f" AND s.customer LIKE '%{cust_filter}%'"
                cur.execute(query)
                for r in cur.fetchall():
                    days = 0
                    if r[6]:
                        try:
                            inv_date = datetime.strptime(r[6], "%Y-%m-%d")
                            days = (today - inv_date).days
                        except:
                            pass
                    status = "OVERDUE" if days > 30 else r[7]
                    self.tree.insert("", "end", values=(r[0], r[1], r[2], r[3][:30] if r[3] else "", 
                                                        f"${r[4]:,.2f}", r[5] or "", r[6] or "", days, status))
                    recv += float(r[4] or 0)
            
            if t in ["ALL", "PAYABLE"]:
                query = """
                    SELECT j.job_no, 'PAY', s.customer, s.freight_desc, s.total, s.invoice_no, s.invoice_date, s.status
                    FROM settlement_items s 
                    JOIN jobs j ON s.job_id=j.id 
                    WHERE s.item_type='COST' AND s.status != 'PAID'
                """
                if cust_filter:
                    query += f" AND s.customer LIKE '%{cust_filter}%'"
                cur.execute(query)
                for r in cur.fetchall():
                    days = 0
                    if r[6]:
                        try:
                            inv_date = datetime.strptime(r[6], "%Y-%m-%d")
                            days = (today - inv_date).days
                        except:
                            pass
                    status = "OVERDUE" if days > 30 else r[7]
                    self.tree.insert("", "end", values=(r[0], r[1], r[2], r[3][:30] if r[3] else "", 
                                                        f"${r[4]:,.2f}", r[5] or "", r[6] or "", days, status))
                    pay += float(r[4] or 0)
            
            self.recv_card._lbl.configure(text=f"${recv:,.2f}")
            self.pay_card._lbl.configure(text=f"${pay:,.2f}")
            net = recv - pay
            self.net_card._lbl.configure(text=f"${net:,.2f}")
            self.net_card.configure(fg_color="#059669" if net >= 0 else "#DC2626")
            
        except Exception as e:
            print(f"Filter error: {e}")
        finally:
            conn.close()

    def _export(self):
        """Export outstanding to CSV"""
        filename = f"outstanding_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        filepath = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=filename)
        if not filepath:
            return
        
        try:
            lines = ["JOB NO,TYPE,CUSTOMER,FREIGHT,AMOUNT,INVOICE,DATE,DAYS,STATUS"]
            for item in self.tree.get_children():
                vals = self.tree.item(item, "values")
                lines.append(",".join(str(v) for v in vals))
            
            with open(filepath, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            messagebox.showinfo("Exported", f"Saved to {filepath}")
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {e}")
