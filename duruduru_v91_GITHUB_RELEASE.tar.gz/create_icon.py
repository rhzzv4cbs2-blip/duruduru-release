# create_icon.py
# Generate app icon for DURUDURU Freight Management System
# Creates multi-resolution icons for macOS, Windows, and Linux

"""
App Icon Generator
==================
Creates rounded-corner logistics truck icon in multiple sizes.
"""

import os


def create_app_icon():
    """Generate app icon using PIL"""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("PIL not installed. Run: pip install Pillow")
        return None
    
    # Create base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    iconset_dir = os.path.join(base_dir, "app_icon.iconset")
    os.makedirs(iconset_dir, exist_ok=True)
    
    # Icon sizes needed
    sizes = [16, 32, 64, 128, 256, 512, 1024]
    
    for size in sizes:
        img = create_single_icon(size)
        
        # Save PNG
        filename = f"icon_{size}x{size}.png"
        filepath = os.path.join(iconset_dir, filename)
        img.save(filepath, "PNG")
        
        # Save @2x version for Retina (except for largest)
        if size <= 512:
            img_2x = create_single_icon(size * 2)
            filename_2x = f"icon_{size}x{size}@2x.png"
            filepath_2x = os.path.join(iconset_dir, filename_2x)
            img_2x.save(filepath_2x, "PNG")
    
    # Create ICO for Windows
    ico_path = os.path.join(base_dir, "app_icon.ico")
    create_windows_ico([16, 32, 48, 64, 128, 256], ico_path)
    
    print(f"✅ Icons created in: {iconset_dir}")
    print(f"✅ Windows icon: {ico_path}")
    
    return iconset_dir


def create_single_icon(size):
    """Create a single icon at specified size"""
    from PIL import Image, ImageDraw, ImageFont
    
    # Colors
    bg_color = "#1565C0"  # Primary blue
    truck_color = "#FFFFFF"
    accent_color = "#FF9800"  # Orange accent
    
    # Create base image
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Rounded rectangle background
    corner_radius = size // 5
    draw_rounded_rect(draw, 0, 0, size-1, size-1, corner_radius, bg_color)
    
    # Draw simplified truck
    padding = size // 8
    
    # Truck body (rectangle)
    body_x1 = padding
    body_y1 = size // 3
    body_x2 = size - padding - size // 6
    body_y2 = size - padding - size // 6
    draw.rectangle([body_x1, body_y1, body_x2, body_y2], fill=truck_color)
    
    # Truck cabin
    cabin_x1 = body_x2
    cabin_y1 = size // 2
    cabin_x2 = size - padding
    cabin_y2 = body_y2
    draw.rectangle([cabin_x1, cabin_y1, cabin_x2, cabin_y2], fill=truck_color)
    
    # Wheels
    wheel_radius = size // 10
    wheel_y = body_y2
    
    # Front wheel
    wheel1_x = padding + size // 5
    draw.ellipse([wheel1_x - wheel_radius, wheel_y - wheel_radius,
                  wheel1_x + wheel_radius, wheel_y + wheel_radius],
                 fill=accent_color, outline="#333333", width=max(1, size // 64))
    
    # Rear wheel
    wheel2_x = body_x2 - size // 8
    draw.ellipse([wheel2_x - wheel_radius, wheel_y - wheel_radius,
                  wheel2_x + wheel_radius, wheel_y + wheel_radius],
                 fill=accent_color, outline="#333333", width=max(1, size // 64))
    
    # Window on cabin
    window_x1 = cabin_x1 + size // 20
    window_y1 = cabin_y1 + size // 20
    window_x2 = cabin_x2 - size // 20
    window_y2 = cabin_y1 + (cabin_y2 - cabin_y1) // 2
    draw.rectangle([window_x1, window_y1, window_x2, window_y2], fill="#87CEEB")
    
    # Add "D" letter for DURUDURU (if large enough)
    if size >= 128:
        try:
            font_size = size // 4
            try:
                font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", font_size)
            except:
                try:
                    font = ImageFont.truetype("arial.ttf", font_size)
                except:
                    font = ImageFont.load_default()
            
            text = "D"
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            
            text_x = (body_x1 + body_x2) // 2 - text_width // 2
            text_y = body_y1 + (body_y2 - body_y1) // 2 - text_height // 2 - size // 15
            
            draw.text((text_x, text_y), text, fill=bg_color, font=font)
        except Exception as e:
            pass
    
    return img


def draw_rounded_rect(draw, x1, y1, x2, y2, radius, fill):
    """Draw rounded rectangle"""
    draw.rectangle([x1 + radius, y1, x2 - radius, y2], fill=fill)
    draw.rectangle([x1, y1 + radius, x2, y2 - radius], fill=fill)
    draw.pieslice([x1, y1, x1 + radius * 2, y1 + radius * 2], 180, 270, fill=fill)
    draw.pieslice([x2 - radius * 2, y1, x2, y1 + radius * 2], 270, 360, fill=fill)
    draw.pieslice([x1, y2 - radius * 2, x1 + radius * 2, y2], 90, 180, fill=fill)
    draw.pieslice([x2 - radius * 2, y2 - radius * 2, x2, y2], 0, 90, fill=fill)


def create_windows_ico(sizes, output_path):
    """Create Windows ICO file"""
    from PIL import Image
    
    images = []
    for size in sizes:
        img = create_single_icon(size)
        images.append(img)
    
    if images:
        images[0].save(output_path, format='ICO', sizes=[(s, s) for s in sizes])


def create_simple_png_icon(output_path, size=512):
    """Create a simple PNG icon"""
    try:
        img = create_single_icon(size)
        img.save(output_path, "PNG")
        print(f"✅ Icon saved: {output_path}")
        return True
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


if __name__ == "__main__":
    print("🎨 Creating DURUDURU app icons...")
    
    try:
        from PIL import Image, ImageDraw
        create_app_icon()
    except ImportError:
        print("Pillow not installed. Creating placeholder...")
        
        # Create minimal placeholder icon using base64
        import base64
        
        # Minimal 16x16 PNG (blue square)
        png_data = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAA"
            "P0lEQVQ4jWNgGLTgPwMDAwMTAwPDfwYGBgZGRkaG/zABJiYm"
            "BgYGBob/DAwMDIyMjAz/YYJMTEwMg97AQAAAAP//AwAjGQZB"
            "fFnwwQAAAABJRU5ErkJggg=="
        )
        
        os.makedirs("app_icon.iconset", exist_ok=True)
        with open("app_icon.iconset/icon_512x512.png", "wb") as f:
            f.write(png_data)
        print("✅ Placeholder icon created")
