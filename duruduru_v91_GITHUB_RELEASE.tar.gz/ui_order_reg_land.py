# ui_order_reg_land.py
# Land Registration Frame - append to ui_order_reg.py

import customtkinter as ctk
from tkcalendar import Calendar
import datetime
from tkinter import messagebox
from tkinter import ttk
import tkinter as tk
from autocomplete_util import AutocompleteEntry, fetch_customers, fetch_quotes
from db import get_connection, now_str


class LandRegFrame(ctk.CTkFrame):
    def __init__(self, master, width=1100, height=650):
        super().__init__(master, fg_color="#FAFAFA", width=width, height=height)
        self._is_dirty = False

        scroll = ctk.CTkScrollableFrame(self, fg_color="#FFFFFF")
        scroll.pack(fill="both", expand=True, padx=8, pady=(38, 8))

        def numeric_only(event):
            v = event.widget.get()
            if v:
                filtered = "".join(ch for ch in v if ch.isdigit() or ch == ".")
                if v != filtered:
                    event.widget.delete(0, "end")
                    event.widget.insert(0, filtered)

        def to_upper(event):
            v = event.widget.get()
            if v:
                event.widget.delete(0, "end")
                event.widget.insert(0, v.upper())

        # Job Order / Quote Ref
        job_row = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        job_row.grid(row=0, column=0, sticky="w", padx=20, pady=(10, 10))

        ctk.CTkLabel(job_row, text="Job Order").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.job_order = ctk.CTkEntry(job_row, width=180)
        self.job_order.grid(row=0, column=1, sticky="w", padx=20, pady=3)
        self.job_order.insert(0, "AUTO")
        self.job_order.configure(state="disabled")

        ctk.CTkLabel(job_row, text="Quote Ref").grid(row=0, column=2, sticky="w", padx=5, pady=3)
        self.quote_ref = ctk.CTkEntry(job_row, width=180)
        self.quote_ref.grid(row=0, column=3, sticky="w", padx=20, pady=3)
        AutocompleteEntry(self.quote_ref, fetch_quotes)

        ctk.CTkButton(job_row, text="🔍", width=32, fg_color="#E5E5EA", command=self._open_offer_search).grid(row=0, column=4, padx=4, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=1, column=0, sticky="ew", padx=20, pady=3)

        # Basic
        basic = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        basic.grid(row=2, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(basic, text="OP").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.op_var = ctk.StringVar()
        self.op_entry = ctk.CTkEntry(basic, width=120, textvariable=self.op_var, state="disabled")
        self.op_entry.grid(row=0, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="TRUCKER").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.trucker = ctk.CTkEntry(basic, width=180)
        self.trucker.grid(row=1, column=1, sticky="w", padx=5, pady=3)
        AutocompleteEntry(self.trucker, fetch_customers)

        ctk.CTkLabel(basic, text="VEHICLE NO").grid(row=1, column=2, sticky="w", padx=5, pady=3)
        self.vehicle_no = ctk.CTkEntry(basic, width=180)
        self.vehicle_no.grid(row=1, column=3, sticky="w", padx=5, pady=3)
        self.vehicle_no.bind("<KeyRelease>", to_upper)

        ctk.CTkLabel(basic, text="DRIVER NAME").grid(row=2, column=0, sticky="w", padx=5, pady=3)
        self.driver_name = ctk.CTkEntry(basic, width=180)
        self.driver_name.grid(row=2, column=1, sticky="w", padx=5, pady=3)

        ctk.CTkLabel(basic, text="DRIVER PHONE").grid(row=2, column=2, sticky="w", padx=5, pady=3)
        self.driver_phone = ctk.CTkEntry(basic, width=180)
        self.driver_phone.grid(row=2, column=3, sticky="w", padx=5, pady=3)

        ctk.CTkFrame(scroll, height=1, fg_color="#E5E5EA").grid(row=3, column=0, sticky="ew", padx=20, pady=3)

        # Routing
        routing = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        routing.grid(row=4, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(routing, text="PICKUP").grid(row=0, column=0, sticky="w", padx=5, pady=3)
        self.pickup_var = ctk.StringVar()
        self.pickup_entry = ctk.CTkEntry(routing, width=300, textvariable=self.pickup_var)
        self.pickup_entry.grid(row=0, column=1, sticky="w", padx=5, pady=3)
        self.pickup_entry.bind("<KeyRelease>", lambda e: self._update_op())

        ctk.CTkLabel(routing, text="DELIVERY").grid(row=1, column=0, sticky="w", padx=5, pady=3)
        self.delivery_var = ctk.StringVar()
        self.delivery_entry = ctk.CTkEntry(routing, width=300, textvariable=self.delivery_var)
        self.delivery_entry.grid(row=1, column=1, sticky="w", padx=5, pady=3)

        # Dates
        date_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        date_frame.grid(row=5, column=0, sticky="w", padx=20, pady=(0, 10))

        ctk.CTkLabel(date_frame, text="PICKUP DATE").grid(row=0, column=0, padx=5, pady=3)
        self.pickup_date = ctk.CTkEntry(date_frame, width=130, placeholder_text="YYYY-MM-DD")
        self.pickup_date.grid(row=0, column=1, padx=5, pady=3)
        ctk.CTkButton(date_frame, text="📅", width=32, fg_color="#E5E5EA", command=lambda: self._open_calendar(self.pickup_date)).grid(row=0, column=2, padx=4)

        ctk.CTkLabel(date_frame, text="DELIVERY DATE").grid(row=0, column=3, padx=5, pady=3)
        self.delivery_date = ctk.CTkEntry(date_frame, width=130, placeholder_text="YYYY-MM-DD")
        self.delivery_date.grid(row=0, column=4, padx=5, pady=3)
        ctk.CTkButton(date_frame, text="📅", width=32, fg_color="#E5E5EA", command=lambda: self._open_calendar(self.delivery_date)).grid(row=0, column=5, padx=4)

        # CUSTOMER / PARTNER
        cust_frame = ctk.CTkFrame(scroll, fg_color="#FFFFFF")
        cust_frame.grid(row=6, column=0, sticky="w", padx=20, pady=(6, 10))

        ctk.CTkLabel(cust_frame, text="CUSTOMER").grid(row=0, column=0, padx=5, pady=3)
        self.customer_code = ctk.CTkEntry(cust_frame, width=100, placeholder_text="Code")
        self.customer_code.grid(row=0, column=1, padx=5, pady=3)
        self.customer_name = ctk.CTkEntry(cust_frame, width=180, placeholder_text="Name")
        self.customer_name.grid(row=0, column=2, padx=5, pady=3)
        AutocompleteEntry(self.customer_code, fetch_customers, related_widgets={'name': self.customer_name})
        AutocompleteEntry(self.customer_name, fetch_customers, related_widgets={'name': self.customer_code})

        ctk.CTkLabel(cust_frame, text="PARTNER").grid(row=0, column=3, padx=20, pady=3)
        self.partner_code = ctk.CTkEntry(cust_frame, width=100, placeholder_text="Code")
        self.partner_code.grid(row=0, column=4, padx=5, pady=3)
        self.partner_name = ctk.CTkEntry(cust_frame, width=180, placeholder_text="Name")
        self.partner_name.grid(row=0, column=5, padx=5, pady=3)
        AutocompleteEntry(self.partner_code, fetch_customers, related_widgets={'name': self.partner_name})
        AutocompleteEntry(self.partner_name, fetch_customers, related_widgets={'name': self.partner_code})

        # Vehicle Info
        vehicle_section = ctk.CTkFrame(scroll, fg_color="#F9FAFB", corner_radius=10)
        vehicle_section.grid(row=7, column=0, sticky="w", padx=20, pady=(5, 10))

        ctk.CTkLabel(vehicle_section, text="Vehicle Info", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 4))

        v_body = ctk.CTkFrame(vehicle_section, fg_color="#FFFFFF")
        v_body.grid(row=1, column=0, sticky="w", padx=10, pady=(0, 10))

        ctk.CTkLabel(v_body, text="CNTR NO").grid(row=0, column=0, padx=5, pady=3)
        self.cntr_no = ctk.CTkEntry(v_body, width=140)
        self.cntr_no.grid(row=0, column=1, padx=5, pady=3)

        ctk.CTkLabel(v_body, text="TYPE").grid(row=0, column=2, padx=5, pady=3)
        self.cntr_type = ctk.CTkComboBox(v_body, values=["1 Ton", "3.5 Tons", "5 Tons", "8 Tons", "11 Tons", "15 Tons", "53ft", "Flatbed", "Lowbed", "Lowboy", "Container"], width=120)
        self.cntr_type.grid(row=0, column=3, padx=5, pady=3)

        # Cargo Section
        cargo_section = ctk.CTkFrame(scroll, fg_color="#F9FAFB", corner_radius=10)
        cargo_section.grid(row=8, column=0, sticky="w", padx=20, pady=(5, 10))

        ctk.CTkLabel(cargo_section, text="Cargo Info", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 4))

        cargo_header = ctk.CTkFrame(cargo_section, fg_color="transparent")
        cargo_header.grid(row=1, column=0, sticky="w", padx=10)
        for i, txt in enumerate(["L", "W", "H", "WT", "PLT", "QTY", "TOT WT", "CBM"]):
            ctk.CTkLabel(cargo_header, text=txt).grid(row=0, column=i, padx=18)

        self.land_cargo_body = ctk.CTkFrame(cargo_section, fg_color="#FFFFFF")
        self.land_cargo_body.grid(row=2, column=0, sticky="w", padx=10)
        self.land_cargo_rows = []

        self.land_total_frame = ctk.CTkFrame(cargo_section, fg_color="#E8F4FD", corner_radius=6)
        self.land_total_frame.grid(row=4, column=0, sticky="w", padx=10, pady=(5, 10))
        ctk.CTkLabel(self.land_total_frame, text="TOTAL:", font=("SF Pro Display", 12, "bold")).grid(row=0, column=0, padx=10, pady=5)
        self.land_total_weight = ctk.CTkLabel(self.land_total_frame, text="0.00 kg")
        self.land_total_weight.grid(row=0, column=1, padx=15, pady=5)
        self.land_total_cbm = ctk.CTkLabel(self.land_total_frame, text="0.000 CBM")
        self.land_total_cbm.grid(row=0, column=2, padx=15, pady=5)

        def recalc():
            tw, tc = 0, 0
            for row in self.land_cargo_rows:
                try:
                    l = float(row["l"].get() or 0)
                    w = float(row["w"].get() or 0)
                    h = float(row["h"].get() or 0)
                    wt = float(row["wt"].get() or 0)
                    qty = float(row["qty"].get() or 0)
                except:
                    continue
                cbm = (l * w * h * qty) / 1_000_000
                twt = wt * qty
                row["twt_lbl"].configure(text=f"{twt:.1f}")
                row["cbm_lbl"].configure(text=f"{cbm:.3f}")
                tw += twt
                tc += cbm
            self.land_total_weight.configure(text=f"{tw:.2f} kg")
            self.land_total_cbm.configure(text=f"{tc:.3f} CBM")

        def add_row():
            r = len(self.land_cargo_rows)
            row = {}
            def on_ch(e):
                numeric_only(e)
                recalc()
            for i, key in enumerate(["l", "w", "h", "wt", "plt", "qty"]):
                e = ctk.CTkEntry(self.land_cargo_body, width=45, justify="center")
                e.grid(row=r, column=i, padx=3, pady=3)
                e.bind("<KeyRelease>", on_ch)
                row[key] = e
            row["twt_lbl"] = ctk.CTkLabel(self.land_cargo_body, text="0.0", width=50)
            row["twt_lbl"].grid(row=r, column=6, padx=3, pady=3)
            row["cbm_lbl"] = ctk.CTkLabel(self.land_cargo_body, text="0.000", width=50)
            row["cbm_lbl"].grid(row=r, column=7, padx=3, pady=3)
            row["del"] = ctk.CTkButton(self.land_cargo_body, text="🗑", width=30, fg_color="#FFCDD2", text_color="#B71C1C", command=lambda rr=r: del_row(rr))
            row["del"].grid(row=r, column=8, padx=3, pady=3)
            self.land_cargo_rows.append(row)

        def del_row(idx):
            if idx >= len(self.land_cargo_rows):
                return
            for w in self.land_cargo_rows[idx].values():
                w.destroy()
            self.land_cargo_rows.pop(idx)
            for i, r in enumerate(self.land_cargo_rows):
                for j, k in enumerate(["l", "w", "h", "wt", "plt", "qty"]):
                    r[k].grid(row=i, column=j, padx=3, pady=3)
                r["twt_lbl"].grid(row=i, column=6, padx=3, pady=3)
                r["cbm_lbl"].grid(row=i, column=7, padx=3, pady=3)
                r["del"].grid(row=i, column=8, padx=3, pady=3)
                r["del"].configure(command=lambda rr=i: del_row(rr))
            recalc()

        add_row()
        ctk.CTkButton(cargo_section, text="+ Add Cargo", fg_color="#E5E5EA", text_color="#333", command=add_row).grid(row=3, column=0, sticky="w", padx=10, pady=(5, 0))

        # Bottom
        bottom = ctk.CTkFrame(self, fg_color="#FFFFFF")
        bottom.pack(fill="x", padx=20, pady=(0, 20))
        ctk.CTkButton(bottom, text="Reset", width=120, fg_color="#FFCDD2", text_color="#B71C1C", command=self._confirm_reset).grid(row=0, column=0, padx=2)
        ctk.CTkButton(bottom, text="Save", width=120, fg_color="#3B82F6", command=self._save_operation).grid(row=0, column=1, padx=2)
        ctk.CTkButton(bottom, text="Save & Close", width=140, fg_color="#E5E5EA", text_color="#333", command=self._save_and_close).grid(row=0, column=2, padx=2)

    def _open_calendar(self, target):
        if hasattr(self, "_cal") and self._cal.winfo_exists():
            self._cal.destroy()
        self._cal = ctk.CTkToplevel(self)
        self._cal.overrideredirect(True)
        self._cal.attributes("-topmost", True)
        self._cal.geometry(f"+{target.winfo_rootx()}+{target.winfo_rooty()+target.winfo_height()}")
        today = datetime.date.today()
        cal = Calendar(self._cal, selectmode="day", year=today.year, month=today.month, day=today.day, date_pattern="yyyy-mm-dd")
        cal.pack(padx=2, pady=2)
        cal.bind("<<CalendarSelected>>", lambda e: [target.delete(0, "end"), target.insert(0, cal.get_date()), self._cal.destroy()])

    def _update_op(self):
        p = (self.pickup_var.get() or "").upper()
        op = "EXPO" if "MX" in p else "IMPO"
        self.op_entry.configure(state="normal")
        self.op_entry.delete(0, "end")
        self.op_entry.insert(0, op)
        self.op_entry.configure(state="disabled")

    def _open_offer_search(self):
        win = ctk.CTkToplevel(self)
        win.title("Search Offers")
        win.geometry("700x500")
        win.transient(self.winfo_toplevel())
        win.grab_set()
        ctk.CTkLabel(win, text="Search:").pack(anchor="w", padx=20, pady=(10, 0))
        sv = ctk.StringVar()
        ctk.CTkEntry(win, textvariable=sv, width=400).pack(anchor="w", padx=20, pady=5)
        tf = ctk.CTkFrame(win)
        tf.pack(fill="both", expand=True, padx=20, pady=10)
        cols = ["quote_ref", "company", "mode", "validity", "status"]
        tree = ttk.Treeview(tf, columns=cols, show="headings")
        for c in cols:
            tree.heading(c, text=c.upper())
            tree.column(c, width=120, anchor="center")
        tree.pack(fill="both", expand=True)
        def load(ft=""):
            for i in tree.get_children():
                tree.delete(i)
            conn = get_connection()
            cur = conn.cursor()
            try:
                q = "SELECT quote_ref, company, mode, COALESCE(validity_from,'') || ' ~ ' || COALESCE(validity_to,''), status FROM offers"
                if ft:
                    q += f" WHERE quote_ref LIKE '%{ft}%' OR company LIKE '%{ft}%'"
                q += " ORDER BY quote_ref DESC"
                cur.execute(q)
                for row in cur.fetchall():
                    tree.insert("", "end", values=row)
            except:
                pass
            finally:
                conn.close()
        sv.trace_add("write", lambda *a: load(sv.get()))
        tree.bind("<Double-1>", lambda e: [self.quote_ref.delete(0, "end"), self.quote_ref.insert(0, tree.item(tree.selection()[0], "values")[0]) if tree.selection() else None, win.destroy()])
        ctk.CTkButton(win, text="Cancel", command=win.destroy).pack(pady=10)
        load()

    def _confirm_reset(self):
        if messagebox.askyesno("Reset", "Reset?"):
            self._reset_all()

    def _reset_all(self):
        for e in [self.quote_ref, self.trucker, self.vehicle_no, self.driver_name, self.driver_phone, self.pickup_date, self.delivery_date, self.cntr_no, self.customer_code, self.customer_name, self.partner_code, self.partner_name]:
            try:
                e.delete(0, "end")
            except:
                pass
        self.pickup_var.set("")
        self.delivery_var.set("")
        self.cntr_type.set("")

    def _generate_job_no(self):
        conn = get_connection()
        cur = conn.cursor()
        prefix = f"JLA{datetime.datetime.now().strftime('%Y%m%d')}"
        try:
            cur.execute("SELECT job_no FROM jobs WHERE job_no LIKE ? ORDER BY job_no DESC LIMIT 1", (f"{prefix}%",))
            row = cur.fetchone()
            seq = int(row[0][-3:]) + 1 if row else 1
            return f"{prefix}{str(seq).zfill(3)}"
        except:
            return f"{prefix}001"
        finally:
            conn.close()

    def _save_operation(self):
        if not self.customer_code.get().strip() and not self.customer_name.get().strip():
            messagebox.showwarning("Required", "Customer is required.")
            return
        job_no = self._generate_job_no()
        conn = get_connection()
        cur = conn.cursor()
        try:
            customer = self.customer_code.get() or self.customer_name.get()
            partner = self.partner_code.get() or self.partner_name.get()
            cur.execute("INSERT INTO jobs (job_no, mode, customer, partner, pol, pod, etd, eta, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                       (job_no, "LAND", customer, partner, self.pickup_var.get(), self.delivery_var.get(), self.pickup_date.get(), self.delivery_date.get(), "OPEN", now_str(), now_str()))
            conn.commit()
            messagebox.showinfo("Saved", f"Job {job_no} saved.")
            self._reset_all()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("Error", f"Failed: {e}")
        finally:
            conn.close()

    def _save_and_close(self):
        self._save_operation()
        try:
            self.master.master._close_frame("LAND")
        except:
            pass

    def set_provider(self, p):
        self._provider = p

    def load(self, id=None):
        self._reset_all()

    def save(self):
        return {"ok": True}

    def get_state(self):
        return {}

    def is_dirty(self):
        return getattr(self, "_is_dirty", False)

    def reset(self):
        self._reset_all()
        self._is_dirty = False
