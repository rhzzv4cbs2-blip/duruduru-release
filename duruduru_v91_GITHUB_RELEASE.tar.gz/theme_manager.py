# theme_manager.py
# Theme Manager with Dark Mode Support
# Created: 2026-01-08

import customtkinter as ctk
import os
import json
from typing import Dict, Optional


class ThemeManager:
    """Manage application themes including dark mode"""
    
    # Theme definitions
    THEMES = {
        "light": {
            "name": "Light",
            "ctk_mode": "light",
            "colors": {
                "bg_primary": "#FFFFFF",
                "bg_secondary": "#F5F5F5",
                "bg_tertiary": "#E0E0E0",
                "bg_accent": "#E3F2FD",
                "text_primary": "#333333",
                "text_secondary": "#666666",
                "text_muted": "#999999",
                "text_inverse": "#FFFFFF",
                "border": "#E5E5EA",
                "border_strong": "#CCCCCC",
                "primary": "#1565C0",
                "primary_hover": "#1976D2",
                "secondary": "#42A5F5",
                "success": "#4CAF50",
                "success_light": "#E8F5E9",
                "warning": "#FF9800",
                "warning_light": "#FFF3E0",
                "danger": "#F44336",
                "danger_light": "#FFEBEE",
                "info": "#2196F3",
                "info_light": "#E3F2FD",
                "sidebar_bg": "#1565C0",
                "sidebar_text": "#FFFFFF",
                "sidebar_hover": "#1976D2",
                "header_bg": "#F8F9FA",
                "table_header": "#1565C0",
                "table_row_alt": "#FAFAFA",
                "input_bg": "#FFFFFF",
                "input_border": "#E5E5EA",
                "button_primary": "#1565C0",
                "button_secondary": "#6C757D",
                "shadow": "rgba(0,0,0,0.1)",
            }
        },
        "dark": {
            "name": "Dark",
            "ctk_mode": "dark",
            "colors": {
                "bg_primary": "#1E1E1E",
                "bg_secondary": "#252526",
                "bg_tertiary": "#2D2D30",
                "bg_accent": "#264F78",
                "text_primary": "#E0E0E0",
                "text_secondary": "#AAAAAA",
                "text_muted": "#777777",
                "text_inverse": "#1E1E1E",
                "border": "#3E3E42",
                "border_strong": "#505050",
                "primary": "#569CD6",
                "primary_hover": "#4FC3F7",
                "secondary": "#64B5F6",
                "success": "#4EC9B0",
                "success_light": "#1E3A2F",
                "warning": "#DCDCAA",
                "warning_light": "#3A3520",
                "danger": "#F14C4C",
                "danger_light": "#3E1E1E",
                "info": "#4FC3F7",
                "info_light": "#1E3A4F",
                "sidebar_bg": "#252526",
                "sidebar_text": "#E0E0E0",
                "sidebar_hover": "#37373D",
                "header_bg": "#2D2D30",
                "table_header": "#264F78",
                "table_row_alt": "#2D2D30",
                "input_bg": "#3C3C3C",
                "input_border": "#3E3E42",
                "button_primary": "#569CD6",
                "button_secondary": "#5A5A5A",
                "shadow": "rgba(0,0,0,0.3)",
            }
        },
        "blue": {
            "name": "Blue Professional",
            "ctk_mode": "light",
            "colors": {
                "bg_primary": "#FFFFFF",
                "bg_secondary": "#F0F4F8",
                "bg_tertiary": "#E1E8ED",
                "bg_accent": "#E3F2FD",
                "text_primary": "#1A365D",
                "text_secondary": "#4A5568",
                "text_muted": "#718096",
                "text_inverse": "#FFFFFF",
                "border": "#CBD5E0",
                "border_strong": "#A0AEC0",
                "primary": "#2B6CB0",
                "primary_hover": "#3182CE",
                "secondary": "#4299E1",
                "success": "#38A169",
                "success_light": "#F0FFF4",
                "warning": "#DD6B20",
                "warning_light": "#FFFAF0",
                "danger": "#E53E3E",
                "danger_light": "#FFF5F5",
                "info": "#3182CE",
                "info_light": "#EBF8FF",
                "sidebar_bg": "#2B6CB0",
                "sidebar_text": "#FFFFFF",
                "sidebar_hover": "#3182CE",
                "header_bg": "#EDF2F7",
                "table_header": "#2B6CB0",
                "table_row_alt": "#F7FAFC",
                "input_bg": "#FFFFFF",
                "input_border": "#CBD5E0",
                "button_primary": "#2B6CB0",
                "button_secondary": "#718096",
                "shadow": "rgba(0,0,0,0.08)",
            }
        },
    }
    
    _current_theme = "light"
    _instance = None
    _listeners = []
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def get_themes(cls) -> Dict[str, str]:
        """Get available themes"""
        return {k: v["name"] for k, v in cls.THEMES.items()}
    
    @classmethod
    def get_current_theme(cls) -> str:
        """Get current theme ID"""
        return cls._current_theme
    
    @classmethod
    def get_theme_data(cls, theme_id: str = None) -> Dict:
        """Get theme data"""
        theme_id = theme_id or cls._current_theme
        return cls.THEMES.get(theme_id, cls.THEMES["light"])
    
    @classmethod
    def get_color(cls, color_key: str) -> str:
        """Get color value for current theme"""
        theme = cls.get_theme_data()
        return theme["colors"].get(color_key, "#FFFFFF")
    
    @classmethod
    def set_theme(cls, theme_id: str):
        """Set current theme"""
        if theme_id not in cls.THEMES:
            return
        
        cls._current_theme = theme_id
        theme = cls.THEMES[theme_id]
        
        # Set CustomTkinter appearance mode
        ctk.set_appearance_mode(theme["ctk_mode"])
        
        # Notify listeners
        for listener in cls._listeners:
            try:
                listener(theme_id, theme)
            except:
                pass
        
        # Save preference
        cls._save_preference(theme_id)
    
    @classmethod
    def add_listener(cls, callback):
        """Add theme change listener"""
        if callback not in cls._listeners:
            cls._listeners.append(callback)
    
    @classmethod
    def remove_listener(cls, callback):
        """Remove theme change listener"""
        if callback in cls._listeners:
            cls._listeners.remove(callback)
    
    @classmethod
    def _save_preference(cls, theme_id: str):
        """Save theme preference"""
        config_dir = os.path.join(os.path.expanduser("~"), ".duruduru")
        os.makedirs(config_dir, exist_ok=True)
        config_file = os.path.join(config_dir, "theme.json")
        
        try:
            with open(config_file, 'w') as f:
                json.dump({"theme": theme_id}, f)
        except:
            pass
    
    @classmethod
    def load_preference(cls) -> str:
        """Load theme preference"""
        config_file = os.path.join(os.path.expanduser("~"), ".duruduru", "theme.json")
        
        try:
            with open(config_file, 'r') as f:
                data = json.load(f)
                return data.get("theme", "light")
        except:
            return "light"
    
    @classmethod
    def initialize(cls):
        """Initialize theme from saved preference"""
        theme_id = cls.load_preference()
        cls.set_theme(theme_id)
    
    @classmethod
    def apply_to_widget(cls, widget, **color_mappings):
        """
        Apply theme colors to a widget
        
        Usage:
            ThemeManager.apply_to_widget(frame, fg_color="bg_secondary")
        """
        theme = cls.get_theme_data()
        colors = theme["colors"]
        
        config = {}
        for prop, color_key in color_mappings.items():
            if color_key in colors:
                config[prop] = colors[color_key]
        
        if config:
            try:
                widget.configure(**config)
            except:
                pass


class ThemeSettingsPanel(ctk.CTkFrame):
    """Theme settings panel for use in settings screen"""
    
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        self._setup_ui()
    
    def _setup_ui(self):
        ctk.CTkLabel(self, text="🎨 Theme / 테마", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        
        themes = ThemeManager.get_themes()
        current = ThemeManager.get_current_theme()
        
        self.theme_var = ctk.StringVar(value=current)
        
        for theme_id, theme_name in themes.items():
            radio = ctk.CTkRadioButton(
                self, 
                text=theme_name,
                variable=self.theme_var,
                value=theme_id,
                command=self._on_theme_change
            )
            radio.pack(anchor="w", padx=20, pady=3)
        
        # Preview
        preview_frame = ctk.CTkFrame(self, fg_color="transparent")
        preview_frame.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(preview_frame, text="Preview:").pack(anchor="w")
        
        self.preview_box = ctk.CTkFrame(preview_frame, height=50, corner_radius=6)
        self.preview_box.pack(fill="x", pady=5)
        
        self._update_preview()
    
    def _on_theme_change(self):
        theme_id = self.theme_var.get()
        ThemeManager.set_theme(theme_id)
        self._update_preview()
    
    def _update_preview(self):
        colors = ThemeManager.get_theme_data()["colors"]
        self.preview_box.configure(fg_color=colors["bg_secondary"])


# Initialize on import
ThemeManager.initialize()
