# theme.py
# Modern UI Theme System for DURUDURU
# Inspired by: Notion, Linear, Figma

from dataclasses import dataclass
from typing import Dict, Optional
import tkinter as tk
from tkinter import ttk

# ============================================================
# COLOR PALETTE
# ============================================================
@dataclass
class ColorPalette:
    """Modern color palette inspired by Linear/Notion"""
    
    # Primary colors
    primary: str = "#5E5CE6"          # Purple (iOS-like)
    primary_hover: str = "#4B49B6"
    primary_light: str = "#E8E8FC"
    
    # Accent colors
    accent: str = "#007AFF"           # Blue
    accent_hover: str = "#0056B3"
    
    # Semantic colors
    success: str = "#34C759"          # Green
    success_bg: str = "#E3F9E5"
    warning: str = "#FF9500"          # Orange
    warning_bg: str = "#FFF4E5"
    error: str = "#FF3B30"            # Red
    error_bg: str = "#FFE5E5"
    info: str = "#5856D6"             # Indigo
    info_bg: str = "#EEEEFF"
    
    # Neutral colors
    bg_primary: str = "#FFFFFF"
    bg_secondary: str = "#F5F5F7"     # Apple-like gray
    bg_tertiary: str = "#E5E5EA"
    bg_hover: str = "#F0F0F5"
    
    # Text colors
    text_primary: str = "#1D1D1F"
    text_secondary: str = "#6E6E73"
    text_tertiary: str = "#AEAEB2"
    text_inverse: str = "#FFFFFF"
    
    # Border colors
    border: str = "#D1D1D6"
    border_light: str = "#E5E5EA"
    border_focus: str = "#5E5CE6"
    
    # Chart colors
    chart_1: str = "#5E5CE6"
    chart_2: str = "#34C759"
    chart_3: str = "#FF9500"
    chart_4: str = "#FF3B30"
    chart_5: str = "#5856D6"
    chart_6: str = "#AF52DE"
    
    # Revenue/Cost specific
    revenue: str = "#34C759"
    revenue_bg: str = "#E3F9E5"
    cost: str = "#FF3B30"
    cost_bg: str = "#FFE5E5"


@dataclass  
class DarkColorPalette(ColorPalette):
    """Dark mode colors"""
    
    primary: str = "#6E6EE8"
    primary_hover: str = "#8080F0"
    primary_light: str = "#2D2D5E"
    
    bg_primary: str = "#1C1C1E"
    bg_secondary: str = "#2C2C2E"
    bg_tertiary: str = "#3A3A3C"
    bg_hover: str = "#3A3A3C"
    
    text_primary: str = "#FFFFFF"
    text_secondary: str = "#AEAEB2"
    text_tertiary: str = "#6E6E73"
    
    border: str = "#3A3A3C"
    border_light: str = "#48484A"


# ============================================================
# TYPOGRAPHY
# ============================================================
@dataclass
class Typography:
    """Typography settings"""
    
    # Font families
    font_family: str = "SF Pro Display"
    font_family_mono: str = "SF Mono"
    
    # Fallback fonts
    font_fallback: str = "Segoe UI, Helvetica Neue, Arial"
    font_mono_fallback: str = "Consolas, Monaco, monospace"
    
    # Sizes
    size_xs: int = 10
    size_sm: int = 12
    size_base: int = 14
    size_lg: int = 16
    size_xl: int = 18
    size_2xl: int = 22
    size_3xl: int = 28
    size_4xl: int = 36
    
    # Weights
    weight_normal: str = "normal"
    weight_medium: str = "bold"  # tkinter limitation
    weight_bold: str = "bold"
    
    def get_font(self, size: str = "base", weight: str = "normal") -> tuple:
        """Get font tuple for tkinter"""
        sizes = {
            "xs": self.size_xs, "sm": self.size_sm, "base": self.size_base,
            "lg": self.size_lg, "xl": self.size_xl, "2xl": self.size_2xl,
            "3xl": self.size_3xl, "4xl": self.size_4xl
        }
        return (self.font_family, sizes.get(size, self.size_base), weight)


# ============================================================
# SPACING
# ============================================================
@dataclass
class Spacing:
    """Consistent spacing values"""
    
    xs: int = 4
    sm: int = 8
    md: int = 12
    lg: int = 16
    xl: int = 24
    xxl: int = 32
    xxxl: int = 48
    
    # Component specific
    button_padding_x: int = 16
    button_padding_y: int = 8
    input_padding_x: int = 12
    input_padding_y: int = 8
    card_padding: int = 16
    section_gap: int = 24


# ============================================================
# SHADOWS & EFFECTS
# ============================================================
@dataclass
class Effects:
    """Visual effects (limited in tkinter)"""
    
    border_radius_sm: int = 4
    border_radius_md: int = 8
    border_radius_lg: int = 12
    border_radius_full: int = 9999
    
    # Transition durations (ms)
    transition_fast: int = 100
    transition_normal: int = 200
    transition_slow: int = 300


# ============================================================
# THEME CLASS
# ============================================================
class Theme:
    """Main theme class"""
    
    def __init__(self, dark_mode: bool = False):
        self.dark_mode = dark_mode
        self.colors = DarkColorPalette() if dark_mode else ColorPalette()
        self.typography = Typography()
        self.spacing = Spacing()
        self.effects = Effects()
    
    def apply_to_ttk(self, style: ttk.Style):
        """Apply theme to ttk widgets"""
        
        # Configure style
        style.theme_use('clam')
        
        # Treeview
        style.configure(
            "Treeview",
            background=self.colors.bg_primary,
            foreground=self.colors.text_primary,
            fieldbackground=self.colors.bg_primary,
            rowheight=32,
            font=(self.typography.font_family, self.typography.size_sm)
        )
        
        style.configure(
            "Treeview.Heading",
            background=self.colors.bg_secondary,
            foreground=self.colors.text_primary,
            font=(self.typography.font_family, self.typography.size_sm, "bold"),
            padding=(8, 8)
        )
        
        style.map(
            "Treeview",
            background=[("selected", self.colors.primary_light)],
            foreground=[("selected", self.colors.text_primary)]
        )
        
        # Buttons
        style.configure(
            "TButton",
            background=self.colors.bg_secondary,
            foreground=self.colors.text_primary,
            padding=(12, 8),
            font=(self.typography.font_family, self.typography.size_sm)
        )
        
        style.configure(
            "Primary.TButton",
            background=self.colors.primary,
            foreground=self.colors.text_inverse,
            padding=(12, 8)
        )
        
        style.configure(
            "Success.TButton",
            background=self.colors.success,
            foreground=self.colors.text_inverse
        )
        
        style.configure(
            "Danger.TButton",
            background=self.colors.error,
            foreground=self.colors.text_inverse
        )
        
        # Entry/Combobox
        style.configure(
            "TEntry",
            fieldbackground=self.colors.bg_primary,
            foreground=self.colors.text_primary,
            padding=(8, 6)
        )
        
        style.configure(
            "TCombobox",
            fieldbackground=self.colors.bg_primary,
            foreground=self.colors.text_primary,
            padding=(8, 6)
        )
        
        # Labels
        style.configure(
            "TLabel",
            background=self.colors.bg_primary,
            foreground=self.colors.text_primary,
            font=(self.typography.font_family, self.typography.size_sm)
        )
        
        style.configure(
            "Title.TLabel",
            font=(self.typography.font_family, self.typography.size_2xl, "bold")
        )
        
        style.configure(
            "Subtitle.TLabel",
            foreground=self.colors.text_secondary,
            font=(self.typography.font_family, self.typography.size_sm)
        )
        
        # Frame
        style.configure(
            "TFrame",
            background=self.colors.bg_primary
        )
        
        style.configure(
            "Card.TFrame",
            background=self.colors.bg_primary,
            relief="flat"
        )
        
        # Notebook (tabs)
        style.configure(
            "TNotebook",
            background=self.colors.bg_secondary
        )
        
        style.configure(
            "TNotebook.Tab",
            background=self.colors.bg_secondary,
            foreground=self.colors.text_secondary,
            padding=(16, 8)
        )
        
        style.map(
            "TNotebook.Tab",
            background=[("selected", self.colors.bg_primary)],
            foreground=[("selected", self.colors.text_primary)]
        )
        
        # Scrollbar
        style.configure(
            "TScrollbar",
            background=self.colors.bg_tertiary,
            troughcolor=self.colors.bg_secondary,
            width=12
        )
        
        # Revenue/Cost specific
        style.configure(
            "Revenue.Treeview",
            background=self.colors.revenue_bg
        )
        
        style.configure(
            "Cost.Treeview",
            background=self.colors.cost_bg
        )
    
    def get_button_style(self, variant: str = "default") -> dict:
        """Get CustomTkinter button style"""
        styles = {
            "default": {
                "fg_color": self.colors.bg_secondary,
                "text_color": self.colors.text_primary,
                "hover_color": self.colors.bg_tertiary,
                "corner_radius": self.effects.border_radius_md
            },
            "primary": {
                "fg_color": self.colors.primary,
                "text_color": self.colors.text_inverse,
                "hover_color": self.colors.primary_hover,
                "corner_radius": self.effects.border_radius_md
            },
            "success": {
                "fg_color": self.colors.success,
                "text_color": self.colors.text_inverse,
                "hover_color": "#2DA44E",
                "corner_radius": self.effects.border_radius_md
            },
            "danger": {
                "fg_color": self.colors.error,
                "text_color": self.colors.text_inverse,
                "hover_color": "#DC2626",
                "corner_radius": self.effects.border_radius_md
            },
            "ghost": {
                "fg_color": "transparent",
                "text_color": self.colors.text_secondary,
                "hover_color": self.colors.bg_hover,
                "corner_radius": self.effects.border_radius_md
            },
            "revenue": {
                "fg_color": self.colors.revenue,
                "text_color": self.colors.text_inverse,
                "hover_color": "#2DA44E",
                "corner_radius": self.effects.border_radius_md
            },
            "cost": {
                "fg_color": self.colors.cost,
                "text_color": self.colors.text_inverse,
                "hover_color": "#DC2626",
                "corner_radius": self.effects.border_radius_md
            }
        }
        return styles.get(variant, styles["default"])
    
    def get_input_style(self) -> dict:
        """Get CustomTkinter input style"""
        return {
            "fg_color": self.colors.bg_primary,
            "text_color": self.colors.text_primary,
            "border_color": self.colors.border,
            "border_width": 1,
            "corner_radius": self.effects.border_radius_md
        }
    
    def get_card_style(self) -> dict:
        """Get card/panel style"""
        return {
            "fg_color": self.colors.bg_primary,
            "corner_radius": self.effects.border_radius_lg,
            "border_width": 1,
            "border_color": self.colors.border_light
        }


# ============================================================
# GLOBAL THEME INSTANCE
# ============================================================
_current_theme: Optional[Theme] = None


def get_theme() -> Theme:
    """Get the current theme instance."""
    global _current_theme
    if _current_theme is None:
        _current_theme = Theme(dark_mode=False)
    return _current_theme


def set_theme(dark_mode: bool = False):
    """Set the current theme."""
    global _current_theme
    _current_theme = Theme(dark_mode=dark_mode)
    return _current_theme


# ============================================================
# ICON CONSTANTS (Unicode/Emoji)
# ============================================================
class Icons:
    """Unicode icons for consistent UI"""
    
    # Navigation
    HOME = "🏠"
    SEARCH = "🔍"
    SETTINGS = "⚙️"
    MENU = "☰"
    BACK = "←"
    FORWARD = "→"
    UP = "↑"
    DOWN = "↓"
    
    # Actions
    ADD = "+"
    REMOVE = "−"
    EDIT = "✏️"
    DELETE = "🗑️"
    SAVE = "💾"
    REFRESH = "🔄"
    COPY = "📋"
    PRINT = "🖨️"
    EXPORT = "📤"
    IMPORT = "📥"
    
    # Status
    SUCCESS = "✓"
    ERROR = "✗"
    WARNING = "⚠️"
    INFO = "ℹ️"
    LOADING = "⟳"
    
    # Business
    DOCUMENT = "📄"
    FOLDER = "📁"
    MONEY = "💰"
    CHART = "📊"
    CALENDAR = "📅"
    USER = "👤"
    COMPANY = "🏢"
    SHIP = "🚢"
    PLANE = "✈️"
    TRUCK = "🚚"
    
    # Settlement
    REVENUE = "📈"
    COST = "📉"
    INVOICE = "🧾"
    PAYMENT = "💳"


# ============================================================
# HELPER FUNCTIONS
# ============================================================
def apply_hover_effect(widget, normal_color: str, hover_color: str):
    """Apply hover effect to a widget."""
    def on_enter(e):
        widget.configure(fg_color=hover_color)
    
    def on_leave(e):
        widget.configure(fg_color=normal_color)
    
    widget.bind("<Enter>", on_enter)
    widget.bind("<Leave>", on_leave)


def create_tooltip(widget, text: str):
    """Create a tooltip for a widget."""
    def show_tooltip(event):
        tooltip = tk.Toplevel(widget)
        tooltip.wm_overrideredirect(True)
        tooltip.wm_geometry(f"+{event.x_root + 10}+{event.y_root + 10}")
        
        theme = get_theme()
        label = tk.Label(
            tooltip, 
            text=text,
            background=theme.colors.text_primary,
            foreground=theme.colors.text_inverse,
            padx=8, pady=4,
            font=(theme.typography.font_family, theme.typography.size_xs)
        )
        label.pack()
        
        widget._tooltip = tooltip
    
    def hide_tooltip(event):
        if hasattr(widget, '_tooltip') and widget._tooltip:
            widget._tooltip.destroy()
            widget._tooltip = None
    
    widget.bind("<Enter>", show_tooltip)
    widget.bind("<Leave>", hide_tooltip)


# ============================================================
# EXPORTS
# ============================================================
__all__ = [
    'ColorPalette', 'DarkColorPalette', 'Typography', 'Spacing', 'Effects',
    'Theme', 'get_theme', 'set_theme', 'Icons',
    'apply_hover_effect', 'create_tooltip'
]
