# autocomplete_util.py
# Enhanced autocomplete with keyboard/mouse selection, improved port search

import customtkinter as ctk
import tkinter as tk
from db import get_connection


class AutocompleteEntry:
    """Enhanced autocomplete with arrow key and mouse selection"""

    def __init__(self, entry_widget, fetch_func, on_select_callback=None, related_widgets=None):
        self.entry = entry_widget
        self.fetch_func = fetch_func
        self.on_select_callback = on_select_callback
        self.related_widgets = related_widgets or {}
        self.listbox = None
        self.popup = None
        self.selected_index = -1
        self.items = []
        self._popup_active = False

        self.entry.bind("<KeyRelease>", self._on_key_release)
        self.entry.bind("<Down>", self._on_arrow_down)
        self.entry.bind("<Up>", self._on_arrow_up)
        self.entry.bind("<Return>", self._on_enter)
        self.entry.bind("<Escape>", self._close_popup)
        self.entry.bind("<FocusOut>", self._delayed_close)
        self.entry.bind("<FocusIn>", self._on_focus_in)

    def _on_focus_in(self, event=None):
        try:
            if hasattr(self.entry, 'configure'):
                self.entry.configure(state="normal")
        except:
            pass

    def _on_key_release(self, event):
        if event.keysym in ("Down", "Up", "Return", "Escape", "Tab", "Shift_L", "Shift_R", "Control_L", "Control_R"):
            return

        text = self.entry.get().strip()
        if len(text) < 1:
            self._close_popup()
            return

        try:
            self.items = self.fetch_func(text) or []
        except Exception as e:
            print(f"Fetch error: {e}")
            self.items = []

        if not self.items:
            self._close_popup()
            return

        self._show_popup()

    def _show_popup(self):
        try:
            if self.popup and self.popup.winfo_exists():
                self.popup.destroy()
        except:
            pass

        try:
            self.popup = tk.Toplevel(self.entry.winfo_toplevel())
            self.popup.wm_overrideredirect(True)
            self.popup.attributes("-topmost", True)
            self._popup_active = True

            x = self.entry.winfo_rootx()
            y = self.entry.winfo_rooty() + self.entry.winfo_height()
            width = max(self.entry.winfo_width(), 400)
            height = min(len(self.items) * 22 + 4, 220)

            self.popup.geometry(f"{width}x{height}+{x}+{y}")

            frame = tk.Frame(self.popup, bg="#FFFFFF", bd=1, relief="solid")
            frame.pack(fill="both", expand=True)

            scrollbar = tk.Scrollbar(frame, orient="vertical")
            
            self.listbox = tk.Listbox(
                frame,
                bg="#FFFFFF",
                fg="#333333",
                selectbackground="#3B82F6",
                selectforeground="#FFFFFF",
                font=("SF Pro Display", 10),
                bd=0,
                highlightthickness=0,
                activestyle="none",
                yscrollcommand=scrollbar.set
            )
            scrollbar.config(command=self.listbox.yview)
            
            self.listbox.pack(side="left", fill="both", expand=True, padx=1, pady=1)
            if len(self.items) > 8:
                scrollbar.pack(side="right", fill="y")

            for item in self.items:
                if isinstance(item, dict):
                    # Port format: CODE - NAME, COUNTRY
                    display = item.get('display', str(item))
                elif isinstance(item, tuple):
                    parts = []
                    for i, x in enumerate(item):
                        if x:
                            val = str(x)
                            if i == 2 and len(val) > 30:
                                val = val[:30] + "..."
                            parts.append(val)
                    display = " | ".join(parts)
                else:
                    display = str(item)
                self.listbox.insert("end", display)

            self.listbox.bind("<ButtonRelease-1>", self._on_click)
            self.listbox.bind("<Motion>", self._on_mouse_motion)
            self.listbox.bind("<Double-1>", self._on_double_click)

            self.selected_index = -1

        except Exception as e:
            print(f"Popup error: {e}")
            self._popup_active = False

    def _on_mouse_motion(self, event):
        try:
            if not self.listbox:
                return
            index = self.listbox.nearest(event.y)
            if 0 <= index < len(self.items) and index != self.selected_index:
                self.listbox.selection_clear(0, "end")
                self.listbox.selection_set(index)
                self.selected_index = index
        except:
            pass

    def _on_click(self, event):
        self._select_current()

    def _on_double_click(self, event):
        self._select_current()

    def _on_arrow_down(self, event):
        if not self.listbox or not self.popup or not self._popup_active:
            return
        try:
            if not self.popup.winfo_exists():
                return
            if self.selected_index < len(self.items) - 1:
                self.selected_index += 1
                self.listbox.selection_clear(0, "end")
                self.listbox.selection_set(self.selected_index)
                self.listbox.see(self.selected_index)
        except:
            pass
        return "break"

    def _on_arrow_up(self, event):
        if not self.listbox or not self.popup or not self._popup_active:
            return
        try:
            if not self.popup.winfo_exists():
                return
            if self.selected_index > 0:
                self.selected_index -= 1
                self.listbox.selection_clear(0, "end")
                self.listbox.selection_set(self.selected_index)
                self.listbox.see(self.selected_index)
        except:
            pass
        return "break"

    def _on_enter(self, event):
        if self.popup and self._popup_active and self.selected_index >= 0:
            self._select_current()
            return "break"

    def _select_current(self):
        try:
            if not self.listbox:
                return

            selection = self.listbox.curselection()
            if selection:
                idx = selection[0]
            elif self.selected_index >= 0:
                idx = self.selected_index
            else:
                return

            if 0 <= idx < len(self.items):
                item = self.items[idx]
                
                # Determine the value to set
                if isinstance(item, dict):
                    value = item.get('value', item.get('code', ''))
                elif isinstance(item, tuple):
                    value = item[0]
                else:
                    value = item

                self.entry.delete(0, "end")
                self.entry.insert(0, value)

                # Populate related widgets
                if isinstance(item, tuple) and self.related_widgets:
                    if 'name' in self.related_widgets and len(item) > 1:
                        w = self.related_widgets['name']
                        try:
                            w.delete(0, "end")
                            w.insert(0, item[1] or "")
                        except:
                            pass
                    if 'address' in self.related_widgets and len(item) > 2:
                        w = self.related_widgets['address']
                        try:
                            if hasattr(w, 'delete') and hasattr(w, 'insert'):
                                w.delete("1.0", "end")
                                w.insert("1.0", item[2] or "")
                            else:
                                w.delete(0, "end")
                                w.insert(0, item[2] or "")
                        except:
                            pass

                # Call callback
                if self.on_select_callback:
                    try:
                        self.on_select_callback(item)
                    except Exception as e:
                        print(f"Callback error: {e}")

            self._close_popup()
            
            try:
                self.entry.configure(state="normal")
                self.entry.focus_set()
            except:
                pass

        except Exception as e:
            print(f"Select error: {e}")
            self._close_popup()

    def _close_popup(self, event=None):
        self._popup_active = False
        try:
            if self.popup and self.popup.winfo_exists():
                self.popup.destroy()
        except:
            pass
        self.popup = None
        self.listbox = None
        self.selected_index = -1
        
        try:
            self.entry.configure(state="normal")
        except:
            pass

    def _delayed_close(self, event=None):
        if self._popup_active:
            self.entry.after(200, self._close_popup)


# ============================================================
# Fetch functions
# ============================================================

def fetch_customers(text):
    """Returns (code, name, address) tuples - searches both code and name"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("""
            SELECT code, name, address FROM customers 
            WHERE code LIKE ? OR name LIKE ? 
            ORDER BY code LIMIT 20
        """, (f"%{text}%", f"%{text}%"))
        results = cur.fetchall()
    except Exception as e:
        print(f"fetch_customers error: {e}")
    finally:
        conn.close()
    return results


def fetch_sea_ports(text):
    """
    Returns list of dicts for sea ports
    Searches: code, name, city, country
    Display format: CODE - NAME, COUNTRY (like KRPUS - BUSAN, KOREA)
    """
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        search = f"%{text}%"
        cur.execute("""
            SELECT code, name, city, country FROM ports 
            WHERE type = 'SEA' AND (
                code LIKE ? OR name LIKE ? OR city LIKE ? OR country LIKE ?
            )
            ORDER BY code LIMIT 20
        """, (search, search, search, search))
        
        for row in cur.fetchall():
            code, name, city, country = row[0], row[1], row[2], row[3]
            # Format: CODE - NAME, COUNTRY
            display_name = name or city or ''
            display_country = country or ''
            if display_country:
                display = f"{code} - {display_name}, {display_country}"
            else:
                display = f"{code} - {display_name}"
            
            results.append({
                'code': code,
                'name': name,
                'city': city,
                'country': country,
                'display': display,
                'value': code  # What gets inserted into the field
            })
    except Exception as e:
        print(f"fetch_sea_ports error: {e}")
    finally:
        conn.close()
    return results


def fetch_air_ports(text):
    """
    Returns list of dicts for air ports
    Searches: code, name, city, country
    Display format: CODE - NAME, COUNTRY
    """
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        search = f"%{text}%"
        cur.execute("""
            SELECT code, name, city, country FROM ports 
            WHERE type = 'AIR' AND (
                code LIKE ? OR name LIKE ? OR city LIKE ? OR country LIKE ?
            )
            ORDER BY code LIMIT 20
        """, (search, search, search, search))
        
        for row in cur.fetchall():
            code, name, city, country = row[0], row[1], row[2], row[3]
            display_name = name or city or ''
            display_country = country or ''
            if display_country:
                display = f"{code} - {display_name}, {display_country}"
            else:
                display = f"{code} - {display_name}"
            
            results.append({
                'code': code,
                'name': name,
                'city': city,
                'country': country,
                'display': display,
                'value': code
            })
    except Exception as e:
        print(f"fetch_air_ports error: {e}")
    finally:
        conn.close()
    return results


def fetch_quotes(text):
    """Returns quote_ref strings"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("""
            SELECT quote_ref FROM offers 
            WHERE quote_ref LIKE ? 
            ORDER BY quote_ref DESC LIMIT 20
        """, (f"%{text}%",))
        results = [row[0] for row in cur.fetchall()]
    except Exception as e:
        print(f"fetch_quotes error: {e}")
    finally:
        conn.close()
    return results


def fetch_vessels(text):
    """Returns vessel names"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("""
            SELECT DISTINCT vessel FROM jobs 
            WHERE vessel LIKE ? AND vessel IS NOT NULL AND vessel != ''
            ORDER BY vessel LIMIT 20
        """, (f"%{text}%",))
        results = [row[0] for row in cur.fetchall()]
    except Exception as e:
        print(f"fetch_vessels error: {e}")
    finally:
        conn.close()
    return results


def fetch_airlines(text):
    """Returns airline names"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("""
            SELECT DISTINCT carrier FROM jobs 
            WHERE mode = 'AIR' AND carrier LIKE ? AND carrier IS NOT NULL AND carrier != ''
            ORDER BY carrier LIMIT 20
        """, (f"%{text}%",))
        results = [row[0] for row in cur.fetchall()]
    except Exception as e:
        print(f"fetch_airlines error: {e}")
    finally:
        conn.close()
    return results


def fetch_jobs_by_bl(text):
    """Returns jobs by MBL or HBL for settlement"""
    conn = get_connection()
    cur = conn.cursor()
    results = []
    try:
        cur.execute("""
            SELECT job_no, mode, mbl, hbl, customer, pol, pod, status
            FROM jobs 
            WHERE mbl LIKE ? OR hbl LIKE ? OR job_no LIKE ?
            ORDER BY created_at DESC LIMIT 20
        """, (f"%{text}%", f"%{text}%", f"%{text}%"))
        results = cur.fetchall()
    except Exception as e:
        print(f"fetch_jobs_by_bl error: {e}")
    finally:
        conn.close()
    return results