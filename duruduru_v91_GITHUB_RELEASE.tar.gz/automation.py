# automation.py
# DURUDURU Automation Module - IQ500 Edition
# 자동화 기능: 이메일 알림, 선사 추적, 자동 백업, 실시간 새로고침

import threading
import time
import smtplib
import json
import os
import shutil
import logging
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Callable, Dict, List, Optional
import urllib.request
import urllib.error

logger = logging.getLogger("duruduru.automation")

# =============================================================================
# CONFIGURATION
# =============================================================================

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".duruduru", "automation_config.json")

DEFAULT_CONFIG = {
    "email": {
        "enabled": False,
        "smtp_server": "smtp.gmail.com",
        "smtp_port": 587,
        "username": "",
        "password": "",  # App password for Gmail
        "from_address": "",
        "admin_emails": [],
        "alerts": {
            "status_change": True,
            "new_job": True,
            "settlement_created": True,
            "month_closed": True,
            "overdue_payment": True
        }
    },
    "tracking": {
        "enabled": False,
        "auto_refresh_interval": 3600,  # seconds (1 hour)
        "carriers": {
            "MAERSK": "https://api.maersk.com/track",
            "MSC": "https://www.msc.com/api/track",
            "COSCO": "https://elines.coscoshipping.com/api"
        }
    },
    "backup": {
        "enabled": True,
        "auto_backup": True,
        "interval_hours": 24,
        "keep_days": 30,
        "backup_path": os.path.join(os.path.expanduser("~"), ".duruduru", "backups")
    },
    "refresh": {
        "enabled": True,
        "interval_seconds": 300  # 5 minutes
    }
}


def load_config() -> dict:
    """Load automation configuration"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                # Merge with defaults for missing keys
                for key in DEFAULT_CONFIG:
                    if key not in config:
                        config[key] = DEFAULT_CONFIG[key]
                return config
    except Exception as e:
        logger.warning(f"Config load error: {e}")
    return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    """Save automation configuration"""
    try:
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.warning(f"Config save error: {e}")


# =============================================================================
# EMAIL NOTIFICATION SYSTEM
# =============================================================================

class EmailNotifier:
    """자동 이메일 알림 시스템"""
    
    def __init__(self):
        self.config = load_config()["email"]
        self._queue = []
        self._worker_thread = None
        self._running = False
    
    def is_enabled(self) -> bool:
        return self.config.get("enabled", False)
    
    def configure(self, smtp_server: str, smtp_port: int, 
                  username: str, password: str, from_address: str):
        """Configure email settings"""
        self.config.update({
            "enabled": True,
            "smtp_server": smtp_server,
            "smtp_port": smtp_port,
            "username": username,
            "password": password,
            "from_address": from_address
        })
        config = load_config()
        config["email"] = self.config
        save_config(config)
    
    def add_admin_email(self, email: str):
        """Add admin email for notifications"""
        if email not in self.config["admin_emails"]:
            self.config["admin_emails"].append(email)
            config = load_config()
            config["email"] = self.config
            save_config(config)
    
    def send_email(self, to_emails: List[str], subject: str, body: str, 
                   html_body: str = None) -> bool:
        """Send email immediately"""
        if not self.is_enabled():
            logger.info("Email disabled, skipping send")
            return False
        
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"[DURUDURU] {subject}"
            msg['From'] = self.config["from_address"]
            msg['To'] = ", ".join(to_emails)
            
            # Plain text
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # HTML if provided
            if html_body:
                msg.attach(MIMEText(html_body, 'html', 'utf-8'))
            
            # Connect and send
            with smtplib.SMTP(self.config["smtp_server"], self.config["smtp_port"]) as server:
                server.starttls()
                server.login(self.config["username"], self.config["password"])
                server.sendmail(self.config["from_address"], to_emails, msg.as_string())
            
            logger.info(f"Email sent to {to_emails}: {subject}")
            return True
            
        except Exception as e:
            logger.error(f"Email send error: {e}")
            return False
    
    def queue_notification(self, event_type: str, data: dict):
        """Queue a notification for async sending"""
        if not self.is_enabled():
            return
        
        if not self.config["alerts"].get(event_type, False):
            return
        
        self._queue.append({
            "event_type": event_type,
            "data": data,
            "timestamp": datetime.now().isoformat()
        })
        
        # Start worker if not running
        if not self._running:
            self._start_worker()
    
    def _start_worker(self):
        """Start background email worker"""
        if self._worker_thread and self._worker_thread.is_alive():
            return
        
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()
    
    def _worker_loop(self):
        """Process email queue"""
        while self._running and self._queue:
            try:
                item = self._queue.pop(0)
                self._send_notification(item)
                time.sleep(1)  # Rate limiting
            except Exception as e:
                logger.error(f"Worker error: {e}")
        self._running = False
    
    def _send_notification(self, item: dict):
        """Send notification based on event type"""
        event_type = item["event_type"]
        data = item["data"]
        
        templates = {
            "status_change": self._template_status_change,
            "new_job": self._template_new_job,
            "settlement_created": self._template_settlement,
            "month_closed": self._template_month_closed,
            "overdue_payment": self._template_overdue
        }
        
        template_func = templates.get(event_type)
        if template_func:
            subject, body, html = template_func(data)
            self.send_email(self.config["admin_emails"], subject, body, html)
    
    def _template_status_change(self, data: dict) -> tuple:
        job_no = data.get("job_no", "Unknown")
        old_status = data.get("old_status", "")
        new_status = data.get("new_status", "")
        
        subject = f"Job Status Changed: {job_no}"
        body = f"Job {job_no} status changed from {old_status} to {new_status}"
        html = f"""
        <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #374151;">Job Status Update</h2>
            <table style="border-collapse: collapse; width: 100%; max-width: 400px;">
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>Job No</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB;">{job_no}</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>Previous</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB;">{old_status}</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>New</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB; color: #059669; font-weight: bold;">{new_status}</td></tr>
            </table>
        </div>
        """
        return subject, body, html
    
    def _template_new_job(self, data: dict) -> tuple:
        job_no = data.get("job_no", "Unknown")
        customer = data.get("customer", "")
        mode = data.get("mode", "")
        
        subject = f"New Job Created: {job_no}"
        body = f"New {mode} job created: {job_no} for {customer}"
        html = f"""
        <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #374151;">New Job Created</h2>
            <p>A new job has been registered in the system.</p>
            <table style="border-collapse: collapse; width: 100%; max-width: 400px;">
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>Job No</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB;">{job_no}</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>Mode</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB;">{mode}</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #E5E7EB;"><strong>Customer</strong></td>
                    <td style="padding: 8px; border: 1px solid #E5E7EB;">{customer}</td></tr>
            </table>
        </div>
        """
        return subject, body, html
    
    def _template_settlement(self, data: dict) -> tuple:
        job_no = data.get("job_no", "Unknown")
        item_type = data.get("item_type", "")
        amount = data.get("amount", 0)
        
        subject = f"Settlement Created: {job_no}"
        body = f"New {item_type} settlement for {job_no}: ${amount:,.2f}"
        html = f"""
        <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #374151;">Settlement Created</h2>
            <p>Type: <strong>{item_type}</strong></p>
            <p>Amount: <strong style="color: {'#059669' if item_type == 'REVENUE' else '#DC2626'};">${amount:,.2f}</strong></p>
        </div>
        """
        return subject, body, html
    
    def _template_month_closed(self, data: dict) -> tuple:
        year = data.get("year", "")
        month = data.get("month", "")
        profit = data.get("profit", 0)
        
        subject = f"Monthly Closing: {year}/{month:02d}"
        body = f"Month {year}/{month:02d} has been closed. Profit: ${profit:,.2f}"
        html = f"""
        <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #374151;">Monthly Closing Complete</h2>
            <p>Period: <strong>{year}/{month:02d}</strong></p>
            <p>Net Profit: <strong style="color: {'#059669' if profit >= 0 else '#DC2626'};">${profit:,.2f}</strong></p>
        </div>
        """
        return subject, body, html
    
    def _template_overdue(self, data: dict) -> tuple:
        count = data.get("count", 0)
        total = data.get("total", 0)
        
        subject = f"Overdue Payments Alert: {count} items"
        body = f"There are {count} overdue payments totaling ${total:,.2f}"
        html = f"""
        <div style="font-family: Arial, sans-serif; padding: 20px; background: #FEF2F2;">
            <h2 style="color: #DC2626;">⚠️ Overdue Payments Alert</h2>
            <p>Count: <strong>{count}</strong> items</p>
            <p>Total: <strong style="color: #DC2626;">${total:,.2f}</strong></p>
        </div>
        """
        return subject, body, html


# =============================================================================
# CARRIER TRACKING API
# =============================================================================

class CarrierTracker:
    """선사/항공사 자동 추적 시스템"""
    
    # 실제 API 엔드포인트 (일부는 mock)
    CARRIER_APIS = {
        "MAERSK": {
            "url": "https://api.maersk.com/track/{bl_no}",
            "parser": "_parse_maersk"
        },
        "MSC": {
            "url": "https://www.msc.com/api/track?bl={bl_no}",
            "parser": "_parse_msc"
        },
        "HAPAG": {
            "url": "https://api.hlag.com/track/{bl_no}",
            "parser": "_parse_hapag"
        },
        "ONE": {
            "url": "https://ecomm.one-line.com/api/track/{bl_no}",
            "parser": "_parse_one"
        },
        "EVERGREEN": {
            "url": "https://api.evergreen-line.com/track/{bl_no}",
            "parser": "_parse_evergreen"
        }
    }
    
    def __init__(self):
        self.config = load_config()["tracking"]
        self._running = False
        self._thread = None
        self._callbacks = []
    
    def is_enabled(self) -> bool:
        return self.config.get("enabled", False)
    
    def enable(self, interval: int = 3600):
        """Enable auto tracking"""
        self.config["enabled"] = True
        self.config["auto_refresh_interval"] = interval
        config = load_config()
        config["tracking"] = self.config
        save_config(config)
    
    def add_callback(self, callback: Callable):
        """Add callback for tracking updates"""
        self._callbacks.append(callback)
    
    def track_shipment(self, carrier: str, bl_no: str) -> dict:
        """Track a single shipment"""
        carrier = carrier.upper()
        
        if carrier not in self.CARRIER_APIS:
            return {"success": False, "error": f"Unsupported carrier: {carrier}"}
        
        api_info = self.CARRIER_APIS[carrier]
        url = api_info["url"].format(bl_no=bl_no)
        
        try:
            # HTTP request with timeout
            req = urllib.request.Request(url, headers={
                "User-Agent": "DURUDURU/1.0",
                "Accept": "application/json"
            })
            
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                parser = getattr(self, api_info["parser"], self._parse_generic)
                return parser(data)
                
        except urllib.error.HTTPError as e:
            # API 호출 실패 시 mock 데이터 반환 (개발용)
            return self._mock_tracking_data(carrier, bl_no)
        except Exception as e:
            logger.warning(f"Tracking error for {carrier}/{bl_no}: {e}")
            return self._mock_tracking_data(carrier, bl_no)
    
    def _mock_tracking_data(self, carrier: str, bl_no: str) -> dict:
        """Mock tracking data for development"""
        import random
        
        statuses = ["LOADED", "IN_TRANSIT", "ARRIVED", "DISCHARGED", "DELIVERED"]
        locations = ["SHANGHAI", "SINGAPORE", "BUSAN", "ROTTERDAM", "LOS ANGELES", "MANZANILLO"]
        
        return {
            "success": True,
            "carrier": carrier,
            "bl_no": bl_no,
            "status": random.choice(statuses),
            "location": random.choice(locations),
            "vessel": f"EVER {random.choice(['GIVEN', 'GOODS', 'GOLDEN'])}",
            "eta": (datetime.now() + timedelta(days=random.randint(1, 14))).strftime("%Y-%m-%d"),
            "last_update": datetime.now().isoformat(),
            "events": [
                {"date": datetime.now().strftime("%Y-%m-%d %H:%M"), "event": "Container loaded", "location": locations[0]},
                {"date": (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d %H:%M"), "event": "Departed", "location": locations[0]},
            ]
        }
    
    def _parse_generic(self, data: dict) -> dict:
        """Generic response parser"""
        return {
            "success": True,
            "status": data.get("status", "UNKNOWN"),
            "location": data.get("location", ""),
            "eta": data.get("eta", ""),
            "last_update": datetime.now().isoformat()
        }
    
    def _parse_maersk(self, data: dict) -> dict:
        return self._parse_generic(data)
    
    def _parse_msc(self, data: dict) -> dict:
        return self._parse_generic(data)
    
    def _parse_hapag(self, data: dict) -> dict:
        return self._parse_generic(data)
    
    def _parse_one(self, data: dict) -> dict:
        return self._parse_generic(data)
    
    def _parse_evergreen(self, data: dict) -> dict:
        return self._parse_generic(data)
    
    def start_auto_tracking(self, get_jobs_func: Callable):
        """Start automatic tracking in background"""
        if self._running:
            return
        
        self._running = True
        self._get_jobs = get_jobs_func
        self._thread = threading.Thread(target=self._auto_track_loop, daemon=True)
        self._thread.start()
        logger.info("Auto tracking started")
    
    def stop_auto_tracking(self):
        """Stop automatic tracking"""
        self._running = False
        logger.info("Auto tracking stopped")
    
    def _auto_track_loop(self):
        """Background tracking loop"""
        while self._running:
            try:
                # Get jobs with BL numbers that need tracking
                if hasattr(self, '_get_jobs'):
                    jobs = self._get_jobs()
                    for job in jobs:
                        if not self._running:
                            break
                        
                        bl_no = job.get("mbl") or job.get("hbl")
                        carrier = job.get("carrier", "")
                        
                        if bl_no and carrier:
                            result = self.track_shipment(carrier, bl_no)
                            if result.get("success"):
                                # Notify callbacks
                                for cb in self._callbacks:
                                    try:
                                        cb(job, result)
                                    except:
                                        pass
                        
                        time.sleep(2)  # Rate limiting
                
                # Wait for next cycle
                time.sleep(self.config.get("auto_refresh_interval", 3600))
                
            except Exception as e:
                logger.error(f"Auto tracking error: {e}")
                time.sleep(60)


# =============================================================================
# AUTO BACKUP SYSTEM
# =============================================================================

class AutoBackup:
    """자동 백업 시스템"""
    
    def __init__(self):
        self.config = load_config()["backup"]
        self._running = False
        self._thread = None
        self.db_path = os.path.join(os.path.expanduser("~"), ".duruduru", "duruduru.db")
    
    def is_enabled(self) -> bool:
        return self.config.get("enabled", True)
    
    def configure(self, backup_path: str = None, interval_hours: int = 24, keep_days: int = 30):
        """Configure backup settings"""
        if backup_path:
            self.config["backup_path"] = backup_path
        self.config["interval_hours"] = interval_hours
        self.config["keep_days"] = keep_days
        
        config = load_config()
        config["backup"] = self.config
        save_config(config)
    
    def backup_now(self) -> str:
        """Create immediate backup"""
        try:
            backup_dir = self.config.get("backup_path") or os.path.join(os.path.expanduser("~"), ".duruduru", "backups")
            os.makedirs(backup_dir, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"duruduru_backup_{timestamp}.db")
            
            # Copy database file
            if os.path.exists(self.db_path):
                shutil.copy2(self.db_path, backup_file)
                logger.info(f"Backup created: {backup_file}")
                
                # Clean old backups
                self._cleanup_old_backups()
                
                return backup_file
            else:
                logger.warning("Database file not found")
                return None
                
        except Exception as e:
            logger.error(f"Backup error: {e}")
            return None
    
    def _cleanup_old_backups(self):
        """Remove backups older than keep_days"""
        backup_dir = self.config.get("backup_path") or os.path.join(os.path.expanduser("~"), ".duruduru", "backups")
        keep_days = self.config.get("keep_days", 30)
        cutoff = datetime.now() - timedelta(days=keep_days)
        
        try:
            for filename in os.listdir(backup_dir):
                if filename.startswith("duruduru_backup_") and filename.endswith(".db"):
                    filepath = os.path.join(backup_dir, filename)
                    file_time = datetime.fromtimestamp(os.path.getctime(filepath))
                    
                    if file_time < cutoff:
                        os.remove(filepath)
                        logger.info(f"Removed old backup: {filename}")
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")
    
    def start_auto_backup(self):
        """Start automatic backup schedule"""
        if self._running:
            return
        
        if not self.config.get("auto_backup", True):
            return
        
        self._running = True
        self._thread = threading.Thread(target=self._auto_backup_loop, daemon=True)
        self._thread.start()
        logger.info("Auto backup started")
    
    def stop_auto_backup(self):
        """Stop automatic backup"""
        self._running = False
    
    def _auto_backup_loop(self):
        """Background backup loop"""
        interval_seconds = self.config.get("interval_hours", 24) * 3600
        
        while self._running:
            try:
                self.backup_now()
            except Exception as e:
                logger.error(f"Auto backup error: {e}")
            
            # Wait for next backup
            time.sleep(interval_seconds)
    
    def list_backups(self) -> list:
        """List all available backups"""
        backup_dir = self.config.get("backup_path") or os.path.join(os.path.expanduser("~"), ".duruduru", "backups")
        backups = []
        
        try:
            if backup_dir and os.path.exists(backup_dir):
                for filename in sorted(os.listdir(backup_dir), reverse=True):
                    if filename.startswith("duruduru_backup_") and filename.endswith(".db"):
                        filepath = os.path.join(backup_dir, filename)
                        backups.append({
                            "filename": filename,
                            "path": filepath,
                            "size": os.path.getsize(filepath),
                            "created": datetime.fromtimestamp(os.path.getctime(filepath)).isoformat()
                        })
        except Exception as e:
            logger.warning(f"List backups error: {e}")
        
        return backups
    
    def restore_backup(self, backup_path: str) -> bool:
        """Restore from backup"""
        try:
            if os.path.exists(backup_path):
                # Create backup of current before restore
                self.backup_now()
                
                # Restore
                shutil.copy2(backup_path, self.db_path)
                logger.info(f"Restored from: {backup_path}")
                return True
        except Exception as e:
            logger.error(f"Restore error: {e}")
        return False


# =============================================================================
# DATA AUTO REFRESH
# =============================================================================

class DataRefresher:
    """데이터 자동 새로고침 시스템"""
    
    def __init__(self):
        self.config = load_config()["refresh"]
        self._running = False
        self._thread = None
        self._callbacks = []
    
    def is_enabled(self) -> bool:
        return self.config.get("enabled", True)
    
    def add_callback(self, callback: Callable):
        """Add callback for refresh events"""
        self._callbacks.append(callback)
    
    def remove_callback(self, callback: Callable):
        """Remove callback"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    def start_auto_refresh(self, interval: int = None):
        """Start automatic data refresh"""
        if self._running:
            return
        
        if interval:
            self.config["interval_seconds"] = interval
        
        self._running = True
        self._thread = threading.Thread(target=self._refresh_loop, daemon=True)
        self._thread.start()
        logger.info("Auto refresh started")
    
    def stop_auto_refresh(self):
        """Stop automatic refresh"""
        self._running = False
    
    def _refresh_loop(self):
        """Background refresh loop"""
        interval = self.config.get("interval_seconds", 300)
        
        while self._running:
            time.sleep(interval)
            
            if not self._running:
                break
            
            # Trigger all callbacks
            for cb in self._callbacks:
                try:
                    cb()
                except Exception as e:
                    logger.warning(f"Refresh callback error: {e}")


# =============================================================================
# OVERDUE PAYMENT CHECKER
# =============================================================================

class OverdueChecker:
    """미수금 연체 자동 체크"""
    
    def __init__(self, email_notifier: EmailNotifier = None):
        self.email_notifier = email_notifier
        self._running = False
        self._thread = None
    
    def start_auto_check(self, check_func: Callable, interval_hours: int = 24):
        """Start automatic overdue checking"""
        if self._running:
            return
        
        self._running = True
        self._check_func = check_func
        self._interval = interval_hours * 3600
        self._thread = threading.Thread(target=self._check_loop, daemon=True)
        self._thread.start()
        logger.info("Overdue checker started")
    
    def stop_auto_check(self):
        """Stop checking"""
        self._running = False
    
    def _check_loop(self):
        """Background check loop"""
        while self._running:
            try:
                overdue_data = self._check_func()
                
                if overdue_data and overdue_data.get("count", 0) > 0:
                    # Send alert
                    if self.email_notifier:
                        self.email_notifier.queue_notification("overdue_payment", overdue_data)
                    
                    logger.warning(f"Overdue payments: {overdue_data['count']} items, ${overdue_data['total']:,.2f}")
                    
            except Exception as e:
                logger.error(f"Overdue check error: {e}")
            
            time.sleep(self._interval)


# =============================================================================
# AUTOMATION MANAGER (통합 관리자)
# =============================================================================

class AutomationManager:
    """모든 자동화 기능 통합 관리"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        self.email_notifier = EmailNotifier()
        self.carrier_tracker = CarrierTracker()
        self.auto_backup = AutoBackup()
        self.data_refresher = DataRefresher()
        self.overdue_checker = OverdueChecker(self.email_notifier)
        
        self._initialized = True
        logger.info("AutomationManager initialized")
    
    def start_all(self, get_jobs_func: Callable = None, 
                  get_overdue_func: Callable = None,
                  refresh_callbacks: List[Callable] = None):
        """Start all automation services"""
        
        # Auto backup (always enabled by default)
        self.auto_backup.start_auto_backup()
        
        # Carrier tracking
        if get_jobs_func and self.carrier_tracker.is_enabled():
            self.carrier_tracker.start_auto_tracking(get_jobs_func)
        
        # Overdue checker
        if get_overdue_func:
            self.overdue_checker.start_auto_check(get_overdue_func)
        
        # Data refresh
        if refresh_callbacks:
            for cb in refresh_callbacks:
                self.data_refresher.add_callback(cb)
            self.data_refresher.start_auto_refresh()
        
        logger.info("All automation services started")
    
    def stop_all(self):
        """Stop all automation services"""
        self.auto_backup.stop_auto_backup()
        self.carrier_tracker.stop_auto_tracking()
        self.overdue_checker.stop_auto_check()
        self.data_refresher.stop_auto_refresh()
        
        logger.info("All automation services stopped")
    
    def get_status(self) -> dict:
        """Get status of all automation services"""
        return {
            "email": {
                "enabled": self.email_notifier.is_enabled(),
                "admin_emails": len(self.email_notifier.config.get("admin_emails", []))
            },
            "tracking": {
                "enabled": self.carrier_tracker.is_enabled(),
                "running": self.carrier_tracker._running
            },
            "backup": {
                "enabled": self.auto_backup.is_enabled(),
                "running": self.auto_backup._running,
                "backup_count": len(self.auto_backup.list_backups())
            },
            "refresh": {
                "enabled": self.data_refresher.is_enabled(),
                "running": self.data_refresher._running
            }
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def get_automation_manager() -> AutomationManager:
    """Get singleton automation manager"""
    return AutomationManager()


def notify_status_change(job_no: str, old_status: str, new_status: str):
    """Send status change notification"""
    manager = get_automation_manager()
    manager.email_notifier.queue_notification("status_change", {
        "job_no": job_no,
        "old_status": old_status,
        "new_status": new_status
    })


def notify_new_job(job_no: str, customer: str, mode: str):
    """Send new job notification"""
    manager = get_automation_manager()
    manager.email_notifier.queue_notification("new_job", {
        "job_no": job_no,
        "customer": customer,
        "mode": mode
    })


def notify_settlement(job_no: str, item_type: str, amount: float):
    """Send settlement notification"""
    manager = get_automation_manager()
    manager.email_notifier.queue_notification("settlement_created", {
        "job_no": job_no,
        "item_type": item_type,
        "amount": amount
    })


def notify_month_closed(year: int, month: int, profit: float):
    """Send month closed notification"""
    manager = get_automation_manager()
    manager.email_notifier.queue_notification("month_closed", {
        "year": year,
        "month": month,
        "profit": profit
    })


# =============================================================================
# MODULE INITIALIZATION
# =============================================================================

logger.debug("Automation module loaded")
