# utils.py
# Centralized utilities module - eliminates code duplication
# All common functions should be imported from here

from datetime import datetime
from typing import List, Tuple, Optional, Dict, Any
import sqlite3
import os

# ============================================================
# DATABASE CONNECTION (uses db.py when available)
# ============================================================
_db_connection_func = None

def _get_db_connection():
    """Get connection using db.py or fallback"""
    global _db_connection_func
    
    if _db_connection_func is None:
        try:
            from db import get_connection as db_get_connection
            _db_connection_func = db_get_connection
        except ImportError:
            # Fallback to local implementation
            DB_PATH = os.path.join(os.path.dirname(__file__), "freight.db")
            def local_get_connection():
                conn = sqlite3.connect(DB_PATH, timeout=30.0)
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA cache_size=10000")
                conn.execute("PRAGMA temp_store=MEMORY")
                conn.row_factory = sqlite3.Row
                return conn
            _db_connection_func = local_get_connection
    
    return _db_connection_func()


def get_connection() -> sqlite3.Connection:
    """
    Get a database connection with optimized settings.
    Uses db.py's connection when available, with fallback.
    """
    return _get_db_connection()


def execute_query(query: str, params: tuple = (), fetch: str = "all") -> Any:
    """
    Execute a query with automatic connection management.
    
    Args:
        query: SQL query string
        params: Query parameters
        fetch: "all", "one", "none", or "lastrowid"
    
    Returns:
        Query results based on fetch type
    """
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(query, params)
        
        if fetch == "all":
            return cur.fetchall()
        elif fetch == "one":
            return cur.fetchone()
        elif fetch == "lastrowid":
            conn.commit()
            return cur.lastrowid
        else:
            conn.commit()
            return None
    finally:
        conn.close()


def execute_many(query: str, params_list: List[tuple]) -> int:
    """Execute multiple queries in a single transaction."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.executemany(query, params_list)
        conn.commit()
        return cur.rowcount
    finally:
        conn.close()


# ============================================================
# DATE/TIME UTILITIES
# ============================================================
def now_str() -> str:
    """Get current timestamp as ISO format string."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today_str() -> str:
    """Get current date as YYYY-MM-DD string."""
    return datetime.now().strftime("%Y-%m-%d")


def format_date(date_obj: datetime, fmt: str = "%Y-%m-%d") -> str:
    """Format a datetime object to string."""
    return date_obj.strftime(fmt) if date_obj else ""


def parse_date(date_str: str, fmt: str = "%Y-%m-%d") -> Optional[datetime]:
    """Parse a date string to datetime object."""
    try:
        return datetime.strptime(date_str, fmt)
    except (ValueError, TypeError):
        return None


# ============================================================
# NUMBER FORMATTING
# ============================================================
def format_currency(amount: float, currency: str = "USD", decimals: int = 2) -> str:
    """Format number as currency string."""
    if currency == "MXN":
        return f"${amount:,.{decimals}f} MXN"
    elif currency == "USD":
        return f"${amount:,.{decimals}f}"
    else:
        return f"{amount:,.{decimals}f} {currency}"


def parse_number(value: Any, default: float = 0.0) -> float:
    """Safely parse a value to float."""
    if value is None:
        return default
    try:
        if isinstance(value, str):
            value = value.replace(",", "").replace("$", "").strip()
        return float(value)
    except (ValueError, TypeError):
        return default


def format_percent(value: float, decimals: int = 1) -> str:
    """Format number as percentage."""
    return f"{value:.{decimals}f}%"


# ============================================================
# DATA FETCHING - CONSOLIDATED FROM MULTIPLE FILES
# ============================================================
def fetch_freight_codes() -> List[Tuple[str, str, str]]:
    """
    Get all freight codes for dropdowns.
    Returns: List of (code, description, default_currency)
    """
    return execute_query(
        "SELECT code, description, default_currency FROM freight_codes ORDER BY code"
    ) or []


def fetch_customers_for_combo() -> List[Tuple[str, str]]:
    """
    Get customers for combobox.
    Returns: List of (code, name)
    """
    return execute_query(
        "SELECT code, name FROM companies WHERE company_type IN ('CUSTOMER', 'BOTH') ORDER BY code"
    ) or []


def fetch_shippers_for_combo() -> List[Tuple[str, str, str]]:
    """
    Get shippers/consignees/notify parties for combobox.
    Excludes: TRUCKER, AIRLINE, SHIPPING_LINE, CARRIER
    Returns: List of (code, name, address)
    """
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check if is_active column exists
        cur.execute("PRAGMA table_info(companies)")
        columns = [row[1] for row in cur.fetchall()]
        has_is_active = 'is_active' in columns
        
        excluded_types = ('TRUCKER', 'AIRLINE', 'SHIPPING_LINE', 'CARRIER', 'Trucker', 'Airline', 'Shipping Line')
        
        if has_is_active:
            cur.execute("""
                SELECT code, name, COALESCE(address, '') 
                FROM companies 
                WHERE (company_type IS NULL OR company_type NOT IN (?, ?, ?, ?, ?, ?, ?))
                  AND (type IS NULL OR type NOT IN (?, ?, ?, ?, ?, ?, ?))
                  AND (is_active = 1 OR is_active IS NULL)
                ORDER BY code
            """, excluded_types + excluded_types)
        else:
            cur.execute("""
                SELECT code, name, COALESCE(address, '') 
                FROM companies 
                WHERE (company_type IS NULL OR company_type NOT IN (?, ?, ?, ?, ?, ?, ?))
                  AND (type IS NULL OR type NOT IN (?, ?, ?, ?, ?, ?, ?))
                ORDER BY code
            """, excluded_types + excluded_types)
        
        return cur.fetchall() or []
    except Exception as e:
        print(f"fetch_shippers_for_combo error: {e}")
        return []
    finally:
        conn.close()


def fetch_vendors_for_combo() -> List[Tuple[str, str]]:
    """
    Get vendors for combobox.
    Returns: List of (code, name)
    """
    return execute_query(
        "SELECT code, name FROM companies WHERE company_type IN ('VENDOR', 'BOTH') ORDER BY code"
    ) or []


def fetch_agents_for_combo() -> List[Tuple[str, str]]:
    """
    Get agents for combobox.
    Returns: List of (code, name)
    """
    return execute_query(
        "SELECT code, name FROM companies WHERE company_type = 'AGENT' ORDER BY code"
    ) or []


def fetch_company_by_code(code: str) -> Optional[Dict]:
    """Get company details by code."""
    row = execute_query(
        "SELECT * FROM companies WHERE code = ?", (code,), fetch="one"
    )
    return dict(row) if row else None


def fetch_ports() -> List[Tuple[str, str, str]]:
    """
    Get all ports for dropdowns.
    Returns: List of (code, name, country)
    """
    return execute_query(
        "SELECT code, name, country FROM ports ORDER BY code"
    ) or []


def fetch_users() -> List[Tuple[int, str, str]]:
    """
    Get all users.
    Returns: List of (id, username, role)
    """
    return execute_query(
        "SELECT id, username, role FROM users ORDER BY username"
    ) or []


# ============================================================
# VALIDATION UTILITIES
# ============================================================
def is_valid_email(email: str) -> bool:
    """Simple email validation."""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email or ""))


def is_valid_phone(phone: str) -> bool:
    """Simple phone validation (allows various formats)."""
    import re
    cleaned = re.sub(r'[\s\-\(\)\+]', '', phone or "")
    return len(cleaned) >= 7 and cleaned.isdigit()


def sanitize_filename(filename: str) -> str:
    """Remove invalid characters from filename."""
    import re
    return re.sub(r'[<>:"/\\|?*]', '_', filename or "untitled")


# ============================================================
# STRING UTILITIES
# ============================================================
def truncate(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """Truncate text to max length with suffix."""
    if not text or len(text) <= max_length:
        return text or ""
    return text[:max_length - len(suffix)] + suffix


def clean_whitespace(text: str) -> str:
    """Normalize whitespace in text."""
    import re
    if not text:
        return ""
    return re.sub(r'\s+', ' ', text.strip())


def generate_code(prefix: str, number: int, width: int = 4) -> str:
    """Generate formatted code like 'JOB-0001'."""
    return f"{prefix}-{number:0{width}d}"


# ============================================================
# EXCHANGE RATE UTILITIES
# ============================================================
def get_exchange_rate(date_str: str = None, from_curr: str = "USD", 
                      to_curr: str = "MXN") -> float:
    """
    Get exchange rate for date with fallback chain.
    
    Priority:
    1. Exact date match in DB
    2. Most recent rate in DB
    3. Default rate (20.50 for USD/MXN)
    """
    if date_str is None:
        date_str = today_str()
    
    # Try exact date (use rate_date column)
    row = execute_query("""
        SELECT rate FROM exchange_rates 
        WHERE rate_date = ? AND from_currency = ? AND to_currency = ?
    """, (date_str, from_curr, to_curr), fetch="one")
    
    if row:
        return float(row[0])
    
    # Try most recent
    row = execute_query("""
        SELECT rate FROM exchange_rates 
        WHERE from_currency = ? AND to_currency = ?
        ORDER BY rate_date DESC LIMIT 1
    """, (from_curr, to_curr), fetch="one")
    
    if row:
        return float(row[0])
    
    # Default
    return 20.50 if (from_curr == "USD" and to_curr == "MXN") else 1.0


def convert_currency(amount: float, from_curr: str, to_curr: str, 
                     rate: float = None) -> float:
    """Convert amount between currencies."""
    if from_curr == to_curr:
        return amount
    
    if rate is None:
        rate = get_exchange_rate(from_curr=from_curr, to_curr=to_curr)
    
    return amount * rate


# ============================================================
# LOGGING UTILITIES
# ============================================================
import logging

def setup_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Setup a logger with standard formatting."""
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    
    logger.setLevel(level)
    return logger


# Module-level logger
logger = setup_logger("duruduru")


# ============================================================
# CACHING UTILITIES
# ============================================================
from functools import lru_cache
import time

_cache: Dict[str, Tuple[Any, float]] = {}
CACHE_TTL = 300  # 5 minutes


def cached_query(key: str, query_func, ttl: int = CACHE_TTL) -> Any:
    """
    Execute query with caching.
    
    Args:
        key: Cache key
        query_func: Function that returns the data
        ttl: Time to live in seconds
    """
    now = time.time()
    
    if key in _cache:
        value, timestamp = _cache[key]
        if now - timestamp < ttl:
            return value
    
    value = query_func()
    _cache[key] = (value, now)
    return value


def clear_cache(prefix: str = None):
    """Clear cache entries, optionally by prefix."""
    global _cache
    if prefix:
        _cache = {k: v for k, v in _cache.items() if not k.startswith(prefix)}
    else:
        _cache = {}


# ============================================================
# EXPORT COMMON SYMBOLS
# ============================================================
__all__ = [
    # Connection
    'get_connection', 'execute_query', 'execute_many',
    # Date/Time
    'now_str', 'today_str', 'format_date', 'parse_date',
    # Numbers
    'format_currency', 'parse_number', 'format_percent',
    # Data fetching
    'fetch_freight_codes', 'fetch_customers_for_combo', 
    'fetch_vendors_for_combo', 'fetch_agents_for_combo',
    'fetch_company_by_code', 'fetch_ports', 'fetch_users',
    # Validation
    'is_valid_email', 'is_valid_phone', 'sanitize_filename',
    # Strings
    'truncate', 'clean_whitespace', 'generate_code',
    # Exchange rate
    'get_exchange_rate', 'convert_currency',
    # Logging
    'setup_logger', 'logger',
    # Caching
    'cached_query', 'clear_cache',
]
