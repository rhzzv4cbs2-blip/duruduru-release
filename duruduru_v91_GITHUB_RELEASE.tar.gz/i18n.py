# i18n.py
# Internationalization Module - Multi-language Support
# Created: 2026-01-08

import json
import os
from typing import Dict, Optional, Tuple
from functools import lru_cache


# ============================================================
# FONT CONFIGURATION BY LANGUAGE
# ============================================================
FONT_CONFIG = {
    "en": {
        "family": "SF Pro Display",
        "family_rounded": "SF Pro Rounded",
        "fallback": "Helvetica Neue",
        "size_title": 20,
        "size_header": 16,
        "size_body": 13,
        "size_small": 11,
        "size_button": 13,
    },
    "ko": {
        "family": "Apple SD Gothic Neo",  # macOS 기본 한글 폰트
        "family_rounded": "Apple SD Gothic Neo",
        "fallback": "Malgun Gothic",  # Windows 한글 폰트
        "size_title": 18,  # 한글은 약간 작게
        "size_header": 15,
        "size_body": 12,
        "size_small": 10,
        "size_button": 12,
    },
    "es": {
        "family": "SF Pro Display",
        "family_rounded": "SF Pro Rounded",
        "fallback": "Helvetica Neue",
        "size_title": 20,
        "size_header": 16,
        "size_body": 13,
        "size_small": 11,
        "size_button": 13,
    },
}


def get_font(style: str = "body", bold: bool = False) -> Tuple[str, int, str]:
    """
    Get font tuple for current language
    
    Args:
        style: "title", "header", "body", "small", "button"
        bold: Whether to use bold weight
    
    Returns:
        Tuple of (family, size, weight)
    
    Usage:
        label = ctk.CTkLabel(parent, text="Hello", font=get_font("header", bold=True))
    """
    lang = I18n.get_language()
    config = FONT_CONFIG.get(lang, FONT_CONFIG["en"])
    
    family = config["family"]
    size_key = f"size_{style}"
    size = config.get(size_key, config["size_body"])
    weight = "bold" if bold else "normal"
    
    return (family, size, weight)


def get_font_family() -> str:
    """Get font family for current language"""
    lang = I18n.get_language()
    config = FONT_CONFIG.get(lang, FONT_CONFIG["en"])
    return config["family"]


class I18n:
    """Internationalization support for multi-language UI"""
    
    # Supported languages
    LANGUAGES = {
        "en": "English",
        "es": "Español",
        "ko": "한국어",
    }
    
    # Default language
    DEFAULT_LANG = "en"
    
    # Translation dictionaries
    TRANSLATIONS = {
        "en": {
            # Menu items
            "menu.dashboard": "Dashboard",
            "menu.registration": "Registration",
            "menu.registration.ocean": "Ocean",
            "menu.registration.air": "Air",
            "menu.registration.land": "Land",
            "menu.quotation": "Quotation",
            "menu.status": "Status",
            "menu.status.operation": "Operation",
            "menu.status.tracking": "Tracking",
            "menu.status.performance": "Performance",
            "menu.accounting": "Accounting",
            "menu.settlement": "Settlement",
            "menu.settings": "Settings",
            "menu.settings.customer": "Customer Code",
            "menu.settings.port": "Port Code",
            "menu.settings.freight": "Freight Mgmt",
            "menu.settings.branch": "Branch Mgmt",
            "menu.settings.budget": "Budget Mgmt",
            "menu.settings.automation": "Automation",
            "menu.settings.admin": "Admin",
            
            # Common actions
            "action.save": "Save",
            "action.cancel": "Cancel",
            "action.delete": "Delete",
            "action.edit": "Edit",
            "action.add": "Add",
            "action.search": "Search",
            "action.reset": "Reset",
            "action.export": "Export",
            "action.import": "Import",
            "action.print": "Print",
            "action.copy": "Copy",
            "action.paste": "Paste",
            "action.refresh": "Refresh",
            "action.close": "Close",
            "action.confirm": "Confirm",
            "action.back": "Back",
            "action.next": "Next",
            "action.finish": "Finish",
            
            # Common labels
            "label.date": "Date",
            "label.status": "Status",
            "label.customer": "Customer",
            "label.partner": "Partner",
            "label.carrier": "Carrier",
            "label.remarks": "Remarks",
            "label.total": "Total",
            "label.subtotal": "Subtotal",
            "label.tax": "Tax",
            "label.amount": "Amount",
            "label.currency": "Currency",
            "label.rate": "Rate",
            "label.quantity": "Quantity",
            "label.unit": "Unit",
            "label.description": "Description",
            "label.page": "Page",
            "label.of": "of",
            "label.records": "records",
            "label.showing": "Showing",
            
            # Job related
            "job.number": "Job Number",
            "job.mode": "Mode",
            "job.ocean": "Ocean",
            "job.air": "Air",
            "job.land": "Land",
            "job.import": "Import",
            "job.export": "Export",
            "job.shipper": "Shipper",
            "job.consignee": "Consignee",
            "job.notify": "Notify Party",
            "job.pol": "Port of Loading",
            "job.pod": "Port of Discharge",
            "job.etd": "ETD",
            "job.eta": "ETA",
            "job.atd": "ATD",
            "job.ata": "ATA",
            "job.mbl": "Master B/L",
            "job.hbl": "House B/L",
            "job.mawb": "MAWB",
            "job.hawb": "HAWB",
            "job.vessel": "Vessel",
            "job.voyage": "Voyage",
            "job.flight": "Flight No.",
            
            # Container related
            "container.number": "Container No.",
            "container.type": "Container Type",
            "container.seal": "Seal No.",
            "container.weight": "Weight",
            "container.cbm": "CBM",
            "container.pcs": "Pieces",
            
            # Invoice related
            "invoice.number": "Invoice No.",
            "invoice.date": "Invoice Date",
            "invoice.due_date": "Due Date",
            "invoice.paid_date": "Paid Date",
            "invoice.revenue": "Revenue",
            "invoice.cost": "Cost",
            "invoice.profit": "Profit",
            "invoice.margin": "Margin",
            
            # Status values
            "status.open": "Open",
            "status.in_progress": "In Progress",
            "status.completed": "Completed",
            "status.cancelled": "Cancelled",
            "status.draft": "Draft",
            "status.sent": "Sent",
            "status.accepted": "Accepted",
            "status.rejected": "Rejected",
            "status.paid": "Paid",
            "status.unpaid": "Unpaid",
            "status.overdue": "Overdue",
            
            # Messages
            "msg.saved": "Saved successfully",
            "msg.deleted": "Deleted successfully",
            "msg.confirm_delete": "Are you sure you want to delete?",
            "msg.error": "An error occurred",
            "msg.required": "This field is required",
            "msg.invalid": "Invalid value",
            "msg.no_data": "No data found",
            "msg.loading": "Loading...",
            "msg.processing": "Processing...",
            
            # Settings
            "settings.language": "Language",
            "settings.theme": "Theme",
            "settings.theme.light": "Light",
            "settings.theme.dark": "Dark",
            "settings.currency.default": "Default Currency",
            "settings.date_format": "Date Format",
            
            # Accounting specific
            "accounting.title": "Accounting",
            "accounting.journal": "Journal",
            "accounting.ar": "Accounts Receivable (AR)",
            "accounting.ap": "Accounts Payable (AP)",
            "accounting.aging": "AR/AP Aging",
            "accounting.pl": "Profit & Loss",
            "accounting.cashflow": "Cash Flow",
            "accounting.bank_accounts": "Bank Accounts",
            "accounting.exchange_rate": "Exchange Rate",
            "accounting.transfer": "Transfer",
            "accounting.balance": "Balance",
            "accounting.debit": "Debit",
            "accounting.credit": "Credit",
            
            # Settlement specific
            "settlement.title": "Settlement",
            "settlement.revenue": "Revenue",
            "settlement.cost": "Cost",
            "settlement.profit": "Profit",
            "settlement.margin": "Margin",
            "settlement.invoice": "Invoice",
            "settlement.payment": "Payment",
            "settlement.pending": "Pending",
            "settlement.completed": "Completed",
            "settlement.fx_gain_loss": "FX Gain/Loss",
            
            # Dashboard
            "dashboard.title": "Dashboard",
            "dashboard.total_jobs": "Total Jobs",
            "dashboard.active_jobs": "Active Jobs",
            "dashboard.monthly_revenue": "Monthly Revenue",
            "dashboard.monthly_profit": "Monthly Profit",
            "dashboard.recent_jobs": "Recent Jobs",
            "dashboard.pending_payments": "Pending Payments",
            
            # Common buttons/labels
            "btn.new": "New",
            "btn.save": "Save",
            "btn.cancel": "Cancel",
            "btn.delete": "Delete",
            "btn.edit": "Edit",
            "btn.search": "Search",
            "btn.filter": "Filter",
            "btn.export": "Export",
            "btn.print": "Print",
            "btn.refresh": "Refresh",
            "btn.close": "Close",
            "btn.apply": "Apply",
            "btn.select_all": "Select All",
            "btn.clear": "Clear",
            "btn.select": "Select",
            "btn.ok": "OK",
            "btn.transfer": "Transfer",
            "btn.add": "Add",
            "btn.remove": "Remove",
            "btn.update": "Update",
            
            # UI Common
            "ui.quick_search": "Quick Search",
            "ui.search_by": "Search By:",
            "ui.enter_search": "Enter search term...",
            "ui.loading": "Loading...",
            "ui.no_data": "No Data",
            "ui.records": "records",
            "ui.from": "From:",
            "ui.to": "To:",
            "ui.date": "Date",
            "ui.type": "Type",
            "ui.mode": "Mode",
            "ui.status": "Status",
            "ui.amount": "Amount",
            "ui.currency": "Currency",
            "ui.description": "Description",
            "ui.reference": "Reference",
            "ui.category": "Category",
            "ui.company": "Company",
            "ui.customer": "Customer",
            "ui.vendor": "Vendor",
            "ui.partner": "Partner",
            
            # Exchange Rate
            "rate.current": "Current Rate:",
            "rate.mxn_per_usd": "MXN per 1 USD",
            "rate.date_range": "Date Range Update",
            "rate.update_range": "Update Range",
            "rate.history": "Rate History",
            "rate.source": "Source",
            "rate.remove_dup": "Remove Duplicates",
            "rate.fetch_today": "Fetch Today",
            "rate.fill_missing": "Fill Missing",
            
            # Bank Transfer
            "transfer.title": "Bank Transfer",
            "transfer.date": "Transfer Date:",
            "transfer.from_account": "From Account:",
            "transfer.to_account": "To Account:",
            "transfer.amount": "Amount:",
            "transfer.rate": "Exchange Rate:",
            "transfer.converted": "Converted:",
            "transfer.fx_gain": "FX Gain/Loss:",
            "transfer.get_rate": "📊 Get Rate",
            "transfer.description": "Description:",
            "transfer.reference": "Reference:",
            
            # Accounting
            "acct.title": "Accounting",
            "acct.date_type": "Date Type:",
            "acct.invoice_date": "Invoice Date",
            "acct.due_date": "Due Date",
            "acct.paid_date": "Paid Date",
            "acct.overview": "Overview",
            "acct.journal": "Journal",
            "acct.ar": "Receivables",
            "acct.ap": "Payables",
            "acct.aging": "AR/AP Aging",
            "acct.pl": "P&L Statement",
            "acct.cashflow": "Cash Flow",
            "acct.bank": "Bank Accounts",
            "acct.exchange": "Exchange Rate",
            "acct.transfer": "Transfer",
            "acct.revenue": "Revenue",
            "acct.expense": "Expense",
            "acct.profit": "Profit",
            "acct.balance": "Balance",
            "acct.debit": "Debit",
            "acct.credit": "Credit",
            
            # Settlement
            "settle.title": "Settlement",
            "settle.job_no": "Job No.",
            "settle.customer": "Customer",
            "settle.revenue": "Revenue",
            "settle.cost": "Cost",
            "settle.profit": "Profit",
            "settle.margin": "Margin",
            "settle.status": "Status",
            "settle.pending": "Pending",
            "settle.completed": "Completed",
            "settle.add_revenue": "Add Revenue",
            "settle.add_cost": "Add Cost",
            "settle.invoice": "Generate Invoice",
            "settle.payment": "Process Payment",
            
            # Status/Operation
            "op.title": "Operation",
            "op.all": "All",
            "op.open": "Open",
            "op.in_transit": "In Transit",
            "op.arrived": "Arrived",
            "op.closed": "Closed",
            "op.job_list": "Job List",
            "op.details": "Details",
            "op.vessel": "Vessel",
            "op.voyage": "Voyage",
            "op.flight": "Flight",
            "op.pol": "POL",
            "op.pod": "POD",
            "op.etd": "ETD",
            "op.eta": "ETA",
            "op.mbl": "Master B/L",
            "op.hbl": "House B/L",
            
            # Tracking
            "track.title": "Tracking",
            "track.carrier": "Carrier",
            "track.container": "Container",
            "track.bl_no": "B/L No.",
            "track.status": "Current Status",
            "track.location": "Location",
            "track.last_update": "Last Update",
            "track.events": "Events",
            "track.refresh": "Refresh Tracking",
            
            # Registration
            "reg.title": "Job Registration",
            "reg.ocean": "Ocean",
            "reg.air": "Air",
            "reg.land": "Land",
            "reg.import": "Import",
            "reg.export": "Export",
            "reg.shipper": "Shipper",
            "reg.consignee": "Consignee",
            "reg.notify": "Notify Party",
            "reg.cargo_type": "Cargo Type",
            "reg.fcl": "FCL (Container)",
            "reg.lcl": "LCL (Consolidation)",
            "reg.container_info": "Container Info",
            "reg.cargo_info": "Cargo Info",
            "reg.ts_info": "T/S Info",
            "reg.save_job": "Save Job",
            "reg.new_job": "New Job",
            
            # Settings
            "set.title": "Settings",
            "set.customer_code": "Customer Code",
            "set.port_code": "Port Code",
            "set.freight": "Freight Mgmt",
            "set.automation": "Automation",
            "set.admin": "Admin",
            "set.language": "Language",
            "set.theme": "Theme",
            
            # Dashboard
            "dash.title": "Dashboard",
            "dash.total_jobs": "Total Jobs",
            "dash.active_jobs": "Active",
            "dash.monthly_revenue": "Monthly Revenue",
            "dash.monthly_profit": "Monthly Profit",
            "dash.recent": "Recent Jobs",
            "dash.pending": "Pending Payments",
            
            # Table Headers
            "th.no": "No.",
            "th.date": "Date",
            "th.job_no": "Job No.",
            "th.customer": "Customer",
            "th.mode": "Mode",
            "th.pol_pod": "POL/POD",
            "th.status": "Status",
            "th.amount": "Amount",
            "th.currency": "Currency",
            "th.rate": "Rate",
            "th.description": "Description",
            "th.vendor": "Vendor",
            "th.invoice_no": "Invoice No.",
            "th.due_date": "Due Date",
            "th.paid": "Paid",
            "th.balance": "Balance",
            "th.account": "Account",
            "th.debit": "Debit",
            "th.credit": "Credit",
        },
        
        "es": {
            # Menu items
            "menu.dashboard": "Panel",
            "menu.registration": "Registro",
            "menu.registration.ocean": "Marítimo",
            "menu.registration.air": "Aéreo",
            "menu.registration.land": "Terrestre",
            "menu.quotation": "Cotización",
            "menu.status": "Estado",
            "menu.status.operation": "Operación",
            "menu.status.tracking": "Rastreo",
            "menu.status.performance": "Rendimiento",
            "menu.accounting": "Contabilidad",
            "menu.settlement": "Liquidación",
            "menu.settings": "Configuración",
            "menu.settings.customer": "Código de Cliente",
            "menu.settings.port": "Código de Puerto",
            "menu.settings.freight": "Gestión de Flete",
            "menu.settings.branch": "Gestión de Sucursal",
            "menu.settings.budget": "Gestión de Presupuesto",
            "menu.settings.automation": "Automatización",
            "menu.settings.admin": "Administración",
            
            # Common actions
            "action.save": "Guardar",
            "action.cancel": "Cancelar",
            "action.delete": "Eliminar",
            "action.edit": "Editar",
            "action.add": "Agregar",
            "action.search": "Buscar",
            "action.reset": "Restablecer",
            "action.export": "Exportar",
            "action.import": "Importar",
            "action.print": "Imprimir",
            "action.copy": "Copiar",
            "action.paste": "Pegar",
            "action.refresh": "Actualizar",
            "action.close": "Cerrar",
            "action.confirm": "Confirmar",
            "action.back": "Atrás",
            "action.next": "Siguiente",
            "action.finish": "Finalizar",
            
            # Common labels
            "label.date": "Fecha",
            "label.status": "Estado",
            "label.customer": "Cliente",
            "label.partner": "Socio",
            "label.carrier": "Transportista",
            "label.remarks": "Observaciones",
            "label.total": "Total",
            "label.subtotal": "Subtotal",
            "label.tax": "IVA",
            "label.amount": "Monto",
            "label.currency": "Moneda",
            "label.rate": "Tarifa",
            "label.quantity": "Cantidad",
            "label.unit": "Unidad",
            "label.description": "Descripción",
            "label.page": "Página",
            "label.of": "de",
            "label.records": "registros",
            "label.showing": "Mostrando",
            
            # Job related
            "job.number": "Número de Trabajo",
            "job.mode": "Modo",
            "job.ocean": "Marítimo",
            "job.air": "Aéreo",
            "job.land": "Terrestre",
            "job.import": "Importación",
            "job.export": "Exportación",
            "job.shipper": "Embarcador",
            "job.consignee": "Consignatario",
            "job.notify": "Notificar a",
            "job.pol": "Puerto de Carga",
            "job.pod": "Puerto de Descarga",
            "job.etd": "ETD",
            "job.eta": "ETA",
            "job.atd": "ATD",
            "job.ata": "ATA",
            "job.mbl": "B/L Master",
            "job.hbl": "B/L House",
            "job.mawb": "MAWB",
            "job.hawb": "HAWB",
            "job.vessel": "Buque",
            "job.voyage": "Viaje",
            "job.flight": "No. de Vuelo",
            
            # Container related
            "container.number": "No. de Contenedor",
            "container.type": "Tipo de Contenedor",
            "container.seal": "No. de Sello",
            "container.weight": "Peso",
            "container.cbm": "CBM",
            "container.pcs": "Piezas",
            
            # Invoice related
            "invoice.number": "No. de Factura",
            "invoice.date": "Fecha de Factura",
            "invoice.due_date": "Fecha de Vencimiento",
            "invoice.paid_date": "Fecha de Pago",
            "invoice.revenue": "Ingresos",
            "invoice.cost": "Costo",
            "invoice.profit": "Utilidad",
            "invoice.margin": "Margen",
            
            # Status values
            "status.open": "Abierto",
            "status.in_progress": "En Proceso",
            "status.completed": "Completado",
            "status.cancelled": "Cancelado",
            "status.draft": "Borrador",
            "status.sent": "Enviado",
            "status.accepted": "Aceptado",
            "status.rejected": "Rechazado",
            "status.paid": "Pagado",
            "status.unpaid": "Sin Pagar",
            "status.overdue": "Vencido",
            
            # Messages
            "msg.saved": "Guardado exitosamente",
            "msg.deleted": "Eliminado exitosamente",
            "msg.confirm_delete": "¿Está seguro de eliminar?",
            "msg.error": "Ocurrió un error",
            "msg.required": "Este campo es requerido",
            "msg.invalid": "Valor inválido",
            "msg.no_data": "No se encontraron datos",
            "msg.loading": "Cargando...",
            "msg.processing": "Procesando...",
            
            # Settings
            "settings.language": "Idioma",
            "settings.theme": "Tema",
            "settings.theme.light": "Claro",
            "settings.theme.dark": "Oscuro",
            "settings.currency.default": "Moneda Predeterminada",
            "settings.date_format": "Formato de Fecha",
        },
        
        "ko": {
            # Menu items
            "menu.dashboard": "대시보드",
            "menu.registration": "등록",
            "menu.registration.ocean": "해상",
            "menu.registration.air": "항공",
            "menu.registration.land": "육상",
            "menu.quotation": "견적",
            "menu.status": "현황",
            "menu.status.operation": "운영",
            "menu.status.tracking": "추적",
            "menu.status.performance": "실적",
            "menu.accounting": "회계",
            "menu.settlement": "정산",
            "menu.settings": "설정",
            "menu.settings.customer": "고객 코드",
            "menu.settings.port": "항구 코드",
            "menu.settings.freight": "운임 관리",
            "menu.settings.branch": "지점 관리",
            "menu.settings.budget": "예산 관리",
            "menu.settings.automation": "자동화",
            "menu.settings.admin": "관리자",
            
            # Common actions
            "action.save": "저장",
            "action.cancel": "취소",
            "action.delete": "삭제",
            "action.edit": "수정",
            "action.add": "추가",
            "action.search": "검색",
            "action.reset": "초기화",
            "action.export": "내보내기",
            "action.import": "가져오기",
            "action.print": "인쇄",
            "action.copy": "복사",
            "action.paste": "붙여넣기",
            "action.refresh": "새로고침",
            "action.close": "닫기",
            "action.confirm": "확인",
            "action.back": "뒤로",
            "action.next": "다음",
            "action.finish": "완료",
            
            # Common labels
            "label.date": "날짜",
            "label.status": "상태",
            "label.customer": "고객",
            "label.partner": "파트너",
            "label.carrier": "운송사",
            "label.remarks": "비고",
            "label.total": "합계",
            "label.subtotal": "소계",
            "label.tax": "세금",
            "label.amount": "금액",
            "label.currency": "통화",
            "label.rate": "단가",
            "label.quantity": "수량",
            "label.unit": "단위",
            "label.description": "설명",
            "label.page": "페이지",
            "label.of": "/",
            "label.records": "건",
            "label.showing": "표시",
            
            # Job related
            "job.number": "작업 번호",
            "job.mode": "모드",
            "job.ocean": "해상",
            "job.air": "항공",
            "job.land": "육상",
            "job.import": "수입",
            "job.export": "수출",
            "job.shipper": "송하인",
            "job.consignee": "수하인",
            "job.notify": "통지처",
            "job.pol": "선적항",
            "job.pod": "도착항",
            "job.etd": "출발예정일",
            "job.eta": "도착예정일",
            "job.atd": "실제출발일",
            "job.ata": "실제도착일",
            "job.mbl": "Master B/L",
            "job.hbl": "House B/L",
            "job.mawb": "MAWB",
            "job.hawb": "HAWB",
            "job.vessel": "선박",
            "job.voyage": "항차",
            "job.flight": "항공편",
            
            # Container related
            "container.number": "컨테이너 번호",
            "container.type": "컨테이너 유형",
            "container.seal": "봉인 번호",
            "container.weight": "중량",
            "container.cbm": "CBM",
            "container.pcs": "수량",
            
            # Invoice related
            "invoice.number": "인보이스 번호",
            "invoice.date": "인보이스 날짜",
            "invoice.due_date": "결제 기한",
            "invoice.paid_date": "결제일",
            "invoice.revenue": "매출",
            "invoice.cost": "매입",
            "invoice.profit": "이익",
            "invoice.margin": "마진",
            
            # Status values
            "status.open": "진행중",
            "status.in_progress": "처리중",
            "status.completed": "완료",
            "status.cancelled": "취소",
            "status.draft": "임시저장",
            "status.sent": "발송됨",
            "status.accepted": "수락됨",
            "status.rejected": "거절됨",
            "status.paid": "결제완료",
            "status.unpaid": "미결제",
            "status.overdue": "연체",
            
            # Messages
            "msg.saved": "저장되었습니다",
            "msg.deleted": "삭제되었습니다",
            "msg.confirm_delete": "삭제하시겠습니까?",
            "msg.error": "오류가 발생했습니다",
            "msg.required": "필수 항목입니다",
            "msg.invalid": "올바르지 않은 값입니다",
            "msg.no_data": "데이터가 없습니다",
            "msg.loading": "로딩 중...",
            "msg.processing": "처리 중...",
            
            # Settings
            "settings.language": "언어",
            "settings.theme": "테마",
            "settings.theme.light": "밝은",
            "settings.theme.dark": "어두운",
            "settings.currency.default": "기본 통화",
            "settings.date_format": "날짜 형식",
            
            # Accounting specific
            "accounting.title": "회계 관리",
            "accounting.journal": "분개장",
            "accounting.ar": "매출채권 (AR)",
            "accounting.ap": "매입채무 (AP)",
            "accounting.aging": "채권/채무 현황",
            "accounting.pl": "손익계산서",
            "accounting.cashflow": "자금 현황",
            "accounting.bank_accounts": "은행 계좌",
            "accounting.exchange_rate": "환율 관리",
            "accounting.transfer": "계좌 이체",
            "accounting.balance": "잔액",
            "accounting.debit": "차변",
            "accounting.credit": "대변",
            
            # Settlement specific
            "settlement.title": "정산 관리",
            "settlement.revenue": "매출",
            "settlement.cost": "매입",
            "settlement.profit": "이익",
            "settlement.margin": "마진율",
            "settlement.invoice": "청구서",
            "settlement.payment": "결제",
            "settlement.pending": "미정산",
            "settlement.completed": "정산완료",
            "settlement.fx_gain_loss": "환차손익",
            
            # Dashboard
            "dashboard.title": "대시보드",
            "dashboard.total_jobs": "전체 작업",
            "dashboard.active_jobs": "진행중 작업",
            "dashboard.monthly_revenue": "월 매출",
            "dashboard.monthly_profit": "월 이익",
            "dashboard.recent_jobs": "최근 작업",
            "dashboard.pending_payments": "미결제 현황",
            
            # Common buttons/labels
            "btn.new": "신규",
            "btn.save": "저장",
            "btn.cancel": "취소",
            "btn.delete": "삭제",
            "btn.edit": "수정",
            "btn.search": "검색",
            "btn.filter": "필터",
            "btn.export": "내보내기",
            "btn.print": "인쇄",
            "btn.refresh": "새로고침",
            "btn.close": "닫기",
            "btn.apply": "적용",
            "btn.select_all": "전체 선택",
            "btn.clear": "초기화",
            "btn.select": "선택",
            "btn.ok": "확인",
            "btn.transfer": "이체",
            "btn.add": "추가",
            "btn.remove": "제거",
            "btn.update": "업데이트",
            
            # UI Common
            "ui.quick_search": "빠른 검색",
            "ui.search_by": "검색 기준:",
            "ui.enter_search": "검색어 입력...",
            "ui.loading": "로딩 중...",
            "ui.no_data": "데이터 없음",
            "ui.records": "건",
            "ui.from": "시작:",
            "ui.to": "종료:",
            "ui.date": "날짜",
            "ui.type": "유형",
            "ui.mode": "모드",
            "ui.status": "상태",
            "ui.amount": "금액",
            "ui.currency": "통화",
            "ui.description": "설명",
            "ui.reference": "참조",
            "ui.category": "분류",
            "ui.company": "회사",
            "ui.customer": "고객",
            "ui.vendor": "거래처",
            "ui.partner": "파트너",
            
            # Exchange Rate
            "rate.current": "현재 환율:",
            "rate.mxn_per_usd": "MXN / 1 USD",
            "rate.date_range": "날짜 범위 업데이트",
            "rate.update_range": "범위 업데이트",
            "rate.history": "환율 히스토리",
            "rate.source": "소스",
            "rate.remove_dup": "중복 제거",
            "rate.fetch_today": "오늘 환율",
            "rate.fill_missing": "누락 채우기",
            
            # Bank Transfer
            "transfer.title": "계좌 이체",
            "transfer.date": "이체 날짜:",
            "transfer.from_account": "출금 계좌:",
            "transfer.to_account": "입금 계좌:",
            "transfer.amount": "금액:",
            "transfer.rate": "환율:",
            "transfer.converted": "환산액:",
            "transfer.fx_gain": "환차손익:",
            "transfer.get_rate": "📊 환율 조회",
            "transfer.description": "설명:",
            "transfer.reference": "참조:",
            
            # Accounting
            "acct.title": "회계 관리",
            "acct.date_type": "날짜 유형:",
            "acct.invoice_date": "청구일",
            "acct.due_date": "결제기한",
            "acct.paid_date": "결제일",
            "acct.overview": "개요",
            "acct.journal": "분개장",
            "acct.ar": "매출채권",
            "acct.ap": "매입채무",
            "acct.aging": "채권/채무 현황",
            "acct.pl": "손익계산서",
            "acct.cashflow": "자금 현황",
            "acct.bank": "은행 계좌",
            "acct.exchange": "환율 관리",
            "acct.transfer": "계좌 이체",
            "acct.revenue": "수익",
            "acct.expense": "비용",
            "acct.profit": "이익",
            "acct.balance": "잔액",
            "acct.debit": "차변",
            "acct.credit": "대변",
            
            # Settlement
            "settle.title": "정산 관리",
            "settle.job_no": "Job 번호",
            "settle.customer": "고객",
            "settle.revenue": "매출",
            "settle.cost": "매입",
            "settle.profit": "이익",
            "settle.margin": "마진율",
            "settle.status": "상태",
            "settle.pending": "미정산",
            "settle.completed": "정산완료",
            "settle.add_revenue": "매출 추가",
            "settle.add_cost": "매입 추가",
            "settle.invoice": "청구서 발행",
            "settle.payment": "결제 처리",
            
            # Status/Operation
            "op.title": "운영 현황",
            "op.all": "전체",
            "op.open": "진행중",
            "op.in_transit": "운송중",
            "op.arrived": "도착",
            "op.closed": "완료",
            "op.job_list": "Job 목록",
            "op.details": "상세 정보",
            "op.vessel": "선박",
            "op.voyage": "항차",
            "op.flight": "항공편",
            "op.pol": "선적항",
            "op.pod": "도착항",
            "op.etd": "출발예정",
            "op.eta": "도착예정",
            "op.mbl": "Master B/L",
            "op.hbl": "House B/L",
            
            # Tracking
            "track.title": "화물 추적",
            "track.carrier": "운송사",
            "track.container": "컨테이너",
            "track.bl_no": "B/L 번호",
            "track.status": "현재 상태",
            "track.location": "현재 위치",
            "track.last_update": "최종 업데이트",
            "track.events": "이벤트 기록",
            "track.refresh": "추적 갱신",
            
            # Registration
            "reg.title": "Job 등록",
            "reg.ocean": "해상",
            "reg.air": "항공",
            "reg.land": "육상",
            "reg.import": "수입",
            "reg.export": "수출",
            "reg.shipper": "송하인",
            "reg.consignee": "수하인",
            "reg.notify": "통지처",
            "reg.cargo_type": "화물 유형",
            "reg.fcl": "FCL (컨테이너)",
            "reg.lcl": "LCL (혼적)",
            "reg.container_info": "컨테이너 정보",
            "reg.cargo_info": "화물 정보",
            "reg.ts_info": "환적 정보",
            "reg.save_job": "Job 저장",
            "reg.new_job": "새 Job",
            
            # Settings
            "set.title": "설정",
            "set.customer_code": "고객 코드",
            "set.port_code": "항구 코드",
            "set.freight": "운임 관리",
            "set.automation": "자동화",
            "set.admin": "관리자",
            "set.language": "언어",
            "set.theme": "테마",
            
            # Dashboard
            "dash.title": "대시보드",
            "dash.total_jobs": "전체 Job",
            "dash.active_jobs": "진행중",
            "dash.monthly_revenue": "월 매출",
            "dash.monthly_profit": "월 이익",
            "dash.recent": "최근 Job",
            "dash.pending": "미결제 현황",
            
            # Table Headers
            "th.no": "No.",
            "th.date": "날짜",
            "th.job_no": "Job No.",
            "th.customer": "고객",
            "th.mode": "모드",
            "th.pol_pod": "POL/POD",
            "th.status": "상태",
            "th.amount": "금액",
            "th.currency": "통화",
            "th.rate": "환율",
            "th.description": "설명",
            "th.vendor": "거래처",
            "th.invoice_no": "청구서번호",
            "th.due_date": "결제기한",
            "th.paid": "결제액",
            "th.balance": "잔액",
            "th.account": "계좌",
            "th.debit": "차변",
            "th.credit": "대변",
        },
    }
    
    _current_lang = DEFAULT_LANG
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def set_language(cls, lang: str):
        """Set current language"""
        if lang in cls.LANGUAGES:
            cls._current_lang = lang
            cls._get_text.cache_clear()  # Clear cache on language change
    
    @classmethod
    def get_language(cls) -> str:
        """Get current language"""
        return cls._current_lang
    
    @classmethod
    def get_available_languages(cls) -> Dict[str, str]:
        """Get available languages"""
        return cls.LANGUAGES.copy()
    
    @classmethod
    @lru_cache(maxsize=1024)
    def _get_text(cls, key: str, lang: str) -> str:
        """Get translated text (cached)"""
        translations = cls.TRANSLATIONS.get(lang, cls.TRANSLATIONS[cls.DEFAULT_LANG])
        return translations.get(key, key)
    
    @classmethod
    def t(cls, key: str, **kwargs) -> str:
        """
        Get translated text for current language
        
        Usage:
            I18n.t("action.save")  # Returns "Save" / "Guardar" / "저장"
            I18n.t("msg.showing", count=10)  # With parameters
        """
        text = cls._get_text(key, cls._current_lang)
        
        # If key not found in current language, try default
        if text == key and cls._current_lang != cls.DEFAULT_LANG:
            text = cls._get_text(key, cls.DEFAULT_LANG)
        
        # Replace placeholders if kwargs provided
        if kwargs:
            try:
                text = text.format(**kwargs)
            except:
                pass
        
        return text
    
    @classmethod
    def load_custom_translations(cls, file_path: str):
        """Load custom translations from JSON file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                custom = json.load(f)
                for lang, translations in custom.items():
                    if lang in cls.TRANSLATIONS:
                        cls.TRANSLATIONS[lang].update(translations)
                    else:
                        cls.TRANSLATIONS[lang] = translations
                cls._get_text.cache_clear()
        except Exception as e:
            print(f"Failed to load translations: {e}")
    
    @classmethod
    def save_language_preference(cls, lang: str):
        """Save language preference to config"""
        config_dir = os.path.join(os.path.expanduser("~"), ".duruduru")
        os.makedirs(config_dir, exist_ok=True)
        config_file = os.path.join(config_dir, "language.json")
        
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump({"language": lang}, f)
        except:
            pass
    
    @classmethod
    def load_language_preference(cls) -> str:
        """Load language preference from config"""
        config_file = os.path.join(os.path.expanduser("~"), ".duruduru", "language.json")
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("language", cls.DEFAULT_LANG)
        except:
            return cls.DEFAULT_LANG


# Convenience function
def t(key: str, **kwargs) -> str:
    """Shorthand for I18n.t()"""
    return I18n.t(key, **kwargs)


def set_language_by_name(name: str):
    """Set language by display name (English, 한국어, Español)"""
    name_to_code = {
        "English": "en",
        "한국어": "ko",
        "Español": "es",
    }
    code = name_to_code.get(name, "en")
    I18n.set_language(code)
    return code


def get_current_language_name() -> str:
    """Get current language display name"""
    code_to_name = {
        "en": "English",
        "ko": "한국어",
        "es": "Español",
    }
    return code_to_name.get(I18n._current_lang, "English")


# Initialize with saved preference
I18n.set_language(I18n.load_language_preference())
