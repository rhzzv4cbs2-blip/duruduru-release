# pdf_export.py
# PDF Export System for Freight Forwarding Documents
# Item 10: Professional document generation using reportlab

from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.units import inch, mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, 
    Image, PageBreak, HRFlowable
)
from reportlab.pdfgen import canvas
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from datetime import datetime
import os


class FreightPDFStyles:
    """Premium centralized styles for freight forwarding documents"""
    
    # Premium Color Palette
    PRIMARY = colors.HexColor("#0D47A1")      # Deep Blue
    PRIMARY_LIGHT = colors.HexColor("#1976D2") # Medium Blue
    SECONDARY = colors.HexColor("#263238")     # Dark Gray-Blue
    ACCENT = colors.HexColor("#FF6F00")        # Orange Accent
    ACCENT_LIGHT = colors.HexColor("#FFB74D")  # Light Orange
    SUCCESS = colors.HexColor("#2E7D32")       # Green
    WARNING = colors.HexColor("#F57C00")       # Warning Orange
    
    # Neutral Colors
    WHITE = colors.HexColor("#FFFFFF")
    LIGHT_GRAY = colors.HexColor("#F8F9FA")
    MEDIUM_GRAY = colors.HexColor("#E9ECEF")
    DARK_GRAY = colors.HexColor("#495057")
    BORDER = colors.HexColor("#DEE2E6")
    
    # Table Colors
    TABLE_HEADER_BG = colors.HexColor("#0D47A1")
    TABLE_ROW_ALT = colors.HexColor("#F5F8FF")
    TABLE_BORDER = colors.HexColor("#B0BEC5")
    
    @staticmethod
    def get_styles():
        styles = getSampleStyleSheet()
        
        # Premium Document Title
        styles.add(ParagraphStyle(
            name='DocTitle',
            parent=styles['Heading1'],
            fontSize=22,
            textColor=FreightPDFStyles.PRIMARY,
            alignment=TA_CENTER,
            spaceAfter=25,
            fontName='Helvetica-Bold',
            leading=26
        ))
        
        # Company Header Style
        styles.add(ParagraphStyle(
            name='CompanyName',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=FreightPDFStyles.PRIMARY,
            alignment=TA_LEFT,
            spaceAfter=3,
            fontName='Helvetica-Bold'
        ))
        
        # Company Details
        styles.add(ParagraphStyle(
            name='CompanyDetails',
            parent=styles['Normal'],
            fontSize=8,
            textColor=FreightPDFStyles.DARK_GRAY,
            alignment=TA_LEFT,
            spaceAfter=2,
            leading=10
        ))
        
        # Document Reference (Invoice No, Date, etc.)
        styles.add(ParagraphStyle(
            name='DocReference',
            parent=styles['Normal'],
            fontSize=10,
            textColor=FreightPDFStyles.SECONDARY,
            alignment=TA_RIGHT,
            fontName='Helvetica-Bold'
        ))
        
        # Section Title with accent bar
        styles.add(ParagraphStyle(
            name='SectionTitle',
            parent=styles['Heading2'],
            fontSize=11,
            textColor=FreightPDFStyles.WHITE,
            spaceBefore=18,
            spaceAfter=10,
            fontName='Helvetica-Bold',
            backColor=FreightPDFStyles.PRIMARY_LIGHT,
            borderPadding=(8, 12, 8, 12),
            leading=14
        ))
        
        # Sub-section Title
        styles.add(ParagraphStyle(
            name='SubSectionTitle',
            parent=styles['Heading3'],
            fontSize=10,
            textColor=FreightPDFStyles.PRIMARY,
            spaceBefore=12,
            spaceAfter=6,
            fontName='Helvetica-Bold',
            borderColor=FreightPDFStyles.PRIMARY_LIGHT,
            borderWidth=0,
            borderPadding=0,
            leftIndent=0
        ))
        
        # Field Label (small, gray)
        styles.add(ParagraphStyle(
            name='FieldLabel',
            parent=styles['Normal'],
            fontSize=7,
            textColor=FreightPDFStyles.DARK_GRAY,
            spaceBefore=1,
            spaceAfter=0,
            fontName='Helvetica'
        ))
        
        # Field Value (bold, black)
        styles.add(ParagraphStyle(
            name='FieldValue',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.black,
            spaceBefore=0,
            spaceAfter=4,
            fontName='Helvetica-Bold'
        ))
        
        # Table Header
        styles.add(ParagraphStyle(
            name='TableHeader',
            parent=styles['Normal'],
            fontSize=8,
            textColor=colors.white,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Table Cell
        styles.add(ParagraphStyle(
            name='TableCell',
            parent=styles['Normal'],
            fontSize=9,
            alignment=TA_LEFT,
            fontName='Helvetica'
        ))
        
        # Table Cell Right Aligned (for numbers)
        styles.add(ParagraphStyle(
            name='TableCellRight',
            parent=styles['Normal'],
            fontSize=9,
            alignment=TA_RIGHT,
            fontName='Helvetica'
        ))
        
        # Total Row
        styles.add(ParagraphStyle(
            name='TotalLabel',
            parent=styles['Normal'],
            fontSize=11,
            textColor=FreightPDFStyles.SECONDARY,
            alignment=TA_RIGHT,
            fontName='Helvetica-Bold'
        ))
        
        styles.add(ParagraphStyle(
            name='TotalAmount',
            parent=styles['Normal'],
            fontSize=12,
            textColor=FreightPDFStyles.PRIMARY,
            alignment=TA_RIGHT,
            fontName='Helvetica-Bold'
        ))
        
        # Footer
        styles.add(ParagraphStyle(
            name='Footer',
            parent=styles['Normal'],
            fontSize=7,
            textColor=FreightPDFStyles.DARK_GRAY,
            alignment=TA_CENTER,
            leading=9
        ))
        
        # Notes/Terms
        styles.add(ParagraphStyle(
            name='Notes',
            parent=styles['Normal'],
            fontSize=8,
            textColor=FreightPDFStyles.DARK_GRAY,
            alignment=TA_LEFT,
            spaceBefore=5,
            spaceAfter=5,
            leading=10
        ))
        
        # Bank Info
        styles.add(ParagraphStyle(
            name='BankInfo',
            parent=styles['Normal'],
            fontSize=8,
            textColor=FreightPDFStyles.SECONDARY,
            alignment=TA_LEFT,
            spaceBefore=3,
            spaceAfter=3,
            fontName='Helvetica'
        ))
        
        return styles
    
    @staticmethod
    def get_premium_table_style(has_alternating_rows=True):
        """Get premium table style"""
        style = [
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.TABLE_HEADER_BG),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            
            # Body styling
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('TOPPADDING', (0, 1), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            
            # Grid
            ('GRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.TABLE_BORDER),
            ('LINEBELOW', (0, 0), (-1, 0), 2, FreightPDFStyles.PRIMARY),
        ]
        
        return TableStyle(style)
    
    @staticmethod
    def get_summary_table_style():
        """Style for summary/total tables"""
        return TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('TEXTCOLOR', (0, 0), (-1, -1), FreightPDFStyles.SECONDARY),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.PRIMARY),
        ])


class PDFDocumentGenerator:
    """Base class for PDF document generation with company info"""
    
    def __init__(self, output_path, pagesize=letter):
        self.output_path = output_path
        self.pagesize = pagesize
        self.styles = FreightPDFStyles.get_styles()
        self.width, self.height = pagesize
        self._load_company_info()
        
    def _load_company_info(self):
        """Load company info from database"""
        try:
            from db import get_company_info
            self.company_info = get_company_info()
        except Exception as e:
            print(f"Could not load company info: {e}")
            self.company_info = {
                "company_name": "FREIGHT FORWARDING CO.",
                "company_address": "",
                "company_city": "",
                "company_phone": "",
                "company_email": "",
                "bank_name": "",
                "bank_account": "",
            }
        
    def _add_header(self, canvas, doc):
        """Add premium company header to each page"""
        canvas.saveState()
        
        ci = self.company_info
        
        # Blue accent bar at top
        canvas.setFillColor(FreightPDFStyles.PRIMARY)
        canvas.rect(0, self.height - 15, self.width, 15, fill=True, stroke=False)
        
        # Company name
        canvas.setFont("Helvetica-Bold", 16)
        canvas.setFillColor(FreightPDFStyles.PRIMARY)
        canvas.drawString(0.75*inch, self.height - 0.55*inch, ci.get("company_name", "FREIGHT FORWARDING CO."))
        
        # Company address line 1
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(FreightPDFStyles.DARK_GRAY)
        address_parts = []
        if ci.get("company_address"):
            address_parts.append(ci["company_address"])
        if ci.get("company_city"):
            address_parts.append(ci["company_city"])
        if ci.get("company_state"):
            address_parts.append(ci["company_state"])
        if ci.get("company_zip"):
            address_parts.append(ci["company_zip"])
        
        if address_parts:
            canvas.drawString(0.75*inch, self.height - 0.72*inch, ", ".join(address_parts))
        
        # Tax ID
        if ci.get("company_tax_id"):
            canvas.drawString(0.75*inch, self.height - 0.85*inch, f"RFC: {ci['company_tax_id']}")
        
        # Contact info (right side)
        right_x = self.width - 0.75*inch
        y_pos = self.height - 0.55*inch
        
        if ci.get("company_phone"):
            canvas.setFont("Helvetica", 8)
            canvas.drawRightString(right_x, y_pos, f"📞 {ci['company_phone']}")
            y_pos -= 0.12*inch
        
        if ci.get("company_email"):
            canvas.drawRightString(right_x, y_pos, f"✉ {ci['company_email']}")
            y_pos -= 0.12*inch
        
        if ci.get("company_website"):
            canvas.drawRightString(right_x, y_pos, f"🌐 {ci['company_website']}")
        
        # Gradient line under header
        canvas.setStrokeColor(FreightPDFStyles.PRIMARY)
        canvas.setLineWidth(3)
        canvas.line(0.75*inch, self.height - 1.0*inch, self.width - 0.75*inch, self.height - 1.0*inch)
        
        # Thin accent line
        canvas.setStrokeColor(FreightPDFStyles.ACCENT)
        canvas.setLineWidth(1)
        canvas.line(0.75*inch, self.height - 1.05*inch, self.width - 0.75*inch, self.height - 1.05*inch)
        
        canvas.restoreState()
    
    def _add_footer(self, canvas, doc):
        """Add premium footer to each page"""
        canvas.saveState()
        
        ci = self.company_info
        
        # Footer line
        canvas.setStrokeColor(FreightPDFStyles.BORDER)
        canvas.setLineWidth(0.5)
        canvas.line(0.75*inch, 0.7*inch, self.width - 0.75*inch, 0.7*inch)
        
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(FreightPDFStyles.DARK_GRAY)
        
        # Page number (center)
        page_num = canvas.getPageNumber()
        canvas.drawCentredString(self.width/2, 0.5*inch, f"— Page {page_num} —")
        
        # Company name (left)
        canvas.drawString(0.75*inch, 0.35*inch, ci.get("company_name", ""))
        
        # Generation date (right)
        canvas.drawRightString(self.width - 0.75*inch, 0.35*inch, 
                              f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        canvas.restoreState()
    
    def _add_bank_info_section(self, story):
        """Add bank information section for invoices"""
        ci = self.company_info
        
        if not ci.get("bank_name"):
            return
        
        story.append(Spacer(1, 15))
        
        # Bank info table
        bank_data = []
        bank_data.append(["PAYMENT INFORMATION", ""])
        
        if ci.get("bank_name"):
            bank_data.append(["Bank:", ci["bank_name"]])
        if ci.get("bank_branch"):
            bank_data.append(["Branch:", ci["bank_branch"]])
        if ci.get("bank_account"):
            bank_data.append(["Account No:", ci["bank_account"]])
        if ci.get("bank_clabe"):
            bank_data.append(["CLABE:", ci["bank_clabe"]])
        if ci.get("bank_usd_account"):
            bank_data.append(["USD Account:", ci["bank_usd_account"]])
        if ci.get("bank_swift"):
            bank_data.append(["SWIFT:", ci["bank_swift"]])
        
        bank_table = Table(bank_data, colWidths=[1.5*inch, 3*inch])
        bank_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY_LIGHT),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('SPAN', (0, 0), (-1, 0)),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            ('BACKGROUND', (0, 1), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('FONTNAME', (0, 1), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 10),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('GRID', (0, 1), (-1, -1), 0.5, FreightPDFStyles.BORDER),
        ]))
        
        story.append(bank_table)
    
    def _on_page(self, canvas, doc):
        """Called on each page"""
        self._add_header(canvas, doc)
        self._add_footer(canvas, doc)


class BillOfLadingPDF(PDFDocumentGenerator):
    """Generate Bill of Lading (B/L) document"""
    
    def generate(self, job_data, containers=None):
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.pagesize,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=1.2*inch,
            bottomMargin=0.75*inch
        )
        
        story = []
        
        # Title
        story.append(Paragraph("BILL OF LADING", self.styles['DocTitle']))
        story.append(Spacer(1, 10))
        
        # B/L Info Row
        bl_data = [
            ["B/L No:", job_data.get('mbl', ''), "Date:", job_data.get('bl_date', datetime.now().strftime('%Y-%m-%d'))],
        ]
        bl_table = Table(bl_data, colWidths=[1*inch, 2.5*inch, 0.8*inch, 2*inch])
        bl_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(bl_table)
        story.append(Spacer(1, 15))
        
        # Shipper & Consignee
        parties_data = [
            [Paragraph("<b>SHIPPER</b>", self.styles['Normal']), 
             Paragraph("<b>CONSIGNEE</b>", self.styles['Normal'])],
            [Paragraph(job_data.get('shipper', '').replace('\n', '<br/>'), self.styles['Normal']),
             Paragraph(job_data.get('consignee', '').replace('\n', '<br/>'), self.styles['Normal'])],
        ]
        parties_table = Table(parties_data, colWidths=[3.25*inch, 3.25*inch])
        parties_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 8),
            ('MINROWHEIGHT', (0, 1), (-1, 1), 60),
        ]))
        story.append(parties_table)
        story.append(Spacer(1, 10))
        
        # Notify Party
        notify_data = [
            [Paragraph("<b>NOTIFY PARTY</b>", self.styles['Normal'])],
            [Paragraph(job_data.get('notify', '').replace('\n', '<br/>'), self.styles['Normal'])],
        ]
        notify_table = Table(notify_data, colWidths=[6.5*inch])
        notify_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 8),
            ('MINROWHEIGHT', (0, 1), (-1, 1), 40),
        ]))
        story.append(notify_table)
        story.append(Spacer(1, 15))
        
        # Vessel & Port Info
        vessel_data = [
            ["VESSEL", "VOYAGE", "POL", "POD"],
            [job_data.get('vessel', ''), job_data.get('voyage', ''), 
             job_data.get('pol', ''), job_data.get('pod', '')],
            ["ETD", "ETA", "CARRIER", "SERVICE"],
            [job_data.get('etd', ''), job_data.get('eta', ''), 
             job_data.get('carrier', ''), job_data.get('service', '')],
        ]
        vessel_table = Table(vessel_data, colWidths=[1.625*inch]*4)
        vessel_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.SECONDARY),
            ('BACKGROUND', (0, 2), (-1, 2), FreightPDFStyles.SECONDARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('TEXTCOLOR', (0, 2), (-1, 2), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 2), (-1, 2), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(vessel_table)
        story.append(Spacer(1, 15))
        
        # Container Details
        story.append(Paragraph("<b>CONTAINER DETAILS</b>", self.styles['SectionTitle']))
        
        container_header = ["CNTR NO", "TYPE", "SEAL NO", "PKGS", "WEIGHT (KG)", "CBM"]
        container_rows = [container_header]
        
        if containers:
            for c in containers:
                container_rows.append([
                    c.get('cntr_no', ''),
                    c.get('cntr_type', ''),
                    c.get('seal_no', ''),
                    str(c.get('pcs', '')),
                    str(c.get('weight', '')),
                    str(c.get('cbm', ''))
                ])
        else:
            container_rows.append(['', '', '', '', '', ''])
        
        cntr_table = Table(container_rows, colWidths=[1.3*inch, 0.8*inch, 1.1*inch, 0.8*inch, 1.1*inch, 0.8*inch])
        cntr_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, FreightPDFStyles.LIGHT_GRAY]),
        ]))
        story.append(cntr_table)
        story.append(Spacer(1, 15))
        
        # Cargo Description
        story.append(Paragraph("<b>DESCRIPTION OF GOODS</b>", self.styles['SectionTitle']))
        
        desc_data = [
            [Paragraph(job_data.get('commodity', 'SAID TO CONTAIN').replace('\n', '<br/>'), self.styles['Normal'])]
        ]
        desc_table = Table(desc_data, colWidths=[6.5*inch])
        desc_table.setStyle(TableStyle([
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 10),
            ('MINROWHEIGHT', (0, 0), (-1, -1), 80),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(desc_table)
        story.append(Spacer(1, 20))
        
        # Signature
        sig_data = [
            ["", ""],
            ["_" * 35, "_" * 35],
            ["Shipper's Signature", "Carrier's Signature"],
        ]
        sig_table = Table(sig_data, colWidths=[3.25*inch, 3.25*inch])
        sig_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('TOPPADDING', (0, 0), (-1, 0), 40),
        ]))
        story.append(sig_table)
        
        # Build PDF
        doc.build(story, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return self.output_path


class AirWaybillPDF(PDFDocumentGenerator):
    """Generate Air Waybill (AWB) document"""
    
    def generate(self, job_data, cargo_details=None):
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.pagesize,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=1.2*inch,
            bottomMargin=0.75*inch
        )
        
        story = []
        
        # Title
        story.append(Paragraph("AIR WAYBILL", self.styles['DocTitle']))
        story.append(Spacer(1, 10))
        
        # AWB Info
        awb_data = [
            ["MAWB No:", job_data.get('mbl', ''), "HAWB No:", job_data.get('hbl', '')],
            ["Issue Date:", job_data.get('awb_date', datetime.now().strftime('%Y-%m-%d')), "", ""],
        ]
        awb_table = Table(awb_data, colWidths=[1*inch, 2.25*inch, 1*inch, 2.25*inch])
        awb_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(awb_table)
        story.append(Spacer(1, 15))
        
        # Shipper & Consignee
        parties_data = [
            [Paragraph("<b>SHIPPER</b>", self.styles['Normal']), 
             Paragraph("<b>CONSIGNEE</b>", self.styles['Normal'])],
            [Paragraph(job_data.get('shipper', '').replace('\n', '<br/>'), self.styles['Normal']),
             Paragraph(job_data.get('consignee', '').replace('\n', '<br/>'), self.styles['Normal'])],
        ]
        parties_table = Table(parties_data, colWidths=[3.25*inch, 3.25*inch])
        parties_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 8),
            ('MINROWHEIGHT', (0, 1), (-1, 1), 60),
        ]))
        story.append(parties_table)
        story.append(Spacer(1, 15))
        
        # Flight Info
        flight_data = [
            ["FLIGHT", "ORIGIN (AOL)", "DESTINATION (AOD)", "ETD", "ETA"],
            [job_data.get('flight', ''), job_data.get('pol', ''), 
             job_data.get('pod', ''), job_data.get('etd', ''), job_data.get('eta', '')],
        ]
        flight_table = Table(flight_data, colWidths=[1.3*inch]*5)
        flight_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.SECONDARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(flight_table)
        story.append(Spacer(1, 15))
        
        # Cargo Details
        story.append(Paragraph("<b>CARGO DETAILS</b>", self.styles['SectionTitle']))
        
        cargo_header = ["PCS", "L (cm)", "W (cm)", "H (cm)", "G.W (KG)", "C.W (KG)", "CBM"]
        cargo_rows = [cargo_header]
        
        total_pcs = 0
        total_gw = 0
        total_cw = 0
        total_cbm = 0
        
        if cargo_details:
            for c in cargo_details:
                pcs = float(c.get('pcs', 0) or 0)
                gw = float(c.get('weight', 0) or 0)
                cw = float(c.get('chargeable_weight', 0) or 0)
                cbm = float(c.get('cbm', 0) or 0)
                
                total_pcs += pcs
                total_gw += gw
                total_cw += cw
                total_cbm += cbm
                
                cargo_rows.append([
                    str(int(pcs)),
                    str(c.get('length', '')),
                    str(c.get('width', '')),
                    str(c.get('height', '')),
                    f"{gw:.2f}",
                    f"{cw:.2f}",
                    f"{cbm:.3f}"
                ])
            
            # Total row
            cargo_rows.append([
                f"TOTAL: {int(total_pcs)}", "", "", "", 
                f"{total_gw:.2f}", f"{total_cw:.2f}", f"{total_cbm:.3f}"
            ])
        else:
            cargo_rows.append(['', '', '', '', '', '', ''])
        
        cargo_table = Table(cargo_rows, colWidths=[0.7*inch, 0.8*inch, 0.8*inch, 0.8*inch, 1*inch, 1*inch, 0.9*inch])
        cargo_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('BACKGROUND', (0, -1), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ]))
        story.append(cargo_table)
        story.append(Spacer(1, 15))
        
        # Nature of Goods
        story.append(Paragraph("<b>NATURE OF GOODS</b>", self.styles['SectionTitle']))
        
        goods_data = [
            [Paragraph(job_data.get('commodity', 'CONSOLIDATED CARGO').replace('\n', '<br/>'), self.styles['Normal'])]
        ]
        goods_table = Table(goods_data, colWidths=[6.5*inch])
        goods_table.setStyle(TableStyle([
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 10),
            ('MINROWHEIGHT', (0, 0), (-1, -1), 60),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        story.append(goods_table)
        
        # Build PDF
        doc.build(story, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return self.output_path


class ArrivalNoticePDF(PDFDocumentGenerator):
    """Generate Arrival Notice document"""
    
    def generate(self, job_data, containers=None):
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.pagesize,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=1.2*inch,
            bottomMargin=0.75*inch
        )
        
        story = []
        
        # Title
        story.append(Paragraph("ARRIVAL NOTICE", self.styles['DocTitle']))
        story.append(Spacer(1, 5))
        
        # Date and Reference
        ref_data = [
            ["Date:", datetime.now().strftime('%Y-%m-%d'), "Job No:", job_data.get('job_no', '')],
            ["MBL/MAWB:", job_data.get('mbl', ''), "HBL/HAWB:", job_data.get('hbl', '')],
        ]
        ref_table = Table(ref_data, colWidths=[1*inch, 2.25*inch, 1*inch, 2.25*inch])
        ref_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(ref_table)
        story.append(Spacer(1, 15))
        
        # Consignee Info
        story.append(Paragraph("<b>TO: CONSIGNEE</b>", self.styles['SectionTitle']))
        consignee_text = job_data.get('consignee', '').replace('\n', '<br/>')
        story.append(Paragraph(consignee_text, self.styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Notice text
        mode = job_data.get('mode', 'OCEAN')
        if mode == 'OCEAN':
            arrival_text = f"""
            We are pleased to inform you that your shipment has arrived / is expected to arrive as follows:
            <br/><br/>
            <b>VESSEL:</b> {job_data.get('vessel', '')} V.{job_data.get('voyage', '')}<br/>
            <b>PORT OF LOADING:</b> {job_data.get('pol', '')}<br/>
            <b>PORT OF DISCHARGE:</b> {job_data.get('pod', '')}<br/>
            <b>ETA:</b> {job_data.get('eta', '')}
            """
        else:
            arrival_text = f"""
            We are pleased to inform you that your shipment has arrived / is expected to arrive as follows:
            <br/><br/>
            <b>FLIGHT:</b> {job_data.get('flight', job_data.get('vessel', ''))}<br/>
            <b>ORIGIN:</b> {job_data.get('pol', '')}<br/>
            <b>DESTINATION:</b> {job_data.get('pod', '')}<br/>
            <b>ETA:</b> {job_data.get('eta', '')}
            """
        
        story.append(Paragraph(arrival_text, self.styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Cargo Details
        story.append(Paragraph("<b>CARGO DETAILS</b>", self.styles['SectionTitle']))
        
        if mode == 'OCEAN' and containers:
            cargo_header = ["CNTR NO", "TYPE", "SEAL NO", "WEIGHT (KG)", "CBM"]
            cargo_rows = [cargo_header]
            for c in containers:
                cargo_rows.append([
                    c.get('cntr_no', ''),
                    c.get('cntr_type', ''),
                    c.get('seal_no', ''),
                    str(c.get('weight', '')),
                    str(c.get('cbm', ''))
                ])
        else:
            cargo_rows = [
                ["PCS", "GROSS WEIGHT", "CHARGEABLE WEIGHT", "CBM", "COMMODITY"],
                [job_data.get('pcs', ''), job_data.get('weight', ''), 
                 job_data.get('chargeable_weight', ''), job_data.get('cbm', ''),
                 job_data.get('commodity', '')]
            ]
        
        cargo_table = Table(cargo_rows, colWidths=[1.3*inch]*len(cargo_rows[0]))
        cargo_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(cargo_table)
        story.append(Spacer(1, 20))
        
        # Instructions
        instructions = """
        <b>IMPORTANT NOTICE:</b><br/><br/>
        1. Please arrange customs clearance and collect your cargo promptly to avoid storage charges.<br/>
        2. Demurrage and detention charges may apply after free time expires.<br/>
        3. Please contact us immediately if you have any questions or need assistance.<br/>
        4. All charges must be settled before cargo release.
        """
        story.append(Paragraph(instructions, self.styles['Normal']))
        story.append(Spacer(1, 20))
        
        # Contact
        contact = f"""
        <b>For further information, please contact:</b><br/>
        Tel: +52-55-1234-5678<br/>
        Email: operations@freight-fwd.com<br/>
        Reference: {job_data.get('job_no', '')}
        """
        story.append(Paragraph(contact, self.styles['Normal']))
        
        # Build PDF
        doc.build(story, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return self.output_path


class DeliveryOrderPDF(PDFDocumentGenerator):
    """Generate Delivery Order (D/O) document"""
    
    def generate(self, job_data, containers=None):
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.pagesize,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=1.2*inch,
            bottomMargin=0.75*inch
        )
        
        story = []
        
        # Title
        story.append(Paragraph("DELIVERY ORDER", self.styles['DocTitle']))
        story.append(Spacer(1, 5))
        
        # D/O Number
        do_data = [
            ["D/O No:", job_data.get('do_no', job_data.get('job_no', '')), 
             "Date:", datetime.now().strftime('%Y-%m-%d')],
        ]
        do_table = Table(do_data, colWidths=[1*inch, 2.25*inch, 1*inch, 2.25*inch])
        do_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.ACCENT),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(do_table)
        story.append(Spacer(1, 15))
        
        # To: Terminal/Warehouse
        story.append(Paragraph("<b>TO:</b>", self.styles['Normal']))
        story.append(Paragraph(job_data.get('terminal', 'Container Terminal / Warehouse'), self.styles['Normal']))
        story.append(Spacer(1, 15))
        
        # Authorization text
        auth_text = """
        Please release the following cargo to the bearer of this Delivery Order:
        """
        story.append(Paragraph(auth_text, self.styles['Normal']))
        story.append(Spacer(1, 10))
        
        # Shipment Info
        ship_data = [
            ["MBL/MAWB:", job_data.get('mbl', ''), "HBL/HAWB:", job_data.get('hbl', '')],
            ["VESSEL/FLIGHT:", job_data.get('vessel', ''), "VOYAGE:", job_data.get('voyage', '')],
            ["POL:", job_data.get('pol', ''), "POD:", job_data.get('pod', '')],
        ]
        ship_table = Table(ship_data, colWidths=[1.2*inch, 2.05*inch, 1.2*inch, 2.05*inch])
        ship_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(ship_table)
        story.append(Spacer(1, 15))
        
        # Container/Cargo Details
        story.append(Paragraph("<b>CARGO TO BE RELEASED:</b>", self.styles['SectionTitle']))
        
        if containers:
            cargo_header = ["CNTR NO", "TYPE", "SEAL NO", "WEIGHT (KG)", "CBM", "STATUS"]
            cargo_rows = [cargo_header]
            for c in containers:
                cargo_rows.append([
                    c.get('cntr_no', ''),
                    c.get('cntr_type', ''),
                    c.get('seal_no', ''),
                    str(c.get('weight', '')),
                    str(c.get('cbm', '')),
                    'RELEASE'
                ])
        else:
            cargo_rows = [
                ["DESCRIPTION", "PCS", "WEIGHT (KG)", "CBM", "STATUS"],
                [job_data.get('commodity', 'CARGO'), job_data.get('pcs', ''), 
                 job_data.get('weight', ''), job_data.get('cbm', ''), 'RELEASE']
            ]
        
        cargo_table = Table(cargo_rows, colWidths=[1.3*inch]*len(cargo_rows[0]))
        cargo_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(cargo_table)
        story.append(Spacer(1, 20))
        
        # Consignee Info
        consignee_data = [
            [Paragraph("<b>CONSIGNEE:</b>", self.styles['Normal'])],
            [Paragraph(job_data.get('consignee', '').replace('\n', '<br/>'), self.styles['Normal'])],
        ]
        consignee_table = Table(consignee_data, colWidths=[6.5*inch])
        consignee_table.setStyle(TableStyle([
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 10),
        ]))
        story.append(consignee_table)
        story.append(Spacer(1, 30))
        
        # Authorization Signature
        sig_data = [
            ["", ""],
            ["_" * 35, "_" * 35],
            ["Authorized Signature", "Date"],
            ["FREIGHT FORWARDING CO.", ""],
        ]
        sig_table = Table(sig_data, colWidths=[3.25*inch, 3.25*inch])
        sig_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('TOPPADDING', (0, 0), (-1, 0), 30),
            ('FONTNAME', (0, 3), (0, 3), 'Helvetica-Bold'),
        ]))
        story.append(sig_table)
        
        # Build PDF
        doc.build(story, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return self.output_path


class InvoicePDF(PDFDocumentGenerator):
    """Generate Invoice document"""
    
    def generate(self, job_data, line_items=None):
        doc = SimpleDocTemplate(
            self.output_path,
            pagesize=self.pagesize,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=1.2*inch,
            bottomMargin=0.75*inch
        )
        
        story = []
        
        # Title
        story.append(Paragraph("INVOICE", self.styles['DocTitle']))
        story.append(Spacer(1, 5))
        
        # Invoice Info
        inv_data = [
            ["Invoice No:", job_data.get('invoice_no', ''), "Date:", job_data.get('invoice_date', datetime.now().strftime('%Y-%m-%d'))],
            ["Job No:", job_data.get('job_no', ''), "Due Date:", job_data.get('due_date', '')],
        ]
        inv_table = Table(inv_data, colWidths=[1*inch, 2.25*inch, 1*inch, 2.25*inch])
        inv_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BACKGROUND', (0, 0), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(inv_table)
        story.append(Spacer(1, 15))
        
        # Bill To
        billto_data = [
            [Paragraph("<b>BILL TO:</b>", self.styles['Normal']), 
             Paragraph("<b>SHIPMENT DETAILS:</b>", self.styles['Normal'])],
            [Paragraph(job_data.get('customer', '').replace('\n', '<br/>'), self.styles['Normal']),
             Paragraph(f"""
                MBL/MAWB: {job_data.get('mbl', '')}<br/>
                POL: {job_data.get('pol', '')} → POD: {job_data.get('pod', '')}<br/>
                ETD: {job_data.get('etd', '')} / ETA: {job_data.get('eta', '')}
             """, self.styles['Normal'])],
        ]
        billto_table = Table(billto_data, colWidths=[3.25*inch, 3.25*inch])
        billto_table.setStyle(TableStyle([
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, FreightPDFStyles.BORDER),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 10),
        ]))
        story.append(billto_table)
        story.append(Spacer(1, 20))
        
        # Line Items
        story.append(Paragraph("<b>CHARGES</b>", self.styles['SectionTitle']))
        
        items_header = ["#", "DESCRIPTION", "QTY", "UNIT", "RATE", "CURRENCY", "AMOUNT"]
        items_rows = [items_header]
        
        total = 0
        if line_items:
            for i, item in enumerate(line_items, 1):
                amount = float(item.get('amount', 0) or 0)
                total += amount
                items_rows.append([
                    str(i),
                    item.get('description', ''),
                    str(item.get('qty', 1)),
                    item.get('unit', ''),
                    f"{float(item.get('rate', 0)):,.2f}",
                    item.get('currency', 'USD'),
                    f"{amount:,.2f}"
                ])
        else:
            items_rows.append(['1', 'Freight Charges', '1', 'LOT', '0.00', 'USD', '0.00'])
        
        # Total row
        items_rows.append(['', '', '', '', '', 'TOTAL:', f"${total:,.2f}"])
        
        items_table = Table(items_rows, colWidths=[0.4*inch, 2.2*inch, 0.6*inch, 0.6*inch, 0.9*inch, 0.8*inch, 1*inch])
        items_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), FreightPDFStyles.PRIMARY),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('ALIGN', (2, 0), (-1, -1), 'CENTER'),
            ('BOX', (0, 0), (-1, -1), 1, FreightPDFStyles.BORDER),
            ('INNERGRID', (0, 0), (-1, -2), 0.5, FreightPDFStyles.BORDER),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('BACKGROUND', (0, -1), (-1, -1), FreightPDFStyles.LIGHT_GRAY),
            ('FONTNAME', (-2, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (-2, -1), (-1, -1), 11),
            ('LINEABOVE', (0, -1), (-1, -1), 2, FreightPDFStyles.PRIMARY),
        ]))
        story.append(items_table)
        story.append(Spacer(1, 20))
        
        # Payment Info - use company info from database
        ci = self.company_info
        
        bank_info = f"""
        <b>PAYMENT INFORMATION:</b><br/><br/>
        <b>Bank:</b> {ci.get('bank_name', 'N/A')}<br/>
        <b>Account Name:</b> {ci.get('company_name', '')}<br/>
        """
        
        # Add USD account info
        if ci.get('bank_usd_account'):
            bank_info += f"<b>USD Account:</b> {ci['bank_usd_account']}<br/>"
        if ci.get('bank_usd_clabe'):
            bank_info += f"<b>USD CLABE:</b> {ci['bank_usd_clabe']}<br/>"
        
        # Add MXN account info
        if ci.get('bank_account'):
            bank_info += f"<b>MXN Account:</b> {ci['bank_account']}<br/>"
        if ci.get('bank_clabe'):
            bank_info += f"<b>MXN CLABE:</b> {ci['bank_clabe']}<br/>"
        
        # Add SWIFT
        if ci.get('bank_swift'):
            bank_info += f"<b>SWIFT:</b> {ci['bank_swift']}<br/>"
        
        bank_info += "<br/>Please include Invoice No. in payment reference."
        
        story.append(Paragraph(bank_info, self.styles['Normal']))
        story.append(Spacer(1, 20))
        
        # Terms
        terms = """
        <b>TERMS & CONDITIONS:</b><br/>
        Payment is due within 30 days from invoice date. Late payments may incur interest charges.
        """
        story.append(Paragraph(terms, self.styles['Normal']))
        
        # Build PDF
        doc.build(story, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return self.output_path


# ============================================================
# PDF EXPORT MANAGER
# ============================================================
class PDFExportManager:
    """Manager class for generating various PDF documents"""
    
    def __init__(self, output_dir="/mnt/user-data/outputs"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def generate_bill_of_lading(self, job_data, containers=None):
        """Generate Bill of Lading PDF"""
        filename = f"BL_{job_data.get('job_no', 'unknown')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        output_path = os.path.join(self.output_dir, filename)
        
        generator = BillOfLadingPDF(output_path)
        return generator.generate(job_data, containers)
    
    def generate_air_waybill(self, job_data, cargo_details=None):
        """Generate Air Waybill PDF"""
        filename = f"AWB_{job_data.get('job_no', 'unknown')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        output_path = os.path.join(self.output_dir, filename)
        
        generator = AirWaybillPDF(output_path)
        return generator.generate(job_data, cargo_details)
    
    def generate_arrival_notice(self, job_data, containers=None):
        """Generate Arrival Notice PDF"""
        filename = f"AN_{job_data.get('job_no', 'unknown')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        output_path = os.path.join(self.output_dir, filename)
        
        generator = ArrivalNoticePDF(output_path)
        return generator.generate(job_data, containers)
    
    def generate_delivery_order(self, job_data, containers=None):
        """Generate Delivery Order PDF"""
        filename = f"DO_{job_data.get('job_no', 'unknown')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        output_path = os.path.join(self.output_dir, filename)
        
        generator = DeliveryOrderPDF(output_path)
        return generator.generate(job_data, containers)
    
    def generate_invoice(self, job_data, line_items=None):
        """Generate Invoice PDF"""
        filename = f"INV_{job_data.get('invoice_no', job_data.get('job_no', 'unknown'))}_{datetime.now().strftime('%Y%m%d%H%M%S')}.pdf"
        output_path = os.path.join(self.output_dir, filename)
        
        generator = InvoicePDF(output_path)
        return generator.generate(job_data, line_items)


# ============================================================
# INTEGRATION FUNCTIONS
# ============================================================
def export_job_documents(job_no, doc_types=None):
    """
    Export documents for a job from database
    
    Args:
        job_no: Job number to export documents for
        doc_types: List of document types to generate, or None for all
                   Options: 'bl', 'awb', 'arrival', 'delivery', 'invoice'
    
    Returns:
        List of generated file paths
    """
    from db import get_connection
    
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        # Get job data
        cur.execute("""
            SELECT job_no, mode, mbl, hbl, shipper, consignee, notify, customer, partner,
                   carrier, vessel, voyage, pol, pod, etd, eta, atd, ata, status, remarks,
                   commodity
            FROM jobs WHERE job_no = ?
        """, (job_no,))
        
        job_row = cur.fetchone()
        if not job_row:
            raise ValueError(f"Job {job_no} not found")
        
        job_data = {
            'job_no': job_row[0],
            'mode': job_row[1],
            'mbl': job_row[2],
            'hbl': job_row[3],
            'shipper': job_row[4] or '',
            'consignee': job_row[5] or '',
            'notify': job_row[6] or '',
            'customer': job_row[7] or '',
            'partner': job_row[8] or '',
            'carrier': job_row[9] or '',
            'vessel': job_row[10] or '',
            'voyage': job_row[11] or '',
            'pol': job_row[12] or '',
            'pod': job_row[13] or '',
            'etd': job_row[14] or '',
            'eta': job_row[15] or '',
            'atd': job_row[16] or '',
            'ata': job_row[17] or '',
            'status': job_row[18] or '',
            'remarks': job_row[19] or '',
            'commodity': job_row[20] or '',
        }
        
        # Get job ID for related data
        cur.execute("SELECT id FROM jobs WHERE job_no = ?", (job_no,))
        job_id = cur.fetchone()[0]
        
        # Get containers
        cur.execute("""
            SELECT cntr_no, cntr_type, seal_no, pcs, weight, cbm, status, location
            FROM containers WHERE job_id = ?
        """, (job_id,))
        
        containers = []
        for row in cur.fetchall():
            containers.append({
                'cntr_no': row[0] or '',
                'cntr_type': row[1] or '',
                'seal_no': row[2] or '',
                'pcs': row[3] or '',
                'weight': row[4] or '',
                'cbm': row[5] or '',
                'status': row[6] or '',
                'location': row[7] or '',
            })
        
        # Get settlement items for invoice
        cur.execute("""
            SELECT freight_desc, qty, unit, rate, currency, total
            FROM settlement_items WHERE job_id = ? AND item_type = 'REVENUE'
        """, (job_id,))
        
        line_items = []
        for row in cur.fetchall():
            line_items.append({
                'description': row[0] or '',
                'qty': row[1] or 1,
                'unit': row[2] or '',
                'rate': row[3] or 0,
                'currency': row[4] or 'USD',
                'amount': row[5] or 0,
            })
        
    finally:
        conn.close()
    
    # Generate documents
    manager = PDFExportManager()
    generated_files = []
    
    mode = job_data.get('mode', 'OCEAN')
    
    if doc_types is None:
        # Default based on mode
        if mode == 'OCEAN':
            doc_types = ['bl', 'arrival', 'delivery', 'invoice']
        elif mode == 'AIR':
            doc_types = ['awb', 'arrival', 'delivery', 'invoice']
        else:
            doc_types = ['arrival', 'delivery', 'invoice']
    
    for doc_type in doc_types:
        try:
            if doc_type == 'bl' and mode == 'OCEAN':
                path = manager.generate_bill_of_lading(job_data, containers)
                generated_files.append(path)
            elif doc_type == 'awb' and mode == 'AIR':
                path = manager.generate_air_waybill(job_data, containers)
                generated_files.append(path)
            elif doc_type == 'arrival':
                path = manager.generate_arrival_notice(job_data, containers)
                generated_files.append(path)
            elif doc_type == 'delivery':
                path = manager.generate_delivery_order(job_data, containers)
                generated_files.append(path)
            elif doc_type == 'invoice':
                path = manager.generate_invoice(job_data, line_items)
                generated_files.append(path)
        except Exception as e:
            print(f"Error generating {doc_type}: {e}")
    
    return generated_files


# Example usage
if __name__ == "__main__":
    # Test with sample data
    sample_job = {
        'job_no': 'SEA-2025-0001',
        'mode': 'OCEAN',
        'mbl': 'COSU1234567890',
        'hbl': 'HBL123456',
        'shipper': 'ABC TRADING CO.\n123 Export Street\nShanghai, China',
        'consignee': 'XYZ IMPORT SA DE CV\n456 Import Ave\nMexico City, Mexico',
        'notify': 'SAME AS CONSIGNEE',
        'customer': 'XYZ IMPORT SA DE CV',
        'carrier': 'COSCO SHIPPING',
        'vessel': 'COSCO PACIFIC',
        'voyage': '025E',
        'pol': 'CNSHA',
        'pod': 'MXMAN',
        'etd': '2025-01-10',
        'eta': '2025-02-05',
        'commodity': 'ELECTRONIC COMPONENTS\n500 CARTONS\nHS CODE: 8542.31',
    }
    
    sample_containers = [
        {'cntr_no': 'COSU1234567', 'cntr_type': '40HC', 'seal_no': 'SEAL001', 'pcs': 250, 'weight': 15000, 'cbm': 55},
        {'cntr_no': 'COSU7654321', 'cntr_type': '40HC', 'seal_no': 'SEAL002', 'pcs': 250, 'weight': 15000, 'cbm': 55},
    ]
    
    manager = PDFExportManager()
    
    # Generate documents
    bl_path = manager.generate_bill_of_lading(sample_job, sample_containers)
    print(f"B/L generated: {bl_path}")
    
    an_path = manager.generate_arrival_notice(sample_job, sample_containers)
    print(f"Arrival Notice generated: {an_path}")
    
    do_path = manager.generate_delivery_order(sample_job, sample_containers)
    print(f"Delivery Order generated: {do_path}")
