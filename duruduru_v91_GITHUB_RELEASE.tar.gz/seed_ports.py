# seed_ports.py
# Seed worldwide ports and cities data
# Includes major sea ports, airports, and land cities for OCEAN/AIR/LAND modes

"""
Worldwide Port Database Seeder
==============================
Contains 500+ locations:
- Major sea ports (UN/LOCODE)
- International airports (IATA)
- Key cities for land transport
"""

from db import get_connection, now_str

# Format: (code, name, type, city, country, country_code)
WORLDWIDE_PORTS = [
    # ============================================
    # ASIA - EAST ASIA
    # ============================================
    # China
    ("CNSHA", "Shanghai Port", "SEA", "Shanghai", "China", "CN"),
    ("CNPVG", "Shanghai Pudong Airport", "AIR", "Shanghai", "China", "CN"),
    ("CNNGB", "Ningbo-Zhoushan Port", "SEA", "Ningbo", "China", "CN"),
    ("CNSHE", "Shenzhen Port (Shekou)", "SEA", "Shenzhen", "China", "CN"),
    ("CNYTN", "Shenzhen Yantian Port", "SEA", "Shenzhen", "China", "CN"),
    ("CNSZX", "Shenzhen Bao'an Airport", "AIR", "Shenzhen", "China", "CN"),
    ("CNTAO", "Qingdao Port", "SEA", "Qingdao", "China", "CN"),
    ("CNTXG", "Qingdao Jiaodong Airport", "AIR", "Qingdao", "China", "CN"),
    ("CNDLC", "Dalian Port", "SEA", "Dalian", "China", "CN"),
    ("CNXMN", "Xiamen Port", "SEA", "Xiamen", "China", "CN"),
    ("CNTJN", "Tianjin Port (Xingang)", "SEA", "Tianjin", "China", "CN"),
    ("CNCAN", "Guangzhou Port (Nansha)", "SEA", "Guangzhou", "China", "CN"),
    ("CNGZU", "Guangzhou Baiyun Airport", "AIR", "Guangzhou", "China", "CN"),
    ("CNPEK", "Beijing Capital Airport", "AIR", "Beijing", "China", "CN"),
    ("CNPKG", "Beijing Daxing Airport", "AIR", "Beijing", "China", "CN"),
    ("CNCKG", "Chongqing Jiangbei Airport", "AIR", "Chongqing", "China", "CN"),
    ("CNCTU", "Chengdu Tianfu Airport", "AIR", "Chengdu", "China", "CN"),
    ("CNHGH", "Hangzhou Xiaoshan Airport", "AIR", "Hangzhou", "China", "CN"),
    ("CNWNZ", "Wenzhou Port", "SEA", "Wenzhou", "China", "CN"),
    ("CNFOC", "Fuzhou Port", "SEA", "Fuzhou", "China", "CN"),
    ("BEIJING", "Beijing", "LAND", "Beijing", "China", "CN"),
    ("SHANGHAI", "Shanghai", "LAND", "Shanghai", "China", "CN"),
    ("GUANGZHOU", "Guangzhou", "LAND", "Guangzhou", "China", "CN"),
    ("SHENZHEN", "Shenzhen", "LAND", "Shenzhen", "China", "CN"),
    
    # Hong Kong & Macau
    ("HKHKG", "Hong Kong Port", "SEA", "Hong Kong", "Hong Kong", "HK"),
    ("HKGCT", "Hong Kong Kwai Tsing Terminal", "SEA", "Hong Kong", "Hong Kong", "HK"),
    ("HKGAP", "Hong Kong International Airport", "AIR", "Hong Kong", "Hong Kong", "HK"),
    ("MOMFM", "Macau Port", "SEA", "Macau", "Macau", "MO"),
    
    # Taiwan
    ("TWKHH", "Kaohsiung Port", "SEA", "Kaohsiung", "Taiwan", "TW"),
    ("TWKEL", "Keelung Port", "SEA", "Keelung", "Taiwan", "TW"),
    ("TWTPE", "Taiwan Taoyuan Airport", "AIR", "Taipei", "Taiwan", "TW"),
    ("TWTXG", "Taichung Port", "SEA", "Taichung", "Taiwan", "TW"),
    
    # Japan
    ("JPTYO", "Tokyo Port", "SEA", "Tokyo", "Japan", "JP"),
    ("JPNRT", "Narita International Airport", "AIR", "Tokyo", "Japan", "JP"),
    ("JPHND", "Tokyo Haneda Airport", "AIR", "Tokyo", "Japan", "JP"),
    ("JPYOK", "Yokohama Port", "SEA", "Yokohama", "Japan", "JP"),
    ("JPOSA", "Osaka Port", "SEA", "Osaka", "Japan", "JP"),
    ("JPKIX", "Kansai International Airport", "AIR", "Osaka", "Japan", "JP"),
    ("JPUKB", "Kobe Port", "SEA", "Kobe", "Japan", "JP"),
    ("JPNGO", "Nagoya Port", "SEA", "Nagoya", "Japan", "JP"),
    ("JPNGOC", "Chubu Centrair Airport", "AIR", "Nagoya", "Japan", "JP"),
    ("JPFUK", "Fukuoka Airport", "AIR", "Fukuoka", "Japan", "JP"),
    ("JPHKT", "Hakata Port", "SEA", "Fukuoka", "Japan", "JP"),
    ("JPCTS", "New Chitose Airport", "AIR", "Sapporo", "Japan", "JP"),
    ("JPMOJ", "Moji Port", "SEA", "Kitakyushu", "Japan", "JP"),
    ("TOKYO", "Tokyo", "LAND", "Tokyo", "Japan", "JP"),
    ("OSAKA", "Osaka", "LAND", "Osaka", "Japan", "JP"),
    
    # South Korea
    ("KRPUS", "Busan Port", "SEA", "Busan", "Korea, South", "KR"),
    ("KRPNC", "Busan New Container Terminal", "SEA", "Busan", "Korea, South", "KR"),
    ("KRICN", "Incheon International Airport", "AIR", "Seoul", "Korea, South", "KR"),
    ("KRINC", "Incheon Port", "SEA", "Incheon", "Korea, South", "KR"),
    ("KRGMP", "Seoul Gimpo Airport", "AIR", "Seoul", "Korea, South", "KR"),
    ("KRPTK", "Pyeongtaek Port", "SEA", "Pyeongtaek", "Korea, South", "KR"),
    ("KRUSN", "Ulsan Port", "SEA", "Ulsan", "Korea, South", "KR"),
    ("KRKWJ", "Gwangyang Port", "SEA", "Gwangyang", "Korea, South", "KR"),
    ("SEOUL", "Seoul", "LAND", "Seoul", "Korea, South", "KR"),
    ("BUSAN", "Busan", "LAND", "Busan", "Korea, South", "KR"),
    
    # ============================================
    # ASIA - SOUTHEAST ASIA
    # ============================================
    # Singapore
    ("SGSIN", "Singapore Port (PSA)", "SEA", "Singapore", "Singapore", "SG"),
    ("SGJUR", "Jurong Port", "SEA", "Singapore", "Singapore", "SG"),
    ("SGCHA", "Singapore Changi Airport", "AIR", "Singapore", "Singapore", "SG"),
    
    # Malaysia
    ("MYPKG", "Port Klang", "SEA", "Klang", "Malaysia", "MY"),
    ("MYTPP", "Port of Tanjung Pelepas", "SEA", "Johor Bahru", "Malaysia", "MY"),
    ("MYKUL", "Kuala Lumpur Airport (KLIA)", "AIR", "Kuala Lumpur", "Malaysia", "MY"),
    ("MYPEN", "Penang Port", "SEA", "Penang", "Malaysia", "MY"),
    ("KUALALUMPUR", "Kuala Lumpur", "LAND", "Kuala Lumpur", "Malaysia", "MY"),
    
    # Thailand
    ("THBKK", "Bangkok Airport (Suvarnabhumi)", "AIR", "Bangkok", "Thailand", "TH"),
    ("THLCH", "Laem Chabang Port", "SEA", "Chonburi", "Thailand", "TH"),
    ("THPAT", "Bangkok Port (Pat)", "SEA", "Bangkok", "Thailand", "TH"),
    ("BANGKOK", "Bangkok", "LAND", "Bangkok", "Thailand", "TH"),
    
    # Vietnam
    ("VNSGN", "Ho Chi Minh City Port (Cat Lai)", "SEA", "Ho Chi Minh City", "Vietnam", "VN"),
    ("VNCLS", "Cat Lai Port", "SEA", "Ho Chi Minh City", "Vietnam", "VN"),
    ("VNHPH", "Haiphong Port", "SEA", "Haiphong", "Vietnam", "VN"),
    ("VNHAN", "Hanoi Noi Bai Airport", "AIR", "Hanoi", "Vietnam", "VN"),
    ("VNSGNA", "Tan Son Nhat Airport", "AIR", "Ho Chi Minh City", "Vietnam", "VN"),
    ("VNDAN", "Da Nang Port", "SEA", "Da Nang", "Vietnam", "VN"),
    ("HOCHIMINH", "Ho Chi Minh City", "LAND", "Ho Chi Minh City", "Vietnam", "VN"),
    ("HANOI", "Hanoi", "LAND", "Hanoi", "Vietnam", "VN"),
    
    # Indonesia
    ("IDJKT", "Jakarta Port (Tanjung Priok)", "SEA", "Jakarta", "Indonesia", "ID"),
    ("IDCGK", "Jakarta Soekarno-Hatta Airport", "AIR", "Jakarta", "Indonesia", "ID"),
    ("IDSUB", "Surabaya Port (Tanjung Perak)", "SEA", "Surabaya", "Indonesia", "ID"),
    ("IDBLW", "Belawan Port", "SEA", "Medan", "Indonesia", "ID"),
    ("IDSMR", "Semarang Port", "SEA", "Semarang", "Indonesia", "ID"),
    ("JAKARTA", "Jakarta", "LAND", "Jakarta", "Indonesia", "ID"),
    
    # Philippines
    ("PHMNL", "Manila Port", "SEA", "Manila", "Philippines", "PH"),
    ("PHMNN", "Ninoy Aquino Airport", "AIR", "Manila", "Philippines", "PH"),
    ("PHCEB", "Cebu Port", "SEA", "Cebu", "Philippines", "PH"),
    ("PHSFS", "Subic Bay Port", "SEA", "Subic", "Philippines", "PH"),
    ("MANILA", "Manila", "LAND", "Manila", "Philippines", "PH"),
    
    # ============================================
    # ASIA - SOUTH ASIA
    # ============================================
    # India
    ("INNSA", "Nhava Sheva Port (JNPT)", "SEA", "Mumbai", "India", "IN"),
    ("INBOM", "Mumbai Chhatrapati Airport", "AIR", "Mumbai", "India", "IN"),
    ("INMAA", "Chennai Port", "SEA", "Chennai", "India", "IN"),
    ("INDEL", "Delhi Indira Gandhi Airport", "AIR", "New Delhi", "India", "IN"),
    ("INCCU", "Kolkata Port", "SEA", "Kolkata", "India", "IN"),
    ("INMUN", "Mundra Port", "SEA", "Mundra", "India", "IN"),
    ("INBLR", "Bangalore Airport", "AIR", "Bangalore", "India", "IN"),
    ("INCOK", "Cochin Port", "SEA", "Kochi", "India", "IN"),
    ("INTUT", "Tuticorin Port", "SEA", "Tuticorin", "India", "IN"),
    ("MUMBAI", "Mumbai", "LAND", "Mumbai", "India", "IN"),
    ("NEWDELHI", "New Delhi", "LAND", "New Delhi", "India", "IN"),
    
    # Bangladesh
    ("BDCGP", "Chittagong Port", "SEA", "Chittagong", "Bangladesh", "BD"),
    ("BDDAC", "Dhaka Airport", "AIR", "Dhaka", "Bangladesh", "BD"),
    ("DHAKA", "Dhaka", "LAND", "Dhaka", "Bangladesh", "BD"),
    
    # Pakistan
    ("PKKHI", "Karachi Port", "SEA", "Karachi", "Pakistan", "PK"),
    ("PKKARA", "Karachi Airport", "AIR", "Karachi", "Pakistan", "PK"),
    ("PKQCT", "Port Qasim", "SEA", "Karachi", "Pakistan", "PK"),
    ("KARACHI", "Karachi", "LAND", "Karachi", "Pakistan", "PK"),
    
    # Sri Lanka
    ("LKCMB", "Colombo Port", "SEA", "Colombo", "Sri Lanka", "LK"),
    ("LKCMBA", "Colombo Airport", "AIR", "Colombo", "Sri Lanka", "LK"),
    
    # ============================================
    # MIDDLE EAST
    # ============================================
    # UAE
    ("AEJEA", "Jebel Ali Port", "SEA", "Dubai", "United Arab Emirates", "AE"),
    ("AEDXB", "Dubai International Airport", "AIR", "Dubai", "United Arab Emirates", "AE"),
    ("AEDWC", "Dubai World Central Airport", "AIR", "Dubai", "United Arab Emirates", "AE"),
    ("AEAUH", "Abu Dhabi Port", "SEA", "Abu Dhabi", "United Arab Emirates", "AE"),
    ("AESHJ", "Sharjah Port", "SEA", "Sharjah", "United Arab Emirates", "AE"),
    ("DUBAI", "Dubai", "LAND", "Dubai", "United Arab Emirates", "AE"),
    
    # Saudi Arabia
    ("SAJED", "Jeddah Port", "SEA", "Jeddah", "Saudi Arabia", "SA"),
    ("SAJEDA", "Jeddah Airport", "AIR", "Jeddah", "Saudi Arabia", "SA"),
    ("SADMM", "Dammam Port", "SEA", "Dammam", "Saudi Arabia", "SA"),
    ("SARUH", "Riyadh Airport", "AIR", "Riyadh", "Saudi Arabia", "SA"),
    ("RIYADH", "Riyadh", "LAND", "Riyadh", "Saudi Arabia", "SA"),
    
    # Qatar
    ("QADOH", "Doha Port", "SEA", "Doha", "Qatar", "QA"),
    ("QAHAM", "Hamad Airport", "AIR", "Doha", "Qatar", "QA"),
    
    # Kuwait
    ("KWSWK", "Shuwaikh Port", "SEA", "Kuwait City", "Kuwait", "KW"),
    ("KWKWI", "Kuwait Airport", "AIR", "Kuwait City", "Kuwait", "KW"),
    
    # Bahrain
    ("BHBAH", "Bahrain Port", "SEA", "Manama", "Bahrain", "BH"),
    
    # Oman
    ("OMSLL", "Salalah Port", "SEA", "Salalah", "Oman", "OM"),
    ("OMSOH", "Sohar Port", "SEA", "Sohar", "Oman", "OM"),
    
    # Israel
    ("ILHFA", "Haifa Port", "SEA", "Haifa", "Israel", "IL"),
    ("ILASH", "Ashdod Port", "SEA", "Ashdod", "Israel", "IL"),
    ("ILTLV", "Tel Aviv Airport", "AIR", "Tel Aviv", "Israel", "IL"),
    
    # Turkey
    ("TRIST", "Istanbul Port (Ambarli)", "SEA", "Istanbul", "Turkey", "TR"),
    ("TRIST2", "Istanbul New Airport", "AIR", "Istanbul", "Turkey", "TR"),
    ("TRISAW", "Istanbul Sabiha Airport", "AIR", "Istanbul", "Turkey", "TR"),
    ("TRMER", "Mersin Port", "SEA", "Mersin", "Turkey", "TR"),
    ("TRIZM", "Izmir Port", "SEA", "Izmir", "Turkey", "TR"),
    ("ISTANBUL", "Istanbul", "LAND", "Istanbul", "Turkey", "TR"),
    
    # ============================================
    # EUROPE - NORTHERN
    # ============================================
    # Netherlands
    ("NLRTM", "Rotterdam Port", "SEA", "Rotterdam", "Netherlands", "NL"),
    ("NLAMS", "Amsterdam Schiphol Airport", "AIR", "Amsterdam", "Netherlands", "NL"),
    ("AMSTERDAM", "Amsterdam", "LAND", "Amsterdam", "Netherlands", "NL"),
    
    # Belgium
    ("BEANR", "Antwerp Port", "SEA", "Antwerp", "Belgium", "BE"),
    ("BEBRU", "Brussels Airport", "AIR", "Brussels", "Belgium", "BE"),
    ("BEZEE", "Zeebrugge Port", "SEA", "Bruges", "Belgium", "BE"),
    
    # Germany
    ("DEHAM", "Hamburg Port", "SEA", "Hamburg", "Germany", "DE"),
    ("DEBRE", "Bremen/Bremerhaven Port", "SEA", "Bremen", "Germany", "DE"),
    ("DEFRA", "Frankfurt Airport", "AIR", "Frankfurt", "Germany", "DE"),
    ("DEMUC", "Munich Airport", "AIR", "Munich", "Germany", "DE"),
    ("FRANKFURT", "Frankfurt", "LAND", "Frankfurt", "Germany", "DE"),
    ("MUNICH", "Munich", "LAND", "Munich", "Germany", "DE"),
    ("BERLIN", "Berlin", "LAND", "Berlin", "Germany", "DE"),
    
    # UK
    ("GBFXT", "Felixstowe Port", "SEA", "Felixstowe", "United Kingdom", "GB"),
    ("GBLGP", "London Gateway Port", "SEA", "London", "United Kingdom", "GB"),
    ("GBSOU", "Southampton Port", "SEA", "Southampton", "United Kingdom", "GB"),
    ("GBLHR", "London Heathrow Airport", "AIR", "London", "United Kingdom", "GB"),
    ("GBLGW", "London Gatwick Airport", "AIR", "London", "United Kingdom", "GB"),
    ("GBMAN", "Manchester Airport", "AIR", "Manchester", "United Kingdom", "GB"),
    ("LONDON", "London", "LAND", "London", "United Kingdom", "GB"),
    
    # France
    ("FRLEH", "Le Havre Port", "SEA", "Le Havre", "France", "FR"),
    ("FRCDG", "Paris CDG Airport", "AIR", "Paris", "France", "FR"),
    ("FRORY", "Paris Orly Airport", "AIR", "Paris", "France", "FR"),
    ("FRMRS", "Marseille Port", "SEA", "Marseille", "France", "FR"),
    ("PARIS", "Paris", "LAND", "Paris", "France", "FR"),
    
    # ============================================
    # EUROPE - SOUTHERN
    # ============================================
    # Spain
    ("ESBCN", "Barcelona Port", "SEA", "Barcelona", "Spain", "ES"),
    ("ESBCNA", "Barcelona Airport", "AIR", "Barcelona", "Spain", "ES"),
    ("ESVLC", "Valencia Port", "SEA", "Valencia", "Spain", "ES"),
    ("ESALG", "Algeciras Port", "SEA", "Algeciras", "Spain", "ES"),
    ("ESMAD", "Madrid Airport", "AIR", "Madrid", "Spain", "ES"),
    ("MADRID", "Madrid", "LAND", "Madrid", "Spain", "ES"),
    ("BARCELONA", "Barcelona", "LAND", "Barcelona", "Spain", "ES"),
    
    # Italy
    ("ITGOA", "Genoa Port", "SEA", "Genoa", "Italy", "IT"),
    ("ITGIT", "Gioia Tauro Port", "SEA", "Gioia Tauro", "Italy", "IT"),
    ("ITMLP", "La Spezia Port", "SEA", "La Spezia", "Italy", "IT"),
    ("ITMXP", "Milan Malpensa Airport", "AIR", "Milan", "Italy", "IT"),
    ("ITFCO", "Rome Fiumicino Airport", "AIR", "Rome", "Italy", "IT"),
    ("MILAN", "Milan", "LAND", "Milan", "Italy", "IT"),
    ("ROME", "Rome", "LAND", "Rome", "Italy", "IT"),
    
    # Greece
    ("GRPIR", "Piraeus Port", "SEA", "Athens", "Greece", "GR"),
    ("GRATH", "Athens Airport", "AIR", "Athens", "Greece", "GR"),
    
    # Portugal
    ("PTLIS", "Lisbon Port", "SEA", "Lisbon", "Portugal", "PT"),
    ("PTLISA", "Lisbon Airport", "AIR", "Lisbon", "Portugal", "PT"),
    ("PTSIE", "Sines Port", "SEA", "Sines", "Portugal", "PT"),
    
    # ============================================
    # EUROPE - NORTHERN/SCANDINAVIA
    # ============================================
    # Sweden
    ("SEGOT", "Gothenburg Port", "SEA", "Gothenburg", "Sweden", "SE"),
    ("SEARN", "Stockholm Arlanda Airport", "AIR", "Stockholm", "Sweden", "SE"),
    ("STOCKHOLM", "Stockholm", "LAND", "Stockholm", "Sweden", "SE"),
    
    # Denmark
    ("DKAAR", "Aarhus Port", "SEA", "Aarhus", "Denmark", "DK"),
    ("DKCPH", "Copenhagen Airport", "AIR", "Copenhagen", "Denmark", "DK"),
    
    # Norway
    ("NOOSL", "Oslo Port", "SEA", "Oslo", "Norway", "NO"),
    ("NOOSLA", "Oslo Airport", "AIR", "Oslo", "Norway", "NO"),
    
    # Finland
    ("FIHEL", "Helsinki Port", "SEA", "Helsinki", "Finland", "FI"),
    ("FIHELA", "Helsinki Airport", "AIR", "Helsinki", "Finland", "FI"),
    
    # Poland
    ("PLGDN", "Gdansk Port", "SEA", "Gdansk", "Poland", "PL"),
    ("PLGDY", "Gdynia Port", "SEA", "Gdynia", "Poland", "PL"),
    ("PLWAW", "Warsaw Airport", "AIR", "Warsaw", "Poland", "PL"),
    ("WARSAW", "Warsaw", "LAND", "Warsaw", "Poland", "PL"),
    
    # Russia
    ("RULED", "St. Petersburg Port", "SEA", "St. Petersburg", "Russia", "RU"),
    ("RUSVO", "Vladivostok Port", "SEA", "Vladivostok", "Russia", "RU"),
    ("RUSLED", "St. Petersburg Airport", "AIR", "St. Petersburg", "Russia", "RU"),
    ("RUMOW", "Moscow Sheremetyevo Airport", "AIR", "Moscow", "Russia", "RU"),
    ("MOSCOW", "Moscow", "LAND", "Moscow", "Russia", "RU"),
    
    # ============================================
    # NORTH AMERICA
    # ============================================
    # USA - West Coast
    ("USLAX", "Los Angeles Port", "SEA", "Los Angeles", "United States", "US"),
    ("USLAXA", "Los Angeles LAX Airport", "AIR", "Los Angeles", "United States", "US"),
    ("USLGB", "Long Beach Port", "SEA", "Long Beach", "United States", "US"),
    ("USOAK", "Oakland Port", "SEA", "Oakland", "United States", "US"),
    ("USSFO", "San Francisco Airport", "AIR", "San Francisco", "United States", "US"),
    ("USSEA", "Seattle Port", "SEA", "Seattle", "United States", "US"),
    ("USSEAA", "Seattle-Tacoma Airport", "AIR", "Seattle", "United States", "US"),
    ("USTAC", "Tacoma Port", "SEA", "Tacoma", "United States", "US"),
    ("USPDX", "Portland Port", "SEA", "Portland", "United States", "US"),
    
    # USA - East Coast
    ("USNYC", "New York/New Jersey Port", "SEA", "New York", "United States", "US"),
    ("USJFK", "New York JFK Airport", "AIR", "New York", "United States", "US"),
    ("USEWR", "Newark Airport", "AIR", "Newark", "United States", "US"),
    ("USSAV", "Savannah Port", "SEA", "Savannah", "United States", "US"),
    ("USCHA", "Charleston Port", "SEA", "Charleston", "United States", "US"),
    ("USNOR", "Norfolk Port", "SEA", "Norfolk", "United States", "US"),
    ("USBOS", "Boston Port", "SEA", "Boston", "United States", "US"),
    ("USBOSA", "Boston Logan Airport", "AIR", "Boston", "United States", "US"),
    ("USBAL", "Baltimore Port", "SEA", "Baltimore", "United States", "US"),
    ("USPHL", "Philadelphia Port", "SEA", "Philadelphia", "United States", "US"),
    
    # USA - Gulf Coast
    ("USHOU", "Houston Port", "SEA", "Houston", "United States", "US"),
    ("USIAH", "Houston IAH Airport", "AIR", "Houston", "United States", "US"),
    ("USNOL", "New Orleans Port", "SEA", "New Orleans", "United States", "US"),
    ("USMIA", "Miami Port", "SEA", "Miami", "United States", "US"),
    ("USMIAA", "Miami International Airport", "AIR", "Miami", "United States", "US"),
    ("USTPA", "Tampa Port", "SEA", "Tampa", "United States", "US"),
    ("USJAX", "Jacksonville Port", "SEA", "Jacksonville", "United States", "US"),
    
    # USA - Inland
    ("USCHI", "Chicago", "LAND", "Chicago", "United States", "US"),
    ("USORD", "Chicago O'Hare Airport", "AIR", "Chicago", "United States", "US"),
    ("USATL", "Atlanta Airport", "AIR", "Atlanta", "United States", "US"),
    ("USDFW", "Dallas/Fort Worth Airport", "AIR", "Dallas", "United States", "US"),
    ("USDAL", "Dallas Love Field", "AIR", "Dallas", "United States", "US"),
    ("USLAS", "Las Vegas Airport", "AIR", "Las Vegas", "United States", "US"),
    ("USDEN", "Denver Airport", "AIR", "Denver", "United States", "US"),
    ("USPHX", "Phoenix Airport", "AIR", "Phoenix", "United States", "US"),
    ("NEWYORK", "New York", "LAND", "New York", "United States", "US"),
    ("LOSANGELES", "Los Angeles", "LAND", "Los Angeles", "United States", "US"),
    ("CHICAGO", "Chicago", "LAND", "Chicago", "United States", "US"),
    ("HOUSTON", "Houston", "LAND", "Houston", "United States", "US"),
    ("DALLAS", "Dallas", "LAND", "Dallas", "United States", "US"),
    
    # Canada
    ("CAVAN", "Vancouver Port", "SEA", "Vancouver", "Canada", "CA"),
    ("CAVANA", "Vancouver Airport", "AIR", "Vancouver", "Canada", "CA"),
    ("CATOR", "Toronto Port", "SEA", "Toronto", "Canada", "CA"),
    ("CAYYZ", "Toronto Pearson Airport", "AIR", "Toronto", "Canada", "CA"),
    ("CAMTR", "Montreal Port", "SEA", "Montreal", "Canada", "CA"),
    ("CAYUL", "Montreal Airport", "AIR", "Montreal", "Canada", "CA"),
    ("CAPRR", "Prince Rupert Port", "SEA", "Prince Rupert", "Canada", "CA"),
    ("CAHAL", "Halifax Port", "SEA", "Halifax", "Canada", "CA"),
    ("TORONTO", "Toronto", "LAND", "Toronto", "Canada", "CA"),
    ("VANCOUVER", "Vancouver", "LAND", "Vancouver", "Canada", "CA"),
    ("MONTREAL", "Montreal", "LAND", "Montreal", "Canada", "CA"),
    
    # ============================================
    # MEXICO & CENTRAL AMERICA
    # ============================================
    # Mexico
    ("MXMZL", "Manzanillo Port", "SEA", "Manzanillo", "Mexico", "MX"),
    ("MXLCB", "Lazaro Cardenas Port", "SEA", "Lazaro Cardenas", "Mexico", "MX"),
    ("MXVER", "Veracruz Port", "SEA", "Veracruz", "Mexico", "MX"),
    ("MXATM", "Altamira Port", "SEA", "Altamira", "Mexico", "MX"),
    ("MXMEX", "Mexico City Airport", "AIR", "Mexico City", "Mexico", "MX"),
    ("MXGDL", "Guadalajara Airport", "AIR", "Guadalajara", "Mexico", "MX"),
    ("MXMTY", "Monterrey Airport", "AIR", "Monterrey", "Mexico", "MX"),
    ("MXTIJ", "Tijuana Airport", "AIR", "Tijuana", "Mexico", "MX"),
    ("MXCUN", "Cancun Airport", "AIR", "Cancun", "Mexico", "MX"),
    ("MEXICOCITY", "Mexico City", "LAND", "Mexico City", "Mexico", "MX"),
    ("GUADALAJARA", "Guadalajara", "LAND", "Guadalajara", "Mexico", "MX"),
    ("MONTERREY", "Monterrey", "LAND", "Monterrey", "Mexico", "MX"),
    ("QUERETARO", "Queretaro", "LAND", "Queretaro", "Mexico", "MX"),
    ("PUEBLA", "Puebla", "LAND", "Puebla", "Mexico", "MX"),
    ("TIJUANA", "Tijuana", "LAND", "Tijuana", "Mexico", "MX"),
    ("TOLUCA", "Toluca", "LAND", "Toluca", "Mexico", "MX"),
    ("AGUASCALIENTES", "Aguascalientes", "LAND", "Aguascalientes", "Mexico", "MX"),
    ("SANLUISPOTOSI", "San Luis Potosi", "LAND", "San Luis Potosi", "Mexico", "MX"),
    ("LEON", "Leon", "LAND", "Leon", "Mexico", "MX"),
    ("MERIDA", "Merida", "LAND", "Merida", "Mexico", "MX"),
    
    # Panama
    ("PAPTC", "Panama Colon Port", "SEA", "Colon", "Panama", "PA"),
    ("PAPBL", "Balboa Port", "SEA", "Panama City", "Panama", "PA"),
    ("PAPTY", "Panama Tocumen Airport", "AIR", "Panama City", "Panama", "PA"),
    
    # Guatemala
    ("GTPRQ", "Puerto Quetzal", "SEA", "San Jose", "Guatemala", "GT"),
    ("GTSTO", "Santo Tomas de Castilla", "SEA", "Puerto Barrios", "Guatemala", "GT"),
    ("GTGUA", "Guatemala City Airport", "AIR", "Guatemala City", "Guatemala", "GT"),
    
    # Costa Rica
    ("CRSJO", "San Jose Airport", "AIR", "San Jose", "Costa Rica", "CR"),
    ("CRLIO", "Puerto Limon", "SEA", "Limon", "Costa Rica", "CR"),
    
    # Honduras
    ("HNPCR", "Puerto Cortes", "SEA", "Puerto Cortes", "Honduras", "HN"),
    ("HNSAP", "San Pedro Sula Airport", "AIR", "San Pedro Sula", "Honduras", "HN"),
    
    # El Salvador
    ("SVSAL", "San Salvador Airport", "AIR", "San Salvador", "El Salvador", "SV"),
    ("SVAQJ", "Acajutla Port", "SEA", "Acajutla", "El Salvador", "SV"),
    
    # ============================================
    # SOUTH AMERICA
    # ============================================
    # Brazil
    ("BRSSZ", "Santos Port", "SEA", "Santos", "Brazil", "BR"),
    ("BRGRU", "Sao Paulo Guarulhos Airport", "AIR", "Sao Paulo", "Brazil", "BR"),
    ("BRRIO", "Rio de Janeiro Port", "SEA", "Rio de Janeiro", "Brazil", "BR"),
    ("BRGIG", "Rio de Janeiro Airport", "AIR", "Rio de Janeiro", "Brazil", "BR"),
    ("BRITA", "Itajai Port", "SEA", "Itajai", "Brazil", "BR"),
    ("BRPNG", "Paranagua Port", "SEA", "Paranagua", "Brazil", "BR"),
    ("BRSUA", "Suape Port", "SEA", "Recife", "Brazil", "BR"),
    ("BRSSA", "Salvador Port", "SEA", "Salvador", "Brazil", "BR"),
    ("SAOPAULO", "Sao Paulo", "LAND", "Sao Paulo", "Brazil", "BR"),
    ("RIODEJANEIRO", "Rio de Janeiro", "LAND", "Rio de Janeiro", "Brazil", "BR"),
    
    # Argentina
    ("ARBUE", "Buenos Aires Port", "SEA", "Buenos Aires", "Argentina", "AR"),
    ("AREZE", "Buenos Aires Ezeiza Airport", "AIR", "Buenos Aires", "Argentina", "AR"),
    ("BUENOSAIRES", "Buenos Aires", "LAND", "Buenos Aires", "Argentina", "AR"),
    
    # Chile
    ("CLSAI", "San Antonio Port", "SEA", "San Antonio", "Chile", "CL"),
    ("CLVAP", "Valparaiso Port", "SEA", "Valparaiso", "Chile", "CL"),
    ("CLSCL", "Santiago Airport", "AIR", "Santiago", "Chile", "CL"),
    ("SANTIAGO", "Santiago", "LAND", "Santiago", "Chile", "CL"),
    
    # Colombia
    ("COCTG", "Cartagena Port", "SEA", "Cartagena", "Colombia", "CO"),
    ("COBUN", "Buenaventura Port", "SEA", "Buenaventura", "Colombia", "CO"),
    ("COBOG", "Bogota Airport", "AIR", "Bogota", "Colombia", "CO"),
    ("BOGOTA", "Bogota", "LAND", "Bogota", "Colombia", "CO"),
    
    # Peru
    ("PECLL", "Callao Port", "SEA", "Callao", "Peru", "PE"),
    ("PELIM", "Lima Airport", "AIR", "Lima", "Peru", "PE"),
    ("LIMA", "Lima", "LAND", "Lima", "Peru", "PE"),
    
    # Ecuador
    ("ECGYE", "Guayaquil Port", "SEA", "Guayaquil", "Ecuador", "EC"),
    ("ECUIO", "Quito Airport", "AIR", "Quito", "Ecuador", "EC"),
    
    # Venezuela
    ("VELGU", "La Guaira Port", "SEA", "Caracas", "Venezuela", "VE"),
    ("VECCS", "Caracas Airport", "AIR", "Caracas", "Venezuela", "VE"),
    
    # Uruguay
    ("UYMVD", "Montevideo Port", "SEA", "Montevideo", "Uruguay", "UY"),
    
    # ============================================
    # AFRICA
    # ============================================
    # South Africa
    ("ZADUR", "Durban Port", "SEA", "Durban", "South Africa", "ZA"),
    ("ZACPT", "Cape Town Port", "SEA", "Cape Town", "South Africa", "ZA"),
    ("ZAJNB", "Johannesburg Airport", "AIR", "Johannesburg", "South Africa", "ZA"),
    ("JOHANNESBURG", "Johannesburg", "LAND", "Johannesburg", "South Africa", "ZA"),
    
    # Egypt
    ("EGPSD", "Port Said", "SEA", "Port Said", "Egypt", "EG"),
    ("EGALY", "Alexandria Port", "SEA", "Alexandria", "Egypt", "EG"),
    ("EGCAI", "Cairo Airport", "AIR", "Cairo", "Egypt", "EG"),
    ("CAIRO", "Cairo", "LAND", "Cairo", "Egypt", "EG"),
    
    # Morocco
    ("MATAN", "Tangier Med Port", "SEA", "Tangier", "Morocco", "MA"),
    ("MACAS", "Casablanca Port", "SEA", "Casablanca", "Morocco", "MA"),
    
    # Nigeria
    ("NGLOS", "Lagos Port (Apapa)", "SEA", "Lagos", "Nigeria", "NG"),
    ("NGTIN", "Tin Can Island Port", "SEA", "Lagos", "Nigeria", "NG"),
    ("NGLAG", "Lagos Airport", "AIR", "Lagos", "Nigeria", "NG"),
    
    # Kenya
    ("KEMBA", "Mombasa Port", "SEA", "Mombasa", "Kenya", "KE"),
    ("KENBO", "Nairobi Airport", "AIR", "Nairobi", "Kenya", "KE"),
    ("NAIROBI", "Nairobi", "LAND", "Nairobi", "Kenya", "KE"),
    
    # Tanzania
    ("TZDAR", "Dar es Salaam Port", "SEA", "Dar es Salaam", "Tanzania", "TZ"),
    
    # Ghana
    ("GHTEM", "Tema Port", "SEA", "Tema", "Ghana", "GH"),
    
    # Ivory Coast
    ("CIABJ", "Abidjan Port", "SEA", "Abidjan", "Ivory Coast", "CI"),
    
    # Senegal
    ("SNDKR", "Dakar Port", "SEA", "Dakar", "Senegal", "SN"),
    
    # ============================================
    # OCEANIA
    # ============================================
    # Australia
    ("AUSYD", "Sydney Port", "SEA", "Sydney", "Australia", "AU"),
    ("AUSYDA", "Sydney Airport", "AIR", "Sydney", "Australia", "AU"),
    ("AUMEL", "Melbourne Port", "SEA", "Melbourne", "Australia", "AU"),
    ("AUMELA", "Melbourne Airport", "AIR", "Melbourne", "Australia", "AU"),
    ("AUBNE", "Brisbane Port", "SEA", "Brisbane", "Australia", "AU"),
    ("AUBNEA", "Brisbane Airport", "AIR", "Brisbane", "Australia", "AU"),
    ("AUFRE", "Fremantle Port", "SEA", "Perth", "Australia", "AU"),
    ("AUPER", "Perth Airport", "AIR", "Perth", "Australia", "AU"),
    ("AUADL", "Adelaide Port", "SEA", "Adelaide", "Australia", "AU"),
    ("SYDNEY", "Sydney", "LAND", "Sydney", "Australia", "AU"),
    ("MELBOURNE", "Melbourne", "LAND", "Melbourne", "Australia", "AU"),
    
    # New Zealand
    ("NZAKL", "Auckland Port", "SEA", "Auckland", "New Zealand", "NZ"),
    ("NZAKLA", "Auckland Airport", "AIR", "Auckland", "New Zealand", "NZ"),
    ("NZTRG", "Tauranga Port", "SEA", "Tauranga", "New Zealand", "NZ"),
    ("NZWLG", "Wellington Port", "SEA", "Wellington", "New Zealand", "NZ"),
    ("AUCKLAND", "Auckland", "LAND", "Auckland", "New Zealand", "NZ"),
]


def seed_ports():
    """Insert all worldwide ports into database"""
    conn = get_connection()
    cur = conn.cursor()
    
    inserted = 0
    updated = 0
    skipped = 0
    
    try:
        for port in WORLDWIDE_PORTS:
            code, name, port_type, city, country, country_code = port
            
            # Check if exists
            cur.execute("SELECT id FROM ports WHERE code = ?", (code,))
            existing = cur.fetchone()
            
            if existing:
                # Update existing
                cur.execute("""
                    UPDATE ports SET name=?, type=?, city=?, country=?, country_code=?, is_active=1
                    WHERE code=?
                """, (name, port_type, city, country, country_code, code))
                updated += 1
            else:
                # Insert new
                cur.execute("""
                    INSERT INTO ports (code, name, type, city, country, country_code, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 1, ?)
                """, (code, name, port_type, city, country, country_code, now_str()))
                inserted += 1
        
        conn.commit()
        print(f"✅ Port seeding complete:")
        print(f"   Inserted: {inserted}")
        print(f"   Updated: {updated}")
        print(f"   Total: {len(WORLDWIDE_PORTS)}")
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Error seeding ports: {e}")
    finally:
        conn.close()
    
    return inserted, updated


def get_port_stats():
    """Get statistics about ports in database"""
    conn = get_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT COUNT(*) FROM ports")
    total = cur.fetchone()[0]
    
    cur.execute("SELECT type, COUNT(*) FROM ports GROUP BY type")
    by_type = {row[0]: row[1] for row in cur.fetchall()}
    
    cur.execute("SELECT country, COUNT(*) FROM ports GROUP BY country ORDER BY COUNT(*) DESC LIMIT 10")
    top_countries = cur.fetchall()
    
    conn.close()
    
    print(f"\n📊 Port Database Statistics:")
    print(f"   Total: {total}")
    print(f"   By Type: {by_type}")
    print(f"   Top Countries: {[(c[0], c[1]) for c in top_countries]}")
    
    return total, by_type, top_countries


if __name__ == "__main__":
    print("🌍 Seeding worldwide ports database...")
    seed_ports()
    get_port_stats()
