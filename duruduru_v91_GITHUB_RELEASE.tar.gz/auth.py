# auth.py
# Authentication and Authorization System with Auto-login

import customtkinter as ctk
from tkinter import messagebox
import tkinter as tk
import hashlib
import json
import os
import random
import string
from db import get_connection, now_str

# Config directory for storing login preferences
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".duruduru")
LOGIN_PREFS_FILE = os.path.join(CONFIG_DIR, "login_prefs.json")

# Colors
COLORS = {
    "bg_primary": "#F5F5F7", "bg_secondary": "#FFFFFF",
    "accent": "#007AFF", "accent_hover": "#0066CC",
    "text_primary": "#1D1D1F", "text_secondary": "#86868B",
    "error": "#FF3B30", "success": "#34C759",
    "border": "#D1D1D6", "warning": "#FF9500"
}


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def generate_random_password(length=10):
    chars = string.ascii_letters + string.digits + "!@#$%"
    return ''.join(random.choice(chars) for _ in range(length))


def ensure_users_table():
    """Create/update users table with all required columns"""
    print("[AUTH] ensure_users_table called")
    
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                full_name TEXT DEFAULT '',
                email TEXT DEFAULT '',
                role TEXT DEFAULT 'USER',
                permissions TEXT DEFAULT '[]',
                is_active INTEGER DEFAULT 1,
                last_login TEXT,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        print("[AUTH] Users table created/verified")
        
        # Check and add missing columns
        cur.execute("PRAGMA table_info(users)")
        existing_cols = [r[1] for r in cur.fetchall()]
        print(f"[AUTH] Existing columns: {existing_cols}")
        
        columns_to_add = {
            'full_name': "TEXT DEFAULT ''",
            'email': "TEXT DEFAULT ''",
            'role': "TEXT DEFAULT 'USER'",
            'permissions': "TEXT DEFAULT '[]'",
            'is_active': "INTEGER DEFAULT 1",
            'last_login': "TEXT",
            'created_at': "TEXT",
            'updated_at': "TEXT"
        }
        
        for col, col_def in columns_to_add.items():
            if col not in existing_cols:
                try:
                    cur.execute(f"ALTER TABLE users ADD COLUMN {col} {col_def}")
                    print(f"[AUTH] Added column: {col}")
                except:
                    pass
        
        # Create default admin if not exists
        cur.execute("SELECT COUNT(*) FROM users WHERE username = 'admin'")
        count = cur.fetchone()[0]
        print(f"[AUTH] Admin users count: {count}")
        
        if count == 0:
            admin_hash = hash_password('admin123')
            cur.execute("""
                INSERT INTO users (username, password_hash, full_name, email, role, permissions, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, ('admin', admin_hash, 'Administrator', 'admin@duruduru.com', 
                  'ADMIN', '["*"]', 1, now_str()))
            print(f"[AUTH] Created admin user with hash: {admin_hash[:20]}...")
        
        conn.commit()
        print("[AUTH] ensure_users_table completed")
    except Exception as e:
        print(f"[AUTH] Error in ensure_users_table: {e}")
        import traceback
        traceback.print_exc()
    finally:
        conn.close()


def create_users_table():
    ensure_users_table()


def save_login_prefs(username=None, password_hash=None, auto_login=False, remember=False, language="English"):
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR, exist_ok=True)
    
    prefs = {
        "username": username if remember else "",
        "password_hash": password_hash if auto_login else "",
        "auto_login": auto_login,
        "remember": remember,
        "language": language
    }
    
    try:
        with open(LOGIN_PREFS_FILE, 'w') as f:
            json.dump(prefs, f)
    except:
        pass


def load_login_prefs():
    """Load login preferences, handle corrupted files"""
    default_prefs = {"username": "", "password_hash": "", "auto_login": False, "remember": False, "language": "English"}
    
    try:
        if os.path.exists(LOGIN_PREFS_FILE):
            with open(LOGIN_PREFS_FILE, 'r') as f:
                content = f.read().strip()
                if content:
                    prefs = json.loads(content)
                    # Validate structure
                    if isinstance(prefs, dict):
                        return {
                            "username": prefs.get("username", ""),
                            "password_hash": prefs.get("password_hash", ""),
                            "auto_login": prefs.get("auto_login", False),
                            "remember": prefs.get("remember", False),
                            "language": prefs.get("language", "English")
                        }
    except Exception as e:
        print(f"[AUTH] Warning: Could not load login prefs: {e}")
        # Delete corrupted file
        try:
            os.remove(LOGIN_PREFS_FILE)
            print("[AUTH] Removed corrupted preferences file")
        except:
            pass
    
    return default_prefs


def authenticate(username, password):
    print(f"[AUTH] authenticate called for username: {username}")
    
    ensure_users_table()
    
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which columns exist
        cur.execute("PRAGMA table_info(users)")
        cols = [r[1] for r in cur.fetchall()]
        print(f"[AUTH] Users table columns: {cols}")
        
        # Build query with available columns
        if 'permissions' in cols:
            cur.execute("""
                SELECT id, username, password_hash, 
                       COALESCE(full_name, ''), COALESCE(role, 'USER'), 
                       COALESCE(permissions, '[]'), COALESCE(is_active, 1), 
                       COALESCE(email, '')
                FROM users WHERE username = ?
            """, (username,))
        else:
            cur.execute("""
                SELECT id, username, password_hash, 
                       COALESCE(full_name, ''), COALESCE(role, 'USER'), 
                       '[]', COALESCE(is_active, 1), 
                       COALESCE(email, '')
                FROM users WHERE username = ?
            """, (username,))
        
        row = cur.fetchone()
        print(f"[AUTH] Query result: {row}")
        
        if row:
            stored_hash = row[2]
            input_hash = hash_password(password)
            is_active = row[6]
            
            print(f"[AUTH] Stored hash: {stored_hash[:20]}...")
            print(f"[AUTH] Input hash:  {input_hash[:20]}...")
            print(f"[AUTH] Hash match: {stored_hash == input_hash}")
            print(f"[AUTH] is_active: {is_active}")
            
            if stored_hash == input_hash and is_active == 1:
                cur.execute("UPDATE users SET last_login = ? WHERE id = ?", (now_str(), row[0]))
                conn.commit()
                
                perms = []
                if row[5]:
                    try:
                        perms = json.loads(row[5])
                    except:
                        perms = ["*"] if row[4] == 'ADMIN' else []
                
                # Default admin permissions
                if row[4] == 'ADMIN' and not perms:
                    perms = ["*"]
                
                result = {
                    "id": row[0], "username": row[1], "full_name": row[3] or "",
                    "role": row[4], "permissions": perms, "email": row[7] or ""
                }
                print(f"[AUTH] SUCCESS: {result}")
                return result
            else:
                print("[AUTH] FAILED: Hash mismatch or inactive account")
        else:
            print(f"[AUTH] FAILED: User '{username}' not found")
            
    except Exception as e:
        print(f"[AUTH] ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        conn.close()
    return None


def authenticate_by_hash(username, password_hash):
    ensure_users_table()
    
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Check which columns exist
        cur.execute("PRAGMA table_info(users)")
        cols = [r[1] for r in cur.fetchall()]
        
        # Build query with available columns
        if 'permissions' in cols:
            cur.execute("""
                SELECT id, username, password_hash, 
                       COALESCE(full_name, ''), COALESCE(role, 'USER'), 
                       COALESCE(permissions, '[]'), COALESCE(is_active, 1), 
                       COALESCE(email, '')
                FROM users WHERE username = ?
            """, (username,))
        else:
            cur.execute("""
                SELECT id, username, password_hash, 
                       COALESCE(full_name, ''), COALESCE(role, 'USER'), 
                       '[]', COALESCE(is_active, 1), 
                       COALESCE(email, '')
                FROM users WHERE username = ?
            """, (username,))
        
        row = cur.fetchone()
        
        if row and row[2] == password_hash and row[6] == 1:
            cur.execute("UPDATE users SET last_login = ? WHERE id = ?", (now_str(), row[0]))
            conn.commit()
            
            perms = []
            if row[5]:
                try:
                    perms = json.loads(row[5])
                except:
                    perms = ["*"] if row[4] == 'ADMIN' else []
            
            # Default admin permissions
            if row[4] == 'ADMIN' and not perms:
                perms = ["*"]
            
            return {
                "id": row[0], "username": row[1], "full_name": row[3] or "",
                "role": row[4], "permissions": perms, "email": row[7] or ""
            }
    except Exception as e:
        print(f"Auth by hash error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        conn.close()
    return None


def reset_password(user_id, new_password=None):
    if new_password is None:
        new_password = generate_random_password()
    
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?",
                   (hash_password(new_password), now_str(), user_id))
        conn.commit()
        return new_password
    except Exception as e:
        print(f"Reset password error: {e}")
        return None
    finally:
        conn.close()


def has_permission(user, permission):
    if not user:
        return False
    perms = user.get("permissions", [])
    return "*" in perms or permission in perms


ALL_MENUS = {
    "ORDER": ["Quote", "Ocean Registration", "Air Registration", "Land Registration"],
    "STATUS": ["Operation", "Performance"],
    "SETTLEMENT": ["Settlement Mgmt"],
    "ACCOUNTING": ["Accounting"],
    "SETTINGS": ["Settings", "Admin"]
}

DEFAULT_PERMISSIONS = {
    "ADMIN": ["*"],
    "MANAGER": ["ORDER.*", "STATUS.*", "SETTLEMENT.*", "ACCOUNTING.*", "SETTINGS.Settings"],
    "OPERATOR": ["ORDER.*", "STATUS.Operation", "SETTLEMENT.Settlement Mgmt"],
    "VIEWER": ["STATUS.Operation", "STATUS.Performance"]
}


class LoginDialog(ctk.CTkToplevel):
    """Modern, sleek Login dialog"""
    
    def __init__(self, master, on_success=None):
        super().__init__(master)
        
        self.on_success = on_success
        self.user = None
        
        # Load preferences safely
        try:
            self.prefs = load_login_prefs()
        except:
            self.prefs = {"username": "", "password_hash": "", "auto_login": False, "remember": False}
        
        self.title("DURUDURU")
        self.geometry("360x420")
        self.resizable(False, False)
        
        # Center on screen
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 360) // 2
        y = (self.winfo_screenheight() - 420) // 2 - 50
        self.geometry(f"360x420+{x}+{y}")
        
        self.configure(fg_color="#FFFFFF")
        self.transient(master)
        
        # Make dialog modal
        self.grab_set()
        self.focus_force()
        self.lift()
        
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        
        try:
            self._create_widgets()
        except Exception as e:
            print(f"Error creating login widgets: {e}")
            import traceback
            traceback.print_exc()
            self._create_minimal_widgets()
        
        if self.prefs.get("auto_login") and self.prefs.get("username") and self.prefs.get("password_hash"):
            self.after(500, self._try_auto_login)
        else:
            try:
                self.after(100, lambda: self.username_entry.focus())
            except:
                pass
    
    def _create_minimal_widgets(self):
        """Minimal fallback UI if main widgets fail"""
        ctk.CTkLabel(self, text="DURUDURU Login", font=("Arial", 18)).pack(pady=20)
        
        ctk.CTkLabel(self, text="Username:").pack()
        self.username_entry = ctk.CTkEntry(self, width=200)
        self.username_entry.pack(pady=5)
        self.username_var = tk.StringVar()
        self.username_entry.configure(textvariable=self.username_var)
        
        ctk.CTkLabel(self, text="Password:").pack()
        self.password_entry = ctk.CTkEntry(self, width=200, show="*")
        self.password_entry.pack(pady=5)
        self.password_var = tk.StringVar()
        self.password_entry.configure(textvariable=self.password_var)
        
        self.error_label = ctk.CTkLabel(self, text="", text_color="red")
        self.error_label.pack(pady=5)
        
        ctk.CTkButton(self, text="Login", command=self._login).pack(pady=10)
        
        self.auto_login_var = tk.BooleanVar(value=False)
        self.remember_var = tk.BooleanVar(value=False)
        
    def _create_widgets(self):
        # Main card - white with subtle shadow effect
        card = ctk.CTkFrame(self, fg_color="#FFFFFF", corner_radius=10)
        card.pack(fill="both", expand=True, padx=1, pady=1)
        
        # App icon (circular, centered) - DARK GRAY
        icon_frame = ctk.CTkFrame(card, fg_color="transparent", height=90)
        icon_frame.pack(fill="x")
        icon_frame.pack_propagate(False)
        
        # Icon circle - Dark Gray (#3A3A3C)
        icon_outer = ctk.CTkFrame(icon_frame, fg_color="#3A3A3C", width=64, height=64, corner_radius=32)
        icon_outer.place(relx=0.5, rely=0.6, anchor="center")
        
        # Icon letter
        ctk.CTkLabel(icon_outer, text="D", font=("SF Pro Display", 28, "bold"),
                    text_color="#FFFFFF").place(relx=0.5, rely=0.5, anchor="center")
        
        # App name
        ctk.CTkLabel(card, text="DURUDURU", font=("SF Pro Display", 15, "bold"),
                    text_color="#1D1D1F").pack(pady=(0, 2))
        
        # Form container
        form = ctk.CTkFrame(card, fg_color="transparent")
        form.pack(fill="x", padx=24, pady=(12, 0))
        
        # English-only input validation
        def validate_english(char):
            # Allow ASCII characters only (letters, numbers, common symbols)
            return all(ord(c) < 128 for c in char)
        
        def on_key_username(event):
            if event.char and not validate_english(event.char):
                return "break"
        
        def on_key_password(event):
            if event.char and not validate_english(event.char):
                return "break"
        
        # Username (English only)
        self.username_var = tk.StringVar(value=self.prefs.get("username", ""))
        self.username_entry = ctk.CTkEntry(
            form, textvariable=self.username_var,
            placeholder_text="Username (English only)", height=32, corner_radius=5,
            border_width=1, border_color="#C7C7CC", fg_color="#FFFFFF",
            font=("SF Pro Text", 13)
        )
        self.username_entry.pack(fill="x", pady=(0, 8))
        self.username_entry.bind("<Return>", lambda e: self.password_entry.focus())
        self.username_entry.bind("<Key>", on_key_username)
        
        # Password (English only)
        self.password_var = tk.StringVar()
        self.password_entry = ctk.CTkEntry(
            form, textvariable=self.password_var,
            placeholder_text="Password (English only)", show="•", height=32, corner_radius=5,
            border_width=1, border_color="#C7C7CC", fg_color="#FFFFFF",
            font=("SF Pro Text", 13)
        )
        self.password_entry.pack(fill="x", pady=(0, 10))
        self.password_entry.bind("<Return>", lambda e: self._login())
        self.password_entry.bind("<Key>", on_key_password)
        
        # Options row
        opt_frame = ctk.CTkFrame(form, fg_color="transparent", height=20)
        opt_frame.pack(fill="x", pady=(0, 10))
        
        self.remember_var = tk.BooleanVar(value=self.prefs.get("remember", False))
        ctk.CTkCheckBox(opt_frame, text="Remember", variable=self.remember_var,
                       font=("SF Pro Text", 11), text_color="#8E8E93",
                       fg_color="#3A3A3C", hover_color="#3A3A3C",
                       checkbox_width=16, checkbox_height=16, corner_radius=4,
                       border_width=1).pack(side="left")
        
        self.auto_login_var = tk.BooleanVar(value=self.prefs.get("auto_login", False))
        ctk.CTkCheckBox(opt_frame, text="Auto", variable=self.auto_login_var,
                       font=("SF Pro Text", 11), text_color="#8E8E93",
                       fg_color="#3A3A3C", hover_color="#3A3A3C",
                       checkbox_width=16, checkbox_height=16, corner_radius=4,
                       border_width=1, command=self._on_auto_toggle).pack(side="right")
        
        # Sign In button - DARK GRAY (#3A3A3C)
        self.login_btn = ctk.CTkButton(
            form, text="Sign In", command=self._login,
            height=32, corner_radius=5, fg_color="#3A3A3C",
            hover_color="#2C2C2E", font=("SF Pro Text", 13, "bold")
        )
        self.login_btn.pack(fill="x", pady=(0, 6))
        
        # Error label
        self.error_label = ctk.CTkLabel(form, text="", font=("SF Pro Text", 11),
                                        text_color="#FF3B30", height=18)
        self.error_label.pack()
        
        # Auto login notice (hidden by default)
        self.auto_notice = ctk.CTkLabel(form, text="",
                                       font=("SF Pro Text", 10), text_color="#FF9500")
        
        # Language selection frame
        lang_frame = ctk.CTkFrame(card, fg_color="transparent", height=40)
        lang_frame.pack(side="bottom", fill="x", pady=(0, 5))
        
        ctk.CTkLabel(lang_frame, text="🌐", font=("SF Pro Text", 14)).pack(side="left", padx=(80, 5))
        
        self.language_var = tk.StringVar(value=self.prefs.get("language", "English"))
        self.language_combo = ctk.CTkComboBox(
            lang_frame,
            variable=self.language_var,
            values=["English", "한국어"],
            width=100, height=26,
            font=("SF Pro Text", 11),
            dropdown_font=("SF Pro Text", 11),
            corner_radius=5,
            fg_color="#F2F2F7",
            border_color="#C7C7CC",
            button_color="#C7C7CC",
            button_hover_color="#AEAEB2",
            dropdown_fg_color="#FFFFFF",
            dropdown_hover_color="#E5E5EA",
            state="readonly"
        )
        self.language_combo.pack(side="left", padx=5)
        
        # Footer
        footer = ctk.CTkFrame(card, fg_color="transparent", height=30)
        footer.pack(side="bottom", fill="x")
        ctk.CTkLabel(footer, text="© 2026", font=("SF Pro Text", 10),
                    text_color="#AEAEB2").pack(pady=8)
    
    def _on_auto_toggle(self):
        if self.auto_login_var.get():
            self.auto_notice.configure(text="⚠️ Auto login enabled for this device")
            self.auto_notice.pack()
            self.remember_var.set(True)
        else:
            self.auto_notice.configure(text="")
            self.auto_notice.pack_forget()
    
    def _try_auto_login(self):
        username = self.prefs.get("username", "")
        password_hash = self.prefs.get("password_hash", "")
        saved_language = self.prefs.get("language", "English")
        
        if username and password_hash:
            self.error_label.configure(text="Auto-logging in...", text_color="#007AFF")
            self.update()
            
            user = authenticate_by_hash(username, password_hash)
            if user:
                # Add saved language to user dict
                user['language'] = saved_language
                
                self.user = user
                if self.on_success:
                    self.on_success(user)
                self.destroy()
            else:
                self.error_label.configure(text="Auto-login failed", text_color="#FF3B30")
                save_login_prefs()
        
    def _login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get()
        
        print(f"Login attempt: username='{username}'")
        
        if not username or not password:
            self.error_label.configure(text="Enter username and password")
            return
        
        print("Calling authenticate...")
        user = authenticate(username, password)
        print(f"Authenticate result: {user}")
        
        if user:
            print("Login successful, saving prefs...")
            # Get selected language
            language = getattr(self, 'language_var', tk.StringVar(value="English")).get()
            
            save_login_prefs(
                username=username, 
                password_hash=hash_password(password),
                auto_login=self.auto_login_var.get(), 
                remember=self.remember_var.get(),
                language=language
            )
            
            # Add language to user dict
            user['language'] = language
            
            self.user = user
            print("Calling on_success callback...")
            if self.on_success:
                self.on_success(user)
            print("Destroying login dialog...")
            self.destroy()
            print("Login dialog destroyed")
        else:
            print("Login failed - invalid credentials")
            self.error_label.configure(text="Invalid username or password")
            self.password_var.set("")
            self.password_entry.focus()
            
    def _on_close(self):
        """Handle dialog close - confirm before exiting app"""
        if not self.user:
            from tkinter import messagebox
            if messagebox.askyesno("Exit", "로그인 없이 종료하시겠습니까?\nExit without login?"):
                try:
                    self.master.quit()
                    self.master.destroy()
                except:
                    pass
            # If user clicks No, dialog stays open
        else:
            self.destroy()


class AdminFrame(ctk.CTkFrame):
    """Admin panel for user management and company settings"""
    
    def __init__(self, master, current_user=None, **kwargs):
        super().__init__(master, fg_color="#F5F5F7", **kwargs)
        self.current_user = current_user
        
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=20, pady=(15, 5))
        ctk.CTkLabel(header, text="⚙️ Admin Panel", font=("SF Pro Display", 18, "bold"),
                    text_color="#1D1D1F").pack(side="left")
        
        self.tabview = ctk.CTkTabview(self, fg_color="#FFFFFF", corner_radius=10)
        self.tabview.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.tabview.add("Company Info")
        self.tabview.add("Users")
        self.tabview.add("Permissions")
        
        self._setup_company_info_tab()
        self._setup_users_tab()
        self._setup_permissions_tab()
    
    def _setup_company_info_tab(self):
        """Setup company information settings"""
        tab = self.tabview.tab("Company Info")
        
        # Header
        header_frame = ctk.CTkFrame(tab, fg_color="#1565C0", corner_radius=10)
        header_frame.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(header_frame, text="🏢 Company Information", font=("SF Pro Display", 16, "bold"),
                    text_color="white").pack(pady=12)
        
        # Scrollable content
        scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Company Basic Info
        basic_frame = ctk.CTkFrame(scroll, fg_color="#F9FAFB", corner_radius=10)
        basic_frame.pack(fill="x", pady=5)
        
        ctk.CTkLabel(basic_frame, text="Basic Information", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        form1 = ctk.CTkFrame(basic_frame, fg_color="transparent")
        form1.pack(fill="x", padx=15, pady=10)
        
        # Row 1: Company Name
        row1 = ctk.CTkFrame(form1, fg_color="transparent")
        row1.pack(fill="x", pady=5)
        ctk.CTkLabel(row1, text="Company Name:", width=120, anchor="e").pack(side="left", padx=5)
        self.company_name_var = tk.StringVar()
        ctk.CTkEntry(row1, textvariable=self.company_name_var, width=400, height=35).pack(side="left", padx=5)
        
        # Row 2: Tax ID (RFC) and Régimen Fiscal
        row2 = ctk.CTkFrame(form1, fg_color="transparent")
        row2.pack(fill="x", pady=5)
        ctk.CTkLabel(row2, text="Tax ID (RFC):", width=120, anchor="e").pack(side="left", padx=5)
        self.company_tax_id_var = tk.StringVar()
        ctk.CTkEntry(row2, textvariable=self.company_tax_id_var, width=180, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row2, text="Régimen Fiscal:", width=110, anchor="e").pack(side="left", padx=5)
        self.company_regime_var = tk.StringVar()
        ctk.CTkEntry(row2, textvariable=self.company_regime_var, width=200, height=35).pack(side="left", padx=5)
        
        # Row 2b: Legal Name
        row2b = ctk.CTkFrame(form1, fg_color="transparent")
        row2b.pack(fill="x", pady=5)
        ctk.CTkLabel(row2b, text="Legal Name:", width=120, anchor="e").pack(side="left", padx=5)
        self.company_legal_name_var = tk.StringVar()
        ctk.CTkEntry(row2b, textvariable=self.company_legal_name_var, width=400, height=35).pack(side="left", padx=5)
        
        # Row 3: Address
        row3 = ctk.CTkFrame(form1, fg_color="transparent")
        row3.pack(fill="x", pady=5)
        ctk.CTkLabel(row3, text="Address:", width=120, anchor="e").pack(side="left", padx=5)
        self.company_address_var = tk.StringVar()
        ctk.CTkEntry(row3, textvariable=self.company_address_var, width=500, height=35).pack(side="left", padx=5)
        
        # Row 4: City, State, ZIP
        row4 = ctk.CTkFrame(form1, fg_color="transparent")
        row4.pack(fill="x", pady=5)
        ctk.CTkLabel(row4, text="City:", width=120, anchor="e").pack(side="left", padx=5)
        self.company_city_var = tk.StringVar()
        ctk.CTkEntry(row4, textvariable=self.company_city_var, width=150, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row4, text="State:", width=60, anchor="e").pack(side="left", padx=5)
        self.company_state_var = tk.StringVar()
        ctk.CTkEntry(row4, textvariable=self.company_state_var, width=120, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row4, text="ZIP:", width=40, anchor="e").pack(side="left", padx=5)
        self.company_zip_var = tk.StringVar()
        ctk.CTkEntry(row4, textvariable=self.company_zip_var, width=80, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row4, text="Country:", width=70, anchor="e").pack(side="left", padx=5)
        self.company_country_var = tk.StringVar(value="Mexico")
        ctk.CTkEntry(row4, textvariable=self.company_country_var, width=100, height=35).pack(side="left", padx=5)
        
        # Row 5: Phone, Email
        row5 = ctk.CTkFrame(form1, fg_color="transparent")
        row5.pack(fill="x", pady=5)
        ctk.CTkLabel(row5, text="Phone:", width=120, anchor="e").pack(side="left", padx=5)
        self.company_phone_var = tk.StringVar()
        ctk.CTkEntry(row5, textvariable=self.company_phone_var, width=150, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row5, text="Email:", width=60, anchor="e").pack(side="left", padx=5)
        self.company_email_var = tk.StringVar()
        ctk.CTkEntry(row5, textvariable=self.company_email_var, width=250, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(row5, text="Website:", width=70, anchor="e").pack(side="left", padx=5)
        self.company_website_var = tk.StringVar()
        ctk.CTkEntry(row5, textvariable=self.company_website_var, width=200, height=35).pack(side="left", padx=5)
        
        # Bank Information
        bank_frame = ctk.CTkFrame(scroll, fg_color="#E3F2FD", corner_radius=10)
        bank_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(bank_frame, text="🏦 Bank Account Information", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        form2 = ctk.CTkFrame(bank_frame, fg_color="transparent")
        form2.pack(fill="x", padx=15, pady=10)
        
        # Bank Row 1
        brow1 = ctk.CTkFrame(form2, fg_color="transparent")
        brow1.pack(fill="x", pady=5)
        ctk.CTkLabel(brow1, text="Bank Name:", width=120, anchor="e").pack(side="left", padx=5)
        self.bank_name_var = tk.StringVar()
        ctk.CTkEntry(brow1, textvariable=self.bank_name_var, width=250, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(brow1, text="Branch:", width=70, anchor="e").pack(side="left", padx=5)
        self.bank_branch_var = tk.StringVar()
        ctk.CTkEntry(brow1, textvariable=self.bank_branch_var, width=200, height=35).pack(side="left", padx=5)
        
        # Bank Row 2
        brow2 = ctk.CTkFrame(form2, fg_color="transparent")
        brow2.pack(fill="x", pady=5)
        ctk.CTkLabel(brow2, text="Account No:", width=120, anchor="e").pack(side="left", padx=5)
        self.bank_account_var = tk.StringVar()
        ctk.CTkEntry(brow2, textvariable=self.bank_account_var, width=200, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(brow2, text="CLABE:", width=70, anchor="e").pack(side="left", padx=5)
        self.bank_clabe_var = tk.StringVar()
        ctk.CTkEntry(brow2, textvariable=self.bank_clabe_var, width=200, height=35).pack(side="left", padx=5)
        
        # Bank Row 3 - USD Account
        brow3 = ctk.CTkFrame(form2, fg_color="transparent")
        brow3.pack(fill="x", pady=5)
        ctk.CTkLabel(brow3, text="USD Account:", width=120, anchor="e").pack(side="left", padx=5)
        self.bank_usd_account_var = tk.StringVar()
        ctk.CTkEntry(brow3, textvariable=self.bank_usd_account_var, width=180, height=35).pack(side="left", padx=5)
        
        ctk.CTkLabel(brow3, text="USD CLABE:", width=90, anchor="e").pack(side="left", padx=5)
        self.bank_usd_clabe_var = tk.StringVar()
        ctk.CTkEntry(brow3, textvariable=self.bank_usd_clabe_var, width=200, height=35).pack(side="left", padx=5)
        
        # Bank Row 4 - SWIFT
        brow4 = ctk.CTkFrame(form2, fg_color="transparent")
        brow4.pack(fill="x", pady=5)
        ctk.CTkLabel(brow4, text="SWIFT Code:", width=120, anchor="e").pack(side="left", padx=5)
        self.bank_swift_var = tk.StringVar()
        ctk.CTkEntry(brow4, textvariable=self.bank_swift_var, width=150, height=35).pack(side="left", padx=5)
        
        # Logo Settings
        logo_frame = ctk.CTkFrame(scroll, fg_color="#FFF3E0", corner_radius=10)
        logo_frame.pack(fill="x", pady=10)
        
        ctk.CTkLabel(logo_frame, text="🖼️ Company Logo (for PDF exports)", font=("SF Pro Display", 14, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        logo_form = ctk.CTkFrame(logo_frame, fg_color="transparent")
        logo_form.pack(fill="x", padx=15, pady=10)
        
        logo_row = ctk.CTkFrame(logo_form, fg_color="transparent")
        logo_row.pack(fill="x", pady=5)
        ctk.CTkLabel(logo_row, text="Logo Path:", width=120, anchor="e").pack(side="left", padx=5)
        self.logo_path_var = tk.StringVar()
        ctk.CTkEntry(logo_row, textvariable=self.logo_path_var, width=350, height=35).pack(side="left", padx=5)
        ctk.CTkButton(logo_row, text="Browse...", width=80, height=35, fg_color="#FF9800",
                     command=self._browse_logo).pack(side="left", padx=5)
        
        # Buttons
        btn_frame = ctk.CTkFrame(scroll, fg_color="transparent")
        btn_frame.pack(fill="x", pady=15)
        
        ctk.CTkButton(btn_frame, text="💾 Save Company Info", width=180, height=40, 
                     fg_color="#28A745", hover_color="#218838",
                     command=self._save_company_info).pack(side="left", padx=10)
        ctk.CTkButton(btn_frame, text="🔄 Reload", width=120, height=40, 
                     fg_color="#6C757D", hover_color="#5A6268",
                     command=self._load_company_info).pack(side="left", padx=5)
        
        # Load existing data
        self._load_company_info()
    
    def _load_company_info(self):
        """Load company info from database"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT key, value FROM app_settings WHERE key LIKE 'company_%' OR key LIKE 'bank_%' OR key = 'logo_path'")
            settings = {row[0]: row[1] for row in cur.fetchall()}
            
            self.company_name_var.set(settings.get("company_name", ""))
            self.company_legal_name_var.set(settings.get("company_legal_name", ""))
            self.company_tax_id_var.set(settings.get("company_tax_id", ""))
            self.company_regime_var.set(settings.get("company_regime", ""))
            self.company_address_var.set(settings.get("company_address", ""))
            self.company_city_var.set(settings.get("company_city", ""))
            self.company_state_var.set(settings.get("company_state", ""))
            self.company_zip_var.set(settings.get("company_zip", ""))
            self.company_country_var.set(settings.get("company_country", "Mexico"))
            self.company_phone_var.set(settings.get("company_phone", ""))
            self.company_email_var.set(settings.get("company_email", ""))
            self.company_website_var.set(settings.get("company_website", ""))
            
            self.bank_name_var.set(settings.get("bank_name", ""))
            self.bank_branch_var.set(settings.get("bank_branch", ""))
            self.bank_account_var.set(settings.get("bank_account", ""))
            self.bank_clabe_var.set(settings.get("bank_clabe", ""))
            self.bank_usd_account_var.set(settings.get("bank_usd_account", ""))
            self.bank_usd_clabe_var.set(settings.get("bank_usd_clabe", ""))
            self.bank_swift_var.set(settings.get("bank_swift", ""))
            self.logo_path_var.set(settings.get("logo_path", ""))
        except Exception as e:
            print(f"Load company info error: {e}")
        finally:
            conn.close()
    
    def _save_company_info(self):
        """Save company info to database"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            # Ensure app_settings table exists
            cur.execute("""
                CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    updated_at TEXT
                )
            """)
            
            settings = {
                "company_name": self.company_name_var.get(),
                "company_legal_name": self.company_legal_name_var.get(),
                "company_tax_id": self.company_tax_id_var.get(),
                "company_regime": self.company_regime_var.get(),
                "company_address": self.company_address_var.get(),
                "company_city": self.company_city_var.get(),
                "company_state": self.company_state_var.get(),
                "company_zip": self.company_zip_var.get(),
                "company_country": self.company_country_var.get(),
                "company_phone": self.company_phone_var.get(),
                "company_email": self.company_email_var.get(),
                "company_website": self.company_website_var.get(),
                "bank_name": self.bank_name_var.get(),
                "bank_branch": self.bank_branch_var.get(),
                "bank_account": self.bank_account_var.get(),
                "bank_clabe": self.bank_clabe_var.get(),
                "bank_usd_account": self.bank_usd_account_var.get(),
                "bank_usd_clabe": self.bank_usd_clabe_var.get(),
                "bank_swift": self.bank_swift_var.get(),
                "logo_path": self.logo_path_var.get(),
            }
            
            from datetime import datetime
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            for key, value in settings.items():
                cur.execute("""
                    INSERT OR REPLACE INTO app_settings (key, value, updated_at)
                    VALUES (?, ?, ?)
                """, (key, value, now))
            
            conn.commit()
            messagebox.showinfo("Success", "Company information saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")
        finally:
            conn.close()
    
    def _browse_logo(self):
        """Browse for company logo file"""
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            title="Select Company Logo",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp"), ("All files", "*.*")]
        )
        if path:
            self.logo_path_var.set(path)
        
    def _setup_users_tab(self):
        tab = self.tabview.tab("Users")
        
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", pady=10)
        
        ctk.CTkButton(toolbar, text="+ Add User", fg_color="#007AFF", corner_radius=8,
                     command=self._add_user_dialog).pack(side="left", padx=5)
        ctk.CTkButton(toolbar, text="🔄 Refresh", fg_color="#E5E5EA", text_color="#333333",
                     corner_radius=8, command=self._load_users).pack(side="left", padx=5)
        
        from tkinter import ttk
        cols = [("id", "#", 40), ("username", "USER", 90), ("full_name", "NAME", 110),
                ("email", "EMAIL", 160), ("role", "ROLE", 70), ("active", "✓", 40), 
                ("last_login", "LAST LOGIN", 120)]
        
        table_frame = ctk.CTkFrame(tab, fg_color="#FFFFFF", corner_radius=8)
        table_frame.pack(fill="both", expand=True, pady=10)
        
        self.users_tree = ttk.Treeview(table_frame, columns=[c[0] for c in cols], 
                                       show="headings", height=10)
        for col_id, col_name, col_width in cols:
            self.users_tree.heading(col_id, text=col_name)
            self.users_tree.column(col_id, width=col_width, anchor="center")
        
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.users_tree.yview)
        self.users_tree.configure(yscrollcommand=vsb.set)
        self.users_tree.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        vsb.pack(side="right", fill="y", pady=5)
        
        self.user_menu = tk.Menu(self, tearoff=0)
        self.user_menu.add_command(label="✏️ Edit", command=self._edit_user)
        self.user_menu.add_command(label="🔑 Reset Password", command=self._reset_password)
        self.user_menu.add_separator()
        self.user_menu.add_command(label="🗑️ Delete", command=self._delete_user)
        
        self.users_tree.bind("<Button-3>", self._show_menu)
        self.users_tree.bind("<Button-2>", self._show_menu)
        self.users_tree.bind("<Double-1>", lambda e: self._edit_user())
        
        self._load_users()
        
    def _setup_permissions_tab(self):
        tab = self.tabview.tab("Permissions")
        
        # Title
        ctk.CTkLabel(tab, text="Role-Based Access Control", 
                    font=("SF Pro Display", 16, "bold")).pack(pady=(10, 15))
        
        # Roles and permissions frame
        main_frame = ctk.CTkFrame(tab, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Left: Roles list
        roles_frame = ctk.CTkFrame(main_frame, fg_color="#F5F5F7", corner_radius=10)
        roles_frame.pack(side="left", fill="y", padx=(0, 10), pady=5)
        
        ctk.CTkLabel(roles_frame, text="Roles", font=("SF Pro Display", 14, "bold")).pack(pady=10)
        
        self.roles = ["ADMIN", "MANAGER", "OPERATOR", "VIEWER"]
        self.role_var = tk.StringVar(value="ADMIN")
        
        for role in self.roles:
            rb = ctk.CTkRadioButton(roles_frame, text=role, variable=self.role_var, value=role,
                                   command=self._on_role_select)
            rb.pack(anchor="w", padx=15, pady=5)
        
        # Right: Permissions checkboxes
        perms_frame = ctk.CTkFrame(main_frame, fg_color="#FFFFFF", corner_radius=10)
        perms_frame.pack(side="left", fill="both", expand=True, pady=5)
        
        ctk.CTkLabel(perms_frame, text="Permissions", font=("SF Pro Display", 14, "bold")).pack(pady=10)
        
        # Permission categories
        self.permissions = {
            "Jobs": ["view_jobs", "create_jobs", "edit_jobs", "delete_jobs"],
            "Settlement": ["view_settlement", "edit_settlement", "generate_invoice", "cancel_invoice"],
            "Accounting": ["view_accounting", "create_entries", "approve_entries", "export_reports"],
            "Settings": ["view_settings", "manage_users", "manage_codes", "system_admin"],
        }
        
        self.perm_vars = {}
        
        perm_scroll = ctk.CTkScrollableFrame(perms_frame, fg_color="transparent", height=300)
        perm_scroll.pack(fill="both", expand=True, padx=10, pady=5)
        
        for category, perms in self.permissions.items():
            cat_frame = ctk.CTkFrame(perm_scroll, fg_color="#F9FAFB", corner_radius=8)
            cat_frame.pack(fill="x", pady=5)
            
            ctk.CTkLabel(cat_frame, text=category, font=("SF Pro Display", 12, "bold")).pack(anchor="w", padx=10, pady=5)
            
            perm_grid = ctk.CTkFrame(cat_frame, fg_color="transparent")
            perm_grid.pack(fill="x", padx=10, pady=(0, 10))
            
            for i, perm in enumerate(perms):
                var = tk.BooleanVar(value=True)
                self.perm_vars[perm] = var
                cb = ctk.CTkCheckBox(perm_grid, text=perm.replace("_", " ").title(), 
                                    variable=var, width=180)
                cb.grid(row=i // 2, column=i % 2, sticky="w", padx=5, pady=2)
        
        # Save button
        btn_frame = ctk.CTkFrame(perms_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkButton(btn_frame, text="💾 Save Permissions", fg_color="#28A745",
                     command=self._save_permissions).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="🔄 Reset", fg_color="#6C757D",
                     command=self._reset_permissions).pack(side="left", padx=5)
        
        # Load initial permissions
        self._on_role_select()
    
    def _on_role_select(self):
        """Load permissions for selected role"""
        role = self.role_var.get()
        
        # Default permissions by role
        role_permissions = {
            "ADMIN": {perm: True for cat in self.permissions.values() for perm in cat},
            "MANAGER": {
                "view_jobs": True, "create_jobs": True, "edit_jobs": True, "delete_jobs": False,
                "view_settlement": True, "edit_settlement": True, "generate_invoice": True, "cancel_invoice": True,
                "view_accounting": True, "create_entries": True, "approve_entries": False, "export_reports": True,
                "view_settings": True, "manage_users": False, "manage_codes": True, "system_admin": False,
            },
            "OPERATOR": {
                "view_jobs": True, "create_jobs": True, "edit_jobs": True, "delete_jobs": False,
                "view_settlement": True, "edit_settlement": True, "generate_invoice": True, "cancel_invoice": False,
                "view_accounting": True, "create_entries": True, "approve_entries": False, "export_reports": False,
                "view_settings": True, "manage_users": False, "manage_codes": False, "system_admin": False,
            },
            "VIEWER": {
                "view_jobs": True, "create_jobs": False, "edit_jobs": False, "delete_jobs": False,
                "view_settlement": True, "edit_settlement": False, "generate_invoice": False, "cancel_invoice": False,
                "view_accounting": True, "create_entries": False, "approve_entries": False, "export_reports": False,
                "view_settings": False, "manage_users": False, "manage_codes": False, "system_admin": False,
            },
        }
        
        perms = role_permissions.get(role, {})
        for perm, var in self.perm_vars.items():
            var.set(perms.get(perm, False))
    
    def _save_permissions(self):
        """Save permissions for current role"""
        role = self.role_var.get()
        perms = {perm: var.get() for perm, var in self.perm_vars.items()}
        
        # In a real system, this would save to database
        # For now, just show confirmation
        enabled = [p for p, v in perms.items() if v]
        messagebox.showinfo("Saved", f"Permissions for {role} saved:\n{len(enabled)} permissions enabled")
    
    def _reset_permissions(self):
        """Reset to default permissions for current role"""
        self._on_role_select()
        
    def _load_users(self):
        for item in self.users_tree.get_children():
            self.users_tree.delete(item)
            
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT id, username, full_name, email, role, is_active, last_login FROM users ORDER BY id")
            for row in cur.fetchall():
                self.users_tree.insert("", "end", values=(
                    row[0], row[1], row[2] or "-", row[3] or "-", 
                    row[4], "✓" if row[5] else "✗", row[6] or "-"))
        except Exception as e:
            print(f"Load users error: {e}")
        finally:
            conn.close()
            
    def _show_menu(self, event):
        try:
            self.users_tree.selection_set(self.users_tree.identify_row(event.y))
            self.user_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.user_menu.grab_release()
            
    def _add_user_dialog(self):
        dialog = UserDialog(self, title="Add User")
        self.wait_window(dialog)
        self._load_users()
        
    def _edit_user(self):
        selected = self.users_tree.selection()
        if not selected:
            return
        
        user_id = self.users_tree.item(selected[0])['values'][0]
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user_data = cur.fetchone()
        conn.close()
        
        if user_data:
            dialog = UserDialog(self, title="Edit User", user_data=user_data)
            self.wait_window(dialog)
            self._load_users()
            
    def _reset_password(self):
        selected = self.users_tree.selection()
        if not selected:
            return
        
        values = self.users_tree.item(selected[0])['values']
        user_id, username, email = values[0], values[1], values[3]
        
        result = messagebox.askyesno("Reset Password", 
            f"Reset password for '{username}'?\n\nA random password will be generated.")
        
        if result:
            new_pw = reset_password(user_id)
            if new_pw:
                messagebox.showinfo("Password Reset", 
                    f"New password for {username}:\n\n{new_pw}\n\n"
                    f"Please share this securely." + 
                    (f"\n\nEmail: {email}" if email and email != "-" else ""))
                
    def _delete_user(self):
        selected = self.users_tree.selection()
        if not selected:
            return
        
        values = self.users_tree.item(selected[0])['values']
        user_id, username = values[0], values[1]
        
        if username == 'admin':
            messagebox.showerror("Error", "Cannot delete admin")
            return
        
        if messagebox.askyesno("Delete", f"Delete user '{username}'?"):
            conn = get_connection()
            cur = conn.cursor()
            cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
            conn.commit()
            conn.close()
            self._load_users()


class UserDialog(ctk.CTkToplevel):
    """User add/edit dialog"""
    
    def __init__(self, master, title="User", user_data=None):
        super().__init__(master)
        
        self.user_data = user_data
        self.title(title)
        self.geometry("400x500")
        self.resizable(False, False)
        
        x = (self.winfo_screenwidth() - 400) // 2
        y = (self.winfo_screenheight() - 500) // 2
        self.geometry(f"400x500+{x}+{y}")
        
        self.configure(fg_color="#F5F5F7")
        self.transient(master)
        self.grab_set()
        
        self._create_widgets()
        if user_data:
            self._populate()
            
    def _create_widgets(self):
        container = ctk.CTkFrame(self, fg_color="#FFFFFF", corner_radius=12)
        container.pack(fill="both", expand=True, padx=15, pady=15)
        
        form = ctk.CTkFrame(container, fg_color="transparent")
        form.pack(fill="both", expand=True, padx=20, pady=15)
        
        # Username
        ctk.CTkLabel(form, text="Username *", font=("SF Pro Display", 11, "bold")).pack(anchor="w")
        self.username_var = tk.StringVar()
        self.username_entry = ctk.CTkEntry(form, textvariable=self.username_var, height=34,
                                          corner_radius=6, border_width=1, border_color="#D1D1D6")
        self.username_entry.pack(fill="x", pady=(4, 10))
        
        # Full Name
        ctk.CTkLabel(form, text="Full Name", font=("SF Pro Display", 11, "bold")).pack(anchor="w")
        self.fullname_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=self.fullname_var, height=34,
                    corner_radius=6, border_width=1, border_color="#D1D1D6").pack(fill="x", pady=(4, 10))
        
        # Email
        ctk.CTkLabel(form, text="Email", font=("SF Pro Display", 11, "bold")).pack(anchor="w")
        self.email_var = tk.StringVar()
        ctk.CTkEntry(form, textvariable=self.email_var, height=34,
                    corner_radius=6, border_width=1, border_color="#D1D1D6").pack(fill="x", pady=(4, 10))
        
        # Password
        if not self.user_data:
            ctk.CTkLabel(form, text="Password *", font=("SF Pro Display", 11, "bold")).pack(anchor="w")
            self.password_var = tk.StringVar()
            ctk.CTkEntry(form, textvariable=self.password_var, height=34, show="•",
                        corner_radius=6, border_width=1, border_color="#D1D1D6").pack(fill="x", pady=(4, 10))
        
        # Role
        ctk.CTkLabel(form, text="Role", font=("SF Pro Display", 11, "bold")).pack(anchor="w")
        self.role_var = tk.StringVar(value="USER")
        role_frame = ctk.CTkFrame(form, fg_color="transparent")
        role_frame.pack(fill="x", pady=(4, 10))
        for role in ["ADMIN", "MANAGER", "OPERATOR", "USER"]:
            ctk.CTkRadioButton(role_frame, text=role, variable=self.role_var, value=role,
                              font=("SF Pro Display", 10), fg_color="#007AFF").pack(side="left", padx=3)
        
        # Active
        self.active_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(form, text="Active", variable=self.active_var,
                       font=("SF Pro Display", 11), fg_color="#007AFF").pack(anchor="w", pady=(5, 20))
        
        # Buttons - 더 명확하게 표시
        btn_frame = ctk.CTkFrame(form, fg_color="transparent", height=50)
        btn_frame.pack(fill="x", side="bottom")
        btn_frame.pack_propagate(False)
        
        ctk.CTkButton(btn_frame, text="Cancel", fg_color="#E5E5EA", text_color="#333333",
                     hover_color="#D1D1D6", corner_radius=8, height=38, width=120,
                     font=("SF Pro Display", 12), command=self.destroy).pack(side="left", padx=(0, 10))
        ctk.CTkButton(btn_frame, text="💾 Save", fg_color="#007AFF", hover_color="#0066CC",
                     corner_radius=8, height=38, width=120, font=("SF Pro Display", 12, "bold"),
                     command=self._save).pack(side="right")
        
    def _populate(self):
        self.username_var.set(self.user_data[1] or "")
        self.fullname_var.set(self.user_data[3] or "")
        self.email_var.set(self.user_data[4] or "")
        self.role_var.set(self.user_data[5] or "USER")
        self.active_var.set(bool(self.user_data[7]))
        self.username_entry.configure(state="disabled")
            
    def _save(self):
        username = self.username_var.get().strip()
        if not username:
            messagebox.showerror("Error", "Username required")
            return
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            if self.user_data:
                cur.execute("""UPDATE users SET full_name=?, email=?, role=?, 
                              permissions=?, is_active=?, updated_at=? WHERE id=?""",
                           (self.fullname_var.get(), self.email_var.get(), self.role_var.get(),
                            json.dumps(DEFAULT_PERMISSIONS.get(self.role_var.get(), [])),
                            1 if self.active_var.get() else 0, now_str(), self.user_data[0]))
            else:
                password = self.password_var.get()
                if not password:
                    messagebox.showerror("Error", "Password required")
                    return
                cur.execute("""INSERT INTO users (username, password_hash, full_name, email, 
                              role, permissions, is_active, created_at) VALUES (?,?,?,?,?,?,?,?)""",
                           (username, hash_password(password), self.fullname_var.get(),
                            self.email_var.get(), self.role_var.get(),
                            json.dumps(DEFAULT_PERMISSIONS.get(self.role_var.get(), [])),
                            1 if self.active_var.get() else 0, now_str()))
            conn.commit()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Save failed: {e}")
        finally:
            conn.close()
