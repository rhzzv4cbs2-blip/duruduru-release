# error_handler.py
# Centralized Error Handling System for DURUDURU
# Provides consistent error handling, logging, and user feedback

"""
DURUDURU Error Handling System
==============================
- Custom exception classes
- Centralized error logging
- User-friendly error messages
- Error tracking and reporting
"""

import logging
import traceback
import sys
import os
from datetime import datetime
from typing import Optional, Callable, Any, Dict
from functools import wraps
from enum import Enum

# Try to import tkinter messagebox, fallback to console output
try:
    from tkinter import messagebox
    HAS_TKINTER = True
except ImportError:
    HAS_TKINTER = False
    messagebox = None


# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_logging(log_dir: str = None, log_level: int = logging.INFO) -> logging.Logger:
    """Setup application logging"""
    if log_dir is None:
        log_dir = os.path.join(os.path.dirname(__file__), "logs")
    
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    # Create logger
    logger = logging.getLogger("duruduru")
    logger.setLevel(log_level)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # File handler - detailed logs
    log_file = os.path.join(log_dir, f"duruduru_{datetime.now().strftime('%Y%m%d')}.log")
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)
    
    # Console handler - important messages only
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.WARNING)
    console_formatter = logging.Formatter('%(levelname)s: %(message)s')
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    return logger


# Global logger instance
logger = setup_logging()


# =============================================================================
# CUSTOM EXCEPTIONS
# =============================================================================

class ErrorSeverity(Enum):
    """Error severity levels"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class DuruduruError(Exception):
    """Base exception for all DURUDURU errors"""
    
    def __init__(self, message: str, severity: ErrorSeverity = ErrorSeverity.ERROR,
                 user_message: str = None, details: Dict = None):
        super().__init__(message)
        self.message = message
        self.severity = severity
        self.user_message = user_message or message
        self.details = details or {}
        self.timestamp = datetime.now()
    
    def log(self):
        """Log this error"""
        log_func = {
            ErrorSeverity.INFO: logger.info,
            ErrorSeverity.WARNING: logger.warning,
            ErrorSeverity.ERROR: logger.error,
            ErrorSeverity.CRITICAL: logger.critical,
        }.get(self.severity, logger.error)
        
        log_func(f"{self.message} | Details: {self.details}")


class DatabaseError(DuruduruError):
    """Database-related errors"""
    
    def __init__(self, message: str, query: str = None, **kwargs):
        user_message = kwargs.pop('user_message', "데이터베이스 오류가 발생했습니다. 잠시 후 다시 시도해주세요.")
        super().__init__(message, user_message=user_message, **kwargs)
        self.details['query'] = query


class ValidationError(DuruduruError):
    """Data validation errors"""
    
    def __init__(self, message: str, field: str = None, **kwargs):
        kwargs.setdefault('severity', ErrorSeverity.WARNING)
        super().__init__(message, **kwargs)
        self.details['field'] = field


class NotFoundError(DuruduruError):
    """Resource not found errors"""
    
    def __init__(self, resource: str, identifier: Any, **kwargs):
        message = f"{resource} not found: {identifier}"
        user_message = kwargs.pop('user_message', f"{resource}을(를) 찾을 수 없습니다.")
        super().__init__(message, user_message=user_message, **kwargs)
        self.details['resource'] = resource
        self.details['identifier'] = identifier


class NetworkError(DuruduruError):
    """Network-related errors"""
    
    def __init__(self, message: str, url: str = None, **kwargs):
        user_message = kwargs.pop('user_message', "네트워크 연결을 확인해주세요.")
        super().__init__(message, user_message=user_message, **kwargs)
        self.details['url'] = url


class PermissionError(DuruduruError):
    """Permission/authorization errors"""
    
    def __init__(self, action: str, **kwargs):
        message = f"Permission denied for action: {action}"
        user_message = kwargs.pop('user_message', "이 작업을 수행할 권한이 없습니다.")
        super().__init__(message, user_message=user_message, **kwargs)
        self.details['action'] = action


class ConfigurationError(DuruduruError):
    """Configuration errors"""
    
    def __init__(self, message: str, config_key: str = None, **kwargs):
        user_message = kwargs.pop('user_message', "시스템 설정 오류입니다. 관리자에게 문의하세요.")
        super().__init__(message, user_message=user_message, **kwargs)
        self.details['config_key'] = config_key


# =============================================================================
# ERROR HANDLING DECORATORS
# =============================================================================

def handle_errors(show_dialog: bool = True, default_return: Any = None, 
                  reraise: bool = False, log_level: int = logging.ERROR):
    """
    Decorator for consistent error handling in functions.
    
    Args:
        show_dialog: Show error dialog to user
        default_return: Value to return on error
        reraise: Re-raise the exception after handling
        log_level: Logging level for errors
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except DuruduruError as e:
                e.log()
                if show_dialog:
                    show_error_dialog(e.user_message, e.severity)
                if reraise:
                    raise
                return default_return
            except Exception as e:
                error_msg = f"Unexpected error in {func.__name__}: {str(e)}"
                logger.log(log_level, error_msg, exc_info=True)
                if show_dialog:
                    show_error_dialog(
                        "예기치 않은 오류가 발생했습니다. 로그를 확인해주세요.",
                        ErrorSeverity.ERROR
                    )
                if reraise:
                    raise
                return default_return
        return wrapper
    return decorator


def safe_db_operation(func: Callable) -> Callable:
    """Decorator specifically for database operations"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            error_msg = str(e)
            
            # Classify the error
            if "no such table" in error_msg.lower():
                raise DatabaseError(
                    f"Table not found: {error_msg}",
                    user_message="데이터베이스 테이블이 없습니다. 시스템을 다시 초기화해주세요."
                )
            elif "no such column" in error_msg.lower():
                raise DatabaseError(
                    f"Column not found: {error_msg}",
                    user_message="데이터베이스 스키마가 맞지 않습니다. 업데이트가 필요합니다."
                )
            elif "unique constraint" in error_msg.lower():
                raise ValidationError(
                    f"Duplicate value: {error_msg}",
                    user_message="이미 존재하는 값입니다."
                )
            elif "foreign key" in error_msg.lower():
                raise ValidationError(
                    f"Foreign key violation: {error_msg}",
                    user_message="참조하는 데이터가 존재하지 않습니다."
                )
            else:
                raise DatabaseError(error_msg)
    return wrapper


# =============================================================================
# UI ERROR DISPLAY
# =============================================================================

def show_error_dialog(message: str, severity: ErrorSeverity = ErrorSeverity.ERROR,
                      title: str = None):
    """Show error dialog to user (falls back to console if no tkinter)"""
    titles = {
        ErrorSeverity.INFO: "알림",
        ErrorSeverity.WARNING: "경고",
        ErrorSeverity.ERROR: "오류",
        ErrorSeverity.CRITICAL: "심각한 오류",
    }
    
    title = title or titles.get(severity, "오류")
    
    if HAS_TKINTER and messagebox:
        if severity == ErrorSeverity.INFO:
            messagebox.showinfo(title, message)
        elif severity == ErrorSeverity.WARNING:
            messagebox.showwarning(title, message)
        else:
            messagebox.showerror(title, message)
    else:
        # Fallback to console
        print(f"[{title}] {message}")


def show_success_dialog(message: str, title: str = "성공"):
    """Show success dialog to user"""
    if HAS_TKINTER and messagebox:
        messagebox.showinfo(title, message)
    else:
        print(f"[{title}] {message}")


def confirm_dialog(message: str, title: str = "확인") -> bool:
    """Show confirmation dialog and return user choice"""
    if HAS_TKINTER and messagebox:
        return messagebox.askyesno(title, message)
    else:
        # Fallback to console input
        response = input(f"{title}: {message} (y/n): ")
        return response.lower() in ('y', 'yes')


# =============================================================================
# ERROR CONTEXT MANAGER
# =============================================================================

class ErrorContext:
    """
    Context manager for consistent error handling in code blocks.
    
    Usage:
        with ErrorContext("Loading data", show_dialog=True):
            data = load_data()
    """
    
    def __init__(self, operation: str, show_dialog: bool = True,
                 default_return: Any = None, suppress: bool = True):
        self.operation = operation
        self.show_dialog = show_dialog
        self.default_return = default_return
        self.suppress = suppress
        self.error = None
        self.success = True
    
    def __enter__(self):
        logger.debug(f"Starting: {self.operation}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.success = False
            self.error = exc_val
            
            if isinstance(exc_val, DuruduruError):
                exc_val.log()
                if self.show_dialog:
                    show_error_dialog(exc_val.user_message, exc_val.severity)
            else:
                logger.error(f"Error in {self.operation}: {exc_val}", exc_info=True)
                if self.show_dialog:
                    show_error_dialog(
                        f"오류가 발생했습니다: {self.operation}",
                        ErrorSeverity.ERROR
                    )
            
            return self.suppress  # Suppress exception if True
        
        logger.debug(f"Completed: {self.operation}")
        return False


# =============================================================================
# VALIDATION HELPERS
# =============================================================================

def validate_required(value: Any, field_name: str) -> Any:
    """Validate that a value is not None or empty"""
    if value is None or (isinstance(value, str) and not value.strip()):
        raise ValidationError(
            f"Required field is empty: {field_name}",
            field=field_name,
            user_message=f"{field_name}은(는) 필수 입력 항목입니다."
        )
    return value


def validate_positive(value: float, field_name: str) -> float:
    """Validate that a number is positive"""
    try:
        num = float(value)
        if num < 0:
            raise ValidationError(
                f"Value must be positive: {field_name}",
                field=field_name,
                user_message=f"{field_name}은(는) 0 이상이어야 합니다."
            )
        return num
    except (TypeError, ValueError):
        raise ValidationError(
            f"Invalid number: {field_name}",
            field=field_name,
            user_message=f"{field_name}에 올바른 숫자를 입력해주세요."
        )


def validate_date(value: str, field_name: str) -> str:
    """Validate date format (YYYY-MM-DD)"""
    if not value:
        return value
    
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError:
        raise ValidationError(
            f"Invalid date format: {field_name}",
            field=field_name,
            user_message=f"{field_name}의 날짜 형식이 올바르지 않습니다. (YYYY-MM-DD)"
        )


def validate_email(value: str, field_name: str = "Email") -> str:
    """Validate email format"""
    if not value:
        return value
    
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, value):
        raise ValidationError(
            f"Invalid email format: {value}",
            field=field_name,
            user_message="올바른 이메일 주소를 입력해주세요."
        )
    return value


# =============================================================================
# ERROR REPORTING
# =============================================================================

class ErrorReporter:
    """Collects and reports errors for analysis"""
    
    _instance = None
    _errors: list = []
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._errors = []
        return cls._instance
    
    def report(self, error: Exception, context: str = ""):
        """Report an error"""
        error_info = {
            "timestamp": datetime.now().isoformat(),
            "type": type(error).__name__,
            "message": str(error),
            "context": context,
            "traceback": traceback.format_exc()
        }
        self._errors.append(error_info)
        
        # Keep only last 100 errors
        if len(self._errors) > 100:
            self._errors = self._errors[-100:]
    
    def get_recent_errors(self, count: int = 10) -> list:
        """Get recent errors"""
        return self._errors[-count:]
    
    def get_error_summary(self) -> Dict[str, int]:
        """Get error type summary"""
        summary = {}
        for error in self._errors:
            error_type = error["type"]
            summary[error_type] = summary.get(error_type, 0) + 1
        return summary
    
    def clear(self):
        """Clear error history"""
        self._errors.clear()


# Global error reporter
error_reporter = ErrorReporter()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Exceptions
    'DuruduruError',
    'DatabaseError',
    'ValidationError',
    'NotFoundError',
    'NetworkError',
    'PermissionError',
    'ConfigurationError',
    'ErrorSeverity',
    
    # Decorators
    'handle_errors',
    'safe_db_operation',
    
    # UI Functions
    'show_error_dialog',
    'show_success_dialog',
    'confirm_dialog',
    
    # Context Manager
    'ErrorContext',
    
    # Validation
    'validate_required',
    'validate_positive',
    'validate_date',
    'validate_email',
    
    # Logging
    'logger',
    'setup_logging',
    
    # Reporting
    'error_reporter',
]
