# ui_dashboard.py
# Dashboard with KPI and summary charts - Premium Design
# Created: 2026-01-07

import tkinter as tk

# I18N
try:
    from i18n import I18n, get_font, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"
from tkinter import ttk, messagebox
import customtkinter as ctk
from datetime import datetime, timedelta
from db import get_connection

# Safe import for exchange rate function
try:
    from db import get_exchange_rate_for_date
except ImportError:
    def get_exchange_rate_for_date(date_str, from_curr="USD", to_curr="MXN"):
        return 20.50


class DashboardFrame(ctk.CTkFrame):
    """Premium Dashboard with KPI metrics and summary views"""
    
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color="#F0F4F8", width=width, height=height)
        
        # Top spacer for window controls
        spacer = ctk.CTkFrame(self, fg_color="transparent", height=35)
        spacer.pack(fill="x")
        
        # Title bar with gradient effect
        title_frame = ctk.CTkFrame(self, fg_color="#1565C0", corner_radius=0)
        title_frame.pack(fill="x")
        
        title_inner = ctk.CTkFrame(title_frame, fg_color="transparent")
        title_inner.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkLabel(title_inner, text="📊 DASHBOARD", font=("SF Pro Display", 24, "bold"), 
                    text_color="white").pack(side="left")
        
        # Last updated label
        self.last_updated = ctk.CTkLabel(title_inner, text="", font=("SF Pro Display", 10),
                                        text_color="#B3E5FC")
        self.last_updated.pack(side="right", padx=10)
        
        # Refresh button
        ctk.CTkButton(title_inner, text="🔄 Refresh", width=100, fg_color="#0D47A1", 
                     hover_color="#374151", command=self._refresh_data).pack(side="right")
        
        # Period selector
        self.period_var = tk.StringVar(value="This Month")
        period_combo = ttk.Combobox(title_inner, textvariable=self.period_var, state="readonly", width=12,
                                   values=["Today", "This Week", "This Month", "This Year", "All Time"])
        period_combo.pack(side="right", padx=10)
        period_combo.bind("<<ComboboxSelected>>", lambda e: self._refresh_data())
        ctk.CTkLabel(title_inner, text="Period:", text_color="white").pack(side="right", padx=5)
        
        # Main content - scrollable
        self.main_scroll = ctk.CTkScrollableFrame(self, fg_color="#F0F4F8")
        self.main_scroll.pack(fill="both", expand=True, padx=20, pady=15)
        
        # === ROW 1: Key Metrics ===
        self._create_kpi_section()
        
        # === ROW 2: Charts Section ===
        self._create_charts_section()
        
        # === ROW 3: Quick Stats Row ===
        self._create_quick_stats()
        
        # === ROW 4: Recent Activity + Upcoming ===
        self._create_activity_section()
        
        # === ROW 5: Exchange Rate ===
        self._create_exchange_section()
        
        # Initial load
        self._refresh_data()
    
    def _create_kpi_section(self):
        """Create premium KPI cards section"""
        kpi_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        kpi_frame.pack(fill="x", pady=(0, 15))
        
        # KPI Cards with icons and gradients
        self.kpi_cards = {}
        
        kpis = [
            ("total_jobs", "📦", "Total Jobs", "0", "#3498DB", "#2980B9"),
            ("active_jobs", "🚚", "Active Jobs", "0", "#27AE60", "#1E8449"),
            ("revenue", "💰", "Revenue", "$0", "#2ECC71", "#27AE60"),
            ("cost", "💸", "Cost", "$0", "#E74C3C", "#C0392B"),
            ("profit", "📈", "Profit", "$0", "#9B59B6", "#8E44AD"),
            ("margin", "📊", "Margin", "0%", "#F39C12", "#D68910"),
        ]
        
        for key, icon, title, default_val, color1, color2 in kpis:
            card = self._create_premium_kpi_card(kpi_frame, icon, title, default_val, color1, color2)
            card.pack(side="left", padx=6, expand=True, fill="both")
            self.kpi_cards[key] = card
    
    def _create_premium_kpi_card(self, parent, icon, title, value, color1, color2):
        """Create a premium KPI card with hover effect"""
        card = ctk.CTkFrame(parent, fg_color="#FFFFFF", corner_radius=15, height=120)
        card.pack_propagate(False)
        
        # Top accent bar
        accent = ctk.CTkFrame(card, fg_color=color1, height=4, corner_radius=0)
        accent.pack(fill="x")
        
        # Icon
        icon_lbl = ctk.CTkLabel(card, text=icon, font=("SF Pro Display", 28))
        icon_lbl.pack(pady=(15, 5))
        
        # Value
        value_lbl = ctk.CTkLabel(card, text=value, font=("SF Pro Display", 24, "bold"), text_color=color1)
        value_lbl.pack(pady=(0, 3))
        
        # Title
        title_lbl = ctk.CTkLabel(card, text=title, font=("SF Pro Display", 10), text_color="#666666")
        title_lbl.pack(pady=(0, 15))
        
        # Store references
        card._value_label = value_lbl
        card._color = color1
        
        return card
    
    def _create_charts_section(self):
        """Create enhanced charts section"""
        charts_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        charts_frame.pack(fill="x", pady=10)
        
        # Left chart - Jobs by Mode (Pie-like display)
        left_chart = ctk.CTkFrame(charts_frame, fg_color="#FFFFFF", corner_radius=15)
        left_chart.pack(side="left", expand=True, fill="both", padx=(0, 8))
        
        header1 = ctk.CTkFrame(left_chart, fg_color="#E3F2FD", corner_radius=0)
        header1.pack(fill="x")
        ctk.CTkLabel(header1, text="🚢 Jobs by Mode", font=("SF Pro Display", 13, "bold"),
                    text_color="#1565C0").pack(pady=12, padx=15, anchor="w")
        
        self.mode_chart_frame = ctk.CTkFrame(left_chart, fg_color="transparent", height=160)
        self.mode_chart_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Right chart - Jobs by Status
        right_chart = ctk.CTkFrame(charts_frame, fg_color="#FFFFFF", corner_radius=15)
        right_chart.pack(side="left", expand=True, fill="both", padx=(8, 0))
        
        header2 = ctk.CTkFrame(right_chart, fg_color="#FFF3E0", corner_radius=0)
        header2.pack(fill="x")
        ctk.CTkLabel(header2, text="📊 Jobs by Status", font=("SF Pro Display", 13, "bold"),
                    text_color="#E65100").pack(pady=12, padx=15, anchor="w")
        
        self.status_chart_frame = ctk.CTkFrame(right_chart, fg_color="transparent", height=160)
        self.status_chart_frame.pack(fill="both", expand=True, padx=15, pady=15)
    
    def _create_quick_stats(self):
        """Create quick statistics row"""
        stats_frame = ctk.CTkFrame(self.main_scroll, fg_color="#FFFFFF", corner_radius=15)
        stats_frame.pack(fill="x", pady=10)
        
        # Header
        header = ctk.CTkFrame(stats_frame, fg_color="#E8F5E9", corner_radius=0)
        header.pack(fill="x")
        ctk.CTkLabel(header, text="⚡ Quick Statistics", font=("SF Pro Display", 13, "bold"),
                    text_color="#2E7D32").pack(pady=10, padx=15, anchor="w")
        
        # Stats grid
        grid = ctk.CTkFrame(stats_frame, fg_color="transparent")
        grid.pack(fill="x", padx=15, pady=15)
        
        self.quick_stats = {}
        
        stats_items = [
            ("pending_quotes", "📝 Pending Quotes", "0"),
            ("open_invoices", "📄 Open Invoices", "0"),
            ("overdue", "⚠️ Overdue", "0"),
            ("this_week_etd", "📅 ETD This Week", "0"),
        ]
        
        for i, (key, label, default) in enumerate(stats_items):
            stat_box = ctk.CTkFrame(grid, fg_color="#F8F9FA", corner_radius=10)
            stat_box.grid(row=0, column=i, padx=5, pady=5, sticky="ew")
            grid.grid_columnconfigure(i, weight=1)
            
            val_lbl = ctk.CTkLabel(stat_box, text=default, font=("SF Pro Display", 20, "bold"),
                                   text_color="#333")
            val_lbl.pack(pady=(12, 2))
            
            ctk.CTkLabel(stat_box, text=label, font=("SF Pro Display", 9), 
                        text_color="#666").pack(pady=(0, 12))
            
            self.quick_stats[key] = val_lbl
    
    def _create_activity_section(self):
        """Create recent activity section"""
        activity_frame = ctk.CTkFrame(self.main_scroll, fg_color="#FFFFFF", corner_radius=12)
        activity_frame.pack(fill="x", pady=10)
        
        # Header
        header = ctk.CTkFrame(activity_frame, fg_color="transparent")
        header.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(header, text="📋 Recent Jobs", font=("SF Pro Display", 14, "bold")).pack(side="left")
        ctk.CTkButton(header, text="View All →", width=80, fg_color="transparent", text_color="#007AFF",
                     hover_color="#F0F0F0").pack(side="right")
        
        # Recent jobs table
        cols = ["job_no", "mode", "customer", "pol", "pod", "etd", "status"]
        self.recent_tree = ttk.Treeview(activity_frame, columns=cols, show="headings", height=5)
        
        headers = ["JOB NO", "MODE", "CUSTOMER", "POL", "POD", "ETD", "STATUS"]
        widths = [100, 60, 150, 80, 80, 90, 80]
        
        for c, h, w in zip(cols, headers, widths):
            self.recent_tree.heading(c, text=h)
            self.recent_tree.column(c, width=w, anchor="center" if c != "customer" else "w")
        
        self.recent_tree.pack(fill="x", padx=15, pady=(0, 15))
    
    def _create_exchange_section(self):
        """Create exchange rate section"""
        exchange_frame = ctk.CTkFrame(self.main_scroll, fg_color="#FFFFFF", corner_radius=12)
        exchange_frame.pack(fill="x", pady=10)
        
        # Header
        header = ctk.CTkFrame(exchange_frame, fg_color="transparent")
        header.pack(fill="x", padx=15, pady=10)
        ctk.CTkLabel(header, text="💱 Exchange Rate (USD/MXN)", font=("SF Pro Display", 14, "bold")).pack(side="left")
        ctk.CTkButton(header, text="🔄 Fetch Latest", width=100, fg_color="#007AFF",
                     command=self._fetch_exchange_rate).pack(side="right")
        
        # Rate display
        rate_frame = ctk.CTkFrame(exchange_frame, fg_color="#E3F2FD", corner_radius=8)
        rate_frame.pack(fill="x", padx=15, pady=(0, 15))
        
        self.rate_date_label = ctk.CTkLabel(rate_frame, text="Date: -", font=("SF Pro Display", 11))
        self.rate_date_label.pack(side="left", padx=20, pady=15)
        
        self.rate_value_label = ctk.CTkLabel(rate_frame, text="Rate: -", font=("SF Pro Display", 18, "bold"), 
                                            text_color="#1565C0")
        self.rate_value_label.pack(side="left", padx=20, pady=15)
        
        self.rate_source_label = ctk.CTkLabel(rate_frame, text="Source: -", font=("SF Pro Display", 11),
                                             text_color="#666")
        self.rate_source_label.pack(side="right", padx=20, pady=15)
    
    def _refresh_data(self):
        """Refresh all dashboard data"""
        period = self.period_var.get()
        
        # Calculate date range
        today = datetime.now().date()
        if period == "Today":
            start_date = today.strftime("%Y-%m-%d")
        elif period == "This Week":
            start_date = (today - timedelta(days=today.weekday())).strftime("%Y-%m-%d")
        elif period == "This Month":
            start_date = today.replace(day=1).strftime("%Y-%m-%d")
        elif period == "This Year":
            start_date = today.replace(month=1, day=1).strftime("%Y-%m-%d")
        else:  # All Time
            start_date = "2000-01-01"
        
        end_date = today.strftime("%Y-%m-%d")
        
        conn = get_connection()
        cur = conn.cursor()
        
        try:
            # === KPI Data ===
            # Total Jobs
            cur.execute("SELECT COUNT(*) FROM jobs WHERE DATE(created_at) >= ? AND DATE(created_at) <= ?", 
                       (start_date, end_date))
            total_jobs = cur.fetchone()[0] or 0
            self.kpi_cards["total_jobs"]._value_label.configure(text=str(total_jobs))
            
            # Active Jobs
            cur.execute("""SELECT COUNT(*) FROM jobs 
                          WHERE status IN ('OPEN', 'IN TRANSIT', 'ARRIVED') 
                          AND DATE(created_at) >= ? AND DATE(created_at) <= ?""", 
                       (start_date, end_date))
            active_jobs = cur.fetchone()[0] or 0
            self.kpi_cards["active_jobs"]._value_label.configure(text=str(active_jobs))
            
            # Revenue
            cur.execute("""SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                          WHERE item_type='REVENUE' AND DATE(created_at) >= ? AND DATE(created_at) <= ?""",
                       (start_date, end_date))
            revenue = cur.fetchone()[0] or 0
            self.kpi_cards["revenue"]._value_label.configure(text=f"${revenue:,.0f}")
            
            # Cost
            cur.execute("""SELECT COALESCE(SUM(total), 0) FROM settlement_items 
                          WHERE item_type='COST' AND DATE(created_at) >= ? AND DATE(created_at) <= ?""",
                       (start_date, end_date))
            cost = cur.fetchone()[0] or 0
            self.kpi_cards["cost"]._value_label.configure(text=f"${cost:,.0f}")
            
            # Profit
            profit = revenue - cost
            profit_color = "#2ECC71" if profit >= 0 else "#E74C3C"
            self.kpi_cards["profit"]._value_label.configure(text=f"${profit:,.0f}", text_color=profit_color)
            
            # Margin
            margin = (profit / revenue * 100) if revenue > 0 else 0
            margin_color = "#27AE60" if margin >= 10 else "#F39C12" if margin >= 0 else "#E74C3C"
            self.kpi_cards["margin"]._value_label.configure(text=f"{margin:.1f}%", text_color=margin_color)
            
            # === Mode Chart ===
            cur.execute("""SELECT mode, COUNT(*) FROM jobs 
                          WHERE DATE(created_at) >= ? AND DATE(created_at) <= ?
                          GROUP BY mode ORDER BY COUNT(*) DESC""", (start_date, end_date))
            mode_data = cur.fetchall()
            self._update_bar_chart(self.mode_chart_frame, mode_data, {"OCEAN": "#3498DB", "AIR": "#9B59B6", "LAND": "#27AE60"})
            
            # === Status Chart ===
            cur.execute("""SELECT status, COUNT(*) FROM jobs 
                          WHERE DATE(created_at) >= ? AND DATE(created_at) <= ?
                          GROUP BY status ORDER BY COUNT(*) DESC""", (start_date, end_date))
            status_data = cur.fetchall()
            self._update_bar_chart(self.status_chart_frame, status_data, 
                                  {"OPEN": "#3498DB", "IN TRANSIT": "#F39C12", "ARRIVED": "#9B59B6", 
                                   "DELIVERED": "#27AE60", "CLOSED": "#95A5A6"})
            
            # === Recent Jobs ===
            for item in self.recent_tree.get_children():
                self.recent_tree.delete(item)
            
            cur.execute("""SELECT job_no, mode, customer, pol, pod, etd, status 
                          FROM jobs ORDER BY created_at DESC LIMIT 10""")
            for row in cur.fetchall():
                self.recent_tree.insert("", "end", values=row)
            
            # === Exchange Rate ===
            cur.execute("""SELECT rate_date, rate, source FROM exchange_rates 
                          WHERE from_currency='USD' AND to_currency='MXN'
                          ORDER BY rate_date DESC LIMIT 1""")
            rate_row = cur.fetchone()
            if rate_row:
                self.rate_date_label.configure(text=f"Date: {rate_row[0]}")
                self.rate_value_label.configure(text=f"${rate_row[1]:.4f} MXN")
                self.rate_source_label.configure(text=f"Source: {rate_row[2]}")
            else:
                self.rate_date_label.configure(text="Date: -")
                self.rate_value_label.configure(text="No data")
                self.rate_source_label.configure(text="Source: -")
                
        except Exception as e:
            print(f"Dashboard refresh error: {e}")
        finally:
            conn.close()
    
    def _update_bar_chart(self, parent, data, colors):
        """Update a simple bar chart"""
        # Clear existing
        for widget in parent.winfo_children():
            widget.destroy()
        
        if not data:
            ctk.CTkLabel(parent, text="No data", text_color="#999").pack(pady=20)
            return
        
        # Find max for scaling
        max_val = max(d[1] for d in data) if data else 1
        
        for label, value in data[:5]:  # Limit to 5 items
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", pady=3)
            
            # Label
            ctk.CTkLabel(row, text=str(label or "N/A")[:12], width=80, anchor="w", 
                        font=("SF Pro Display", 10)).pack(side="left")
            
            # Bar
            bar_width = int((value / max_val) * 200) if max_val > 0 else 0
            color = colors.get(label, "#3498DB")
            
            bar_container = ctk.CTkFrame(row, fg_color="#E0E0E0", height=20, corner_radius=4)
            bar_container.pack(side="left", fill="x", expand=True, padx=5)
            bar_container.pack_propagate(False)
            
            if bar_width > 0:
                bar = ctk.CTkFrame(bar_container, fg_color=color, width=bar_width, corner_radius=4)
                bar.pack(side="left", fill="y")
            
            # Value
            ctk.CTkLabel(row, text=str(value), width=40, font=("SF Pro Display", 10, "bold")).pack(side="right")
    
    def _fetch_exchange_rate(self):
        """Fetch latest exchange rate from API"""
        try:
            from db import fetch_exchange_rate_dof, save_exchange_rate, today_str
            rate = fetch_exchange_rate_dof()
            if rate:
                today = today_str()
                save_exchange_rate(today, rate, "USD", "MXN", "API")
                messagebox.showinfo("Success", f"Exchange rate fetched: ${rate:.4f} MXN per USD")
                self._refresh_data()
            else:
                messagebox.showwarning("Warning", "Could not fetch exchange rate from API")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to fetch rate: {e}")
