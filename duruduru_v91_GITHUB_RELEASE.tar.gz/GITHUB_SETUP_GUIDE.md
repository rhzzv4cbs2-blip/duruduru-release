# DURUDURU GitHub Releases 설정 가이드

## 🚀 빠른 시작 (5분)

### Step 1: GitHub 저장소 생성

1. **GitHub.com 접속** → 로그인
2. **New repository** 클릭
3. 설정:
   - Repository name: `duruduru-releases`
   - Description: `DURUDURU Freight Forwarding System`
   - **Public** 선택 (무료 Release 사용)
   - ✅ Add README
4. **Create repository** 클릭

---

### Step 2: auto_updater.py 설정 확인

`auto_updater.py` 파일에서 아래 값 확인:

```python
GITHUB_OWNER = "yjhong-staticweb"  # ← 본인 GitHub 사용자명
GITHUB_REPO = "duruduru-releases"  # ← 저장소 이름
```

---

### Step 3: 첫 Release 생성

1. GitHub 저장소 페이지 → **Releases** (오른쪽)
2. **Create a new release** 클릭
3. 설정:
   ```
   Tag: v1.0.91
   Title: DURUDURU v1.0.91
   Description:
   ## What's New
   - 자동 업데이트 시스템 추가
   - Cash Flow 입출금 기능 개선
   - DB 스키마 자동 마이그레이션
   ```
4. **Assets 업로드** (드래그 & 드롭):
   - `DURUDURU.exe` (Windows용)
   - `duruduru_v91.tar.gz` (소스)
5. **Publish release** 클릭

---

### Step 4: 테스트

```bash
# macOS에서 테스트
python3 auto_updater.py
```

예상 출력:
```
DURUDURU Auto-Updater
Current Version: 1.0.91
Checking for updates...

✓ You're up to date!
```

---

## 📦 새 버전 배포 방법

### 1. 코드 수정 후

```python
# auto_updater.py
APP_VERSION = "1.0.92"  # ← 버전 올리기
```

### 2. Windows EXE 빌드 (Windows PC에서)

```cmd
python build_windows_exe.py
# 결과: dist/DURUDURU.exe
```

### 3. GitHub Release 생성

1. GitHub → Releases → **Draft a new release**
2. Tag: `v1.0.92`
3. `DURUDURU.exe` 업로드
4. **Publish**

### 4. 사용자 앱에서 자동 감지

```
앱 시작 → 로그인 → "새 버전 v1.0.92 있습니다!" 알림
```

---

## 🔧 문제 해결

### SSL 인증서 오류 (macOS)

```bash
# certifi 설치
pip3 install certifi

# 또는 Python 인증서 설치
/Applications/Python\ 3.x/Install\ Certificates.command
```

### Release를 찾을 수 없음

- 저장소가 **Public**인지 확인
- Tag 이름이 `v`로 시작하는지 확인 (예: `v1.0.91`)
- Release가 **Published** 상태인지 확인 (Draft 아님)

### API Rate Limit

- 인증 없이 60회/시간 제한
- 개발 중 테스트 많이 하면 일시적 차단
- 1시간 후 자동 해제

---

## 📋 Release 체크리스트

새 버전 배포 시:

- [ ] `auto_updater.py`의 `APP_VERSION` 업데이트
- [ ] 모든 기능 테스트 완료
- [ ] Windows EXE 빌드 (Windows PC)
- [ ] GitHub Release 생성
- [ ] DURUDURU.exe 업로드
- [ ] Release Notes 작성
- [ ] Publish 클릭
- [ ] 다운로드 링크 테스트

---

## 🏷️ 버전 번호 규칙

```
1.0.91
│ │ └── 패치 (버그 수정)
│ └──── 마이너 (새 기능)
└────── 메이저 (큰 변경)
```

예시:
- `1.0.91` → `1.0.92`: 버그 수정
- `1.0.92` → `1.1.0`: 새 기능 추가
- `1.1.0` → `2.0.0`: 대규모 변경

---

## 📞 요약

| 작업 | 위치 |
|------|------|
| 버전 관리 | `auto_updater.py` → `APP_VERSION` |
| EXE 빌드 | Windows PC → `python build_windows_exe.py` |
| 배포 | GitHub → Releases → Upload & Publish |
| 사용자 업데이트 | 자동 (앱 시작 시 체크) |

