import customtkinter as ctk
from tkinter import messagebox
import tkinter as tk
from PIL import Image, ImageTk
import os
import sys

# =============================================================================
# SYSTEM INITIALIZATION
# =============================================================================

print("=" * 50)
print("DURUDURU Freight Forwarding System Starting...")
print("=" * 50)

# Initialize database first (this will create tables)
try:
    from db import get_connection, now_str
    conn = get_connection()
    conn.close()
    print("✓ Database initialized")
except Exception as e:
    print(f"✗ Database initialization failed: {e}")
    import traceback
    traceback.print_exc()

# Initialize UI design system (optional)
try:
    from ui_design import configure_ttk_styles, COLORS
    print("✓ UI design system loaded")
except ImportError:
    print("⚠ UI design module not available")
    COLORS = None
    def configure_ttk_styles():
        pass

# Initialize automation system
try:
    from automation import get_automation_manager, AutomationManager
    HAS_AUTOMATION = True
    print("✓ Automation system loaded")
except ImportError as e:
    print(f"⚠ Automation module not available: {e}")
    HAS_AUTOMATION = False
    get_automation_manager = None

# =============================================================================
# MODULE IMPORTS
# =============================================================================

from ui_order_reg import OceanRegFrame, AirRegFrame, LandRegFrame
from ui_status import OperationFrame, PerformanceFrame
from ui_settlement import SettlementMgmtFrame, OutstandingFrame
from ui_accounting import AccountingFrame
from ui_settings import CustomerMgmtFrame, PortMgmtFrame, FreightMgmtFrame, CompanyProfileFrame, AutomationSettingsFrame
from provider_mock import MockProvider

# Tracking import
try:
    from ui_tracking import TrackingFrame
    HAS_TRACKING = True
except ImportError:
    HAS_TRACKING = False
    TrackingFrame = None

# Dashboard and Quotation imports
try:
    from ui_dashboard import DashboardFrame
    HAS_DASHBOARD = True
except ImportError:
    HAS_DASHBOARD = False
    DashboardFrame = None

try:
    from ui_quotation import QuotationFrame
    HAS_QUOTATION = True
except ImportError:
    HAS_QUOTATION = False
    QuotationFrame = None

try:
    from ui_vendor_quote import VendorQuoteFrame
    HAS_VENDOR_QUOTE = True
except ImportError:
    HAS_VENDOR_QUOTE = False
    VendorQuoteFrame = None

# Auth import
try:
    from auth import LoginDialog, create_users_table
    HAS_AUTH = True
    print("✓ Auth module loaded")
except ImportError as e:
    print(f"⚠ Auth module not available: {e}")
    HAS_AUTH = False
    def create_users_table(): pass

# Auto-updater import
try:
    from auto_updater import check_updates_on_startup, APP_VERSION
    HAS_AUTO_UPDATE = True
    print(f"✓ Auto-updater loaded (v{APP_VERSION})")
except ImportError as e:
    print(f"⚠ Auto-updater not available: {e}")
    HAS_AUTO_UPDATE = False
    APP_VERSION = "1.0.0"

# Set appearance mode
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


# =============================================================================
# MAIN APPLICATION
# =============================================================================

class MainApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        print("Creating main window...")
        
        # Apply TTK styles
        try:
            configure_ttk_styles()
        except:
            pass


        # ---------------------------------------------------------
        # 창 설정
        # ---------------------------------------------------------
        self.title("DURUDURU FORWARDING SYSTEM")
        self.geometry("1400x850")
        self.minsize(300, 210)
        
        # ---------------------------------------------------------
        # 종료 확인 설정
        # ---------------------------------------------------------
        self.protocol("WM_DELETE_WINDOW", self._on_close_confirm)
        
        # ---------------------------------------------------------
        # 아이콘 설정 (macOS)
        # ---------------------------------------------------------
        self._set_app_icon()

        # ---------------------------------------------------------
        # 레이아웃
        # ---------------------------------------------------------
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        # ---------------------------------------------------------
        # Frame / Dock 관리 변수
        # ---------------------------------------------------------
        self.frames = {}
        self.active_frame = None
        self.active_frame_name = None
        self.dock_buttons = {}
        self.frame_zoom_states = {}
        self.window_offset = 0

        # --- ADD THIS LINE (prevents duplicate frame creation) ---
        self._creating_frames = set()

        # ---------------------------------------------------------
        # Sidebar 상태 변수
        # ---------------------------------------------------------
        self.section_headers = {}
        self.section_children = {}
        self.sections_order = []
        self.expanded_section = None

        # ---------------------------------------------------------
        # Sidebar - Monochrome Minimal
        # ---------------------------------------------------------
        self.sidebar = ctk.CTkFrame(self, fg_color="#F9FAFB", width=230)  # Gray 50
        self.sidebar.grid(row=0, column=0, sticky="nsw")
        self.sidebar.grid_propagate(False)

        self.sidebar_inner = ctk.CTkFrame(self.sidebar, fg_color="#F9FAFB")
        self.sidebar_inner.pack(fill="both", expand=True)

        # ---------------------------------------------------------
        # Content 영역 - Clean White
        # ---------------------------------------------------------
        self.content_frame = ctk.CTkFrame(self, fg_color="#FFFFFF")
        self.content_frame.grid(row=0, column=1, sticky="nsew")

        # ---------------------------------------------------------
        # mock provider 불러오기 (content_frame 생성 후)
        # ---------------------------------------------------------
        self._mock_provider = MockProvider()

        # ---------------------------------------------------------
        # Dock - Monochrome
        # ---------------------------------------------------------
        self.dock_bar = ctk.CTkFrame(self, fg_color="#F3F4F6", height=46)  # Gray 100
        self.dock_bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        self.dock_bar.grid_propagate(False)
        # 왼쪽은 확장, 오른쪽은 고정(버튼 영역)
        self.dock_bar.grid_columnconfigure(0, weight=1)
        self.dock_bar.grid_columnconfigure(1, weight=0)
        # 오른쪽에 최소 너비를 확보해서 scale_frame이 보이도록 함 (기존 레이아웃을 크게 변경하지 않음)
        self.dock_bar.grid_columnconfigure(1, minsize=180)

        self.dock_inner = ctk.CTkFrame(self.dock_bar, fg_color="#F2F2F2")
        self.dock_inner.grid(row=0, column=0, sticky="w", padx=12, pady=6)

        # ============================
        # UI 전체 확대/축소 컨트롤
        # ============================
        # 이 블록은 기존 기능을 건드리지 않고, 오른쪽에 항상 보이도록 grid로 추가함
        self.current_scale = 1.0

        # macOS style button
        btn_style = {
            "fg_color": "#E5E5E5",
            "hover_color": "#D0D0D0",
            "text_color": "#333333",
            "corner_radius": 6
        }

        scale_frame = ctk.CTkFrame(self.dock_bar, fg_color="#F2F2F2")
        scale_frame.grid(row=0, column=1, sticky="e", padx=12, pady=6)

        def apply_scale():
            # CustomTkinter의 전체 스케일 적용
            try:
                ctk.set_widget_scaling(self.current_scale)
            except Exception:
                # 안전 장치: set_widget_scaling이 실패해도 앱이 멈추지 않도록 함
                pass
            # 레이블 업데이트 (5% 단위로 보이도록 정수 퍼센트)
            percent = int(round(self.current_scale * 100))
            # 버튼이 생성되어 있을 때만 업데이트
            if hasattr(self, "scale_label_btn"):
                self.scale_label_btn.configure(text=f"{percent}%")

        def scale_down():
            # 5% 단위로 감소
            self.current_scale = max(0.5, round((self.current_scale - 0.05) * 100) / 100.0)
            apply_scale()

        def scale_reset():
            self.current_scale = 1.0
            apply_scale()

        def scale_up():
            # 5% 단위로 증가
            self.current_scale = min(1.5, round((self.current_scale + 0.05) * 100) / 100.0)
            apply_scale()

        # 버튼 생성 (pack은 scale_frame 내부에서만 사용)
        ctk.CTkButton(scale_frame, text="-", width=40, command=scale_down, **btn_style).pack(side="left", padx=4)
        self.scale_label_btn = ctk.CTkButton(scale_frame, text="100%", width=60, command=scale_reset, **btn_style)
        self.scale_label_btn.pack(side="left", padx=4)
        ctk.CTkButton(scale_frame, text="+", width=40, command=scale_up, **btn_style).pack(side="left", padx=4)

        # ============================
        # Ctrl/Cmd + 마우스 휠 확대/축소 (단축키 지원)
        # ============================
        def _on_zoom_wheel(event):
            # event.delta는 플랫폼/환경에 따라 다를 수 있으므로 안전하게 처리
            delta = getattr(event, "delta", None)
            # Windows: delta > 0 or < 0, macOS: delta >0/<0 with Command modifier
            if delta is None:
                # 일부 리눅스 환경에서는 Button-4/5 이벤트를 사용하므로 무시(추가 바인딩 필요 시 확장)
                return
            if delta > 0:
                self.current_scale = min(1.5, round((self.current_scale + 0.05) * 100) / 100.0)
            else:
                self.current_scale = max(0.5, round((self.current_scale - 0.05) * 100) / 100.0)
            apply_scale()

        # 바인딩: Windows/Linux (Ctrl+Wheel), macOS (Command+Wheel)
        try:
            self.bind("<Control-MouseWheel>", _on_zoom_wheel)
        except Exception:
            pass
        try:
            self.bind("<Command-MouseWheel>", _on_zoom_wheel)
        except Exception:
            pass
        
        # Shift+Escape: 현재 활성화된 프레임 최소화
        self.bind("<Shift-Escape>", self._minimize_active_frame)
        
        # ============================
        # 키보드 단축키 시스템
        # ============================
        self._setup_keyboard_shortcuts()

        # ---------------------------------------------------------
        # Sidebar 구축
        # ---------------------------------------------------------
        self._build_sidebar()

        # ---------------------------------------------------------
        # 기본 워터마크
        # ---------------------------------------------------------
        self._build_watermark()

        # ---------------------------------------------------------
        # 로그인 화면 표시 (앱 시작 시)
        # ---------------------------------------------------------
        self.current_user = None
        
        # 로그인 전에는 사이드바, 워터마크 숨김
        self.sidebar.grid_remove()
        self.watermark_frame.pack_forget()
        
        # Ensure main window is visible before showing login
        self.update()
        self.deiconify()
        
        print("Main window ready")
        
        if HAS_AUTH:
            try:
                print("Creating users table...")
                create_users_table()
                print("✓ Users table ready")
            except Exception as e:
                print(f"✗ Create users table error: {e}")
                import traceback
                traceback.print_exc()
            
            print("Scheduling login dialog...")
            self.after(300, self._show_login)
        else:
            print("No auth module - showing app directly")
            self.sidebar.grid()
            self.watermark_frame.pack(fill="both", expand=True)
            self._start_automation()

    def _show_login(self):
        """Show login dialog"""
        print("Showing login dialog...")
        
        def on_success(user):
            print(f"✓ Login callback called for user: {user.get('username', 'unknown')}")
            self.current_user = user
            
            # Apply language setting
            language = user.get('language', 'English')
            try:
                from i18n import set_language_by_name
                set_language_by_name(language)
                print(f"✓ Language set to: {language}")
            except ImportError:
                pass
            
            # Rebuild sidebar with new language
            self._rebuild_sidebar()
            
            # 로그인 성공 시 사이드바 표시
            self.sidebar.grid()
            self.watermark_frame.pack(fill="both", expand=True)
            print("✓ UI updated after login")
            
            # Start automation services
            self._start_automation()
            
            # Check for updates (background)
            if HAS_AUTO_UPDATE:
                try:
                    check_updates_on_startup(self)
                    print("✓ Update check initiated")
                except Exception as e:
                    print(f"⚠ Update check failed: {e}")
        
        try:
            dialog = LoginDialog(self, on_success=on_success)
            print(f"✓ Login dialog created: {dialog}")
        except Exception as e:
            print(f"✗ Login dialog error: {e}")
            import traceback
            traceback.print_exc()
            # If login dialog fails, show app anyway
            self.sidebar.grid()
            self.watermark_frame.pack(fill="both", expand=True)
            self._start_automation()

    def _start_automation(self):
        """Start all automation services"""
        if not HAS_AUTOMATION:
            return
        
        try:
            manager = get_automation_manager()
            
            # Define functions for automation
            def get_active_jobs():
                """Get jobs for tracking"""
                from db import get_connection
                conn = get_connection()
                cur = conn.cursor()
                try:
                    cur.execute("""
                        SELECT id, job_no, mbl, hbl, carrier, status 
                        FROM jobs 
                        WHERE status IN ('BOOKING', 'CONFIRMED', 'IN_TRANSIT')
                        LIMIT 50
                    """)
                    cols = [d[0] for d in cur.description]
                    return [dict(zip(cols, row)) for row in cur.fetchall()]
                finally:
                    conn.close()
            
            def get_overdue_data():
                """Get overdue payment data"""
                from db import get_aging_report_data
                ar_data = get_aging_report_data('AR')
                total_overdue = sum(item.get('over_90', 0) for item in ar_data)
                count = len([item for item in ar_data if item.get('over_90', 0) > 0])
                return {"count": count, "total": total_overdue}
            
            # Start automation with callbacks
            manager.start_all(
                get_jobs_func=get_active_jobs,
                get_overdue_func=get_overdue_data
            )
            
            print("✓ Automation services started")
            
        except Exception as e:
            print(f"⚠ Automation start error: {e}")

    def _get_admin_frame(self, master, **kwargs):
        """Get AdminFrame from auth module"""
        if HAS_AUTH:
            from auth import AdminFrame
            return AdminFrame(master, current_user=self.current_user, **kwargs)
        return None

    # ============================================================
    # 워터마크
    # ============================================================
    def _set_app_icon(self):
        """앱 아이콘 설정"""
        try:
            # Try multiple possible icon paths
            possible_paths = [
                os.path.join(os.path.dirname(__file__), "icon_1024x1024.png"),
                os.path.join(os.path.dirname(__file__), "app_icon.iconset", "icon_512x512.png"),
                os.path.join(os.path.dirname(__file__), "icon.png"),
            ]
            
            for icon_path in possible_paths:
                if os.path.exists(icon_path):
                    icon_image = Image.open(icon_path)
                    # Resize for better display
                    icon_image = icon_image.resize((256, 256), Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(icon_image)
                    self.iconphoto(True, photo)
                    # Keep reference
                    self._icon_photo = photo
                    print(f"✓ App icon loaded: {icon_path}")
                    break
        except Exception as e:
            print(f"Icon load failed: {e}")
    
    def _on_close_confirm(self):
        """종료 시 확인 메시지"""
        # Check if any frame has unsaved data
        has_unsaved = False
        
        # Check active frame for unsaved changes
        if self.active_frame:
            # Check for common entry/text widgets with content
            try:
                for widget in self.active_frame.winfo_children():
                    if hasattr(widget, 'get'):
                        content = widget.get() if callable(widget.get) else ""
                        if content and str(content).strip():
                            has_unsaved = True
                            break
            except:
                pass
        
        if has_unsaved:
            from tkinter import messagebox
            result = messagebox.askyesno(
                "Exit Confirmation",
                "There may be unsaved data.\nAre you sure you want to exit?",
                icon="warning"
            )
            if not result:
                return
        
        self.quit()
        self.destroy()
    
    def _build_watermark(self):
        self.watermark_frame = ctk.CTkFrame(self.content_frame, fg_color="#FFFFFF")
        self.watermark_frame.pack(fill="both", expand=True)

        self.watermark_label = ctk.CTkLabel(
            self.watermark_frame,
            text="DURUDURU",
            font=("SF Pro Display", 80, "bold"),
            text_color="#E5E7EB",  # Gray 200
        )
        self.watermark_label.place(relx=0.5, rely=0.5, anchor="center")

    # ============================================================
    # 프레임 컨트롤 + 드래그 + 리사이즈 + 경계선
    # ============================================================
    def _attach_frame_controls(self, frame, name):
        if getattr(frame, "_has_window_controls", False):
            return

        # 전체 프레임 배경/테두리 - Monochrome Minimal
        frame.configure(
            fg_color="#FFFFFF",
            border_width=1,
            border_color="#E5E7EB",  # Gray 200
        )

        # ---------------- 상단 바 - Clean Gray ----------------
        bar = ctk.CTkFrame(frame, fg_color="#F9FAFB", height=30)  # Gray 50
        bar.place(relx=0, rely=0, anchor="nw", relwidth=1)
        bar.lift()

        btn_container = ctk.CTkFrame(bar, fg_color="transparent")
        btn_container.pack(side="right", padx=10, pady=6)

        # 닫기 - Muted Red
        def on_close():
            self._close_frame(name)

        close_btn = ctk.CTkButton(
            btn_container, width=14, height=14,
            fg_color="#EF4444", hover_color="#DC2626",  # Red 500/600
            text="", corner_radius=7, command=on_close
        )
        close_btn.grid(row=0, column=0, padx=4)

        # 최소화 - Muted Amber
        def on_minimize():
            self._minimize_to_dock(name, frame)

        min_btn = ctk.CTkButton(
            btn_container, width=14, height=14,
            fg_color="#F59E0B", hover_color="#D97706",  # Amber 500/600
            text="", corner_radius=7, command=on_minimize
        )
        min_btn.grid(row=0, column=1, padx=4)

        # 줌 - Muted Green
        def on_zoom():
            self._toggle_zoom(name, frame)

        zoom_btn = ctk.CTkButton(
            btn_container, width=14, height=14,
            fg_color="#10B981", hover_color="#059669",  # Emerald 500/600
            text="", corner_radius=7, command=on_zoom
        )
        zoom_btn.grid(row=0, column=2, padx=4)

        # ---------------- 경로 표시 레이블 (버튼 우측) ----------------
        path_container = ctk.CTkFrame(bar, fg_color="transparent")
        path_container.pack(side="right", padx=(8, 16), pady=6)

        path_label = ctk.CTkLabel(path_container, text="", text_color="#9CA3AF", font=("SF Pro Display", 10))  # Gray 400
        path_label.pack(side="right")

        # 프레임에 레이블 참조 저장
        frame._path_label = path_label

        # ---------------- 헤더 드래그 이동 ----------------
        def start_move(event):
            frame.lift()
            frame._drag_start_x = event.x_root
            frame._drag_start_y = event.y_root
            info = frame.place_info()
            frame._orig_x = int(info.get("x", frame.winfo_x()))
            frame._orig_y = int(info.get("y", frame.winfo_y()))

        def do_move(event):
            # 축소 상태에서만 이동 가능
            if not self.frame_zoom_states.get(name, False):
                return
            dx = event.x_root - frame._drag_start_x
            dy = event.y_root - frame._drag_start_y
            frame.place_configure(x=frame._orig_x + dx, y=frame._orig_y + dy)

        bar.bind("<Button-1>", start_move)
        bar.bind("<B1-Motion>", do_move)
        bar.configure(cursor="fleur")

        # ---------------- 리사이즈 ZONE (축소 상태에서만) ----------------
        min_w, min_h = 500, 300
        edge_thickness = 6

        def start_resize(event, edge):
            # 축소 상태에서만 리사이즈 가능
            if not self.frame_zoom_states.get(name, False):
                return
            frame.lift()
            info = frame.place_info()
            frame._resize_start_x = event.x_root
            frame._resize_start_y = event.y_root
            frame._orig_x = int(info.get("x", frame.winfo_x()))
            frame._orig_y = int(info.get("y", frame.winfo_y()))
            frame._orig_w = frame.winfo_width()
            frame._orig_h = frame.winfo_height()
            frame._resize_edge = edge

        def do_resize(event):
            # 축소 상태에서만 리사이즈
            if not self.frame_zoom_states.get(name, False):
                return
            if not hasattr(frame, '_resize_edge'):
                return
                
            dx = event.x_root - frame._resize_start_x
            dy = event.y_root - frame._resize_start_y
            edge = frame._resize_edge
            x, y = frame._orig_x, frame._orig_y
            w, h = frame._orig_w, frame._orig_h

            if "e" in edge:
                w = max(min_w, frame._orig_w + dx)
            if "s" in edge:
                h = max(min_h, frame._orig_h + dy)
            if "w" in edge:
                new_w = max(min_w, frame._orig_w - dx)
                x = frame._orig_x + (frame._orig_w - new_w)
                w = new_w
            if "n" in edge:
                new_h = max(min_h, frame._orig_h - new_h)
                y = frame._orig_y + (frame._orig_h - new_h)
                h = new_h

            # CustomTkinter 호환: configure로 크기 변경 후 place
            try:
                frame.configure(width=w, height=h)
                frame.place_configure(x=x, y=y)
            except:
                pass  # 일부 위젯은 configure(width/height) 지원 안 함

        # 좌/우/상/하 및 코너 바인딩 (기존과 동일)
        left_zone = ctk.CTkFrame(frame, fg_color="transparent", width=edge_thickness)
        left_zone.place(relx=0, rely=0, relheight=1, anchor="nw")
        left_zone.bind("<Button-1>", lambda e: start_resize(e, "w"))
        left_zone.bind("<B1-Motion>", do_resize)
        left_zone.configure(cursor="sb_h_double_arrow")
        left_zone.lift()

        right_zone = ctk.CTkFrame(frame, fg_color="transparent", width=edge_thickness)
        right_zone.place(relx=1, rely=0, relheight=1, anchor="ne")
        right_zone.bind("<Button-1>", lambda e: start_resize(e, "e"))
        right_zone.bind("<B1-Motion>", do_resize)
        right_zone.configure(cursor="sb_h_double_arrow")
        right_zone.lift()

        top_zone = ctk.CTkFrame(frame, fg_color="transparent", height=edge_thickness)
        top_zone.place(relx=0, rely=0, relwidth=1, y=30)
        top_zone.bind("<Button-1>", lambda e: start_resize(e, "n"))
        top_zone.bind("<B1-Motion>", do_resize)
        top_zone.configure(cursor="sb_v_double_arrow")
        top_zone.lift()

        bottom_zone = ctk.CTkFrame(frame, fg_color="transparent", height=edge_thickness)
        bottom_zone.place(relx=0, rely=1, relwidth=1, anchor="sw")
        bottom_zone.bind("<Button-1>", lambda e: start_resize(e, "s"))
        bottom_zone.bind("<B1-Motion>", do_resize)
        bottom_zone.configure(cursor="sb_v_double_arrow")
        bottom_zone.lift()

        for edge, rx, ry, anc in [
            ("nw", 0, 0, "nw"),
            ("ne", 1, 0, "ne"),
            ("sw", 0, 1, "sw"),
            ("se", 1, 1, "se"),
        ]:
            corner = ctk.CTkFrame(frame, fg_color="transparent", width=edge_thickness, height=edge_thickness)
            corner.place(relx=rx, rely=ry, anchor=anc)
            corner.bind("<Button-1>", lambda e, ed=edge: start_resize(e, ed))
            corner.bind("<B1-Motion>", do_resize)
            corner.configure(cursor="sizing")
            corner.lift()

        frame._has_window_controls = True

    # ============================================================
    # 프레임 닫기 (dirty check 포함)
    # ============================================================
    def _close_frame(self, name):
        frame = self.frames.get(name)

        if frame and getattr(frame, "_is_dirty", False):
            result = messagebox.askyesnocancel(
                "변경 사항 저장",
                "변경된 내용이 있습니다. 저장하시겠습니까?"
            )
            if result is None:
                return
            if result is True:
                if hasattr(frame, "save"):
                    frame.save()
                frame._is_dirty = False

        if name in self.dock_buttons:
            self.dock_buttons[name].destroy()
            del self.dock_buttons[name]

        if name in self.frames:
            self.frames[name].destroy()
            del self.frames[name]

        if self.active_frame_name == name:
            self.active_frame = None
            self.active_frame_name = None

        if name in self.frame_zoom_states:
            del self.frame_zoom_states[name]

        if not self.frames:
            if not self.watermark_frame.winfo_ismapped():
                self.watermark_frame.pack(fill="both", expand=True)

    # ============================================================
    # 줌 토글 - 스마트 멀티 프레임 배치
    # ============================================================
    def _toggle_zoom(self, name, frame):
        """
        Zoom Toggle 로직:
        - zoom=False (전체 크기) → zoom=True (축소): 1/4 크기로 배치
        - zoom=True (축소) → zoom=False (전체): 다른 전체 프레임 최소화 후 전체 크기
        """
        current = self.frame_zoom_states.get(name, False)
        new_state = not current
        self.frame_zoom_states[name] = new_state

        if new_state:
            # Zoom ON → 1/4 크기로 축소 (스마트 배치)
            position = self._get_next_zoom_position(name)
            relx = (position % 2) * 0.5
            rely = (position // 2) * 0.5
            
            # relwidth/relheight 사용
            frame.place_configure(relx=relx, rely=rely, relwidth=0.5, relheight=0.5, x=0, y=0)
        else:
            # Zoom OFF → 전체 크기
            # 다른 전체 크기 프레임들은 최소화
            for other_name in list(self.frames.keys()):
                if other_name != name and other_name not in self.dock_buttons:
                    if not self.frame_zoom_states.get(other_name, False):
                        self._minimize_to_dock(other_name, self.frames[other_name])
            
            frame.place_configure(x=0, y=0, relx=0, rely=0, relwidth=1.0, relheight=1.0)
        
        frame.lift()
        self.active_frame = frame
        self.active_frame_name = name

    def _get_next_zoom_position(self, exclude_name):
        """축소된 프레임들의 다음 위치 (0=좌상, 1=우상, 2=좌하, 3=우하)"""
        used_positions = set()
        
        for name, frame in self.frames.items():
            if name == exclude_name:
                continue
            if name in self.dock_buttons:
                continue
            if self.frame_zoom_states.get(name, False):  # 축소된 프레임
                # 현재 위치 파악
                try:
                    info = frame.place_info()
                    x = int(info.get('x', 0))
                    y = int(info.get('y', 0))
                    
                    base_w = self.content_frame.winfo_width()
                    base_h = self.content_frame.winfo_height()
                    
                    col = 1 if x > base_w // 4 else 0
                    row = 1 if y > base_h // 4 else 0
                    pos = row * 2 + col
                    used_positions.add(pos)
                except:
                    pass
        
        # 빈 위치 찾기
        for pos in [0, 1, 2, 3]:
            if pos not in used_positions:
                return pos
        return 0  # 모두 사용 중이면 좌상단

    # ============================================================
    # SIDEBAR
    # ============================================================
    def _build_sidebar(self):
        # Import translation function and font helper
        try:
            from i18n import I18n, get_font, get_font_family
            t = I18n.t
            font_family = get_font_family()
        except ImportError:
            t = lambda x: x.split(".")[-1]
            font_family = "SF Pro Display"
        
        title = ctk.CTkLabel(
            self.sidebar_inner,
            text="DURUDURU",
            font=(font_family, 18, "bold"),
            text_color="#222222",
            anchor="w",
        )
        title.pack(fill="x", padx=16, pady=(16, 6))

        line = ctk.CTkFrame(self.sidebar_inner, fg_color="#DDDDDD", height=1)
        line.pack(fill="x", padx=12, pady=(0, 8))

        # Menu structure with i18n keys
        sections = [
            (t("menu.dashboard"), [
                (t("menu.dashboard"), "DASHBOARD", DashboardFrame if HAS_DASHBOARD else None),
            ]),
            (t("menu.registration"), [
                (t("menu.registration.ocean"), "OCEAN", OceanRegFrame),
                (t("menu.registration.air"), "AIR", AirRegFrame),
                (t("menu.registration.land"), "LAND", LandRegFrame),
            ]),
            (t("menu.quotation"), [
                (t("menu.quotation"), "QUOTATION", QuotationFrame if HAS_QUOTATION else None),
                ("📦 Vendor Quotes", "VENDOR_QUOTE", VendorQuoteFrame if HAS_VENDOR_QUOTE else None),
            ]),
            (t("menu.status"), [
                (t("menu.status.operation"), "OPERATION", OperationFrame),
                (t("menu.status.tracking"), "TRACKING", TrackingFrame if HAS_TRACKING else None),
                (t("menu.status.performance"), "PERFORMANCE", PerformanceFrame),
            ]),
            (t("menu.accounting"), [
                (t("menu.accounting"), "ACCOUNTING", AccountingFrame),
            ]),
            (t("menu.settlement"), [
                (t("menu.settlement"), "SETTLEMENT_MGMT", SettlementMgmtFrame),
            ]),
            (t("menu.settings"), [
                (t("menu.settings.customer"), "SETTINGS_CUSTOMERS", CustomerMgmtFrame),
                (t("menu.settings.port"), "SETTINGS_PORTS", PortMgmtFrame),
                (t("menu.settings.freight"), "SETTINGS_FREIGHT", FreightMgmtFrame),
                (t("menu.settings.automation"), "SETTINGS_AUTOMATION", AutomationSettingsFrame),
                (t("menu.settings.admin"), "SETTINGS_ADMIN", self._get_admin_frame),
            ]),
        ]

        for title_text, items in sections:
            self._add_section(title_text, items, font_family)

    def _add_section(self, title, items, font_family="SF Pro Display"):
        wrapper = ctk.CTkFrame(self.sidebar_inner, fg_color="transparent", height=2)
        wrapper.pack(fill="x")

        header = ctk.CTkLabel(
            wrapper,
            text=title.upper(),
            font=(font_family, 10, "bold"),
            text_color="#9CA3AF",  # Gray 400
            anchor="w",
        )
        header.pack(fill="x", padx=16, pady=0)

        header.bind("<Enter>", lambda e, h=header: h.configure(text_color="#374151"))  # Gray 700
        header.bind("<Leave>", lambda e, h=header: h.configure(text_color="#9CA3AF"))
        header.bind("<Button-1>", lambda e, t=title: self._on_header_click(t))

        self.section_headers[title] = header
        self.section_children[title] = []

        for text, name, frame_class in items:
            btn = ctk.CTkButton(
                self.sidebar_inner,
                text=text,
                font=(font_family, 13),
                fg_color="transparent",
                hover_color="#E5E7EB",  # Gray 200
                text_color="#374151",   # Gray 700
                anchor="w",
                corner_radius=6,
                height=28,
                command=lambda n=name, fc=frame_class: self.show_frame(n, fc),
            )
            btn._padx = 28
            self.section_children[title].append(btn)

        spacer = ctk.CTkFrame(self.sidebar_inner, fg_color="transparent", height=2)
        spacer.pack(fill="x")

    def _on_header_click(self, section_title):
        if self.expanded_section == section_title:
            self._collapse_section(section_title)
            return

        if self.expanded_section:
            self._collapse_section(self.expanded_section)

        self._expand_section(section_title)

    def _expand_section(self, section_title):
        header = self.section_headers.get(section_title)
        children = self.section_children.get(section_title, [])
        prev_widget = header

        for btn in children:
            btn.pack(fill="x", padx=btn._padx, pady=(0, 1), after=prev_widget)
            prev_widget = btn

        self.expanded_section = section_title

    def _collapse_section(self, section_title):
        for btn in self.section_children.get(section_title, []):
            btn.pack_forget()
        self.expanded_section = None
    
    def _rebuild_sidebar(self):
        """Rebuild sidebar with current language settings"""
        # Clear existing sidebar content
        for widget in self.sidebar_inner.winfo_children():
            widget.destroy()
        
        # Reset state
        self.section_headers = {}
        self.section_children = {}
        self.expanded_section = None
        self.menu_buttons = {}
        
        # Rebuild
        self._build_sidebar()
        print("✓ Sidebar rebuilt with new language")

    # ============================================================
    # FRAME SHOW / RESTORE / MINIMIZE - COMPLETE REWRITE
    # ============================================================
    def show_frame(self, name, frame_class):
        """
        프레임 표시 로직 (CustomTkinter 호환)
        
        CustomTkinter는 place(width=, height=)를 지원하지 않음
        → relwidth=1.0, relheight=1.0 사용
        """
        # Prevent concurrent creation
        if name in self._creating_frames:
            return

        try:
            self._creating_frames.add(name)

            if frame_class is None:
                return

            # Hide watermark
            if hasattr(self, "watermark_frame") and self.watermark_frame.winfo_ismapped():
                self.watermark_frame.pack_forget()

            # CASE 1: 독에 최소화된 상태 → 복원
            if name in self.dock_buttons:
                self._creating_frames.discard(name)
                self._restore_from_dock(name)
                return

            # CASE 2: 이미 존재하는 프레임 → 앞으로 가져오기
            if name in self.frames:
                frame = self.frames[name]
                
                # 다른 전체 크기 프레임들 최소화
                for other_name in list(self.frames.keys()):
                    if other_name != name and other_name not in self.dock_buttons:
                        if not self.frame_zoom_states.get(other_name, False):
                            self._minimize_to_dock(other_name, self.frames[other_name])
                
                # 이 프레임을 전체 크기로 표시 (relwidth/relheight 사용)
                frame.place(x=0, y=0, relwidth=1.0, relheight=1.0)
                frame.lift()
                
                self.active_frame = frame
                self.active_frame_name = name
                self.frame_zoom_states[name] = False
                
                if hasattr(frame, "_path_label"):
                    section = self._section_for_name(name)
                    frame._path_label.configure(text=f"{section} › {self._label_for_name(name)}")
                return

            # CASE 3: 새 프레임 생성
            self.update_idletasks()
            base_w = max(self.content_frame.winfo_width(), 800)
            base_h = max(self.content_frame.winfo_height(), 600)

            # 프레임 생성
            if callable(frame_class) and hasattr(frame_class, '__self__'):
                frame = frame_class(self.content_frame, width=base_w, height=base_h)
            else:
                frame = frame_class(self.content_frame, width=base_w, height=base_h)
            
            if frame is None:
                return
            
            frame._is_dirty = getattr(frame, "_is_dirty", False)

            # 저장
            self.frames[name] = frame
            self.frame_zoom_states[name] = False
            self._attach_frame_controls(frame, name)

            # 새 프레임을 먼저 표시 (relwidth/relheight 사용)
            frame.place(x=0, y=0, relwidth=1.0, relheight=1.0)
            frame.lift()
            
            self.active_frame = frame
            self.active_frame_name = name

            # 이제 다른 전체 크기 프레임들 최소화
            for other_name in list(self.frames.keys()):
                if other_name != name and other_name not in self.dock_buttons:
                    if not self.frame_zoom_states.get(other_name, False):
                        self._minimize_to_dock(other_name, self.frames[other_name])

            # 경로 레이블 업데이트
            if hasattr(frame, "_path_label"):
                section = self._section_for_name(name)
                frame._path_label.configure(text=f"{section} › {self._label_for_name(name)}")

        finally:
            self._creating_frames.discard(name)

    def _bring_frame_to_front(self, name):
        """기존 프레임을 앞으로 (show_frame에서 처리하므로 호출만)"""
        if name in self.frames:
            self.show_frame(name, None)  # frame_class는 None이어도 됨

    def _minimize_fullsize_frames(self, exclude=None):
        """전체 크기 프레임들 최소화 (더 이상 사용 안 함 - 호환성용)"""
        pass

    def _count_visible_frames(self):
        """현재 보이는 프레임 수"""
        count = 0
        for name, frame in self.frames.items():
            if name not in self.dock_buttons and frame.winfo_ismapped():
                count += 1
        return count

    def _has_fullsize_frame(self, exclude=None):
        """전체 크기 프레임이 있는지 확인"""
        for name in self.frames:
            if name == exclude:
                continue
            if name in self.dock_buttons:
                continue
            if not self.frame_zoom_states.get(name, False):  # zoom=False면 전체 크기
                return True
        return False

    def _minimize_active_frame(self, event=None):
        """Shift+ESC: 현재 활성화된 프레임 최소화"""
        if self.active_frame and self.active_frame_name:
            self._minimize_to_dock(self.active_frame_name, self.active_frame)
        return "break"

    def _minimize_to_dock(self, name, frame):
        # 현재 프레임의 배치 관리자와 geometry 저장
        geom = {}
        try:
            # pack인지 확인
            pack_info = frame.pack_info()
            geom["manager"] = "pack"
            geom["pack_info"] = pack_info
            geom["width"] = frame.winfo_width()
            geom["height"] = frame.winfo_height()
            # pack된 경우 pack_forget로 숨김
            frame.pack_forget()
        except Exception:
            # pack_info()가 예외면 pack으로 관리되지 않음 -> place로 가정
            place_info = frame.place_info()
            geom["manager"] = "place"
            geom["place_info"] = place_info
            geom["x"] = int(place_info.get("x", frame.winfo_x()))
            geom["y"] = int(place_info.get("y", frame.winfo_y()))
            geom["width"] = frame.winfo_width()
            geom["height"] = frame.winfo_height()
            frame.place_forget()

        # 안전하게 저장
        frame._last_geometry = geom

        if name in self.dock_buttons:
            return

        icon = self._icon_for_name(name)
        label = self._label_for_name(name)

        dock_text = f"{icon} {label}"
        if len(dock_text) > 12:
            dock_text = dock_text[:12]

        btn = ctk.CTkButton(
            self.dock_inner,
            text=dock_text,
            fg_color="#E5E5EA",
            hover_color="#D1D1D6",
            text_color="#333333",
            font=("SF Pro Display", 12),
            corner_radius=10,
            height=30,
            width=90,
            anchor="w",
            command=lambda n=name: self._restore_from_dock(n),
        )
        btn.pack(side="left", padx=4)

        self.dock_buttons[name] = btn

        if self.active_frame_name == name:
            self.active_frame = None
            self.active_frame_name = None

        if not any(f.winfo_ismapped() for f in self.frames.values()):
            if not self.watermark_frame.winfo_ismapped():
                self.watermark_frame.pack(fill="both", expand=True)

    def _restore_from_dock(self, name):
        """
        독에서 프레임 복원:
        - 복원되는 프레임은 전체 크기로 복원
        - 다른 전체 크기 프레임이 있으면 최소화
        """
        if name not in self.frames:
            return

        frame = self.frames[name]

        # 독 버튼 제거
        if name in self.dock_buttons:
            self.dock_buttons[name].destroy()
            del self.dock_buttons[name]

        # 워터마크 숨기기
        if self.watermark_frame.winfo_ismapped():
            self.watermark_frame.pack_forget()

        # 전체 화면으로 배치 (relwidth/relheight 사용)
        frame.place(x=0, y=0, relwidth=1.0, relheight=1.0)
        frame.lift()
        
        self.frame_zoom_states[name] = False
        self.active_frame = frame
        self.active_frame_name = name

        # 다른 전체 크기 프레임들 최소화
        for other_name in list(self.frames.keys()):
            if other_name != name and other_name not in self.dock_buttons:
                if not self.frame_zoom_states.get(other_name, False):
                    self._minimize_to_dock(other_name, self.frames[other_name])

    # ============================================================
    # ICON / LABEL
    # ============================================================
    def _icon_for_name(self, name):
        if name == "OCEAN": return "🛳"
        if name == "AIR": return "✈"
        if name == "LAND": return "🚚"
        if name == "OPERATION": return "📊"
        if name == "PERFORMANCE": return "📈"
        if name == "ACCOUNTING": return "💰"
        if name == "SETTLEMENT_MGMT": return "📑"
        if name == "SETTLEMENT_OUTSTANDING": return "📂"
        if name.startswith("SETTIN"): return "⚙"
        return "▢"

    def _label_for_name(self, name):
        mapping = {
            "OCEAN": "Ocean",
            "AIR": "Air",
            "LAND": "Land",
            "OPERATION": "Operation",
            "PERFORMANCE": "Performance",
            "ACCOUNTING": "Accounting",
            "SETTLEMENT_MGMT": "Settlement",
            "SETTINGS_CUSTOMERS": "Customers",
            "SETTINGS_PORTS": "Ports",
            "SETTINGS_OFFERS": "Offers",
            "SETTINGS_FREIGHT": "Freight",
            "SETTINGS_ADMIN": "Admin",
        }
        return mapping.get(name, name)

    def _section_for_name(self, name):
        """Return human-friendly section name for a frame key."""
        if name is None:
            return "UNKNOWN"
        if name.startswith("SETTINGS_"):
            return "SETTING"
        if name in ("OCEAN", "AIR", "LAND"):
            return "REGISTRATION"
        if name in ("OPERATION", "PERFORMANCE", "TRACKING"):
            return "STATUS"
        if name in ("ACCOUNTING",):
            return "ACCOUNTING"
        if name in ("SETTLEMENT_MGMT",):
            return "SETTLEMENT"
        if name in ("DASHBOARD",):
            return "DASHBOARD"
        if name in ("QUOTATION",):
            return "QUOTATION"
        return name.replace("_", " ").title()

    # ============================================================
    # KEYBOARD SHORTCUTS SYSTEM
    # ============================================================
    def _setup_keyboard_shortcuts(self):
        """Setup global keyboard shortcuts"""
        # 새 Job 등록 (Ctrl+N)
        self.bind("<Control-n>", lambda e: self.show_frame("OCEAN", OceanRegFrame))
        self.bind("<Control-N>", lambda e: self.show_frame("OCEAN", OceanRegFrame))
        
        # 저장 (Ctrl+S) - 현재 프레임의 save 메서드 호출
        self.bind("<Control-s>", self._shortcut_save)
        self.bind("<Control-S>", self._shortcut_save)
        
        # 검색 (Ctrl+F) - Operation 프레임 열기
        self.bind("<Control-f>", lambda e: self.show_frame("OPERATION", OperationFrame))
        self.bind("<Control-F>", lambda e: self.show_frame("OPERATION", OperationFrame))
        
        # 새로고침 (F5)
        self.bind("<F5>", self._shortcut_refresh)
        
        # Dashboard (Ctrl+D)
        self.bind("<Control-d>", lambda e: self.show_frame("DASHBOARD", DashboardFrame) if HAS_DASHBOARD else None)
        self.bind("<Control-D>", lambda e: self.show_frame("DASHBOARD", DashboardFrame) if HAS_DASHBOARD else None)
        
        # Accounting (Ctrl+A)
        self.bind("<Control-a>", lambda e: self.show_frame("ACCOUNTING", AccountingFrame))
        self.bind("<Control-A>", lambda e: self.show_frame("ACCOUNTING", AccountingFrame))
        
        # 단축키 도움말 (F1)
        self.bind("<F1>", self._show_shortcut_help)
        
        # Escape: 현재 프레임 닫기
        self.bind("<Escape>", self._shortcut_close)

    def _shortcut_save(self, event=None):
        """Ctrl+S: Save current frame"""
        if self.active_frame and hasattr(self.active_frame, 'save'):
            try:
                self.active_frame.save()
            except Exception as e:
                print(f"Save error: {e}")
        return "break"

    def _shortcut_refresh(self, event=None):
        """F5: Refresh current frame"""
        if self.active_frame:
            # Try various refresh method names
            for method_name in ['refresh', '_refresh', 'search', '_load_data', 'reload']:
                if hasattr(self.active_frame, method_name):
                    try:
                        getattr(self.active_frame, method_name)()
                        break
                    except:
                        pass
        return "break"

    def _shortcut_close(self, event=None):
        """Escape: Close or minimize current frame"""
        if self.active_frame_name:
            self._minimize_to_dock(self.active_frame_name, self.active_frame)
        return "break"

    def _show_shortcut_help(self, event=None):
        """F1: Show keyboard shortcuts help"""
        help_text = """
═══════════════════════════════════════
           KEYBOARD SHORTCUTS
═══════════════════════════════════════

Navigation:
  Ctrl+N      New Job Registration (Ocean)
  Ctrl+F      Search / Operation
  Ctrl+D      Dashboard
  Ctrl+A      Accounting

Actions:
  Ctrl+S      Save
  F5          Refresh
  Escape      Close/Minimize Frame
  Shift+Esc   Minimize Active Frame

Window:
  Ctrl+/-/0   Zoom In/Out/Reset
  Ctrl+Wheel  Mouse Zoom

Help:
  F1          This Help
═══════════════════════════════════════
"""
        messagebox.showinfo("Keyboard Shortcuts", help_text)
        return "break"


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='DURUDURU Freight Forwarding System')
    parser.add_argument('--skip-login', action='store_true', help='Skip login dialog (dev mode)')
    parser.add_argument('--reset-prefs', action='store_true', help='Reset login preferences')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    args = parser.parse_args()
    
    print("=" * 60)
    print("Starting DURUDURU application...")
    print("=" * 60)
    
    # Reset preferences if requested
    if args.reset_prefs:
        prefs_file = os.path.join(os.path.expanduser("~"), ".duruduru", "login_prefs.json")
        if os.path.exists(prefs_file):
            os.remove(prefs_file)
            print("✓ Login preferences reset")
    
    # Override HAS_AUTH if skip-login
    if args.skip_login:
        print("⚠ Running in DEV MODE (skip login)")
        HAS_AUTH = False
    
    try:
        app = MainApp()
        print("✓ MainApp created")
        print("Starting mainloop...")
        print("-" * 60)
        app.mainloop()
    except Exception as e:
        print(f"✗ Application error: {e}")
        import traceback
        traceback.print_exc()
        
        print("\n" + "=" * 60)
        print("문제 해결 방법:")
        print("=" * 60)
        print("""
1. 로그인 프레퍼런스 초기화:
   python3 main.py --reset-prefs

2. 로그인 없이 실행 (개발 모드):
   python3 main.py --skip-login

3. DB 초기화 후 재시작:
   rm -rf ~/.duruduru/duruduru.db
   python3 main.py

4. 테스트 스크립트 실행:
   python3 test_login.py
""")
        print(f"Application error: {e}")
        import traceback
        traceback.print_exc()