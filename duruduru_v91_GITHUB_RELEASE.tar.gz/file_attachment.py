# file_attachment.py
# File Attachment System for DURUDURU
# Supports: BL, Invoice, Packing List, etc.
# v37 - 2026-01-09

import os
import shutil
import hashlib
from datetime import datetime
from tkinter import filedialog, messagebox
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk

try:
    from db import get_connection, now_str
except ImportError:
    import sqlite3
    def get_connection():
        return sqlite3.connect("duruduru.db")
    def now_str():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =============================================================================
# CONFIGURATION
# =============================================================================
ATTACHMENT_DIR = os.path.join(os.path.expanduser("~"), ".duruduru", "attachments")

ALLOWED_EXTENSIONS = {
    "document": [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt"],
    "image": [".jpg", ".jpeg", ".png", ".gif", ".bmp"],
    "all": [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".zip", ".rar"]
}

FILE_TYPES = [
    "BL (Bill of Lading)",
    "Invoice",
    "Packing List",
    "Certificate of Origin",
    "Insurance",
    "Customs Declaration",
    "Delivery Order",
    "Other"
]

# Design tokens
class DS:
    PRIMARY = "#007AFF"
    SUCCESS = "#34C759"
    ERROR = "#FF3B30"
    BG = "#F5F5F7"
    SURFACE = "#FFFFFF"
    TEXT = "#1D1D1F"
    TEXT_SEC = "#86868B"
    FONT = "SF Pro Display"


# =============================================================================
# DATABASE
# =============================================================================
def ensure_attachment_table():
    """Create attachments table if not exists"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""CREATE TABLE IF NOT EXISTS attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER,
            job_no TEXT,
            file_type TEXT,
            original_name TEXT,
            stored_name TEXT,
            file_path TEXT,
            file_size INTEGER,
            mime_type TEXT,
            uploaded_by TEXT,
            created_at TEXT,
            notes TEXT
        )""")
        conn.commit()
    except Exception as e:
        print(f"Attachment table error: {e}")
    finally:
        conn.close()


def save_attachment(job_id, job_no, file_type, original_name, stored_name, 
                   file_path, file_size, mime_type="", uploaded_by="", notes=""):
    """Save attachment record to database"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""INSERT INTO attachments 
                      (job_id, job_no, file_type, original_name, stored_name, 
                       file_path, file_size, mime_type, uploaded_by, created_at, notes)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                   (job_id, job_no, file_type, original_name, stored_name,
                    file_path, file_size, mime_type, uploaded_by, now_str(), notes))
        conn.commit()
        return cur.lastrowid
    except Exception as e:
        print(f"Save attachment error: {e}")
        return None
    finally:
        conn.close()


def get_attachments(job_id=None, job_no=None):
    """Get attachments for a job"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        if job_id:
            cur.execute("""SELECT id, file_type, original_name, file_size, created_at, notes
                          FROM attachments WHERE job_id=? ORDER BY created_at DESC""", (job_id,))
        elif job_no:
            cur.execute("""SELECT id, file_type, original_name, file_size, created_at, notes
                          FROM attachments WHERE job_no=? ORDER BY created_at DESC""", (job_no,))
        else:
            return []
        return cur.fetchall()
    except Exception as e:
        print(f"Get attachments error: {e}")
        return []
    finally:
        conn.close()


def delete_attachment(attachment_id):
    """Delete attachment record and file"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Get file path
        cur.execute("SELECT file_path FROM attachments WHERE id=?", (attachment_id,))
        row = cur.fetchone()
        if row and row[0] and os.path.exists(row[0]):
            os.remove(row[0])
        
        cur.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
        conn.commit()
        return True
    except Exception as e:
        print(f"Delete attachment error: {e}")
        return False
    finally:
        conn.close()


# =============================================================================
# FILE OPERATIONS
# =============================================================================
def generate_stored_name(original_name, job_no):
    """Generate unique stored filename"""
    ext = os.path.splitext(original_name)[1]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    hash_part = hashlib.md5(f"{original_name}{timestamp}".encode()).hexdigest()[:8]
    return f"{job_no}_{timestamp}_{hash_part}{ext}"


def upload_file(job_id, job_no, file_type="Other", uploaded_by=""):
    """Open file dialog and upload file"""
    # Ensure directory exists
    os.makedirs(ATTACHMENT_DIR, exist_ok=True)
    
    # Open file dialog
    filetypes = [
        ("All Supported", "*.pdf *.doc *.docx *.xls *.xlsx *.jpg *.jpeg *.png"),
        ("PDF Files", "*.pdf"),
        ("Documents", "*.doc *.docx"),
        ("Spreadsheets", "*.xls *.xlsx"),
        ("Images", "*.jpg *.jpeg *.png"),
        ("All Files", "*.*")
    ]
    
    filepath = filedialog.askopenfilename(
        title="Select File to Attach",
        filetypes=filetypes
    )
    
    if not filepath:
        return None
    
    original_name = os.path.basename(filepath)
    stored_name = generate_stored_name(original_name, job_no or "TEMP")
    dest_path = os.path.join(ATTACHMENT_DIR, stored_name)
    
    try:
        # Copy file
        shutil.copy2(filepath, dest_path)
        file_size = os.path.getsize(dest_path)
        
        # Determine MIME type
        ext = os.path.splitext(original_name)[1].lower()
        mime_types = {
            ".pdf": "application/pdf",
            ".doc": "application/msword",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xls": "application/vnd.ms-excel",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png"
        }
        mime_type = mime_types.get(ext, "application/octet-stream")
        
        # Save to database
        attachment_id = save_attachment(
            job_id, job_no, file_type, original_name, stored_name,
            dest_path, file_size, mime_type, uploaded_by
        )
        
        return {
            "id": attachment_id,
            "original_name": original_name,
            "file_path": dest_path,
            "file_size": file_size
        }
        
    except Exception as e:
        messagebox.showerror("Error", f"Failed to upload file: {e}")
        return None


def open_file(attachment_id):
    """Open attachment file with default application"""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT file_path FROM attachments WHERE id=?", (attachment_id,))
        row = cur.fetchone()
        if row and row[0] and os.path.exists(row[0]):
            import subprocess
            import platform
            
            if platform.system() == "Darwin":  # macOS
                subprocess.call(["open", row[0]])
            elif platform.system() == "Windows":
                os.startfile(row[0])
            else:  # Linux
                subprocess.call(["xdg-open", row[0]])
            return True
        else:
            messagebox.showerror("Error", "File not found.")
            return False
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open file: {e}")
        return False
    finally:
        conn.close()


def format_file_size(size):
    """Format file size to human readable"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


# =============================================================================
# UI COMPONENT
# =============================================================================
class AttachmentPanel(ctk.CTkFrame):
    """Reusable attachment panel for job forms"""
    
    def __init__(self, parent, job_id=None, job_no=None):
        super().__init__(parent, fg_color=DS.SURFACE, corner_radius=8)
        
        self.job_id = job_id
        self.job_no = job_no
        
        ensure_attachment_table()
        self._build_ui()
        self._load_attachments()
    
    def _build_ui(self):
        # Header
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=12, pady=(12, 8))
        
        ctk.CTkLabel(header, text="📎 Attachments", font=(DS.FONT, 13, "bold"),
                    text_color=DS.TEXT).pack(side="left")
        
        # File type selector
        self.file_type_var = tk.StringVar(value="BL (Bill of Lading)")
        ttk.Combobox(header, textvariable=self.file_type_var, width=18, state="readonly",
                    values=FILE_TYPES).pack(side="right", padx=(8, 0))
        
        ctk.CTkButton(header, text="+ Add File", width=80, height=26,
                     fg_color=DS.PRIMARY, hover_color="#0056B3",
                     command=self._add_file).pack(side="right")
        
        # File list
        list_frame = ctk.CTkFrame(self, fg_color="transparent")
        list_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        
        cols = ("id", "type", "name", "size", "date")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=5)
        
        self.tree.heading("id", text="")
        self.tree.heading("type", text="Type")
        self.tree.heading("name", text="File Name")
        self.tree.heading("size", text="Size")
        self.tree.heading("date", text="Uploaded")
        
        self.tree.column("id", width=0, stretch=False)
        self.tree.column("type", width=100)
        self.tree.column("name", width=200)
        self.tree.column("size", width=70, anchor="e")
        self.tree.column("date", width=100)
        
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        
        self.tree.bind("<Double-1>", self._open_file)
        self.tree.bind("<Button-3>", self._show_context_menu)
    
    def _add_file(self):
        if not self.job_no:
            messagebox.showwarning("Warning", "Please save the job first before adding attachments.")
            return
        
        file_type = self.file_type_var.get()
        result = upload_file(self.job_id, self.job_no, file_type)
        
        if result:
            self._load_attachments()
            messagebox.showinfo("Success", f"File '{result['original_name']}' uploaded successfully.")
    
    def _load_attachments(self):
        self.tree.delete(*self.tree.get_children())
        
        attachments = get_attachments(self.job_id, self.job_no)
        
        for att in attachments:
            att_id, file_type, name, size, date, notes = att
            size_str = format_file_size(size) if size else "N/A"
            date_str = date[:10] if date else "N/A"
            
            self.tree.insert("", "end", values=(att_id, file_type or "Other", name, size_str, date_str))
    
    def _open_file(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        
        att_id = self.tree.item(sel[0], "values")[0]
        open_file(int(att_id))
    
    def _show_context_menu(self, event):
        sel = self.tree.identify_row(event.y)
        if not sel:
            return
        
        self.tree.selection_set(sel)
        
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="Open", command=self._open_file)
        menu.add_command(label="Delete", command=self._delete_file)
        menu.tk_popup(event.x_root, event.y_root)
    
    def _delete_file(self):
        sel = self.tree.selection()
        if not sel:
            return
        
        if not messagebox.askyesno("Confirm", "Delete this attachment?"):
            return
        
        att_id = self.tree.item(sel[0], "values")[0]
        if delete_attachment(int(att_id)):
            self._load_attachments()
            messagebox.showinfo("Deleted", "Attachment deleted.")
    
    def set_job(self, job_id, job_no):
        """Update job reference and reload attachments"""
        self.job_id = job_id
        self.job_no = job_no
        self._load_attachments()


# =============================================================================
# TEST
# =============================================================================
if __name__ == "__main__":
    ensure_attachment_table()
    
    root = ctk.CTk()
    root.title("Attachment Test")
    root.geometry("600x400")
    
    panel = AttachmentPanel(root, job_no="TEST001")
    panel.pack(fill="both", expand=True, padx=20, pady=20)
    
    root.mainloop()
