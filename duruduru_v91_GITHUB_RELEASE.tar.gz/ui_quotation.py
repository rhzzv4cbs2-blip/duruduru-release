# ui_quotation.py
# Customer Quotation Management - 고객 견적 관리
# Unified UI/UX Design v76

import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
from datetime import datetime, timedelta
from db import get_connection, now_str

# I18N
try:
    from i18n import I18n, get_font_family
    def _t(key): return I18n.t(key)
except ImportError:
    def _t(key): return key.split(".")[-1].replace("_", " ").title()
    def get_font_family(): return "SF Pro Display"

# Design Constants
COLORS = {
    "primary": "#374151",
    "success": "#059669", 
    "warning": "#F59E0B",
    "error": "#DC2626",
    "info": "#3B82F6",
    "bg": "#F9FAFB",
    "surface": "#FFFFFF",
    "text": "#1F2937",
    "text_secondary": "#6B7280",
    "border": "#E5E7EB"
}


class QuotationFrame(ctk.CTkFrame):
    """Customer Quotation Management - 고객 견적 관리"""
    
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color=COLORS["surface"], width=width, height=height)
        
        self.font = get_font_family()
        self.current_quote_id = None
        
        self._ensure_tables()
        self._build_ui()
        self._load_quotes()
    
    def _ensure_tables(self):
        """Ensure tables exist"""
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS quotes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    quote_no TEXT UNIQUE, date TEXT, valid_until TEXT,
                    customer_code TEXT, customer_name TEXT, contact_person TEXT, email TEXT, phone TEXT,
                    mode TEXT DEFAULT 'OCEAN', pol TEXT, pol_name TEXT, pod TEXT, pod_name TEXT,
                    commodity TEXT, terms TEXT DEFAULT 'CIF', remarks TEXT,
                    total_amount REAL DEFAULT 0, currency TEXT DEFAULT 'USD', status TEXT DEFAULT 'DRAFT',
                    created_at TEXT, updated_at TEXT
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS quote_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, quote_id INTEGER,
                    freight_code TEXT, description TEXT, unit TEXT DEFAULT 'B/L',
                    qty REAL DEFAULT 1, currency TEXT DEFAULT 'USD', rate REAL DEFAULT 0, amount REAL DEFAULT 0,
                    FOREIGN KEY (quote_id) REFERENCES quotes(id)
                )
            """)
            conn.commit()
        except Exception as e:
            print(f"Table error: {e}")
        finally:
            conn.close()
    
    def _build_ui(self):
        """Build UI"""
        # Spacer
        ctk.CTkFrame(self, fg_color="transparent", height=35).pack(fill="x")
        
        # Title Bar
        title_bar = ctk.CTkFrame(self, fg_color=COLORS["primary"], corner_radius=0, height=50)
        title_bar.pack(fill="x")
        title_bar.pack_propagate(False)
        
        ctk.CTkLabel(title_bar, text="📋 QUOTATION (고객 견적)", 
                    font=(self.font, 18, "bold"), text_color="white").pack(side="left", padx=20)
        
        btn_frame = ctk.CTkFrame(title_bar, fg_color="transparent")
        btn_frame.pack(side="right", padx=15)
        
        ctk.CTkButton(btn_frame, text="➕ New", width=80, fg_color=COLORS["success"],
                     command=self._new_quote).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📄 Copy", width=70, fg_color="#6B7280",
                     command=self._duplicate_quote).pack(side="left", padx=3)
        ctk.CTkButton(btn_frame, text="📥 PDF", width=70, fg_color=COLORS["warning"],
                     command=self._export_pdf).pack(side="left", padx=3)
        
        # Main Content
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=15, pady=10)
        
        # Left: List
        left = ctk.CTkFrame(main, fg_color=COLORS["bg"], width=380, corner_radius=8)
        left.pack(side="left", fill="y", padx=(0, 10))
        left.pack_propagate(False)
        
        # Search
        search_f = ctk.CTkFrame(left, fg_color="transparent")
        search_f.pack(fill="x", padx=10, pady=10)
        self.search_var = tk.StringVar()
        ctk.CTkEntry(search_f, textvariable=self.search_var, placeholder_text="🔍 Search...", width=280).pack(side="left")
        ctk.CTkButton(search_f, text="🔍", width=40, fg_color=COLORS["primary"], command=self._search).pack(side="right", padx=5)
        
        # Filter
        filter_f = ctk.CTkFrame(left, fg_color="transparent")
        filter_f.pack(fill="x", padx=10, pady=5)
        self.status_filter = tk.StringVar(value="All")
        for st, col in [("All", "#6B7280"), ("DRAFT", "#F59E0B"), ("SENT", "#3B82F6"), ("ACCEPTED", "#10B981"), ("REJECTED", "#EF4444")]:
            ctk.CTkButton(filter_f, text=st, width=65, height=26, fg_color=col if st != "All" else "#E5E7EB",
                         text_color="white" if st != "All" else "#374151",
                         command=lambda s=st: self._filter(s)).pack(side="left", padx=2)
        
        # Tree
        list_f = ctk.CTkFrame(left, fg_color=COLORS["surface"], corner_radius=8)
        list_f.pack(fill="both", expand=True, padx=10, pady=10)
        
        cols = ["no", "customer", "route", "total", "status"]
        self.tree = ttk.Treeview(list_f, columns=cols, show="headings", height=20)
        for c, h, w in [("no", "Quote#", 95), ("customer", "Customer", 95), ("route", "Route", 80), ("total", "Total", 65), ("status", "Status", 60)]:
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor="center" if c in ["total", "status"] else "w")
        
        vsb = ttk.Scrollbar(list_f, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        
        # Right: Detail
        right = ctk.CTkFrame(main, fg_color=COLORS["bg"], corner_radius=8)
        right.pack(side="right", fill="both", expand=True)
        self._build_detail(right)
    
    def _build_detail(self, parent):
        """Build detail panel"""
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Header
        hdr = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8)
        hdr.pack(fill="x", pady=(0, 10))
        h_in = ctk.CTkFrame(hdr, fg_color="transparent")
        h_in.pack(fill="x", padx=15, pady=12)
        
        ctk.CTkLabel(h_in, text="Quote#:").pack(side="left")
        self.quote_no_var = tk.StringVar()
        ctk.CTkEntry(h_in, textvariable=self.quote_no_var, width=130, state="readonly", fg_color="#F3F4F6").pack(side="left", padx=(5, 15))
        ctk.CTkLabel(h_in, text="Date:").pack(side="left")
        self.date_var = tk.StringVar()
        ctk.CTkEntry(h_in, textvariable=self.date_var, width=100).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(h_in, text="Valid:").pack(side="left")
        self.valid_var = tk.StringVar()
        ctk.CTkEntry(h_in, textvariable=self.valid_var, width=100).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(h_in, text="Status:").pack(side="left")
        self.status_var = tk.StringVar(value="DRAFT")
        ttk.Combobox(h_in, textvariable=self.status_var, values=["DRAFT", "SENT", "ACCEPTED", "REJECTED"], width=10).pack(side="left", padx=5)
        
        # Customer
        cust = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8)
        cust.pack(fill="x", pady=5)
        ctk.CTkLabel(cust, text="👤 Customer", font=(self.font, 12, "bold")).pack(anchor="w", padx=15, pady=(12, 8))
        c_in = ctk.CTkFrame(cust, fg_color="transparent")
        c_in.pack(fill="x", padx=15, pady=(0, 12))
        
        r1 = ctk.CTkFrame(c_in, fg_color="transparent")
        r1.pack(fill="x", pady=3)
        ctk.CTkLabel(r1, text="Code:", width=60, anchor="e").pack(side="left")
        self.cust_code = tk.StringVar()
        e = ctk.CTkEntry(r1, textvariable=self.cust_code, width=100)
        e.pack(side="left", padx=5)
        e.bind("<FocusOut>", self._on_cust_change)
        ctk.CTkLabel(r1, text="Name:", width=50, anchor="e").pack(side="left", padx=(10, 0))
        self.cust_name = tk.StringVar()
        ctk.CTkEntry(r1, textvariable=self.cust_name, width=250).pack(side="left", padx=5)
        
        r2 = ctk.CTkFrame(c_in, fg_color="transparent")
        r2.pack(fill="x", pady=3)
        ctk.CTkLabel(r2, text="Contact:", width=60, anchor="e").pack(side="left")
        self.contact = tk.StringVar()
        ctk.CTkEntry(r2, textvariable=self.contact, width=140).pack(side="left", padx=5)
        ctk.CTkLabel(r2, text="Email:", width=50, anchor="e").pack(side="left", padx=(10, 0))
        self.email = tk.StringVar()
        ctk.CTkEntry(r2, textvariable=self.email, width=170).pack(side="left", padx=5)
        ctk.CTkLabel(r2, text="Phone:", width=50, anchor="e").pack(side="left", padx=(10, 0))
        self.phone = tk.StringVar()
        ctk.CTkEntry(r2, textvariable=self.phone, width=110).pack(side="left", padx=5)
        
        # Route
        route = ctk.CTkFrame(scroll, fg_color="#FEF3C7", corner_radius=8)
        route.pack(fill="x", pady=5)
        rh = ctk.CTkFrame(route, fg_color="transparent")
        rh.pack(fill="x", padx=15, pady=(12, 5))
        ctk.CTkLabel(rh, text="🚢 Route", font=(self.font, 12, "bold")).pack(side="left")
        self.mode = tk.StringVar(value="OCEAN")
        ttk.Combobox(rh, textvariable=self.mode, values=["OCEAN", "AIR", "LAND", "MULTI"], width=10).pack(side="right")
        ctk.CTkLabel(rh, text="Mode:").pack(side="right", padx=5)
        
        r_in = ctk.CTkFrame(route, fg_color="transparent")
        r_in.pack(fill="x", padx=15, pady=(0, 12))
        
        fr = ctk.CTkFrame(r_in, fg_color="transparent")
        fr.pack(fill="x", pady=3)
        ctk.CTkLabel(fr, text="FROM:", font=(self.font, 11, "bold"), width=50).pack(side="left")
        self.pol = tk.StringVar()
        ctk.CTkEntry(fr, textvariable=self.pol, width=80, placeholder_text="Code").pack(side="left", padx=5)
        self.pol_name = tk.StringVar()
        ctk.CTkEntry(fr, textvariable=self.pol_name, width=250, placeholder_text="Port/City").pack(side="left", padx=5)
        
        ctk.CTkLabel(r_in, text="▼", font=(self.font, 14), text_color="#D97706").pack(pady=2)
        
        tr = ctk.CTkFrame(r_in, fg_color="transparent")
        tr.pack(fill="x", pady=3)
        ctk.CTkLabel(tr, text="TO:", font=(self.font, 11, "bold"), width=50).pack(side="left")
        self.pod = tk.StringVar()
        ctk.CTkEntry(tr, textvariable=self.pod, width=80, placeholder_text="Code").pack(side="left", padx=5)
        self.pod_name = tk.StringVar()
        ctk.CTkEntry(tr, textvariable=self.pod_name, width=250, placeholder_text="Port/City").pack(side="left", padx=5)
        
        ct = ctk.CTkFrame(r_in, fg_color="transparent")
        ct.pack(fill="x", pady=5)
        ctk.CTkLabel(ct, text="Commodity:").pack(side="left")
        self.commodity = tk.StringVar()
        ctk.CTkEntry(ct, textvariable=self.commodity, width=200).pack(side="left", padx=5)
        ctk.CTkLabel(ct, text="Terms:").pack(side="left", padx=(15, 0))
        self.terms = tk.StringVar(value="CIF")
        ttk.Combobox(ct, textvariable=self.terms, values=["FOB", "CIF", "CFR", "EXW", "DDP", "DAP"], width=8).pack(side="left", padx=5)
        
        # Charges
        charges = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8)
        charges.pack(fill="x", pady=5)
        ch = ctk.CTkFrame(charges, fg_color="transparent")
        ch.pack(fill="x", padx=15, pady=(12, 8))
        ctk.CTkLabel(ch, text="💰 Charges", font=(self.font, 12, "bold")).pack(side="left")
        ctk.CTkButton(ch, text="➕", width=40, height=26, fg_color=COLORS["success"], command=self._add_item).pack(side="right")
        ctk.CTkButton(ch, text="➖", width=40, height=26, fg_color=COLORS["error"], command=self._del_item).pack(side="right", padx=5)
        ctk.CTkButton(ch, text="📊 View Cost", width=85, height=26, fg_color="#1E40AF", command=self._view_vendor_cost).pack(side="right", padx=5)
        
        it_f = ctk.CTkFrame(charges, fg_color="#F9FAFB", corner_radius=4)
        it_f.pack(fill="x", padx=15, pady=(0, 10))
        cols = ["id", "code", "desc", "unit", "qty", "curr", "rate", "amt"]
        self.items = ttk.Treeview(it_f, columns=cols, show="headings", height=6)
        for c, h, w in [("id", "#", 30), ("code", "CODE", 60), ("desc", "DESCRIPTION", 180), ("unit", "UNIT", 50), ("qty", "QTY", 40), ("curr", "CURR", 50), ("rate", "RATE", 80), ("amt", "AMOUNT", 90)]:
            self.items.heading(c, text=h)
            self.items.column(c, width=w, anchor="center" if c != "desc" else "w")
        self.items.column("id", width=0, stretch=False)
        self.items.pack(fill="x", padx=5, pady=5)
        self.items.bind("<Double-1>", lambda e: (self._del_item(), self._add_item()))
        
        tot = ctk.CTkFrame(charges, fg_color="#DBEAFE", corner_radius=4)
        tot.pack(fill="x", padx=15, pady=(0, 12))
        ctk.CTkLabel(tot, text="TOTAL:", font=(self.font, 13, "bold")).pack(side="left", padx=15, pady=10)
        self.total_lbl = ctk.CTkLabel(tot, text="$0.00", font=(self.font, 16, "bold"), text_color=COLORS["primary"])
        self.total_lbl.pack(side="right", padx=15, pady=10)
        
        # Remarks
        rem = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8)
        rem.pack(fill="x", pady=5)
        ctk.CTkLabel(rem, text="📝 Remarks", font=(self.font, 12, "bold")).pack(anchor="w", padx=15, pady=(12, 5))
        self.remarks = ctk.CTkTextbox(rem, height=60)
        self.remarks.pack(fill="x", padx=15, pady=(0, 12))
        
        # Actions
        act = ctk.CTkFrame(scroll, fg_color="transparent")
        act.pack(fill="x", pady=10)
        ctk.CTkButton(act, text="💾 Save", width=100, height=36, fg_color=COLORS["success"], command=self._save).pack(side="right", padx=5)
        ctk.CTkButton(act, text="🗑 Delete", width=90, height=36, fg_color=COLORS["error"], command=self._delete).pack(side="right", padx=5)
        ctk.CTkButton(act, text="📧 Send", width=90, height=36, fg_color=COLORS["info"], command=self._send).pack(side="right", padx=5)
    
    # ===== Methods =====
    def _load_quotes(self, status="All", search=""):
        for i in self.tree.get_children(): self.tree.delete(i)
        conn = get_connection()
        cur = conn.cursor()
        try:
            q = "SELECT id, quote_no, customer_name, pol, pod, total_amount, status FROM quotes WHERE 1=1"
            p = []
            if status != "All": q += " AND status=?"; p.append(status)
            if search: q += " AND (quote_no LIKE ? OR customer_name LIKE ?)"; p.extend([f"%{search}%"]*2)
            q += " ORDER BY date DESC"
            cur.execute(q, p)
            for r in cur.fetchall():
                route = f"{r[3] or '?'}→{r[4] or '?'}"
                self.tree.insert("", "end", iid=str(r[0]), values=(r[1], r[2] or "", route, f"${r[5]:,.0f}" if r[5] else "$0", r[6]))
        except Exception as e: print(f"Load error: {e}")
        finally: conn.close()
    
    def _search(self): self._load_quotes(self.status_filter.get(), self.search_var.get())
    def _filter(self, s): self.status_filter.set(s); self._load_quotes(s, self.search_var.get())
    def _on_select(self, e):
        s = self.tree.selection()
        if s: self._load_detail(int(s[0]))
    
    def _load_detail(self, qid):
        self.current_quote_id = qid
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("SELECT quote_no, date, valid_until, customer_code, customer_name, contact_person, email, phone, mode, pol, pol_name, pod, pod_name, commodity, terms, remarks, total_amount, status FROM quotes WHERE id=?", (qid,))
            r = cur.fetchone()
            if r:
                self.quote_no_var.set(r[0] or ""); self.date_var.set(r[1] or ""); self.valid_var.set(r[2] or "")
                self.cust_code.set(r[3] or ""); self.cust_name.set(r[4] or ""); self.contact.set(r[5] or "")
                self.email.set(r[6] or ""); self.phone.set(r[7] or ""); self.mode.set(r[8] or "OCEAN")
                self.pol.set(r[9] or ""); self.pol_name.set(r[10] or ""); self.pod.set(r[11] or "")
                self.pod_name.set(r[12] or ""); self.commodity.set(r[13] or ""); self.terms.set(r[14] or "CIF")
                self.remarks.delete("1.0", "end"); self.remarks.insert("1.0", r[15] or "")
                self.total_lbl.configure(text=f"${r[16]:,.2f}" if r[16] else "$0.00"); self.status_var.set(r[17] or "DRAFT")
            for i in self.items.get_children(): self.items.delete(i)
            cur.execute("SELECT id, freight_code, description, unit, qty, currency, rate, amount FROM quote_items WHERE quote_id=?", (qid,))
            for r in cur.fetchall(): self.items.insert("", "end", values=(r[0], r[1], r[2], r[3], r[4], r[5], f"{r[6]:,.2f}", f"{r[7]:,.2f}"))
            self._update_total()
        except Exception as e: print(f"Detail error: {e}")
        finally: conn.close()
    
    def _new_quote(self):
        self.current_quote_id = None
        conn = get_connection()
        cur = conn.cursor()
        try:
            ym = datetime.now().strftime("%Y%m")
            cur.execute("SELECT COUNT(*) FROM quotes WHERE quote_no LIKE ?", (f"QT-{ym}%",))
            n = cur.fetchone()[0] + 1
            qno = f"QT-{ym}-{n:04d}"
        except: qno = f"QT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        finally: conn.close()
        
        self.quote_no_var.set(qno); self.date_var.set(datetime.now().strftime("%Y-%m-%d"))
        self.valid_var.set((datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d"))
        for v in [self.cust_code, self.cust_name, self.contact, self.email, self.phone, self.pol, self.pol_name, self.pod, self.pod_name, self.commodity]: v.set("")
        self.mode.set("OCEAN"); self.terms.set("CIF"); self.status_var.set("DRAFT")
        self.remarks.delete("1.0", "end"); self.total_lbl.configure(text="$0.00")
        for i in self.items.get_children(): self.items.delete(i)
    
    def _save(self):
        conn = get_connection()
        cur = conn.cursor()
        try:
            rem = self.remarks.get("1.0", "end").strip()
            total = sum(float(str(self.items.item(i, "values")[7]).replace(",", "") or 0) for i in self.items.get_children())
            if self.current_quote_id:
                cur.execute("UPDATE quotes SET date=?, valid_until=?, customer_code=?, customer_name=?, contact_person=?, email=?, phone=?, mode=?, pol=?, pol_name=?, pod=?, pod_name=?, commodity=?, terms=?, remarks=?, total_amount=?, status=?, updated_at=? WHERE id=?",
                           (self.date_var.get(), self.valid_var.get(), self.cust_code.get(), self.cust_name.get(), self.contact.get(), self.email.get(), self.phone.get(), self.mode.get(), self.pol.get(), self.pol_name.get(), self.pod.get(), self.pod_name.get(), self.commodity.get(), self.terms.get(), rem, total, self.status_var.get(), now_str(), self.current_quote_id))
            else:
                cur.execute("INSERT INTO quotes (quote_no, date, valid_until, customer_code, customer_name, contact_person, email, phone, mode, pol, pol_name, pod, pod_name, commodity, terms, remarks, total_amount, currency, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'USD', ?, ?, ?)",
                           (self.quote_no_var.get(), self.date_var.get(), self.valid_var.get(), self.cust_code.get(), self.cust_name.get(), self.contact.get(), self.email.get(), self.phone.get(), self.mode.get(), self.pol.get(), self.pol_name.get(), self.pod.get(), self.pod_name.get(), self.commodity.get(), self.terms.get(), rem, total, self.status_var.get(), now_str(), now_str()))
                self.current_quote_id = cur.lastrowid
            conn.commit(); self._load_quotes(); messagebox.showinfo("Saved", "Quote saved!")
        except Exception as e: messagebox.showerror("Error", str(e))
        finally: conn.close()
    
    def _delete(self):
        if not self.current_quote_id: return
        if not messagebox.askyesno("Confirm", "Delete this quote?"): return
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("DELETE FROM quote_items WHERE quote_id=?", (self.current_quote_id,))
            cur.execute("DELETE FROM quotes WHERE id=?", (self.current_quote_id,))
            conn.commit(); self._new_quote(); self._load_quotes()
        except Exception as e: messagebox.showerror("Error", str(e))
        finally: conn.close()
    
    def _duplicate_quote(self):
        s = self.tree.selection()
        if not s: messagebox.showwarning("Select", "Select a quote"); return
        self._load_detail(int(s[0]))
        conn = get_connection()
        cur = conn.cursor()
        try:
            ym = datetime.now().strftime("%Y%m")
            cur.execute("SELECT COUNT(*) FROM quotes WHERE quote_no LIKE ?", (f"QT-{ym}%",))
            n = cur.fetchone()[0] + 1
            qno = f"QT-{ym}-{n:04d}"
        except: qno = f"QT-COPY"
        finally: conn.close()
        self.current_quote_id = None; self.quote_no_var.set(qno); self.status_var.set("DRAFT")
        messagebox.showinfo("Copied", f"Duplicated as {qno}")
    
    def _send(self):
        if not self.current_quote_id: return
        self.status_var.set("SENT"); self._save()
    
    def _export_pdf(self): messagebox.showinfo("PDF", "Coming soon")
    
    def _add_item(self):
        if not self.current_quote_id: messagebox.showwarning("Save First", "Save quote first"); return
        dlg = ctk.CTkToplevel(self); dlg.title("Add Charge"); dlg.geometry("400x300"); dlg.transient(self); dlg.grab_set()
        f = ctk.CTkFrame(dlg, fg_color="transparent"); f.pack(fill="both", expand=True, padx=20, pady=15)
        
        ctk.CTkLabel(f, text="Code:").grid(row=0, column=0, sticky="e", pady=6)
        code = tk.StringVar()
        ttk.Combobox(f, textvariable=code, values=["OFR", "AFR", "THC", "DOC", "CFS", "DEL", "CUS", "OTH"], width=12).grid(row=0, column=1, sticky="w", pady=6)
        ctk.CTkLabel(f, text="Desc:").grid(row=1, column=0, sticky="e", pady=6)
        desc = tk.StringVar(); ctk.CTkEntry(f, textvariable=desc, width=220).grid(row=1, column=1, sticky="w", pady=6)
        ctk.CTkLabel(f, text="Unit:").grid(row=2, column=0, sticky="e", pady=6)
        unit = tk.StringVar(value="B/L"); ttk.Combobox(f, textvariable=unit, values=["B/L", "CNTR", "CBM", "KG"], width=10).grid(row=2, column=1, sticky="w", pady=6)
        ctk.CTkLabel(f, text="Qty:").grid(row=3, column=0, sticky="e", pady=6)
        qty = tk.StringVar(value="1"); ctk.CTkEntry(f, textvariable=qty, width=80).grid(row=3, column=1, sticky="w", pady=6)
        ctk.CTkLabel(f, text="Curr:").grid(row=4, column=0, sticky="e", pady=6)
        curr = tk.StringVar(value="USD"); ttk.Combobox(f, textvariable=curr, values=["USD", "MXN"], width=8).grid(row=4, column=1, sticky="w", pady=6)
        ctk.CTkLabel(f, text="Rate:").grid(row=5, column=0, sticky="e", pady=6)
        rate = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=rate, width=100).grid(row=5, column=1, sticky="w", pady=6)
        
        def save():
            try:
                q, r = float(qty.get() or 1), float(rate.get() or 0)
                conn = get_connection(); cur = conn.cursor()
                cur.execute("INSERT INTO quote_items (quote_id, freight_code, description, unit, qty, currency, rate, amount) VALUES (?,?,?,?,?,?,?,?)",
                           (self.current_quote_id, code.get(), desc.get(), unit.get(), q, curr.get(), r, q*r))
                conn.commit(); conn.close(); self._load_detail(self.current_quote_id); dlg.destroy()
            except Exception as e: messagebox.showerror("Error", str(e))
        
        bf = ctk.CTkFrame(dlg, fg_color="transparent"); bf.pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(bf, text="Save", width=80, fg_color=COLORS["success"], command=save).pack(side="right", padx=5)
        ctk.CTkButton(bf, text="Cancel", width=80, fg_color="#6B7280", command=dlg.destroy).pack(side="right", padx=5)
    
    def _del_item(self):
        s = self.items.selection()
        if not s: return
        iid = self.items.item(s[0], "values")[0]
        if iid:
            conn = get_connection(); cur = conn.cursor()
            cur.execute("DELETE FROM quote_items WHERE id=?", (iid,))
            conn.commit(); conn.close()
        self.items.delete(s[0]); self._update_total()
    
    def _update_total(self):
        t = sum(float(str(self.items.item(i, "values")[7]).replace(",", "") or 0) for i in self.items.get_children())
        self.total_lbl.configure(text=f"${t:,.2f}")
    
    def _on_cust_change(self, e):
        code = self.cust_code.get()
        if not code: return
        conn = get_connection(); cur = conn.cursor()
        try:
            cur.execute("SELECT name, contact, phone, email FROM companies WHERE code=?", (code,))
            r = cur.fetchone()
            if r: self.cust_name.set(r[0] or ""); self.contact.set(r[1] or ""); self.phone.set(r[2] or ""); self.email.set(r[3] or "")
        except: pass
        finally: conn.close()
    
    def _view_vendor_cost(self):
        """View vendor cost comparison"""
        pol = self.pol.get()
        pod = self.pod.get()
        
        if not pol or not pod:
            messagebox.showwarning("Route Required", "Please enter FROM/TO route first")
            return
        
        # Create dialog
        dlg = ctk.CTkToplevel(self)
        dlg.title("📊 Vendor Cost Reference")
        dlg.geometry("750x550")
        dlg.transient(self)
        dlg.grab_set()
        
        # Header
        hdr = ctk.CTkFrame(dlg, fg_color="#1E40AF", corner_radius=0, height=50)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        ctk.CTkLabel(hdr, text="📊 Vendor Cost Reference (원가 참조)", font=(self.font, 16, "bold"), 
                    text_color="white").pack(side="left", padx=20)
        ctk.CTkLabel(hdr, text=f"Route: {pol} → {pod}", font=(self.font, 12), 
                    text_color="#93C5FD").pack(side="right", padx=20)
        
        # Vendor selection
        sel_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        sel_frame.pack(fill="x", padx=20, pady=15)
        
        ctk.CTkLabel(sel_frame, text="Vendor Quote:").pack(side="left")
        vendor_var = tk.StringVar()
        vendor_combo = ttk.Combobox(sel_frame, textvariable=vendor_var, width=40)
        vendor_combo.pack(side="left", padx=10)
        
        ctk.CTkLabel(sel_frame, text="Container:").pack(side="left", padx=(20, 0))
        cntr_var = tk.StringVar(value="40HQ")
        cntr_combo = ttk.Combobox(sel_frame, textvariable=cntr_var, values=["20GP", "40GP", "40HQ", "CBM", "B/L"], width=8)
        cntr_combo.pack(side="left", padx=5)
        
        # Load vendor quotes
        vq_map = {}
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""
                SELECT id, quote_ref, vendor_name FROM vendor_quotes 
                WHERE status='ACTIVE' AND (origin_port LIKE ? OR ?='') AND (dest_port LIKE ? OR ?='')
            """, (f"%{pol}%", pol, f"%{pod}%", pod))
            vq_list = []
            for r in cur.fetchall():
                label = f"{r[1]} - {r[2]}"
                vq_list.append(label)
                vq_map[label] = r[0]
            vendor_combo['values'] = vq_list
            if vq_list:
                vendor_combo.current(0)
        except Exception as e:
            print(f"Load vendor quotes error: {e}")
        finally:
            conn.close()
        
        # Comparison table
        table_frame = ctk.CTkFrame(dlg, fg_color="#FFFFFF", corner_radius=8)
        table_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        cols = ["code", "desc", "cost", "your", "profit", "margin"]
        comp_tree = ttk.Treeview(table_frame, columns=cols, show="headings", height=12)
        for c, h, w in [("code", "CODE", 60), ("desc", "DESCRIPTION", 180), ("cost", "VENDOR COST", 100), 
                       ("your", "YOUR PRICE", 100), ("profit", "PROFIT", 90), ("margin", "MARGIN", 70)]:
            comp_tree.heading(c, text=h)
            comp_tree.column(c, width=w, anchor="center" if c != "desc" else "w")
        
        comp_tree.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Summary
        sum_frame = ctk.CTkFrame(dlg, fg_color="#E8F5E9", corner_radius=8)
        sum_frame.pack(fill="x", padx=20, pady=10)
        
        sum_inner = ctk.CTkFrame(sum_frame, fg_color="transparent")
        sum_inner.pack(fill="x", padx=15, pady=10)
        
        total_cost_lbl = ctk.CTkLabel(sum_inner, text="Total Cost: $0", font=(self.font, 12))
        total_cost_lbl.pack(side="left", padx=10)
        total_price_lbl = ctk.CTkLabel(sum_inner, text="Your Total: $0", font=(self.font, 12))
        total_price_lbl.pack(side="left", padx=10)
        total_profit_lbl = ctk.CTkLabel(sum_inner, text="Profit: $0", font=(self.font, 14, "bold"), text_color="#2E7D32")
        total_profit_lbl.pack(side="right", padx=10)
        total_margin_lbl = ctk.CTkLabel(sum_inner, text="Margin: 0%", font=(self.font, 12))
        total_margin_lbl.pack(side="right", padx=10)
        
        def refresh_comparison(*args):
            # Clear tree
            for i in comp_tree.get_children():
                comp_tree.delete(i)
            
            vq_label = vendor_var.get()
            if not vq_label or vq_label not in vq_map:
                return
            
            vq_id = vq_map[vq_label]
            cntr_type = cntr_var.get()
            rate_col = {"20GP": "rate_20gp", "40GP": "rate_40gp", "40HQ": "rate_40hq", 
                       "CBM": "rate_cbm", "B/L": "rate_bl"}.get(cntr_type, "rate_40hq")
            
            # Get vendor costs
            conn = get_connection()
            cur = conn.cursor()
            cost_map = {}
            try:
                cur.execute(f"SELECT freight_code, description, {rate_col} FROM vendor_quote_items WHERE vq_id=?", (vq_id,))
                for r in cur.fetchall():
                    cost_map[r[0]] = (r[1], r[2] or 0)
            except Exception as e:
                print(f"Get vendor items error: {e}")
            finally:
                conn.close()
            
            # Get my quote items
            my_items = {}
            for item in self.items.get_children():
                vals = self.items.item(item, "values")
                code = vals[1]
                rate = float(str(vals[7]).replace(",", "") or 0)
                my_items[code] = (vals[2], rate)
            
            # Compare
            all_codes = set(cost_map.keys()) | set(my_items.keys())
            total_cost = 0
            total_price = 0
            
            for code in sorted(all_codes):
                cost_desc, cost_rate = cost_map.get(code, ("", 0))
                my_desc, my_rate = my_items.get(code, ("", 0))
                
                desc = my_desc or cost_desc or code
                profit = my_rate - cost_rate
                margin = (profit / my_rate * 100) if my_rate > 0 else 0
                
                cost_str = f"${cost_rate:,.0f}" if cost_rate > 0 else "-"
                my_str = f"${my_rate:,.0f}" if my_rate > 0 else "-"
                profit_str = f"+${profit:,.0f}" if profit >= 0 else f"-${abs(profit):,.0f}"
                margin_str = f"{margin:.1f}%"
                
                # Color tag based on margin
                tag = "good" if margin >= 20 else ("warn" if margin >= 10 else "bad")
                comp_tree.insert("", "end", values=(code, desc, cost_str, my_str, profit_str, margin_str), tags=(tag,))
                
                total_cost += cost_rate
                total_price += my_rate
            
            # Configure tags
            comp_tree.tag_configure("good", foreground="#2E7D32")
            comp_tree.tag_configure("warn", foreground="#F57C00")
            comp_tree.tag_configure("bad", foreground="#C62828")
            
            # Update summary
            total_profit = total_price - total_cost
            total_margin = (total_profit / total_price * 100) if total_price > 0 else 0
            
            total_cost_lbl.configure(text=f"Total Cost: ${total_cost:,.0f}")
            total_price_lbl.configure(text=f"Your Total: ${total_price:,.0f}")
            total_profit_lbl.configure(text=f"Profit: ${total_profit:,.0f}")
            total_margin_lbl.configure(text=f"Margin: {total_margin:.1f}%")
            
            if total_profit >= 0:
                total_profit_lbl.configure(text_color="#2E7D32")
            else:
                total_profit_lbl.configure(text_color="#C62828")
        
        vendor_combo.bind("<<ComboboxSelected>>", refresh_comparison)
        cntr_combo.bind("<<ComboboxSelected>>", refresh_comparison)
        
        # Initial load
        refresh_comparison()
        
        # Buttons
        btn_frame = ctk.CTkFrame(dlg, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(btn_frame, text="Close", width=80, fg_color="#6B7280", command=dlg.destroy).pack(side="right")

