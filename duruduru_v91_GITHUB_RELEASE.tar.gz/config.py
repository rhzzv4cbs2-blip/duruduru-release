# config.py
# Unified Configuration Module for DURUDURU
# Single source of truth for all styling, performance settings, and constants

"""
DURUDURU Configuration
======================
Centralized configuration for consistent UI and optimized performance.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional


# =============================================================================
# TYPOGRAPHY
# =============================================================================

@dataclass(frozen=True)
class Typography:
    """Unified font settings"""
    
    # Font families
    FONT_FAMILY: str = "SF Pro Display"
    FONT_FAMILY_MONO: str = "SF Mono"
    FONT_FAMILY_FALLBACK: str = "Helvetica"
    
    # Font sizes
    SIZE_XS: int = 10
    SIZE_SM: int = 11
    SIZE_BASE: int = 12
    SIZE_MD: int = 13
    SIZE_LG: int = 14
    SIZE_XL: int = 16
    SIZE_2XL: int = 18
    SIZE_3XL: int = 20
    SIZE_4XL: int = 24
    
    # Common font tuples
    @property
    def TITLE(self) -> Tuple[str, int, str]:
        return (self.FONT_FAMILY, self.SIZE_3XL, "bold")
    
    @property
    def HEADER(self) -> Tuple[str, int, str]:
        return (self.FONT_FAMILY, self.SIZE_XL, "bold")
    
    @property
    def SUBHEADER(self) -> Tuple[str, int, str]:
        return (self.FONT_FAMILY, self.SIZE_LG, "bold")
    
    @property
    def BODY(self) -> Tuple[str, int]:
        return (self.FONT_FAMILY, self.SIZE_BASE)
    
    @property
    def SMALL(self) -> Tuple[str, int]:
        return (self.FONT_FAMILY, self.SIZE_SM)
    
    @property
    def LABEL(self) -> Tuple[str, int]:
        return (self.FONT_FAMILY, self.SIZE_SM)
    
    @property
    def BUTTON(self) -> Tuple[str, int]:
        return (self.FONT_FAMILY, self.SIZE_BASE)


FONTS = Typography()


# =============================================================================
# COLOR PALETTE
# =============================================================================

@dataclass(frozen=True)
class Colors:
    """Unified color palette"""
    
    # Primary
    PRIMARY: str = "#1565C0"
    PRIMARY_DARK: str = "#0D47A1"
    PRIMARY_LIGHT: str = "#42A5F5"
    
    # Secondary
    SECONDARY: str = "#424242"
    SECONDARY_DARK: str = "#212121"
    SECONDARY_LIGHT: str = "#757575"
    
    # Accent
    ACCENT: str = "#FF9800"
    ACCENT_DARK: str = "#F57C00"
    
    # Semantic
    SUCCESS: str = "#4CAF50"
    SUCCESS_DARK: str = "#388E3C"
    SUCCESS_BG: str = "#E8F5E9"
    
    WARNING: str = "#FF9800"
    WARNING_DARK: str = "#F57C00"
    WARNING_BG: str = "#FFF3E0"
    
    ERROR: str = "#F44336"
    ERROR_DARK: str = "#D32F2F"
    ERROR_BG: str = "#FFEBEE"
    
    INFO: str = "#2196F3"
    INFO_BG: str = "#E3F2FD"
    
    # Business
    REVENUE: str = "#1565C0"
    REVENUE_BG: str = "#E3F2FD"
    COST: str = "#C62828"
    COST_BG: str = "#FFEBEE"
    PROFIT: str = "#2E7D32"
    PROFIT_BG: str = "#E8F5E9"
    
    # Neutrals
    WHITE: str = "#FFFFFF"
    BACKGROUND: str = "#F5F5F5"
    SURFACE: str = "#FFFFFF"
    SURFACE_ALT: str = "#FAFAFA"
    
    # Text
    TEXT_PRIMARY: str = "#212121"
    TEXT_SECONDARY: str = "#757575"
    TEXT_TERTIARY: str = "#9E9E9E"
    TEXT_INVERSE: str = "#FFFFFF"
    
    # Borders
    BORDER: str = "#E0E0E0"
    BORDER_LIGHT: str = "#EEEEEE"
    BORDER_DARK: str = "#BDBDBD"
    BORDER_FOCUS: str = "#1565C0"
    
    # Status
    STATUS_OPEN: str = "#4CAF50"
    STATUS_TRANSIT: str = "#FF9800"
    STATUS_ARRIVED: str = "#2196F3"
    STATUS_DELIVERED: str = "#1565C0"
    STATUS_CLOSED: str = "#9E9E9E"


COLORS = Colors()


# =============================================================================
# SPACING
# =============================================================================

@dataclass(frozen=True)
class Spacing:
    """Consistent spacing values"""
    
    XS: int = 4
    SM: int = 8
    MD: int = 12
    LG: int = 16
    XL: int = 20
    XXL: int = 24
    XXXL: int = 32
    
    # Common padding tuples
    CARD: Tuple[int, int] = (16, 12)
    SECTION: Tuple[int, int] = (20, 15)
    DIALOG: Tuple[int, int] = (20, 20)


SPACING = Spacing()


# =============================================================================
# COMPONENT SIZES
# =============================================================================

@dataclass(frozen=True)
class Sizes:
    """Standard component sizes"""
    
    # Buttons
    BUTTON_HEIGHT_SM: int = 28
    BUTTON_HEIGHT_MD: int = 32
    BUTTON_HEIGHT_LG: int = 36
    
    # Inputs
    INPUT_HEIGHT: int = 32
    INPUT_HEIGHT_SM: int = 28
    
    # Corner radius
    RADIUS_SM: int = 4
    RADIUS_MD: int = 6
    RADIUS_LG: int = 8
    RADIUS_XL: int = 10
    
    # Window
    SIDEBAR_WIDTH: int = 230
    TOP_SPACER: int = 40
    
    # Table row height
    TABLE_ROW_HEIGHT: int = 24


SIZES = Sizes()


# =============================================================================
# PERFORMANCE SETTINGS
# =============================================================================

@dataclass
class PerformanceConfig:
    """Performance optimization settings"""
    
    # Pagination
    DEFAULT_PAGE_SIZE: int = 100
    MAX_PAGE_SIZE: int = 500
    
    # Lazy loading
    LAZY_LOAD_THRESHOLD: int = 50
    
    # Caching
    CACHE_ENABLED: bool = True
    CACHE_TTL_SECONDS: int = 300  # 5 minutes
    
    # Database
    DB_QUERY_TIMEOUT: int = 30
    DB_BATCH_SIZE: int = 100
    
    # UI refresh
    UI_DEBOUNCE_MS: int = 150
    SEARCH_DEBOUNCE_MS: int = 300
    
    # Virtual scrolling
    VIRTUAL_SCROLL_ENABLED: bool = True
    VIRTUAL_SCROLL_BUFFER: int = 20


PERFORMANCE = PerformanceConfig()


# =============================================================================
# DATA CACHE
# =============================================================================

class DataCache:
    """Simple in-memory cache for frequently accessed data"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._cache = {}
            cls._instance._timestamps = {}
        return cls._instance
    
    def get(self, key: str, default=None):
        """Get cached value if not expired"""
        import time
        if key in self._cache:
            if time.time() - self._timestamps.get(key, 0) < PERFORMANCE.CACHE_TTL_SECONDS:
                return self._cache[key]
            else:
                del self._cache[key]
                del self._timestamps[key]
        return default
    
    def set(self, key: str, value):
        """Set cached value"""
        import time
        self._cache[key] = value
        self._timestamps[key] = time.time()
    
    def clear(self, key: str = None):
        """Clear cache entry or all cache"""
        if key:
            self._cache.pop(key, None)
            self._timestamps.pop(key, None)
        else:
            self._cache.clear()
            self._timestamps.clear()
    
    def get_or_fetch(self, key: str, fetch_func, *args, **kwargs):
        """Get from cache or fetch and cache"""
        value = self.get(key)
        if value is None:
            value = fetch_func(*args, **kwargs)
            if value is not None:
                self.set(key, value)
        return value


# Global cache instance
cache = DataCache()


# =============================================================================
# CONSTANTS
# =============================================================================

# Transport modes
TRANSPORT_MODES = ["OCEAN", "AIR", "LAND"]

# Job statuses
JOB_STATUSES = ["OPEN", "IN TRANSIT", "ARRIVED", "DELIVERED", "CLOSED", "CANCELLED"]

# Quote statuses
QUOTE_STATUSES = ["DRAFT", "SENT", "ACCEPTED", "REJECTED", "EXPIRED"]

# Currencies
CURRENCIES = ["USD", "MXN", "EUR"]

# Units
UNITS = ["EA", "SET", "LOT", "CBM", "KG", "LB", "M3", "TEU", "CTN", "PKG"]

# Container types
CONTAINER_TYPES = ["20'", "40'", "40'HC", "45'HC", "20'RF", "40'RF", "20'OT", "40'OT", "20'FR", "40'FR"]

# Incoterms
INCOTERMS = ["EXW", "FCA", "FAS", "FOB", "CFR", "CIF", "CPT", "CIP", "DAP", "DPU", "DDP"]


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_font(style: str = "body") -> Tuple:
    """Get font tuple by style name"""
    styles = {
        "title": FONTS.TITLE,
        "header": FONTS.HEADER,
        "subheader": FONTS.SUBHEADER,
        "body": FONTS.BODY,
        "small": FONTS.SMALL,
        "label": FONTS.LABEL,
        "button": FONTS.BUTTON,
    }
    return styles.get(style, FONTS.BODY)


def get_status_color(status: str) -> str:
    """Get color for status"""
    status_colors = {
        "OPEN": COLORS.STATUS_OPEN,
        "IN TRANSIT": COLORS.STATUS_TRANSIT,
        "ARRIVED": COLORS.STATUS_ARRIVED,
        "DELIVERED": COLORS.STATUS_DELIVERED,
        "CLOSED": COLORS.STATUS_CLOSED,
        "CANCELLED": COLORS.ERROR,
        "DRAFT": COLORS.TEXT_SECONDARY,
        "SENT": COLORS.INFO,
        "ACCEPTED": COLORS.SUCCESS,
        "REJECTED": COLORS.ERROR,
        "EXPIRED": COLORS.TEXT_TERTIARY,
    }
    return status_colors.get(status, COLORS.TEXT_SECONDARY)


def apply_button_style(button, style: str = "primary"):
    """Apply consistent button styling"""
    styles = {
        "primary": {"fg_color": COLORS.PRIMARY, "hover_color": COLORS.PRIMARY_DARK},
        "secondary": {"fg_color": COLORS.SECONDARY, "hover_color": COLORS.SECONDARY_DARK},
        "success": {"fg_color": COLORS.SUCCESS, "hover_color": COLORS.SUCCESS_DARK},
        "warning": {"fg_color": COLORS.WARNING, "hover_color": COLORS.WARNING_DARK},
        "danger": {"fg_color": COLORS.ERROR, "hover_color": COLORS.ERROR_DARK},
        "ghost": {"fg_color": "transparent", "hover_color": COLORS.BORDER_LIGHT, "text_color": COLORS.TEXT_PRIMARY},
    }
    if style in styles:
        button.configure(**styles[style])
