# ui_design.py
# Unified UI Design System for DURUDURU
# Single source of truth for all UI styling

"""
DURUDURU Design System
======================
Consistent colors, typography, spacing, and components.
Inspired by Apple Human Interface Guidelines & Linear.
"""

import customtkinter as ctk
from tkinter import ttk
import tkinter as tk
from typing import Dict, Optional, Callable, Any
from dataclasses import dataclass, field


# =============================================================================
# COLOR PALETTE - WARM MINIMALIST
# =============================================================================

@dataclass
class ColorPalette:
    """Warm minimalist color palette - macOS inspired"""
    
    # Primary Brand Colors - Muted Teal
    primary: str = "#374151"          # Muted teal blue
    primary_dark: str = "#3A7A8E"
    primary_light: str = "#E8F4F8"
    
    # Semantic Colors - Warm versions
    success: str = "#059669"          # Soft green
    success_dark: str = "#5AB868"
    warning: str = "#FFD93D"          # Warm amber
    warning_dark: str = "#E8C52D"
    error: str = "#DC2626"            # Soft coral
    error_dark: str = "#E85A5A"
    info: str = "#4ECDC4"             # Teal
    
    # Business Colors - Warm
    revenue: str = "#059669"          # Soft green for income
    cost: str = "#DC2626"             # Coral for expenses
    profit: str = "#374151"           # Teal for profit
    
    # Neutral Colors - Warm tones
    white: str = "#FFFFFF"
    background: str = "#FAFAFA"       # Warm off-white
    surface: str = "#FFFFFF"
    surface_alt: str = "#FFFCF9"      # Warm white
    
    # Text Colors - Warm dark gray
    text_primary: str = "#2D3436"     # Warm dark (not pure black)
    text_secondary: str = "#636E72"   # Medium gray
    text_tertiary: str = "#A0A8AB"
    text_inverse: str = "#FFFFFF"
    
    # Border Colors - Warm
    border: str = "#E8E4E0"
    border_light: str = "#F0EBE6"
    border_focus: str = "#374151"
    
    # Status Colors - Warm palette
    status_open: str = "#059669"
    status_transit: str = "#D97706"
    status_arrived: str = "#4ECDC4"
    status_delivered: str = "#374151"
    status_closed: str = "#A0A8AB"
    status_cancelled: str = "#DC2626"


# Global color instance
COLORS = ColorPalette()


# =============================================================================
# TYPOGRAPHY
# =============================================================================

@dataclass
class Typography:
    """Typography system"""
    
    # Font families
    font_family: str = "SF Pro Display"
    font_family_mono: str = "SF Mono"
    
    # Font sizes
    size_xs: int = 10
    size_sm: int = 12
    size_base: int = 14
    size_lg: int = 16
    size_xl: int = 18
    size_2xl: int = 22
    size_3xl: int = 28
    size_4xl: int = 36
    
    # Font weights
    weight_normal: str = "normal"
    weight_medium: str = "bold"  # CTk doesn't support medium
    weight_bold: str = "bold"
    
    def get_font(self, size: str = "base", weight: str = "normal") -> tuple:
        """Get font tuple for tkinter"""
        sizes = {
            "xs": self.size_xs,
            "sm": self.size_sm,
            "base": self.size_base,
            "lg": self.size_lg,
            "xl": self.size_xl,
            "2xl": self.size_2xl,
            "3xl": self.size_3xl,
            "4xl": self.size_4xl,
        }
        weights = {
            "normal": "",
            "medium": "bold",
            "bold": "bold",
        }
        
        font_size = sizes.get(size, self.size_base)
        font_weight = weights.get(weight, "")
        
        if font_weight:
            return (self.font_family, font_size, font_weight)
        return (self.font_family, font_size)


# Global typography instance
TYPOGRAPHY = Typography()


# =============================================================================
# SPACING
# =============================================================================

@dataclass
class Spacing:
    """Spacing system (in pixels)"""
    
    xs: int = 4
    sm: int = 8
    md: int = 12
    lg: int = 16
    xl: int = 24
    xxl: int = 32
    xxxl: int = 48
    
    # Component-specific
    button_padding_x: int = 16
    button_padding_y: int = 8
    card_padding: int = 16
    input_padding: int = 12
    section_gap: int = 24
    
    # Border radius
    radius_sm: int = 4
    radius_md: int = 8
    radius_lg: int = 12
    radius_xl: int = 16
    radius_full: int = 9999


# Global spacing instance
SPACING = Spacing()


# =============================================================================
# ICONS (Unicode/Emoji)
# =============================================================================

class Icons:
    """Icon constants using emoji/unicode"""
    
    # Navigation
    HOME = "🏠"
    BACK = "←"
    FORWARD = "→"
    MENU = "☰"
    SEARCH = "🔍"
    SETTINGS = "⚙️"
    
    # Actions
    ADD = "+"
    REMOVE = "−"
    EDIT = "✏️"
    DELETE = "🗑️"
    SAVE = "💾"
    REFRESH = "🔄"
    EXPORT = "📤"
    IMPORT = "📥"
    PRINT = "🖨️"
    
    # Status
    SUCCESS = "✓"
    ERROR = "✗"
    WARNING = "⚠️"
    INFO = "ℹ️"
    PENDING = "⏳"
    
    # Business
    INVOICE = "📄"
    PAYMENT = "💳"
    REVENUE = "📈"
    COST = "📉"
    PROFIT = "💰"
    CUSTOMER = "👤"
    COMPANY = "🏢"
    
    # Transport
    SHIP = "🚢"
    PLANE = "✈️"
    TRUCK = "🚚"
    CONTAINER = "📦"
    
    # Misc
    CALENDAR = "📅"
    CLOCK = "🕐"
    LOCATION = "📍"
    PHONE = "📞"
    EMAIL = "📧"
    DOCUMENT = "📋"
    FOLDER = "📁"
    LOCK = "🔒"
    UNLOCK = "🔓"


# =============================================================================
# COMPONENT STYLES
# =============================================================================

class ComponentStyles:
    """Pre-defined component styles"""
    
    @staticmethod
    def button_primary() -> Dict:
        return {
            "fg_color": COLORS.primary,
            "hover_color": COLORS.primary_dark,
            "text_color": COLORS.white,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base", "medium"),
        }
    
    @staticmethod
    def button_secondary() -> Dict:
        return {
            "fg_color": COLORS.surface,
            "hover_color": COLORS.background,
            "text_color": COLORS.text_primary,
            "border_width": 1,
            "border_color": COLORS.border,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base"),
        }
    
    @staticmethod
    def button_success() -> Dict:
        return {
            "fg_color": COLORS.success,
            "hover_color": COLORS.success_dark,
            "text_color": COLORS.white,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base", "medium"),
        }
    
    @staticmethod
    def button_danger() -> Dict:
        return {
            "fg_color": COLORS.error,
            "hover_color": COLORS.error_dark,
            "text_color": COLORS.white,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base", "medium"),
        }
    
    @staticmethod
    def button_warning() -> Dict:
        return {
            "fg_color": COLORS.warning,
            "hover_color": COLORS.warning_dark,
            "text_color": COLORS.white,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base", "medium"),
        }
    
    @staticmethod
    def button_ghost() -> Dict:
        return {
            "fg_color": "transparent",
            "hover_color": COLORS.background,
            "text_color": COLORS.text_primary,
            "corner_radius": SPACING.radius_md,
            "font": TYPOGRAPHY.get_font("base"),
        }
    
    @staticmethod
    def card() -> Dict:
        return {
            "fg_color": COLORS.surface,
            "corner_radius": SPACING.radius_lg,
            "border_width": 1,
            "border_color": COLORS.border_light,
        }
    
    @staticmethod
    def input() -> Dict:
        return {
            "fg_color": COLORS.surface,
            "border_color": COLORS.border,
            "border_width": 1,
            "corner_radius": SPACING.radius_md,
            "text_color": COLORS.text_primary,
            "placeholder_text_color": COLORS.text_tertiary,
            "font": TYPOGRAPHY.get_font("base"),
        }
    
    @staticmethod
    def label_primary() -> Dict:
        return {
            "text_color": COLORS.text_primary,
            "font": TYPOGRAPHY.get_font("base"),
        }
    
    @staticmethod
    def label_secondary() -> Dict:
        return {
            "text_color": COLORS.text_secondary,
            "font": TYPOGRAPHY.get_font("sm"),
        }
    
    @staticmethod
    def label_title() -> Dict:
        return {
            "text_color": COLORS.text_primary,
            "font": TYPOGRAPHY.get_font("2xl", "bold"),
        }
    
    @staticmethod
    def label_subtitle() -> Dict:
        return {
            "text_color": COLORS.text_secondary,
            "font": TYPOGRAPHY.get_font("lg"),
        }


# =============================================================================
# TTK STYLE CONFIGURATION
# =============================================================================

def configure_ttk_styles():
    """Configure ttk widget styles for consistency"""
    style = ttk.Style()
    
    # Use clam theme as base (works well across platforms)
    style.theme_use('clam')
    
    # Treeview styling
    style.configure(
        "Treeview",
        background=COLORS.surface,
        foreground=COLORS.text_primary,
        fieldbackground=COLORS.surface,
        rowheight=32,
        font=TYPOGRAPHY.get_font("base"),
    )
    
    style.configure(
        "Treeview.Heading",
        background=COLORS.background,
        foreground=COLORS.text_primary,
        font=TYPOGRAPHY.get_font("sm", "bold"),
        padding=(8, 8),
    )
    
    style.map(
        "Treeview",
        background=[("selected", COLORS.primary_light)],
        foreground=[("selected", COLORS.white)],
    )
    
    # Combobox styling
    style.configure(
        "TCombobox",
        fieldbackground=COLORS.surface,
        background=COLORS.surface,
        foreground=COLORS.text_primary,
        padding=8,
        font=TYPOGRAPHY.get_font("base"),
    )
    
    # Entry styling
    style.configure(
        "TEntry",
        fieldbackground=COLORS.surface,
        foreground=COLORS.text_primary,
        padding=8,
        font=TYPOGRAPHY.get_font("base"),
    )
    
    # Scrollbar styling
    style.configure(
        "TScrollbar",
        background=COLORS.background,
        troughcolor=COLORS.surface,
        borderwidth=0,
        arrowsize=14,
    )
    
    # Notebook (tab) styling
    style.configure(
        "TNotebook",
        background=COLORS.background,
        tabmargins=[2, 5, 2, 0],
    )
    
    style.configure(
        "TNotebook.Tab",
        background=COLORS.surface,
        foreground=COLORS.text_primary,
        padding=[16, 8],
        font=TYPOGRAPHY.get_font("base"),
    )
    
    style.map(
        "TNotebook.Tab",
        background=[("selected", COLORS.primary)],
        foreground=[("selected", COLORS.white)],
    )
    
    return style


# =============================================================================
# STYLED COMPONENTS
# =============================================================================

class StyledButton(ctk.CTkButton):
    """Pre-styled button with variants"""
    
    VARIANTS = {
        "primary": ComponentStyles.button_primary,
        "secondary": ComponentStyles.button_secondary,
        "success": ComponentStyles.button_success,
        "danger": ComponentStyles.button_danger,
        "warning": ComponentStyles.button_warning,
        "ghost": ComponentStyles.button_ghost,
    }
    
    def __init__(self, master, variant: str = "primary", **kwargs):
        style = self.VARIANTS.get(variant, self.VARIANTS["primary"])()
        
        # Merge default style with custom kwargs
        for key, value in style.items():
            kwargs.setdefault(key, value)
        
        # Default sizing
        kwargs.setdefault("height", 36)
        kwargs.setdefault("width", 100)
        
        super().__init__(master, **kwargs)


class StyledEntry(ctk.CTkEntry):
    """Pre-styled entry field"""
    
    def __init__(self, master, **kwargs):
        style = ComponentStyles.input()
        
        for key, value in style.items():
            kwargs.setdefault(key, value)
        
        kwargs.setdefault("height", 36)
        kwargs.setdefault("width", 200)
        
        super().__init__(master, **kwargs)


class StyledLabel(ctk.CTkLabel):
    """Pre-styled label with variants"""
    
    VARIANTS = {
        "primary": ComponentStyles.label_primary,
        "secondary": ComponentStyles.label_secondary,
        "title": ComponentStyles.label_title,
        "subtitle": ComponentStyles.label_subtitle,
    }
    
    def __init__(self, master, variant: str = "primary", **kwargs):
        style = self.VARIANTS.get(variant, self.VARIANTS["primary"])()
        
        for key, value in style.items():
            kwargs.setdefault(key, value)
        
        super().__init__(master, **kwargs)


class StyledCard(ctk.CTkFrame):
    """Pre-styled card/panel"""
    
    def __init__(self, master, **kwargs):
        style = ComponentStyles.card()
        
        for key, value in style.items():
            kwargs.setdefault(key, value)
        
        super().__init__(master, **kwargs)


class StatusBadge(ctk.CTkLabel):
    """Status badge with color based on status"""
    
    STATUS_COLORS = {
        "OPEN": COLORS.status_open,
        "IN TRANSIT": COLORS.status_transit,
        "ARRIVED": COLORS.status_arrived,
        "DELIVERED": COLORS.status_delivered,
        "CLOSED": COLORS.status_closed,
        "CANCELLED": COLORS.status_cancelled,
        "PENDING": COLORS.warning,
        "PAID": COLORS.success,
        "OVERDUE": COLORS.error,
    }
    
    def __init__(self, master, status: str, **kwargs):
        color = self.STATUS_COLORS.get(status.upper(), COLORS.text_secondary)
        
        kwargs.setdefault("fg_color", color)
        kwargs.setdefault("text_color", COLORS.white)
        kwargs.setdefault("corner_radius", SPACING.radius_sm)
        kwargs.setdefault("font", TYPOGRAPHY.get_font("xs", "medium"))
        kwargs.setdefault("text", status)
        kwargs.setdefault("width", 80)
        kwargs.setdefault("height", 24)
        
        super().__init__(master, **kwargs)


class AmountLabel(ctk.CTkLabel):
    """Amount label with color based on value"""
    
    def __init__(self, master, amount: float, currency: str = "USD", 
                 show_sign: bool = False, **kwargs):
        # Determine color
        if amount > 0:
            color = COLORS.revenue
        elif amount < 0:
            color = COLORS.cost
        else:
            color = COLORS.text_primary
        
        # Format amount
        sign = ""
        if show_sign and amount > 0:
            sign = "+"
        
        if currency == "MXN":
            text = f"{sign}${amount:,.2f} MXN"
        else:
            text = f"{sign}${amount:,.2f}"
        
        kwargs.setdefault("text_color", color)
        kwargs.setdefault("font", TYPOGRAPHY.get_font("base", "bold"))
        kwargs.setdefault("text", text)
        
        super().__init__(master, **kwargs)


# =============================================================================
# PAGE HEADER COMPONENT
# =============================================================================

class PageHeader(ctk.CTkFrame):
    """Consistent page header component"""
    
    def __init__(self, master, title: str, subtitle: str = None,
                 icon: str = None, actions: list = None, **kwargs):
        kwargs.setdefault("fg_color", "transparent")
        super().__init__(master, **kwargs)
        
        # Left side: icon + title
        left = ctk.CTkFrame(self, fg_color="transparent")
        left.pack(side="left", fill="y")
        
        title_text = f"{icon} {title}" if icon else title
        StyledLabel(left, variant="title", text=title_text).pack(anchor="w")
        
        if subtitle:
            StyledLabel(left, variant="secondary", text=subtitle).pack(anchor="w")
        
        # Right side: action buttons
        if actions:
            right = ctk.CTkFrame(self, fg_color="transparent")
            right.pack(side="right", fill="y")
            
            for action in actions:
                btn = StyledButton(
                    right,
                    variant=action.get("variant", "secondary"),
                    text=action.get("text", ""),
                    width=action.get("width", 100),
                    command=action.get("command"),
                )
                btn.pack(side="left", padx=SPACING.sm)


# =============================================================================
# TOOLBAR COMPONENT
# =============================================================================

class Toolbar(ctk.CTkFrame):
    """Consistent toolbar component"""
    
    def __init__(self, master, **kwargs):
        kwargs.setdefault("fg_color", COLORS.background)
        kwargs.setdefault("corner_radius", SPACING.radius_lg)
        super().__init__(master, **kwargs)
        
        # Internal padding
        self._inner = ctk.CTkFrame(self, fg_color="transparent")
        self._inner.pack(fill="both", expand=True, padx=SPACING.md, pady=SPACING.sm)
    
    def add_button(self, text: str, variant: str = "secondary", 
                   icon: str = None, command: Callable = None, **kwargs) -> StyledButton:
        """Add button to toolbar"""
        display_text = f"{icon} {text}" if icon else text
        btn = StyledButton(
            self._inner,
            variant=variant,
            text=display_text,
            command=command,
            **kwargs
        )
        btn.pack(side="left", padx=SPACING.xs)
        return btn
    
    def add_separator(self):
        """Add vertical separator"""
        sep = ctk.CTkFrame(
            self._inner,
            width=1,
            height=30,
            fg_color=COLORS.border
        )
        sep.pack(side="left", padx=SPACING.md)
    
    def add_spacer(self):
        """Add flexible spacer"""
        spacer = ctk.CTkFrame(self._inner, fg_color="transparent")
        spacer.pack(side="left", fill="x", expand=True)
    
    def add_search(self, placeholder: str = "Search...", 
                   command: Callable = None, **kwargs) -> StyledEntry:
        """Add search entry"""
        entry = StyledEntry(
            self._inner,
            placeholder_text=placeholder,
            width=kwargs.get("width", 200),
        )
        entry.pack(side="left", padx=SPACING.xs)
        
        if command:
            entry.bind("<Return>", lambda e: command())
        
        return entry


# =============================================================================
# INITIALIZATION
# =============================================================================

def initialize_ui():
    """Initialize UI design system"""
    # Set CTk appearance
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    
    # Configure ttk styles
    configure_ttk_styles()
    
    return True


# =============================================================================
# EXPORTS
# =============================================================================

# Design System Tokens (Simplified for quick access)
class DS:
    """Design System Tokens - Single Source of Truth"""
    # Colors
    PRIMARY = "#007AFF"
    PRIMARY_HOVER = "#0056B3"
    SUCCESS = "#34C759"
    WARNING = "#FF9500"
    ERROR = "#FF3B30"
    INFO = "#5856D6"
    
    BG = "#F5F5F7"
    SURFACE = "#FFFFFF"
    BORDER = "#E5E5EA"
    
    TEXT = "#1D1D1F"
    TEXT_SECONDARY = "#86868B"
    TEXT_MUTED = "#AEAEB2"
    
    # Typography
    FONT = "SF Pro Display"
    FONT_XS, FONT_SM, FONT_BASE, FONT_LG, FONT_XL = 10, 12, 13, 15, 18
    
    # Spacing (8px grid)
    SP_XS, SP_SM, SP_MD, SP_LG, SP_XL = 4, 8, 12, 16, 24
    
    # Components
    BTN_H = 32
    INPUT_H = 32
    RADIUS = 8


class EditableTreeview(ttk.Treeview):
    """Treeview with inline editing - No popup dialogs"""
    
    def __init__(self, parent, columns, on_edit=None, **kwargs):
        super().__init__(parent, columns=columns, show="headings", **kwargs)
        self.on_edit = on_edit
        self._entry = None
        self._editing_item = None
        self._editing_col = None
        self.bind("<Double-1>", self._on_double_click)
        self.bind("<Escape>", self._cancel_edit)
    
    def _on_double_click(self, event):
        region = self.identify_region(event.x, event.y)
        if region != "cell":
            return
        
        col = self.identify_column(event.x)
        item = self.identify_row(event.y)
        if not item or not col:
            return
        
        col_idx = int(col[1:]) - 1
        bbox = self.bbox(item, col)
        if not bbox:
            return
        
        x, y, w, h = bbox
        values = list(self.item(item, "values"))
        current = str(values[col_idx] if col_idx < len(values) else "").replace("$", "").replace(",", "")
        
        self._cancel_edit(None)
        self._entry = tk.Entry(self, font=(DS.FONT, DS.FONT_SM))
        self._entry.place(x=x, y=y, width=w, height=h)
        self._entry.insert(0, current)
        self._entry.select_range(0, tk.END)
        self._entry.focus_set()
        self._editing_item, self._editing_col = item, col_idx
        self._entry.bind("<Return>", self._confirm_edit)
        self._entry.bind("<FocusOut>", self._confirm_edit)
        self._entry.bind("<Escape>", self._cancel_edit)
    
    def _confirm_edit(self, event):
        if not self._entry:
            return
        new_value = self._entry.get()
        item, col_idx = self._editing_item, self._editing_col
        values = list(self.item(item, "values"))
        if col_idx < len(values):
            values[col_idx] = new_value
            self.item(item, values=values)
        if self.on_edit:
            self.on_edit(item, col_idx, new_value)
        self._cancel_edit(None)
    
    def _cancel_edit(self, event):
        if self._entry:
            self._entry.destroy()
            self._entry = None
        self._editing_item = self._editing_col = None


__all__ = [
    # Design System
    'DS',
    'EditableTreeview',
    
    # Color & Style
    'COLORS',
    'TYPOGRAPHY', 
    'SPACING',
    'Icons',
    'ComponentStyles',
    
    # Configuration
    'configure_ttk_styles',
    'initialize_ui',
    
    # Components
    'StyledButton',
    'StyledEntry',
    'StyledLabel',
    'StyledCard',
    'StatusBadge',
    'AmountLabel',
    'PageHeader',
    'Toolbar',
]
