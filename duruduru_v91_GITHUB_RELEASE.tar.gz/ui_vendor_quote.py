# ui_vendor_quote.py
# Vendor Quote Management - 실행사 견적 관리
# Unified UI/UX Design v77

import tkinter as tk
from tkinter import ttk, messagebox
import customtkinter as ctk
from datetime import datetime, timedelta
from db import get_connection, now_str

try:
    from i18n import get_font_family
except ImportError:
    def get_font_family(): return "SF Pro Display"

COLORS = {"primary": "#374151", "success": "#059669", "warning": "#F59E0B", "error": "#DC2626", "info": "#3B82F6", "bg": "#F9FAFB", "surface": "#FFFFFF", "vendor": "#1E40AF"}

class VendorQuoteFrame(ctk.CTkFrame):
    def __init__(self, master, width=1100, height=700):
        super().__init__(master, fg_color=COLORS["surface"], width=width, height=height)
        self.font = get_font_family()
        self.current_vq_id = None
        self._ensure_tables()
        self._build_ui()
        self._load_quotes()
    
    def _ensure_tables(self):
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute("""CREATE TABLE IF NOT EXISTS vendor_quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_ref TEXT UNIQUE, vendor_code TEXT, vendor_name TEXT NOT NULL, vendor_type TEXT DEFAULT 'CARRIER', quote_date TEXT, valid_from TEXT, valid_until TEXT, origin_port TEXT, origin_name TEXT, dest_port TEXT, dest_name TEXT, mode TEXT DEFAULT 'OCEAN', transit_time TEXT, currency TEXT DEFAULT 'USD', remarks TEXT, status TEXT DEFAULT 'ACTIVE', created_at TEXT, updated_at TEXT)""")
            cur.execute("""CREATE TABLE IF NOT EXISTS vendor_quote_items (id INTEGER PRIMARY KEY AUTOINCREMENT, vq_id INTEGER, freight_code TEXT, description TEXT, unit TEXT DEFAULT 'CNTR', rate_20gp REAL DEFAULT 0, rate_40gp REAL DEFAULT 0, rate_40hq REAL DEFAULT 0, rate_cbm REAL DEFAULT 0, rate_bl REAL DEFAULT 0, FOREIGN KEY (vq_id) REFERENCES vendor_quotes(id) ON DELETE CASCADE)""")
            conn.commit()
        except Exception as e: print(f"Table error: {e}")
        finally: conn.close()
    
    def _build_ui(self):
        ctk.CTkFrame(self, fg_color="transparent", height=35).pack(fill="x")
        title = ctk.CTkFrame(self, fg_color=COLORS["vendor"], corner_radius=0, height=50)
        title.pack(fill="x"); title.pack_propagate(False)
        ctk.CTkLabel(title, text="📦 VENDOR QUOTES (실행사 견적)", font=(self.font, 18, "bold"), text_color="white").pack(side="left", padx=20)
        bf = ctk.CTkFrame(title, fg_color="transparent"); bf.pack(side="right", padx=15)
        ctk.CTkButton(bf, text="➕ New", width=80, fg_color=COLORS["success"], command=self._new_quote).pack(side="left", padx=3)
        ctk.CTkButton(bf, text="📄 Copy", width=70, fg_color="#6B7280", command=self._duplicate).pack(side="left", padx=3)
        ctk.CTkButton(bf, text="🗑 Del", width=60, fg_color=COLORS["error"], command=self._delete).pack(side="left", padx=3)
        
        main = ctk.CTkFrame(self, fg_color="transparent"); main.pack(fill="both", expand=True, padx=15, pady=10)
        left = ctk.CTkFrame(main, fg_color=COLORS["bg"], width=400, corner_radius=8); left.pack(side="left", fill="y", padx=(0, 10)); left.pack_propagate(False)
        sf = ctk.CTkFrame(left, fg_color="transparent"); sf.pack(fill="x", padx=10, pady=10)
        self.search_var = tk.StringVar()
        ctk.CTkEntry(sf, textvariable=self.search_var, placeholder_text="🔍 Search...", width=300).pack(side="left")
        ctk.CTkButton(sf, text="🔍", width=40, fg_color=COLORS["vendor"], command=self._search).pack(side="right", padx=5)
        
        ff = ctk.CTkFrame(left, fg_color="transparent"); ff.pack(fill="x", padx=10, pady=5)
        self.type_filter = tk.StringVar(value="ALL")
        for vt, lb in [("ALL", "All"), ("CARRIER", "선사"), ("TRUCKER", "트럭"), ("WAREHOUSE", "창고"), ("CUSTOMS", "통관")]:
            ctk.CTkButton(ff, text=lb, width=60, height=26, fg_color=COLORS["vendor"] if vt=="ALL" else "#E5E7EB", text_color="white" if vt=="ALL" else "#374151", command=lambda t=vt: self._filter(t)).pack(side="left", padx=2)
        
        lf = ctk.CTkFrame(left, fg_color=COLORS["surface"], corner_radius=8); lf.pack(fill="both", expand=True, padx=10, pady=10)
        cols = ["ref", "vendor", "route", "valid", "status"]
        self.tree = ttk.Treeview(lf, columns=cols, show="headings", height=20)
        for c, h, w in [("ref", "Ref#", 90), ("vendor", "Vendor", 80), ("route", "FROM→TO", 110), ("valid", "Valid", 70), ("status", "Status", 55)]:
            self.tree.heading(c, text=h); self.tree.column(c, width=w, anchor="center" if c in ["valid", "status"] else "w")
        vsb = ttk.Scrollbar(lf, orient="vertical", command=self.tree.yview); self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True); vsb.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        
        right = ctk.CTkFrame(main, fg_color=COLORS["bg"], corner_radius=8); right.pack(side="right", fill="both", expand=True)
        self._build_detail(right)
    
    def _build_detail(self, parent):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent"); scroll.pack(fill="both", expand=True, padx=15, pady=15)
        
        hdr = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8); hdr.pack(fill="x", pady=(0, 10))
        h_in = ctk.CTkFrame(hdr, fg_color="transparent"); h_in.pack(fill="x", padx=15, pady=12)
        r1 = ctk.CTkFrame(h_in, fg_color="transparent"); r1.pack(fill="x", pady=3)
        ctk.CTkLabel(r1, text="Ref:").pack(side="left"); self.ref_var = tk.StringVar(); ctk.CTkEntry(r1, textvariable=self.ref_var, width=130, state="readonly", fg_color="#F3F4F6").pack(side="left", padx=(5, 15))
        ctk.CTkLabel(r1, text="Date:").pack(side="left"); self.date_var = tk.StringVar(); ctk.CTkEntry(r1, textvariable=self.date_var, width=100).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(r1, text="Status:").pack(side="left"); self.status_var = tk.StringVar(value="ACTIVE"); ttk.Combobox(r1, textvariable=self.status_var, values=["ACTIVE", "EXPIRED", "CANCELLED"], width=10).pack(side="left", padx=5)
        
        r2 = ctk.CTkFrame(h_in, fg_color="transparent"); r2.pack(fill="x", pady=3)
        ctk.CTkLabel(r2, text="Vendor:").pack(side="left"); self.vendor_var = tk.StringVar(); ctk.CTkEntry(r2, textvariable=self.vendor_var, width=200).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(r2, text="Type:").pack(side="left"); self.type_var = tk.StringVar(value="CARRIER"); ttk.Combobox(r2, textvariable=self.type_var, values=["CARRIER", "TRUCKER", "WAREHOUSE", "CUSTOMS", "FORWARDER", "OTHER"], width=12).pack(side="left", padx=5)
        
        r3 = ctk.CTkFrame(h_in, fg_color="transparent"); r3.pack(fill="x", pady=3)
        ctk.CTkLabel(r3, text="Valid From:").pack(side="left"); self.valid_from = tk.StringVar(); ctk.CTkEntry(r3, textvariable=self.valid_from, width=100).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(r3, text="Until:").pack(side="left"); self.valid_until = tk.StringVar(); ctk.CTkEntry(r3, textvariable=self.valid_until, width=100).pack(side="left", padx=(5, 15))
        ctk.CTkLabel(r3, text="Curr:").pack(side="left"); self.currency = tk.StringVar(value="USD"); ttk.Combobox(r3, textvariable=self.currency, values=["USD", "MXN"], width=6).pack(side="left", padx=5)
        
        route = ctk.CTkFrame(scroll, fg_color="#DBEAFE", corner_radius=8); route.pack(fill="x", pady=5)
        rh = ctk.CTkFrame(route, fg_color="transparent"); rh.pack(fill="x", padx=15, pady=(12, 5))
        ctk.CTkLabel(rh, text="🚢 Route", font=(self.font, 12, "bold")).pack(side="left")
        self.mode = tk.StringVar(value="OCEAN"); ttk.Combobox(rh, textvariable=self.mode, values=["OCEAN", "AIR", "TRUCK", "RAIL"], width=10).pack(side="right")
        ctk.CTkLabel(rh, text="Mode:").pack(side="right", padx=5)
        
        r_in = ctk.CTkFrame(route, fg_color="transparent"); r_in.pack(fill="x", padx=15, pady=(0, 12))
        fr = ctk.CTkFrame(r_in, fg_color="transparent"); fr.pack(fill="x", pady=3)
        ctk.CTkLabel(fr, text="FROM:", font=(self.font, 11, "bold"), width=50).pack(side="left")
        self.origin_code = tk.StringVar(); ctk.CTkEntry(fr, textvariable=self.origin_code, width=80).pack(side="left", padx=5)
        self.origin_name = tk.StringVar(); ctk.CTkEntry(fr, textvariable=self.origin_name, width=250).pack(side="left", padx=5)
        ctk.CTkLabel(r_in, text="▼", font=(self.font, 14), text_color=COLORS["vendor"]).pack(pady=2)
        tr = ctk.CTkFrame(r_in, fg_color="transparent"); tr.pack(fill="x", pady=3)
        ctk.CTkLabel(tr, text="TO:", font=(self.font, 11, "bold"), width=50).pack(side="left")
        self.dest_code = tk.StringVar(); ctk.CTkEntry(tr, textvariable=self.dest_code, width=80).pack(side="left", padx=5)
        self.dest_name = tk.StringVar(); ctk.CTkEntry(tr, textvariable=self.dest_name, width=250).pack(side="left", padx=5)
        tt = ctk.CTkFrame(r_in, fg_color="transparent"); tt.pack(fill="x", pady=5)
        ctk.CTkLabel(tt, text="Transit:").pack(side="left"); self.transit = tk.StringVar(); ctk.CTkEntry(tt, textvariable=self.transit, width=120).pack(side="left", padx=5)
        
        rates = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8); rates.pack(fill="x", pady=5)
        rh2 = ctk.CTkFrame(rates, fg_color="transparent"); rh2.pack(fill="x", padx=15, pady=(12, 8))
        ctk.CTkLabel(rh2, text="💰 Rates", font=(self.font, 12, "bold")).pack(side="left")
        ctk.CTkButton(rh2, text="➕", width=40, height=26, fg_color=COLORS["success"], command=self._add_rate).pack(side="right")
        ctk.CTkButton(rh2, text="➖", width=40, height=26, fg_color=COLORS["error"], command=self._del_rate).pack(side="right", padx=5)
        
        rt_f = ctk.CTkFrame(rates, fg_color="#F9FAFB", corner_radius=4); rt_f.pack(fill="x", padx=15, pady=(0, 12))
        cols = ["id", "code", "desc", "unit", "20gp", "40gp", "40hq", "cbm", "bl"]
        self.rates_tree = ttk.Treeview(rt_f, columns=cols, show="headings", height=7)
        for c, h, w in [("id", "#", 30), ("code", "CODE", 55), ("desc", "DESC", 140), ("unit", "UNIT", 50), ("20gp", "20GP", 60), ("40gp", "40GP", 60), ("40hq", "40HQ", 60), ("cbm", "CBM", 55), ("bl", "B/L", 55)]:
            self.rates_tree.heading(c, text=h); self.rates_tree.column(c, width=w, anchor="center" if c != "desc" else "w")
        self.rates_tree.column("id", width=0, stretch=False); self.rates_tree.pack(fill="x", padx=5, pady=5)
        
        rem = ctk.CTkFrame(scroll, fg_color=COLORS["surface"], corner_radius=8); rem.pack(fill="x", pady=5)
        ctk.CTkLabel(rem, text="📝 Remarks", font=(self.font, 12, "bold")).pack(anchor="w", padx=15, pady=(12, 5))
        self.remarks = ctk.CTkTextbox(rem, height=60); self.remarks.pack(fill="x", padx=15, pady=(0, 12))
        
        act = ctk.CTkFrame(scroll, fg_color="transparent"); act.pack(fill="x", pady=10)
        ctk.CTkButton(act, text="💾 Save", width=100, height=36, fg_color=COLORS["success"], command=self._save).pack(side="right", padx=5)
        ctk.CTkButton(act, text="🔄 Clear", width=80, height=36, fg_color="#6B7280", command=self._clear).pack(side="right", padx=5)
    
    def _load_quotes(self, tf="ALL", s=""):
        for i in self.tree.get_children(): self.tree.delete(i)
        conn = get_connection(); cur = conn.cursor()
        try:
            q = "SELECT id, quote_ref, vendor_name, origin_port, dest_port, valid_until, status FROM vendor_quotes WHERE 1=1"
            p = []
            if tf != "ALL": q += " AND vendor_type=?"; p.append(tf)
            if s: q += " AND (vendor_name LIKE ? OR origin_port LIKE ?)"; p.extend([f"%{s}%"]*2)
            q += " ORDER BY quote_date DESC"
            cur.execute(q, p)
            for r in cur.fetchall(): self.tree.insert("", "end", iid=str(r[0]), values=(r[1], r[2], f"{r[3] or '?'}→{r[4] or '?'}", r[5] or "", r[6]))
        except: pass
        finally: conn.close()
    
    def _search(self): self._load_quotes(self.type_filter.get(), self.search_var.get())
    def _filter(self, t): self.type_filter.set(t); self._load_quotes(t, self.search_var.get())
    def _on_select(self, e):
        s = self.tree.selection()
        if s: self._load_detail(int(s[0]))
    
    def _load_detail(self, vq_id):
        self.current_vq_id = vq_id
        conn = get_connection(); cur = conn.cursor()
        try:
            cur.execute("SELECT quote_ref, vendor_name, vendor_type, quote_date, valid_from, valid_until, origin_port, origin_name, dest_port, dest_name, mode, transit_time, currency, remarks, status FROM vendor_quotes WHERE id=?", (vq_id,))
            r = cur.fetchone()
            if r:
                self.ref_var.set(r[0] or ""); self.vendor_var.set(r[1] or ""); self.type_var.set(r[2] or "CARRIER")
                self.date_var.set(r[3] or ""); self.valid_from.set(r[4] or ""); self.valid_until.set(r[5] or "")
                self.origin_code.set(r[6] or ""); self.origin_name.set(r[7] or ""); self.dest_code.set(r[8] or ""); self.dest_name.set(r[9] or "")
                self.mode.set(r[10] or "OCEAN"); self.transit.set(r[11] or ""); self.currency.set(r[12] or "USD")
                self.remarks.delete("1.0", "end"); self.remarks.insert("1.0", r[13] or ""); self.status_var.set(r[14] or "ACTIVE")
            for i in self.rates_tree.get_children(): self.rates_tree.delete(i)
            cur.execute("SELECT id, freight_code, description, unit, rate_20gp, rate_40gp, rate_40hq, rate_cbm, rate_bl FROM vendor_quote_items WHERE vq_id=?", (vq_id,))
            for r in cur.fetchall():
                def f(v): return f"{v:,.0f}" if v else "-"
                self.rates_tree.insert("", "end", values=(r[0], r[1], r[2], r[3], f(r[4]), f(r[5]), f(r[6]), f(r[7]), f(r[8])))
        except: pass
        finally: conn.close()
    
    def _new_quote(self):
        self.current_vq_id = None
        conn = get_connection(); cur = conn.cursor()
        try:
            ym = datetime.now().strftime("%Y%m"); cur.execute("SELECT COUNT(*) FROM vendor_quotes WHERE quote_ref LIKE ?", (f"VQ-{ym}%",))
            ref = f"VQ-{ym}-{cur.fetchone()[0]+1:04d}"
        except: ref = f"VQ-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        finally: conn.close()
        self._clear(); self.ref_var.set(ref); self.date_var.set(datetime.now().strftime("%Y-%m-%d"))
        self.valid_from.set(datetime.now().strftime("%Y-%m-%d")); self.valid_until.set((datetime.now()+timedelta(days=30)).strftime("%Y-%m-%d"))
    
    def _clear(self):
        self.current_vq_id = None
        for v in [self.ref_var, self.vendor_var, self.date_var, self.valid_from, self.valid_until, self.origin_code, self.origin_name, self.dest_code, self.dest_name, self.transit]: v.set("")
        self.type_var.set("CARRIER"); self.mode.set("OCEAN"); self.currency.set("USD"); self.status_var.set("ACTIVE"); self.remarks.delete("1.0", "end")
        for i in self.rates_tree.get_children(): self.rates_tree.delete(i)
    
    def _save(self):
        if not self.vendor_var.get(): messagebox.showwarning("Required", "Vendor name required"); return
        conn = get_connection(); cur = conn.cursor()
        try:
            rem = self.remarks.get("1.0", "end").strip()
            if self.current_vq_id:
                cur.execute("UPDATE vendor_quotes SET vendor_name=?, vendor_type=?, quote_date=?, valid_from=?, valid_until=?, origin_port=?, origin_name=?, dest_port=?, dest_name=?, mode=?, transit_time=?, currency=?, remarks=?, status=?, updated_at=? WHERE id=?",
                    (self.vendor_var.get(), self.type_var.get(), self.date_var.get(), self.valid_from.get(), self.valid_until.get(), self.origin_code.get(), self.origin_name.get(), self.dest_code.get(), self.dest_name.get(), self.mode.get(), self.transit.get(), self.currency.get(), rem, self.status_var.get(), now_str(), self.current_vq_id))
            else:
                cur.execute("INSERT INTO vendor_quotes (quote_ref, vendor_name, vendor_type, quote_date, valid_from, valid_until, origin_port, origin_name, dest_port, dest_name, mode, transit_time, currency, remarks, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (self.ref_var.get(), self.vendor_var.get(), self.type_var.get(), self.date_var.get(), self.valid_from.get(), self.valid_until.get(), self.origin_code.get(), self.origin_name.get(), self.dest_code.get(), self.dest_name.get(), self.mode.get(), self.transit.get(), self.currency.get(), rem, self.status_var.get(), now_str(), now_str()))
                self.current_vq_id = cur.lastrowid
            self._save_rates(); conn.commit(); self._load_quotes(); messagebox.showinfo("Saved", "Quote saved!")
        except Exception as e: messagebox.showerror("Error", str(e))
        finally: conn.close()
    
    def _save_rates(self):
        if not self.current_vq_id: return
        conn = get_connection(); cur = conn.cursor()
        try:
            cur.execute("DELETE FROM vendor_quote_items WHERE vq_id=?", (self.current_vq_id,))
            for i in self.rates_tree.get_children():
                v = self.rates_tree.item(i, "values")
                def pr(x): return float(str(x).replace(",", "")) if x and x != "-" else 0
                cur.execute("INSERT INTO vendor_quote_items (vq_id, freight_code, description, unit, rate_20gp, rate_40gp, rate_40hq, rate_cbm, rate_bl) VALUES (?,?,?,?,?,?,?,?,?)",
                    (self.current_vq_id, v[1], v[2], v[3], pr(v[4]), pr(v[5]), pr(v[6]), pr(v[7]), pr(v[8])))
            conn.commit()
        except: pass
        finally: conn.close()
    
    def _delete(self):
        s = self.tree.selection()
        if not s: return
        if not messagebox.askyesno("Confirm", "Delete?"): return
        conn = get_connection(); cur = conn.cursor()
        try:
            cur.execute("DELETE FROM vendor_quote_items WHERE vq_id=?", (int(s[0]),))
            cur.execute("DELETE FROM vendor_quotes WHERE id=?", (int(s[0]),))
            conn.commit(); self._clear(); self._load_quotes()
        except: pass
        finally: conn.close()
    
    def _duplicate(self):
        s = self.tree.selection()
        if not s: return
        self._load_detail(int(s[0]))
        conn = get_connection(); cur = conn.cursor()
        try:
            ym = datetime.now().strftime("%Y%m"); cur.execute("SELECT COUNT(*) FROM vendor_quotes WHERE quote_ref LIKE ?", (f"VQ-{ym}%",))
            ref = f"VQ-{ym}-{cur.fetchone()[0]+1:04d}"
        except: ref = f"VQ-COPY"
        finally: conn.close()
        self.current_vq_id = None; self.ref_var.set(ref); self.date_var.set(datetime.now().strftime("%Y-%m-%d"))
    
    def _add_rate(self):
        dlg = ctk.CTkToplevel(self); dlg.title("Add Rate"); dlg.geometry("420x350"); dlg.transient(self); dlg.grab_set()
        f = ctk.CTkFrame(dlg, fg_color="transparent"); f.pack(fill="both", expand=True, padx=20, pady=15)
        ctk.CTkLabel(f, text="Code:").grid(row=0, column=0, sticky="e", pady=5); code = tk.StringVar(); ttk.Combobox(f, textvariable=code, values=["OFR", "AFR", "THC", "DOC", "CFS", "DEL", "BAF", "SEAL"], width=12).grid(row=0, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="Desc:").grid(row=1, column=0, sticky="e", pady=5); desc = tk.StringVar(); ctk.CTkEntry(f, textvariable=desc, width=200).grid(row=1, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="Unit:").grid(row=2, column=0, sticky="e", pady=5); unit = tk.StringVar(value="CNTR"); ttk.Combobox(f, textvariable=unit, values=["CNTR", "B/L", "CBM", "KG"], width=10).grid(row=2, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="20GP:").grid(row=3, column=0, sticky="e", pady=5); r20 = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=r20, width=100).grid(row=3, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="40GP:").grid(row=4, column=0, sticky="e", pady=5); r40 = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=r40, width=100).grid(row=4, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="40HQ:").grid(row=5, column=0, sticky="e", pady=5); r40hq = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=r40hq, width=100).grid(row=5, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="CBM:").grid(row=6, column=0, sticky="e", pady=5); rcbm = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=rcbm, width=100).grid(row=6, column=1, sticky="w", pady=5)
        ctk.CTkLabel(f, text="B/L:").grid(row=7, column=0, sticky="e", pady=5); rbl = tk.StringVar(value="0"); ctk.CTkEntry(f, textvariable=rbl, width=100).grid(row=7, column=1, sticky="w", pady=5)
        def save():
            def fm(v): x = float(v or 0); return f"{x:,.0f}" if x > 0 else "-"
            self.rates_tree.insert("", "end", values=("", code.get(), desc.get(), unit.get(), fm(r20.get()), fm(r40.get()), fm(r40hq.get()), fm(rcbm.get()), fm(rbl.get()))); dlg.destroy()
        bf = ctk.CTkFrame(dlg, fg_color="transparent"); bf.pack(fill="x", padx=20, pady=10)
        ctk.CTkButton(bf, text="Save", width=80, fg_color=COLORS["success"], command=save).pack(side="right", padx=5)
        ctk.CTkButton(bf, text="Cancel", width=80, fg_color="#6B7280", command=dlg.destroy).pack(side="right", padx=5)
    
    def _del_rate(self):
        s = self.rates_tree.selection()
        if s: self.rates_tree.delete(s[0])
